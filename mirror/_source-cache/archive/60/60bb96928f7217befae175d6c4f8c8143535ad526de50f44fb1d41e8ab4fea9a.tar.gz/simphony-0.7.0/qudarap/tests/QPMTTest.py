#!/usr/bin/env python

import os, numpy as np, matplotlib as mp, textwrap
from opticks.ana.fold import Fold
import matplotlib.pyplot as plt
SIZE = np.array([1280, 720])
np.set_printoptions(edgeitems=16)

hc_eVnm = 1239.84198433200208455673

e2w_ = lambda e:hc_eVnm/e
w2e_ = lambda w:hc_eVnm/w

PMTIDX = int(os.environ.get("PMTIDX","0")) # 0-based index into list of lpmtid
SCRIPT = os.environ.get("SCRIPT", "unknown-SCRIPT")

class QPMTTest(object):

    NAMES = "NNVT HAMA NNVTHiQE".split()
    S_NAMES = "SPMT".split()

    def __init__(self, t):
        self.t = t
        self.init_energy_eV_domain()
        self.init_theta_radians_domain()
        self.init_costh_domain()
        self.title_prefix = "%s : %s " % ( SCRIPT, t.base )

    def init_energy_eV_domain(self):
        e = self.t.qscan.energy_eV_domain
        #e0,e1 = 2.3, 3.3
        e0,e1 = 1.55, 4.3
        w0,w1 = e2w_(e0), e2w_(e1)
        ese = np.logical_and( e >= e0, e <= e1 )

        self.e0 = e0
        self.e1 = e1
        self.w0 = w0
        self.w1 = w1
        self.ese = ese

    def init_theta_radians_domain(self):
        h = self.t.qscan.theta_radians_domain
        h0 = h[0]
        h1 = h[-1]
        hse = np.logical_and( h >= h0, h <= h1 )

        self.h0 = h0
        self.h1 = h1
        self.hse = hse

    def init_costh_domain(self):
        c = self.t.qscan.costh_domain
        c0 = c[-1]   ## flip the order as reversed
        c1 = c[0]
        cse = np.logical_and( c >= c0, c <= c1 )

        self.c0 = c0
        self.c1 = c1
        self.cse = cse



    def present_qeshape(self):
        t = self.t
        se = self.ese
        d = t.qscan.energy_eV_domain
        a = t.qscan.pmtcat_qeshape
        if a is None: return

        prop_ni = t.qpmt.qeshape[:,-1,-1].view(np.int32)  ## last values from input prop arrays

        v0,v1 = 0.0,0.38

        assert len(a.shape) == 2, interp.shape

        ni = a.shape[0]  # pmtcat
        nj = a.shape[1]  # energy

        title = "%s : qeshape GPU interpolation lines and values " % self.title_prefix

        fig, axs = mp.pyplot.subplots(1, ni, figsize=SIZE/100.)
        fig.suptitle(title)

        for i in range(ni):
            ax = axs[i]
            ax.set_ylim( v0, v1 )
            v = a[i]
            name = self.NAMES[i]
            label = "%s qeshape" % name
            ax.set_xlabel("energy [eV]")
            ax.plot( d[se], v[se], label=label )
            ax.legend(loc=os.environ.get("LOC", "upper left")) # upper/center/lower right/left

            p_e = t.qpmt.qeshape[i,:prop_ni[i],0]
            p_v = t.qpmt.qeshape[i,:prop_ni[i],1]
            p_s = np.logical_and( p_e >= self.e0, p_e <= self.e1 )

            ax.scatter( p_e[p_s], p_v[p_s] )
        pass
        fig.show()


    def present_s_qeshape(self):
        t = self.t
        se = self.ese
        d = t.qscan.energy_eV_domain
        a = t.qscan.pmtcat_s_qeshape
        if a is None: return

        prop_ni = t.qpmt.s_qeshape[:,-1,-1].view(np.int32)  ## last values from input prop arrays

        v0,v1 = 0.0,0.30

        assert len(a.shape) == 2, interp.shape

        ni = a.shape[0]  # pmtcat
        nj = a.shape[1]  # energy

        assert(ni == 1)

        title = "%s : s_qeshape GPU interpolation lines and values " % self.title_prefix

        fig, axs = mp.pyplot.subplots(1, ni, figsize=SIZE/100.)
        fig.suptitle(title)

        for i in range(ni):
            ax = axs[i] if ni > 1 else axs
            ax.set_ylim( v0, v1 )
            v = a[i]
            name = self.S_NAMES[i]
            label = "%s s_qeshape" % name
            ax.set_xlabel("energy [eV]")
            ax.plot( d[se], v[se], label=label )
            ax.legend(loc=os.environ.get("LOC", "upper left")) # upper/center/lower right/left

            p_e = t.qpmt.s_qeshape[i,:prop_ni[i],0]
            p_v = t.qpmt.s_qeshape[i,:prop_ni[i],1]
            p_s = np.logical_and( p_e >= self.e0, p_e <= self.e1 )

            ax.scatter( p_e[p_s], p_v[p_s] )
        pass
        fig.show()






    def present_cetheta(self):
        t = self.t
        se = self.hse
        d = t.qscan.theta_radians_domain
        a = t.qscan.pmtcat_cetheta
        if a is None: return

        prop_ni = t.qpmt.cetheta[:,-1,-1].view(np.int32)  ## last values from input prop arrays

        v0,v1 = 0.0,1.1

        assert len(a.shape) == 2, interp.shape

        ni = a.shape[0]  # pmtcat
        nj = a.shape[1]  # theta

        title = "%s : cetheta GPU interpolation lines and values " % self.title_prefix

        fig, axs = mp.pyplot.subplots(1, ni, figsize=SIZE/100.)
        fig.suptitle(title)

        for i in range(ni):
            ax = axs[i]
            ax.set_ylim( v0, v1 )
            v = a[i]
            name = self.NAMES[i]
            label = "%s cetheta" % name
            ax.set_xlabel("theta [radians]")
            ax.plot( d[se], v[se], label=label )
            ax.legend(loc=os.environ.get("LOC", "upper left")) # upper/center/lower right/left

            ## input (domain,value) pairs used by the interpolation
            p_d = t.qpmt.cetheta[i,:prop_ni[i],0]
            p_v = t.qpmt.cetheta[i,:prop_ni[i],1]
            p_s = np.logical_and( p_d >= self.h0, p_d <= self.h1 )

            ax.scatter( p_d[p_s], p_v[p_s] )
        pass
        fig.show()


    def present_cecosth(self):
        t = self.t
        se = self.cse
        d = t.qscan.costh_domain
        a = t.qscan.pmtcat_cecosth
        if a is None: return

        prop_ni = t.qpmt.cecosth[:,-1,-1].view(np.int32)  ## last values from input prop arrays

        v0,v1 = 0.0,1.1

        assert len(a.shape) == 2, interp.shape

        ni = a.shape[0]  # pmtcat
        nj = a.shape[1]  # theta

        title = "%s : cecosth GPU interpolation lines and values " % self.title_prefix

        fig, axs = mp.pyplot.subplots(1, ni, figsize=SIZE/100.)
        fig.suptitle(title)

        for i in range(ni):
            ax = axs[i]
            ax.set_ylim( v0, v1 )
            v = a[i]
            name = self.NAMES[i]
            label = "%s cecosth" % name
            ax.set_xlabel("cosine_theta")
            ax.plot( d[se], v[se], label=label )
            ax.legend(loc=os.environ.get("LOC", "upper left")) # upper/center/lower right/left

            ## input (domain,value) pairs used by the interpolation
            p_d = t.qpmt.cecosth[i,:prop_ni[i],0]
            p_v = t.qpmt.cecosth[i,:prop_ni[i],1]
            p_s = np.logical_and( p_d >= self.c0, p_d <= self.c1 )

            ax.scatter( p_d[p_s], p_v[p_s] )
        pass
        fig.show()


    def present_rindex(self):
        t = self.t

        a = t.qscan.pmtcat_rindex
        if a is None: return
        assert len(a.shape) == 4, a.shape

        se = self.se
        e = t.qscan.energy_eV_domain

        prop_ni = t.qpmt.rindex[:,-1,-1].view(np.int32)
        v0,v1 = -0.1,3.2

        ni = a.shape[0]  # pmtcat
        nj = a.shape[1]  # layers
        nk = a.shape[2]  # props

        title = "%s : PMT layer refractive index interpolations on GPU  " % self.title_prefix

        fig, axs = mp.pyplot.subplots(1, ni, figsize=SIZE/100.)
        fig.suptitle(title)

        for i in range(ni):

            ax = axs[i]
            ax.set_ylim( v0, v1 )

            name = self.NAMES[i]
            #ax.set_title(name)
            ax.set_xlabel("energy [eV]")

            sax = ax.secondary_xaxis('top', functions=(e2w_, w2e_))
            sax.set_xlabel('%s   wavelength [nm]' % name)
            # secondary_xaxis w2e_ : RuntimeWarning: divide by zero encountered in true_divide

            for j in range(nj):
                if j in [0,3]: continue   # skip layers 0,3 Pyrex,Vacuum
                for k in range(nk):
                    v = a[i,j,k]
                    iprop = i*nj*nk + j*nk + k

                    label = "L%d %sINDEX" % ( j, "R" if k == 0 else "K" )

                    ax.plot( e[se], v[se], label=label )

                    p_ni = prop_ni[iprop]
                    p_e = t.qpmt.rindex[iprop,:p_ni,0]
                    p_v = t.qpmt.rindex[iprop,:p_ni,1]

                    p_s = np.logical_and( p_e >= self.e0, p_e <= self.e1 )
                    ax.scatter( p_e[p_s], p_v[p_s] )
                pass
            pass
            ax.legend(loc=os.environ.get("LOC", "lower right")) # upper/center/lower right/left
        pass
        fig.show()


    def check_lpmtcat(self):
        t = self.t
        p = t.qpmt  # QPMT members
        s = t.qscan # QPMTTest scan results

        expect_lpmtcat = p.src_lcqs[s.lpmtidx,0]
        assert np.all(s.lpmtcat == expect_lpmtcat)


class SPMTID(object):
    """
    t.qscan.s_qescale.shape
    t.qscan.s_qescale

    p.s_qescale[:,0].shape
    p.s_qescale[:,0]

    t.qscan.spmtid.shape
    t.qscan.spmtid

    np.all( t.qscan.s_qescale == p.s_qescale[:,0][t.qscan.spmtid - 20000] )

    """
    @classmethod
    def EXPR(cls):
        return list(map(str.strip,textwrap.dedent(cls.__doc__).split("\n")))

    def __init__(self, t, symbol="sp"):
        self.t = t
        self.symbol = symbol

    def __repr__(self):
        t = self.t
        p = t.qpmt  # QPMT members
        s = t.qscan # QPMTTest scan results

        lines = []
        lines.append("[%s" % self.symbol)
        for expr in self.EXPR():
            lines.append(expr)
            if expr == "" or expr[0] == "#": continue
            lines.append(repr(eval(expr)))
        pass
        lines.append("]%s" % self.symbol)
        return "\n".join(lines)


if __name__ == '__main__':
    t = Fold.Load(symbol="t")
    print(repr(t))
    pt = QPMTTest(t)

    pt.check_lpmtcat()

    sp = SPMTID(t, symbol="sp")
    print(repr(sp))

    p = t.qpmt
    s = t.qscan

    #plot = "rindex"
    #plot = "qeshape"
    #plot = "cetheta"
    #plot = "cecosth"
    plot = "s_qeshape"

    PLOT = os.environ.get("PLOT", plot )
    if PLOT == "rindex":
        pt.present_rindex()
    elif PLOT == "qeshape":
        pt.present_qeshape()
    elif PLOT == "s_qeshape":
        pt.present_s_qeshape()
    elif PLOT == "cetheta":
        pt.present_cetheta()
    elif PLOT == "cecosth":
        pt.present_cecosth()
    else:
        print("PLOT:%s not handled " % PLOT)
    pass


