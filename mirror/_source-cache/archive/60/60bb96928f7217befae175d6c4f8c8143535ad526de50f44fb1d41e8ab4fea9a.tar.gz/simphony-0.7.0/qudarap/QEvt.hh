#pragma once

struct sevent ;
struct quad4 ;
struct sphoton ;
struct salloc ;
struct sslice ;
struct qat4 ;
struct quad6 ;
struct NP ;

struct SEvt ;

struct sphoton_selector ;
struct sphotonlite_selector ;


#include <vector>
#include <string>
#include "plog/Severity.h"
#include "SComp.h"
#include "QUDARAP_API_EXPORT.hh"
#include "NP_future.h"

/**
QEvt.hh
=======

Canonical *event* instanciated within QSim::QSim

Unlike typical CPU side event classes with many instances the QEvt/sevent is rather "static"
and singular with long lived buffers of defined maximum capacity that get reused for each launch.

* Note that CUDA has no realloc for these device buffers.
  Hence decided to define maximum buffer sizes as calculated from max number of photons for each launch
  and arrange that lanches to never exceed those maximums

* hence all GPU buffers can get allocated once at initialization
  with the configured maximum sizes and simply get reused from event to event
  (or more specifically from launch to launch which might not map one-to-one with events)

* this simplifies memory handling as free-ing only needed at termination, so can get away with
  not doing it

* so "resizing" just becomes changing a CPU/GPU side constant eg *num_photons*
* just need to ensure that launches are always arranged to be below the max

* how to decide the maximums ? depends on available VRAM and also should be user configurable
  within some range


QEvt::setGenstep is the primary method for lifecycle understanding
-----------------------------------------------------------------------

When Opticks is integrated with a Geant4 based detector simulation framework
this primary QEvt::setGenstep method is invoked with a stack like the below,
where the upper part depends on details of how Opticks is integrated with the simulation framework::

    "G4VSensitiveDetector::EndOfEvent(G4HCofThisEvent* HCE)" (stub overridded by the below)
    junoSD_PMT_v2::EndOfEvent(G4HCofThisEvent* HCE)
    junoSD_PMT_v2_Opticks::EndOfEvent(G4HCofThisEvent*, int eventID )
    junoSD_PMT_v2_Opticks::EndOfEvent_Simulate(int eventID )
    G4CXOpticks::simulate(int eventID, bool reset_ )
    QSim::simulate(int eventID, bool reset_)
    QEvt::setGenstep


**/



struct QUDARAP_API QEvt : public SCompProvider
{
    friend struct QEvtTest ;
    friend struct QEvt_setInputPhoton_Test ;

    static constexpr const char* QEvt__LIFECYCLE = "QEvt__LIFECYCLE" ;
    static bool LIFECYCLE ;

    static const plog::Severity LEVEL ;
    static QEvt* INSTANCE ;
    static QEvt* Get();
    static const bool SEvt_NPFold_VERBOSE ;
    static std::string Desc();


    sevent* getDevicePtr() const ;

    QEvt();

private:
    void init();
    void init_SEvt();

    // NB members needed on both CPU+GPU or from the QEvt.cu functions
    // should reside inside the sevent.h instance not up here in QEvt.hh

public:
    SEvt*             sev ;
private:
    sphoton_selector*     photon_selector ;
    sphotonlite_selector* photonlite_selector ;

    sevent*           evt ;
    sevent*           d_evt ;
    const NP*         gs ;
    sslice*           gss ;

    NP*               input_photon ;
public:
    int               upload_count ;

    /**
    std::string       meta ;
    Q: IS THIS meta NEEDED ? SEvt HAS meta TOO ?
    A: YES, for now. The metadata gets collected in SEvt::gather_components
       via SCompProvider method QEvt::getMeta (OR SEvt::getMeta)

    A2: Dont need the meta, need the method that access the underlying SEvt.
    **/
public:
    // PRIMARY ACTION OF QEvt : genstep uploading
    //int setGenstep();
    int setGenstepUpload_NP(const NP* gs);
    int setGenstepUpload_NP(const NP* gs,  const sslice* sl );
    unsigned long long get_photon_slot_offset() const ;
    void clear();
private:

    int setGenstepUpload(const quad6* qq0, int num_gs );
    int setGenstepUpload(const quad6* qq0, int gs_start, int gs_stop );
    void device_alloc_genstep_and_seed();
    void setInputPhotonAndUpload();
    void setInputPhotonSimtraceAndUpload();
    void checkInputPhoton() const ;

    //int setGenstep(quad6* gs, unsigned num_gs );
    unsigned count_genstep_photons();
    void     fill_seed_buffer();
    void     count_genstep_photons_and_fill_seed_buffer();

public:
    // who uses these ? TODO: switch to comp based
    bool hasGenstep() const ;
    bool hasSeed() const ;
    bool hasPhoton() const ;
    bool hasPhotonLite() const ;
    bool hasRecord() const ;
    bool hasRec() const ;
    bool hasSeq() const ;
    bool hasPrd() const ;
    bool hasTag() const ;
    bool hasFlat() const ;
    bool hasHit() const ;
    bool hasHitLite() const ;
    bool hasSimtrace() const ;
public:
    static constexpr const char* TYPENAME = "QEvt" ;
    // SCompProvider methods
    std::string getMeta() const ;  // returns underlying (SEvt)sev->meta
    const char* getTypeName() const ;
    NP*      gatherComponent(unsigned comp) const ;
public:
    // [ expedient getters : despite these coming from SEvt
    NP*      getGenstep() const ;
    NP*      getInputPhoton() const ;
    // ]

    NP*      gatherPhoton() const ;
    NP*      gatherPhotonLite() const ;

    NP*      gatherHit() const ;
    NP*      gatherHitLite() const ;
    NP*      gatherHitLiteMerged() const ;
    NP*      gatherHitMerged() const ;


#ifndef PRODUCTION
    NP*      gatherSeed() const ;
    NP*      gatherDomain() const ;
    NP*      gatherGenstepFromDevice() const ;
    void     gatherSimtrace(     NP* t ) const ;
    NP*      gatherSimtrace() const ;
    void     gatherSeq(          NP* seq) const ;
    NP*      gatherSeq() const ;       // seqhis..
    NP*      gatherPrd() const ;
    NP*      gatherFlat() const ;
    NP*      gatherRecord() const ;    // full step records
    NP*      gatherTag() const ;
    NP*      gatherRec() const  ;      // compressed step record
#endif

public:
    void     gatherPhoton(       NP* p ) const ;
    void     gatherPhotonLite(   NP* l ) const ;

private:
    NP*      gatherComponent_(unsigned comp) const ;
    NP*      gatherHit_() const ;
    NP*      gatherHitLite_() const ;
public:

    template<typename T>
    static NP*       PerLaunchMerge(sevent* evt, cudaStream_t stream );

    template<typename T>
    static NP*       FinalMerge(      const NP* hitmerged_or_hitlitemerged, cudaStream_t stream);

    template<typename T>
    static NP_future FinalMerge_async(const NP* hitmerged_or_hitlitemerged, cudaStream_t stream);

public:
    size_t   getNumHit() const ;
    size_t   getNumHitLite() const ;
private:
    void     setNumPhoton(size_t num_photon) ;
    void     setNumSimtrace(size_t num_simtrace) ;
    void     device_alloc_photon();
    void     device_alloc_simtrace();
    static void SetAllocMeta(salloc* alloc, const sevent* evt);
    void     uploadEvt();
public:
    size_t getNumPhoton() const ;
    size_t getNumSimtrace() const ;
public:
    std::string desc() const ;
    std::string desc_alloc() const ;

    void checkEvt() ;  // GPU side

};
