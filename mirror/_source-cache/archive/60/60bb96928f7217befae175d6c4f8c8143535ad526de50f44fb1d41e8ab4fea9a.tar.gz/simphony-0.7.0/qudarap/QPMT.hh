#pragma once
/**
QPMT.hh : projecting PMT properties onto device using qpmt.h
==============================================================

* narrowing (or widening, or copying) inputs to template type done in ctor

* QPMT.hh does not directly depend on any external PMT geometry package.
  The QPMT ctor accepts serialized PMT property arrays prepared by the test helpers.

* QPMT.hh/qpmt.h layout has some similarities to QCerenkov.hh/qcerenkov.h

**/

#include "plog/Severity.h"
#include "NPFold.h"

#include "sproc.h"
#include "qpmt_enum.h"
#include "qpmt.h"
#include "s_pmt.h"
#include "QProp.hh"

#if defined(MOCK_CURAND) || defined(MOCK_CUDA)
#else
#include "QU.hh"
#endif

#include "QUDARAP_API_EXPORT.hh"

template<typename T>
struct QUDARAP_API QPMT
{
    static const plog::Severity LEVEL ;
    static const QPMT<T>*    INSTANCE ;
    static const QPMT<T>*    Get();

    static std::string Desc();

    const char* ExecutableName ;

    const NP* src_rindex ;    // (NUM_PMTCAT, NUM_LAYER, NUM_PROP, NEN, 2:[energy,value] )
    const NP* src_thickness ; // (NUM_PMTCAT, NUM_LAYER, 1:value )
    const NP* src_qeshape ;   // (NUM_PMTCAT, NUM_SAMPLES~44, 2:[energy,value] )
    const NP* src_cetheta ;   // (NUM_PMTCAT, NUM_SAMPLES~9, 2:[theta,value] )
    const NP* src_cecosth ;   // (NUM_PMTCAT, NUM_SAMPLES~9, 2:[costh,value] )
    const NP* src_lcqs ;      // (NUM_LPMT, 2:[cat,qescale])

    const NP* rindex3 ;       // (NUM_PMTCAT*NUM_LAYER*NUM_PROP,  NEN, 2:[energy,value] )
    const NP* rindex ;
    const QProp<T>* rindex_prop ;

    const NP* qeshape ;
    const QProp<T>* qeshape_prop ;

    const NP* cetheta ;
    const QProp<T>* cetheta_prop ;

    const NP* cecosth ;
    const QProp<T>* cecosth_prop ;


    const NP* thickness ;
    const NP* lcqs ;
    const int* i_lcqs ;  // CPU side lpmtid -> lpmtcat 0/1/2


    const NP* src_s_qeshape ;
    const NP* src_s_qescale ;

    const NP* s_qeshape ;
    const QProp<T>* s_qeshape_prop ;

    const NP* s_qescale ;


    qpmt<T>* pmt ;
    qpmt<T>* d_pmt ;

    // .h
    QPMT(const NPFold* pf);

    // .cc
    void init();
    void init_prop();
    void init_thickness();
    void init_lcqs();
    void init_s_qescale();

    // .h
    NPFold* serialize() const ;  // formerly get_fold
    std::string desc() const ;

    // .h : CPU side lookups


    int  get_lpmtcat_from_lpmtidx( int lpmtidx ) const ;
    int  get_lpmtcat_from_lpmtid(  int lpmtid  ) const ;
    int  get_lpmtcat_from_lpmtid(  int* lpmtcat, const int* lpmtid , int num ) const ;

    int  get_lpmtidx_from_lpmtid(  int* lpmtidx, const int* lpmtid , int num ) const ;
    int  get_spmtidx_from_spmtid(  int* spmtidx, const int* spmtid , int num ) const ;

    static NP *MakeArray_pmtcat(int etype, unsigned num_domain);
    static NP *MakeArray_pmtid(int etype, unsigned num_domain, unsigned num_pmtid);

    // .cc
    void pmtcat_check_domain_lookup_shape(int etype, const NP *domain, const NP *lookup) const;

    static const T *Upload(const NP *arr, const char *label);
    static T *Alloc(NP *out, const char *label);

    NP *pmtcat_scan(int etype, const NP *domain) const;
    NP *spmtid_scan(int etype, const NP *spmtid) const;
};


/**
QPMT::QPMT
------------

1. copy rindex_ into 3D in rindex3 then narrows rindex3 into rindex,
   NB this order preserves last prop column integer annotations
2. creates rindex_prop from rindex
3. narrows src_qeshape into qeshape
4. creates qeshape_prop from qeshape
5. creates cetheta_prop from cetheta
5. narrows src_thickness into thickness
6. narrows src_lcqs into lcqs

NB the jpmt argument is the NPFold provided by SPMT::CreateFromJPMTAndSerialize
not the raw fold from _PMTSimParamData. So all the data preparation done
in SPMT.h is accessible from here.

**/

template<typename T>
inline QPMT<T>::QPMT(const NPFold* jpmt )
    :
    ExecutableName(sproc::ExecutableName()),
    src_rindex(   jpmt->get("rindex")),
    src_thickness(jpmt->get("thickness")),
    src_qeshape(  jpmt->get("qeshape")),
    src_cetheta(  jpmt->get("cetheta")),
    src_cecosth(  jpmt->get("cecosth")),
    src_lcqs(     jpmt->get("lcqs")),
    rindex3(  NP::MakeCopy3D(src_rindex)),   // make copy and change shape to 3D
    rindex(   NP::MakeWithType<T>(rindex3)), // adopt template type, potentially narrowing
    rindex_prop(new QProp<T>(rindex)),
    qeshape(   NP::MakeWithType<T>(src_qeshape)), // adopt template type, potentially narrowing
    qeshape_prop(new QProp<T>(qeshape)),
    cetheta(   NP::MakeWithType<T>(src_cetheta)), // adopt template type, potentially narrowing
    cetheta_prop(new QProp<T>(cetheta)),
    cecosth(   NP::MakeWithType<T>(src_cecosth)), // adopt template type, potentially narrowing
    cecosth_prop(new QProp<T>(cecosth)),
    thickness(NP::MakeWithType<T>(src_thickness)),
    lcqs(src_lcqs ? NP::MakeWithType<T>(src_lcqs) : nullptr),
    i_lcqs( lcqs ? (int*)lcqs->cvalues<T>() : nullptr ),    // CPU side lookup lpmtidx->lpmtcat 0/1/2
    src_s_qeshape(  jpmt->get("s_qeshape")),
    src_s_qescale(  jpmt->get("s_qescale")),
    s_qeshape(   NP::MakeWithType<T>(src_s_qeshape)), // adopt template type, potentially narrowing
    s_qeshape_prop(new QProp<T>(s_qeshape)),
    s_qescale(src_s_qescale ? NP::MakeWithType<T>(src_s_qescale) : nullptr),
    pmt(new qpmt<T>()),                    // host-side qpmt.h instance
    d_pmt(nullptr)                         // device-side pointer set at upload in init
{
    init();
}

// init in .cc
template<typename T>
inline NPFold* QPMT<T>::serialize() const  // formerly get_fold
{
    NPFold* fold = new NPFold ;

    fold->add("src_thickness", src_thickness );
    fold->add("src_rindex", src_rindex );
    fold->add("src_qeshape", src_qeshape );
    fold->add("src_cetheta", src_cetheta );
    fold->add("src_cecosth", src_cecosth );
    fold->add("src_lcqs", src_lcqs );

    fold->add("thickness", thickness );
    fold->add("rindex", rindex );
    fold->add("qeshape", qeshape );
    fold->add("cetheta", cetheta );
    fold->add("cecosth", cecosth );
    fold->add("lcqs", lcqs );

    fold->add("rindex_prop_a", rindex_prop->a );
    fold->add("qeshape_prop_a", qeshape_prop->a );
    fold->add("cetheta_prop_a", cetheta_prop->a );
    fold->add("cecosth_prop_a", cecosth_prop->a );

    fold->add("s_qeshape", s_qeshape );
    fold->add("s_qeshape_prop_a", s_qeshape_prop->a );
    fold->add("s_qescale", s_qescale );

    return fold ;
}

template<typename T>
inline std::string QPMT<T>::desc() const
{
    int w = 30 ;
    std::stringstream ss ;
    ss
       << "QPMT::desc"
       << std::endl
       << std::setw(w) << "rindex "    << rindex->sstr() << std::endl
       << std::setw(w) << "qeshape " << qeshape->sstr() << std::endl
       << std::setw(w) << "cetheta " << cetheta->sstr() << std::endl
       << std::setw(w) << "cecosth " << cecosth->sstr() << std::endl
       << std::setw(w) << "thickness " << thickness->sstr() << std::endl
       << std::setw(w) << "lcqs " << lcqs->sstr() << std::endl
       << std::setw(w) << "s_qeshape " << s_qeshape->sstr() << std::endl
       << std::setw(w) << "s_qescale " << s_qescale->sstr() << std::endl
       << std::setw(w) << " pmt.rindex_prop " << pmt->rindex_prop  << std::endl
       << std::setw(w) << " pmt.qeshape_prop " << pmt->qeshape_prop  << std::endl
       << std::setw(w) << " pmt.cetheta_prop " << pmt->cetheta_prop  << std::endl
       << std::setw(w) << " pmt.cecosth_prop " << pmt->cecosth_prop  << std::endl
       << std::setw(w) << " pmt.thickness " << pmt->thickness  << std::endl
       << std::setw(w) << " pmt.lcqs " << pmt->lcqs  << std::endl
       << std::setw(w) << " d_pmt " << d_pmt   << std::endl
       ;
    std::string s = ss.str();
    return s ;
}

/**
QPMT::get_lpmtcat_from_lpmtidx
--------------------------------

CPU side lookup of lpmtcat from lpmtidx using i_lcqs array.

**/

template<typename T>
inline int QPMT<T>::get_lpmtcat_from_lpmtidx( int lpmtidx ) const
{
    assert( lpmtidx >= 0 && lpmtidx < s_pmt::NUM_LPMTIDX );  // extended from NUM_CD_LPMT_AND_WP
    const int& lpmtcat = i_lcqs[lpmtidx*2+0] ;
    return lpmtcat ;
}

template<typename T>
inline int QPMT<T>::get_lpmtcat_from_lpmtid( int lpmtid ) const
{
    int lpmtidx = s_pmt::lpmtidx_from_pmtid(lpmtid);
    return get_lpmtcat_from_lpmtidx(lpmtidx);
}


template<typename T>
inline int QPMT<T>::get_lpmtcat_from_lpmtid( int* lpmtcat_, const int* lpmtid_, int num_lpmtid ) const
{
    for(int i=0 ; i < num_lpmtid ; i++)
    {
        int lpmtid = lpmtid_[i] ;
        int lpmtcat = get_lpmtcat_from_lpmtid(lpmtid) ;
        lpmtcat_[i] = lpmtcat ;
    }
    return num_lpmtid ;
}

template<typename T>
inline int QPMT<T>::get_lpmtidx_from_lpmtid( int* lpmtidx_, const int* lpmtid_, int num_lpmtid ) const
{
    for(int i=0 ; i < num_lpmtid ; i++)
    {
        int lpmtid = lpmtid_[i] ;
        int lpmtidx = s_pmt::lpmtidx_from_pmtid(lpmtid);
        lpmtidx_[i] = lpmtidx ;
    }
    return num_lpmtid ;
}

template<typename T>
inline int QPMT<T>::get_spmtidx_from_spmtid( int* spmtidx_, const int* spmtid_, int num_spmtid ) const
{
    for(int i=0 ; i < num_spmtid ; i++)
    {
        int spmtid = spmtid_[i] ;
        int spmtidx = s_pmt::spmtidx_from_pmtid(spmtid);
        spmtidx_[i] = spmtidx ;
    }
    return num_spmtid ;
}






/**
QPMT::MakeArray_pmtcat
-------------------------

HMM: this is mainly for testing, perhaps put in QPMTTest ?

**/

template<typename T>
inline NP* QPMT<T>::MakeArray_pmtcat(int etype, unsigned num_domain )   // static
{
    const int& ni = s_pmt::NUM_CAT ;
    const int& nj = s_pmt::NUM_LAYR ;
    const int& nk = s_pmt::NUM_PROP ;
    NP* lookup = nullptr ;
    switch(etype)
    {
       case qpmt_RINDEX:  lookup = NP::Make<T>( ni, nj, nk, num_domain ) ; break ;
       case qpmt_CATSPEC: lookup = NP::Make<T>( ni, num_domain, 4, 4  )  ; break ;
       case qpmt_QESHAPE: lookup = NP::Make<T>( ni,         num_domain ) ; break ;
       case qpmt_CETHETA: lookup = NP::Make<T>( ni,         num_domain ) ; break ;
       case qpmt_CECOSTH: lookup = NP::Make<T>( ni,         num_domain ) ; break ;
       case qpmt_S_QESHAPE: lookup = NP::Make<T>( 1,        num_domain ) ; break ;
    }
    return lookup ;
}


template<typename T>
inline NP* QPMT<T>::MakeArray_pmtid(int etype, unsigned num_domain, unsigned num_pmtid )   // static
{
    const int ni = num_pmtid ;
    const int nj = num_domain ;

    NP* lookup = nullptr ;
    switch(etype)
    {
       case qpmt_S_QESCALE:  lookup = NP::Make<T>( num_pmtid )        ; break ;
    }
    return lookup ;
}
