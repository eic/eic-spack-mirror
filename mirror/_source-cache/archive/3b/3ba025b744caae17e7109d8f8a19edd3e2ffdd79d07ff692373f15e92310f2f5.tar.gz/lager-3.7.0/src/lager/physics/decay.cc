// lAger: General Purpose l/A-event Generator
// Copyright (C) 2016-2021 Sylvester Joosten <sjoosten@anl.gov>
// 
// This file is part of lAger.
// 
// lAger is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Shoftware Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// lAger is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with lAger.  If not, see <https://www.gnu.org/licenses/>.
// 

#include "decay.hh"
#include <cmath>
#include <lager/core/pdg.hh>

namespace lager {
namespace physics {

// two body decay of a particle 'part' into two particles xx (xx.first,
// xx.second), with angles of the first decay particle ('theta1', 'phi1')
//
// Note: the angles are assumed to be in the helicity frame of 'part'
void decay_2body(const particle& part, const double theta_1, const double phi_1,
                 std::pair<particle, particle>& xx,
                 std::pair<particle, particle>& xx_cm) {

  // calculate the CM kinematics
  const double E = part.mass();
  const double M2_1 = xx.first.mass() * xx.first.mass();
  const double M2_2 = xx.second.mass() * xx.second.mass();
  const double E_1 = (E * E + M2_1 - M2_2) / (2 * E);
  const double E_2 = (E * E - M2_1 + M2_2) / (2 * E);
  const double P_1 = sqrt(E_1 * E_1 - M2_1);
  const double P_2 = sqrt(E_2 * E_2 - M2_2);

  // create the 4-vectors in the part helicity frame
  const particle::Polar3DVector p3_1{P_1, theta_1, phi_1};
  xx.first.p() = {p3_1.X(), p3_1.Y(), p3_1.Z(), E_1};
  // decay particle 1 and two are back-to-back in the CM frame
  const particle::Polar3DVector p3_2{P_2, theta_1 + TMath::Pi(), phi_1};
  xx.second.p() = {p3_2.X(), p3_2.Y(), p3_2.Z(), E_2};

  // store the CM info prior to boosting / rotating
  xx_cm.first.p() = xx.first.p();
  xx_cm.second.p() = xx.first.p();

  // boost back to the rotated version of the original frame pointing in the
  // direction of part
  const particle::Boost b_from_cm{
      -(particle::XYZTVector{0, 0, sqrt(part.p().Vect().Mag2()), part.p().E()}
            .BoostToCM())};
  xx.first.boost(b_from_cm);
  xx.second.boost(b_from_cm);

  // rotate to the original frame
  xx.first.rotate_uz(part.p().Vect());
  xx.second.rotate_uz(part.p().Vect());

  // that's all
}
void decay_2body(const particle& part, const double theta_1, const double phi_1,
                 std::pair<particle, particle>& xx) {
  std::pair<particle, particle> dummy_cm;
  decay_2body(part, theta_1, phi_1, xx, dummy_cm);
}

} // physics
} // lager
