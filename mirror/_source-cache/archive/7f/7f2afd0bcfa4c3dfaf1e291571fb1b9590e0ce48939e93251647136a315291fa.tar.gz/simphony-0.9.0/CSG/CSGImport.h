#pragma once

#include <string>
#include "plog/Severity.h"

struct stree ; 
struct snode ; 
struct sn ; 

struct CSGFoundry ; 
struct CSGSolid ; 
struct CSGPrim ; 
struct CSGNode ; 

#include "CSG_API_EXPORT.hh"


struct CSG_API CSGImport  // HMM: maybe CSGCreate is a better name ? 
{
    static const plog::Severity LEVEL ; 
    static const int LVID ; 
    static const int NDID ; 

    CSGFoundry*  fd ; 
    const stree* st ; 

    CSGImport( CSGFoundry* fd );  
 
    void import(); 
    void importNames(); 
    void importSolid(); 
    void importInst(); 

    CSGSolid* importSolidRemainder_OLD(int ridx, const char* rlabel); 

    CSGSolid* importSolidGlobal(       int ridx, char ridx_type );
    CSGSolid* importSolidFactor(       int ridx, char ridx_type ); 

    CSGPrim*  importPrim( int primIdx, const snode& node ); 
    CSGNode*  importNode( int nodeOffset, int partIdx, const snode& node, const sn* nd); 
    CSGNode*  importListnode(int nodeOffset, int partIdx, const snode& node, const sn* nd); 

}; 
