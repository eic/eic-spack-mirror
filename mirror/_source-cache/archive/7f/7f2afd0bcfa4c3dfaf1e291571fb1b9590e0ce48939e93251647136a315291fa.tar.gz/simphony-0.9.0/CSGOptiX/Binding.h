#pragma once
#include <stdint.h>
#include <vector_types.h>

struct RaygenData
{
};

struct MissData
{
    float r, g, b;
};


struct CustomPrim
{
    int nodeOffset ;
    int globalPrimIdx ;
};

struct TriMesh
{
    unsigned boundary ;
    uint3*  indice ;  // indices of triangle vertices and normal
    float3* vertex ;
    float3* normal ;
    int globalPrimIdx ;
};


struct HitGroupData
{
    union
    {
        CustomPrim prim ;
        TriMesh    mesh ;
    };
};




#if defined(__CUDACC__) || defined(__CUDABE__)
#else
#include <optix_types.h>

template <typename T>
struct SbtRecord
{
    __align__( OPTIX_SBT_RECORD_ALIGNMENT ) char header[OPTIX_SBT_RECORD_HEADER_SIZE];
    T data;
};

typedef SbtRecord<RaygenData>     Raygen ;
typedef SbtRecord<MissData>       Miss ;
typedef SbtRecord<HitGroupData>   HitGroup ;

#endif

