#include "catch2/catch_test_macros.hpp"
#include "catch2/matchers/catch_matchers_vector.hpp"

#include "podio/LinkCollection.h"
#include "podio/LinkNavigator.h"
#include "podio/utilities/TypeHelpers.h"

#include "datamodel/ExampleClusterCollection.h"
#include "datamodel/ExampleHitCollection.h"
#include "datamodel/TestInterfaceLinkCollection.h"
#include "datamodel/TypeWithEnergy.h"
#include <utility>

#ifdef PODIO_JSON_OUTPUT
  #include "nlohmann/json.hpp"
#endif

#include <map>
#include <set>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>

// Test datatypes (spelling them out here explicitly to make sure that
// assumptions about typedefs actually hold)
using TestL = podio::Link<ExampleHit, ExampleCluster>;
using TestMutL = podio::MutableLink<ExampleHit, ExampleCluster>;
using TestLColl = podio::LinkCollection<ExampleHit, ExampleCluster>;
using TestLIter = podio::LinkCollectionIterator<ExampleHit, ExampleCluster>;
using TestLMutIter = podio::LinkMutableCollectionIterator<ExampleHit, ExampleCluster>;

TEST_CASE("Link constness", "[links][static-checks]") {
  STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestMutL>().getFrom()), const ExampleHit>);
  STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestMutL>().getTo()), const ExampleCluster>);

  STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestL>().getFrom()), const ExampleHit>);
  STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestL>().getTo()), const ExampleCluster>);
}

TEST_CASE("Link basics", "[links]") {
  // NOLINTBEGIN(clang-analyzer-cplusplus.NewDeleteLeaks): There are quite a few
  // false positives here from clang-tidy that we are confident are false
  // positives, because we don't see issues in our builds with sanitizers
  auto cluster = MutableExampleCluster();
  auto hit = MutableExampleHit();

  auto mutLink = TestMutL();
  mutLink.setWeight(3.14f);
  mutLink.setFrom(hit);
  mutLink.setTo(cluster);

  REQUIRE(mutLink.getWeight() == 3.14f);
  REQUIRE(mutLink.getFrom() == hit);
  REQUIRE(mutLink.getTo() == cluster);

  SECTION("Copying") {
    auto otherLink = mutLink;
    REQUIRE(otherLink.getWeight() == 3.14f);
    REQUIRE(otherLink.getFrom() == hit);
    REQUIRE(otherLink.getTo() == cluster);

    auto otherCluster = ExampleCluster();
    auto otherHit = ExampleHit();
    otherLink.setFrom(otherHit);
    otherLink.setTo(otherCluster);
    otherLink.setWeight(42.0f);
    REQUIRE(otherLink.getWeight() == 42.0f);
    REQUIRE(otherLink.getFrom() == otherHit);
    REQUIRE(otherLink.getTo() == otherCluster);

    // Make sure original link changes as well
    REQUIRE(mutLink.getWeight() == 42.0f);
    REQUIRE(mutLink.getFrom() == otherHit);
    REQUIRE(mutLink.getTo() == otherCluster);
  }

  SECTION("Assignment") {
    auto otherLink = TestMutL();
    otherLink = mutLink;
    REQUIRE(otherLink.getWeight() == 3.14f);
    REQUIRE(otherLink.getFrom() == hit);
    REQUIRE(otherLink.getTo() == cluster);

    auto otherCluster = ExampleCluster();
    auto otherHit = ExampleHit();
    otherLink.setFrom(otherHit);
    otherLink.setTo(otherCluster);
    otherLink.setWeight(42.0f);
    REQUIRE(otherLink.getWeight() == 42.0f);
    REQUIRE(otherLink.getFrom() == otherHit);
    REQUIRE(otherLink.getTo() == otherCluster);

    // Make sure original link changes as well
    REQUIRE(mutLink.getWeight() == 42.0f);
    REQUIRE(mutLink.getFrom() == otherHit);
    REQUIRE(mutLink.getTo() == otherCluster);
  }

  SECTION("Implicit conversion") {
    // Use an immediately invoked lambda to check that the implicit conversion
    // is working as desired
    [hit, cluster](TestL link) { // NOLINT(performance-unnecessary-value-param):
                                 // We want the value here to force the
                                 // conversion
      REQUIRE(link.getWeight() == 3.14f);
      REQUIRE(link.getFrom() == hit);
      REQUIRE(link.getTo() == cluster);
    }(mutLink);
  }

  SECTION("Cloning") {
    auto otherLink = mutLink.clone();
    REQUIRE(otherLink.getWeight() == 3.14f);
    REQUIRE(otherLink.getFrom() == hit);
    REQUIRE(otherLink.getTo() == cluster);

    auto otherCluster = ExampleCluster();
    auto otherHit = ExampleHit();
    otherLink.setFrom(otherHit);
    otherLink.setTo(otherCluster);
    otherLink.setWeight(42.0f);
    REQUIRE(otherLink.getWeight() == 42.0f);
    REQUIRE(otherLink.getFrom() == otherHit);
    REQUIRE(otherLink.getTo() == otherCluster);

    // Make sure original link is unchanged
    REQUIRE(mutLink.getWeight() == 3.14f);
    REQUIRE(mutLink.getFrom() == hit);
    REQUIRE(mutLink.getTo() == cluster);

    // Check cloning from an immutable one
    TestL link = mutLink;
    auto anotherLink = link.clone();
    anotherLink.setFrom(otherHit);
    anotherLink.setTo(otherCluster);
    anotherLink.setWeight(42.0f);
    REQUIRE(anotherLink.getWeight() == 42.0f);
    REQUIRE(anotherLink.getFrom() == otherHit);
    REQUIRE(anotherLink.getTo() == otherCluster);

    // Cloning without relations
    auto linkNoRel = link.clone(false);
    REQUIRE_FALSE(linkNoRel.getFrom().isAvailable());
    REQUIRE_FALSE(linkNoRel.getTo().isAvailable());
    REQUIRE(linkNoRel.getWeight() == 3.14f);
  }

  SECTION("Equality operator") {
    auto otherLink = mutLink; // NOLINT(performance-unnecessary-copy-initialization)
    REQUIRE(otherLink == mutLink);

    // Mutable and immutable links should be comparable
    TestL link = mutLink;
    REQUIRE(link == mutLink);

    // operator!= is also defined and working
    auto newLink = TestL{};
    REQUIRE(otherLink != newLink);
    REQUIRE(link != newLink);
  }
}
// NOLINTEND(clang-analyzer-cplusplus.NewDeleteLeaks)

TEST_CASE("Links hash and containers", "[links][hash]") {
  // NOLINTBEGIN(clang-analyzer-cplusplus.NewDeleteLeaks): There are quite a few
  // false positives here from clang-tidy that we are confident are false
  // positives, because we don't see issues in our builds with sanitizers
  SECTION("hash") {
    auto hit1 = ExampleHit();
    auto cluster1 = ExampleCluster();
    auto link1 = TestMutL();
    link1.set(hit1);
    link1.set(cluster1);
    auto hash1 = std::hash<TestMutL>{}(link1);
    // rehashing should give the same result
    auto rehash = std::hash<TestMutL>{}(link1);
    REQUIRE(rehash == hash1);

    // same object should have the same hash
    auto link2 = link1;
    auto hash2 = std::hash<TestMutL>{}(link2);
    REQUIRE(link2 == link1);
    REQUIRE(hash2 == hash1);

    // different objects should have different hashes
    auto different_link = TestMutL();
    auto hash_different = std::hash<TestMutL>{}(different_link);
    REQUIRE(different_link != link1);
    REQUIRE(hash_different != hash1);

    // podio specific:
    // changing  properties doesn't change hash as long as the same object is used
    auto another_hit = ExampleHit();
    link1.setWeight(3.14);
    link1.set(another_hit);
    auto hash_mod = std::hash<TestMutL>{}(link1);
    REQUIRE(link1 == link2);
    REQUIRE(hash_mod == hash2);

    // podio specific:
    // mutable and immutable objects should have the same hash
    auto immutable_link = TestL(link1);
    auto hash_immutable = std::hash<TestL>{}(immutable_link);
    REQUIRE(immutable_link == link1);
    REQUIRE(hash_immutable == hash1);
  }

  SECTION("associative containers") {
    ExampleHit hit1, hit2;
    ExampleCluster cluster1, cluster2;
    TestMutL link1, link2, link3, link4;
    link1.set(hit1);
    link1.set(cluster1);
    link1.setWeight(1.0);
    link2.set(hit2);
    link2.set(cluster2);
    link2.setWeight(2.0);
    link3.set(hit1);
    link3.set(cluster2);
    link3.setWeight(3.0);
    link4.set(hit1);
    link4.set(cluster1);
    link4.setWeight(4.0);
    auto link5 = link2;

    std::set<TestL> linkSet;
    linkSet.insert(link1);
    linkSet.insert(link2);
    linkSet.insert(link3);
    linkSet.insert(link4);
    linkSet.insert(link4);
    linkSet.insert(link5);
    REQUIRE(linkSet.size() == 4);

    std::map<TestL, int> linkMap;
    linkMap[link1]++;
    linkMap[link2]++;
    linkMap[link3]++;
    linkMap[link4]++;
    linkMap[link5]++;
    REQUIRE(linkMap[link1] == 1);
    REQUIRE(linkMap[link2] == 2);
    REQUIRE(linkMap[link3] == 1);
    REQUIRE(linkMap[link4] == 1);
    REQUIRE(linkMap[link5] == 2);

    // unordered associative containers
    std::unordered_set<TestL> linkUnorderedSet;
    linkUnorderedSet.insert(link1);
    linkUnorderedSet.insert(link2);
    linkUnorderedSet.insert(link3);
    linkUnorderedSet.insert(link4);
    linkUnorderedSet.insert(link4);
    linkUnorderedSet.insert(link5);
    REQUIRE(linkUnorderedSet.size() == 4);

    std::unordered_map<TestL, int> linkUnorderedMap;
    linkUnorderedMap[link1]++;
    linkUnorderedMap[link2]++;
    linkUnorderedMap[link3]++;
    linkUnorderedMap[link4]++;
    linkUnorderedMap[link5]++;

    REQUIRE(linkUnorderedMap[link1] == 1);
    REQUIRE(linkUnorderedMap[link2] == 2);
    REQUIRE(linkUnorderedMap[link3] == 1);
    REQUIRE(linkUnorderedMap[link4] == 1);
    REQUIRE(linkUnorderedMap[link5] == 2);
  }
  // NOLINTEND(clang-analyzer-cplusplus.NewDeleteLeaks)
}

TEST_CASE("Links templated accessors", "[links]") {
  // NOLINTBEGIN(clang-analyzer-cplusplus.NewDeleteLeaks): There are quite a few
  // false positives here from clang-tidy that we are confident are false
  // positives, because we don't see issues in our builds with sanitizers
  ExampleHit hit;
  ExampleCluster cluster;

  TestMutL link;
  link.set(hit);
  link.set(cluster);
  link.setWeight(1.0);

  SECTION("Mutable Link") {
    REQUIRE(hit == link.get<ExampleHit>());
    REQUIRE(cluster == link.get<ExampleCluster>());

    const auto& [h, c, w] = link;
    REQUIRE(h == hit);
    REQUIRE(c == cluster);
    REQUIRE(w == 1.0);
  }

  SECTION("Immutable link") {
    TestL a{link};

    REQUIRE(hit == a.get<ExampleHit>());
    REQUIRE(cluster == a.get<ExampleCluster>());

    const auto& [h, c, w] = a;
    REQUIRE(h == hit);
    REQUIRE(c == cluster);
    REQUIRE(w == 1.0);
  }
}
// NOLINTEND(clang-analyzer-cplusplus.NewDeleteLeaks)
TEST_CASE("LinkCollection collection concept", "[links][concepts]") {
  STATIC_REQUIRE(podio::CollectionType<TestLColl>);
  STATIC_REQUIRE(std::is_same_v<std::ranges::range_value_t<TestLColl>, TestL>);
  STATIC_REQUIRE(std::is_same_v<std::ranges::range_value_t<const TestLColl>, TestL>);
}

TEST_CASE("LinkCollection constness", "[links][static-checks][const-correctness]") {
  // Test type-aliases in LinkCollection
  STATIC_REQUIRE(std::is_same_v<TestLColl::const_iterator, TestLIter>);
  STATIC_REQUIRE(std::is_same_v<TestLColl::iterator, TestLMutIter>);

  SECTION("const collections with const iterators") {
    const auto coll = TestLColl();
    // this essentially checks the whole "chain" from begin() / end() through
    // iterator operators
    for (auto link : coll) {
      STATIC_REQUIRE(std::is_same_v<decltype(link), TestL>); // const collection iterators should only return
                                                             // immutable objects
    }

    // check the individual steps again from above, to see where things fail if they fail
    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<const TestLColl>().begin()),
                                  TestLColl::const_iterator>); // const collection begin() should return a
                                                               // LinkCollectionIterator

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<const TestLColl>().end()),
                                  TestLColl::const_iterator>); // const collection end() should return a
                                                               // LinkCollectionIterator

    STATIC_REQUIRE(std::is_same_v<decltype(*std::declval<const TestLColl>().begin()),
                                  TestL>); // LinkCollectionIterator should only give access to immutable
                                           // objects

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLIter>().operator->()),
                                  TestL*>); // LinkCollectionIterator should only give access to immutable
                                            // objects
  }

  SECTION("non-const collections with mutable iterators") {
    auto coll = TestLColl();
    // this essentially checks the whole "chain" from begin() / end() through
    // iterator operators
    for (auto link : coll) {
      STATIC_REQUIRE(std::is_same_v<decltype(link), TestMutL>); // collection iterators should return return
                                                                // mutable objects
    }

    // check the individual steps again from above, to see where things fail if they fail
    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLColl>().begin()),
                                  TestLColl::iterator>); // collection begin() should return a
                                                         // MutableCollectionIterator

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLColl>().end()),
                                  TestLColl::iterator>); // collection end() should return a
                                                         // MutableCollectionIterator

    STATIC_REQUIRE(std::is_same_v<decltype(*std::declval<TestLColl>().begin()),
                                  TestMutL>); // MutableCollectionIterator should give access to immutable
                                              // mutable objects

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLMutIter>().operator->()),
                                  TestMutL*>); // MutableCollectionIterator should give access to immutable
                                               // mutable objects
  }

  SECTION("const correct indexed access to const collections") {
    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<const TestLColl>()[0]),
                                  TestL>); // const collections should only have indexed indexed access to immutable
                                           // objects

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<const TestLColl>().at(0)),
                                  TestL>); // const collections should only have indexed indexed access to immutable
                                           // objects
  }

  SECTION("const correct indexed access to collections") {
    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLColl>()[0]),
                                  TestMutL>); // collections should have indexed indexed access to mutable objects

    STATIC_REQUIRE(std::is_same_v<decltype(std::declval<TestLColl>().at(0)),
                                  TestMutL>); // collections should have indexed indexed access to mutable objects
  }
}

TEST_CASE("LinkCollection subset collection", "[links][subset-colls]") {
  // NOLINTBEGIN(clang-analyzer-cplusplus.NewDeleteLeaks): There are quite a few
  // false positives here from clang-tidy that we are confident are false
  // positives, because we don't see issues in our builds with sanitizers
  auto links = TestLColl();
  auto link1 = links.create();
  link1.setWeight(1.0f);
  auto link2 = links.create();
  link2.setWeight(2.0f);

  auto linkRefs = TestLColl();
  linkRefs.setSubsetCollection();
  for (const auto a : links) {
    linkRefs.push_back(a);
  }

  SECTION("Collection iterators work with subset collections") {

    // index-based looping / access
    for (size_t i = 0; i < linkRefs.size(); ++i) {
      REQUIRE(linkRefs[i].getWeight() == i + 1);
    }

    // range-based for loop
    int index = 1;
    for (const auto a : linkRefs) {
      REQUIRE(a.getWeight() == index++);
    }
  }

  SECTION("Conversion failures") {
    // Cannot convert into a subset collection if elements already present
    REQUIRE_THROWS_AS(links.setSubsetCollection(), std::logic_error);

    // Cannot convert a subset collection into a normal collection
    REQUIRE_THROWS_AS(linkRefs.setSubsetCollection(false), std::logic_error);
  }

  SECTION("Subset collection only handles tracked objects") {
    auto link = TestL();
    REQUIRE_THROWS_AS(linkRefs.push_back(link), std::invalid_argument);
    REQUIRE_THROWS_AS(linkRefs.create(), std::logic_error);
  }
}
// NOLINTEND(clang-analyzer-cplusplus.NewDeleteLeaks)

TEST_CASE("LinkCollection basics", "[links]") {
  STATIC_REQUIRE(TestL::typeName == "podio::Link<ExampleHit,ExampleCluster>");
  STATIC_REQUIRE(TestLColl::typeName == "podio::LinkCollection<ExampleHit,ExampleCluster>");

  auto links = TestLColl{};
  auto link = links.create();
  REQUIRE(link.id().collectionID == 0);

  links.setID(42);
  for (auto l : links) {
    REQUIRE(l.id().collectionID == 42);
  }
}

TEST_CASE("LinkCollection create with linked objects", "[links][basics]") {
  // NOLINTBEGIN(clang-analyzer-cplusplus.NewDeleteLeaks): There are quite a few
  // false positives here from clang-tidy that we are confident are false
  // positives, because we don't see issues in our builds with sanitizers
  auto hits = ExampleHitCollection();
  auto clusters = ExampleClusterCollection();
  auto hit = hits.create();
  auto cluster = clusters.create();

  auto links = TestLColl();

  SECTION("Canonical order") {
    auto link = links.create(hit, cluster);
    REQUIRE(links.size() == 1);
    REQUIRE(link.getFrom() == hit);
    REQUIRE(link.getTo() == cluster);
    // The weight defaults to the same value as for a default constructed link
    REQUIRE(link.getWeight() == 1.f);
    REQUIRE(link.getWeight() == links.create().getWeight());
  }

  SECTION("Reversed order") {
    auto link = links.create(cluster, hit);
    REQUIRE(links.size() == 1);
    REQUIRE(link.getFrom() == hit);
    REQUIRE(link.getTo() == cluster);
    REQUIRE(link.getWeight() == 1.f);
  }

  SECTION("With a weight") {
    auto link = links.create(hit, cluster, 3.14f);
    REQUIRE(link.getFrom() == hit);
    REQUIRE(link.getTo() == cluster);
    REQUIRE(link.getWeight() == 3.14f);

    auto reversed = links.create(cluster, hit, 42.f);
    REQUIRE(reversed.getFrom() == hit);
    REQUIRE(reversed.getTo() == cluster);
    REQUIRE(reversed.getWeight() == 42.f);
  }

  SECTION("Immutable handles") {
    auto link = links.create(std::as_const(hits)[0], std::as_const(clusters)[0]);
    REQUIRE(link.getFrom() == hit);
    REQUIRE(link.getTo() == cluster);
  }

  SECTION("Links are appended to the collection") {
    links.create(hit, cluster, 1.f);
    links.create(cluster, hit, 2.f);
    REQUIRE(links.size() == 2);
    REQUIRE(links[0].getWeight() == 1.f);
    REQUIRE(links[1].getWeight() == 2.f);
    for (auto link : links) {
      REQUIRE(link.getFrom() == hit);
      REQUIRE(link.getTo() == cluster);
    }
  }

  SECTION("Subset collections cannot create links") {
    auto subsetColl = TestLColl();
    subsetColl.setSubsetCollection();
    REQUIRE_THROWS_AS(subsetColl.create(hit, cluster), std::logic_error);
  }

  SECTION("Links with the same From and To type") {
    using SameTypeLColl = podio::LinkCollection<ExampleHit, ExampleHit>;
    auto otherHit = hits.create();
    auto sameTypeLinks = SameTypeLColl();
    // Only the canonical order is possible here
    auto link = sameTypeLinks.create(hit, otherHit, 1.23f);
    REQUIRE(link.getFrom() == hit);
    REQUIRE(link.getTo() == otherHit);
    REQUIRE(link.getWeight() == 1.23f);
  }
}
// NOLINTEND(clang-analyzer-cplusplus.NewDeleteLeaks)

auto createLinkCollections(const size_t nElements = 3u) {
  auto colls = std::make_tuple(TestLColl(), ExampleHitCollection(), ExampleClusterCollection());

  auto& [linkColl, hitColl, clusterColl] = colls;
  for (auto i = 0u; i < nElements; ++i) {
    auto hit = hitColl.create();
    auto cluster = clusterColl.create();
  }

  for (auto i = 0u; i < nElements; ++i) {
    auto link = linkColl.create();
    link.setWeight(i);
    // Fill the relations in opposite orders to at least uncover issues that
    // could be hidden by running the indices in parallel
    link.setFrom(hitColl[i]);
    link.setTo(clusterColl[nElements - i - 1]);
  }

  return colls;
}

void checkCollections(const TestLColl& links, const ExampleHitCollection& hits,
                      const ExampleClusterCollection& clusters, const size_t nElements = 3u) {
  REQUIRE(links.size() == 3);
  REQUIRE(hits.size() == 3);
  REQUIRE(clusters.size() == 3);

  size_t index = 0;
  for (auto link : links) {
    REQUIRE(link.getWeight() == index);
    REQUIRE(link.getFrom() == hits[index]);
    REQUIRE(link.getTo() == clusters[nElements - index - 1]);

    index++;
  }
}

TEST_CASE("LinkCollection access and iteration", "[links][basics]") {
  const auto [linkColl, hitColl, clusterColl] = createLinkCollections();

  SECTION("element access") {
    for (size_t i = 0; i < linkColl.size(); ++i) {
      REQUIRE(linkColl[i].getWeight() == i);
      REQUIRE(std::as_const(linkColl)[i].getWeight() == i);
      REQUIRE(linkColl.at(i).getWeight() == i);
      REQUIRE(std::as_const(linkColl).at(i).getWeight() == i);
    }

    REQUIRE_THROWS_AS(linkColl.at(linkColl.size()), std::out_of_range);
    REQUIRE_THROWS_AS(std::as_const(linkColl).at(linkColl.size()), std::out_of_range);
  }

  SECTION("looping") {
    int i = 0;
    const auto collSize = linkColl.size();
    for (const auto& [from, to, weight] : linkColl) {
      STATIC_REQUIRE(std::is_same_v<decltype(from), const ExampleHit>);
      STATIC_REQUIRE(std::is_same_v<decltype(to), const ExampleCluster>);
      STATIC_REQUIRE(std::is_same_v<decltype(weight), const float>);

      REQUIRE(from == hitColl[i]);
      REQUIRE(to == clusterColl[collSize - 1 - i]);
      REQUIRE(weight == i);
      i++;
    }
  }
}

TEST_CASE("LinkCollection movability", "[links][move-semantics][collections]") {
  // Setup a few collections for testing
  auto [linkColl, hitColl, clusterColl] = createLinkCollections();

  // Check that after the setup everything is as expected
  checkCollections(linkColl, hitColl, clusterColl);

  SECTION("Move constructor and assignment") {
    // NOTE: moving datatype collections is already covered by respective tests
    auto newLinks = std::move(linkColl);
    checkCollections(newLinks, hitColl, clusterColl);

    auto newerLinks = TestLColl();
    newerLinks = std::move(newLinks);
    checkCollections(newerLinks, hitColl, clusterColl);
  }

  SECTION("Prepared collections can be move assigned/constructed") {
    linkColl.prepareForWrite();
    auto newLinks = std::move(linkColl);
    // checkCollections(newLinks, hitColl, clusterColl);

    newLinks.prepareForWrite();
    auto newerLinks = TestLColl();
    newerLinks = std::move(newLinks);
    // checkCollections(newLinks, hitColl, clusterColl);
  }

  SECTION("Subset collections can be moved") {
    // Create a subset collection to move from
    auto subsetLinks = TestLColl();
    subsetLinks.setSubsetCollection();
    for (auto a : linkColl) {
      subsetLinks.push_back(a);
    }
    checkCollections(subsetLinks, hitColl, clusterColl);

    // Move constructor
    auto newSubsetLinks = std::move(subsetLinks);
    checkCollections(newSubsetLinks, hitColl, clusterColl);
    REQUIRE(newSubsetLinks.isSubsetCollection());

    // Move assignment
    auto evenNewerLinks = TestLColl();
    evenNewerLinks = std::move(newSubsetLinks);
    checkCollections(evenNewerLinks, hitColl, clusterColl);
    REQUIRE(evenNewerLinks.isSubsetCollection());
  }
}

TEST_CASE("Links with interfaces", "[links][interface-types]") {
  auto coll = TestInterfaceLinkCollection{};
  auto cluster = ExampleCluster();
  auto hit = ExampleHit();
  auto iface = TypeWithEnergy(hit);

  auto link = coll.create();
  link.setFrom(cluster);
  link.setTo(iface);

  REQUIRE(link.getFrom() == cluster);
  REQUIRE(link.get<ExampleCluster>() == cluster);
  REQUIRE(link.getTo() == iface);
  REQUIRE(link.get<TypeWithEnergy>() == iface);

  link.set(TypeWithEnergy(cluster));
  REQUIRE(link.get<ExampleCluster>() == cluster); // unchanged
  REQUIRE(link.get<TypeWithEnergy>() == cluster);

  // Setting with implicit conversion to interface
  auto hit2 = ExampleHit();
  link.setTo(hit2);
  REQUIRE(link.get<TypeWithEnergy>() == hit2);

  link.set(hit);
  REQUIRE(link.get<TypeWithEnergy>() == hit);
  REQUIRE(link.get<ExampleCluster>() == cluster);

  // Check determining `set` direction for a link going in a reverse direction
  using ReverseInterfaceLinkCollection =
      podio::LinkCollection<TestInterfaceLinkCollection::to_type, TestInterfaceLinkCollection::from_type>;
  auto rColl = ReverseInterfaceLinkCollection{};
  auto rLink = rColl.create();

  rLink.set(cluster);
  rLink.set(iface);
  REQUIRE(rLink.get<TypeWithEnergy>() == iface);
  REQUIRE(rLink.get<ExampleCluster>() == cluster);

  rLink.set(hit);
  REQUIRE(rLink.get<TypeWithEnergy>() == hit);
  REQUIRE(rLink.get<ExampleCluster>() == cluster);

  SECTION("Creating links with interfaces") {
    // Interface types can be passed directly
    auto ifaceLink = coll.create(cluster, iface, 1.f);
    REQUIRE(ifaceLink.getFrom() == cluster);
    REQUIRE(ifaceLink.getTo() == iface);
    REQUIRE(ifaceLink.getWeight() == 1.f);

    // As can types that implicitly convert to an interface, in any order
    auto convLink = coll.create(cluster, hit);
    REQUIRE(convLink.getFrom() == cluster);
    REQUIRE(convLink.getTo() == hit);

    auto reversedLink = coll.create(hit, cluster);
    REQUIRE(reversedLink.getFrom() == cluster);
    REQUIRE(reversedLink.getTo() == hit);

    // If both orders are possible the canonical one (from, to) wins
    auto otherCluster = ExampleCluster();
    auto ambiguousLink = coll.create(cluster, otherCluster);
    REQUIRE(ambiguousLink.getFrom() == cluster);
    REQUIRE(ambiguousLink.get<TypeWithEnergy>() == otherCluster);

    // Also works for links that go in the other direction
    auto rIfaceLink = rColl.create(cluster, hit);
    REQUIRE(rIfaceLink.getFrom() == hit);
    REQUIRE(rIfaceLink.getTo() == cluster);
  }
}

TEST_CASE("Links reverse iterators", "[links][iterator]") {
  const auto [linkColl, hitColl, clusterColl] = createLinkCollections();
  REQUIRE(linkColl.size() > 1);
  auto it = --linkColl.rend();
  REQUIRE(*it == *linkColl.begin());
  it = linkColl.rbegin();
  REQUIRE(*it == *--linkColl.end());
  auto cit = --linkColl.rend();
  REQUIRE(*cit == *linkColl.cbegin());
  cit = linkColl.crbegin();
  REQUIRE(*cit == *--linkColl.cend());
}

#ifdef PODIO_JSON_OUTPUT
TEST_CASE("Link JSON conversion", "[links][json]") {
  const auto& [links, hits, clusters] = createLinkCollections();
  const nlohmann::json json{{"links", links}};

  REQUIRE(json["links"].size() == 3);

  int i = 0;
  for (const auto& link : json["links"]) {
    REQUIRE(link["weight"] == i);
    REQUIRE(link["from"]["index"] == i);
    i++;
  }

  i = 2;
  for (const auto& link : json["links"]) {
    REQUIRE(link["to"]["index"] == i);
    i--;
  }
}

#endif

TEST_CASE("LinkCollection construction from range", "[links][basics]") {
  std::vector<TestMutL> links(11);
  auto linkColl = TestLColl::from(links);
  REQUIRE_FALSE(linkColl.isSubsetCollection());
  REQUIRE(linkColl.size() == links.size());
  for (size_t i = 0; i < links.size(); ++i) {
    REQUIRE(linkColl[i] == links[i]);
  }

  const auto anotherLinkColl = TestLColl::from(std::as_const(linkColl));
  REQUIRE(anotherLinkColl.isSubsetCollection());
  REQUIRE(anotherLinkColl.size() == linkColl.size());
  for (size_t i = 0; i < linkColl.size(); ++i) {
    REQUIRE(anotherLinkColl[i] == linkColl[i]);
  }

  // Cannot construct a collection from unowned immutable handles
  std::array<TestL, 11> immutableLinks{};
  REQUIRE_THROWS_AS(TestLColl::from(immutableLinks), std::invalid_argument);
  // Cannot construct a collection from a range of mutalbe handles that are
  // already owned
  REQUIRE_THROWS_AS(TestLColl::from(links), std::invalid_argument);
}

#if defined(__cpp_lib_containers_ranges)
TEST_CASE("LinkCollection construction from ranges::to", "[links][range]") {
  using namespace std::views;
  const auto linkColl = iota(0, 5) | transform([](auto const v) { return TestMutL(v); }) | std::ranges::to<TestLColl>();
  REQUIRE(linkColl.size() == 5);
  REQUIRE_FALSE(linkColl.isSubsetCollection());
  for (size_t i = 1; i < linkColl.size(); ++i) {
    REQUIRE(linkColl[i].getWeight() == i);
  }

  using namespace std::ranges::views;
  const auto immutableLinkColl = std::as_const(linkColl) | take(3) | std::ranges::to<TestLColl>();
  REQUIRE(immutableLinkColl.size() == 3);
  REQUIRE(immutableLinkColl.isSubsetCollection());
  for (size_t i = 0; i < immutableLinkColl.size(); ++i) {
    REQUIRE(immutableLinkColl[i] == linkColl[i]);
  }
}
#endif

TEST_CASE("LinkNavigator", "[links]") {
  SECTION("basics") {
    TestLColl coll{};
    std::vector<ExampleHit> hits(11);
    std::vector<ExampleCluster> clusters(3);

    for (size_t i = 0; i < 10; ++i) {
      auto a = coll.create();
      a.set(hits[i]);
      a.set(clusters[i % 3]);
      a.setWeight(i * 0.1f);
    }

    auto a = coll.create();
    a.set(hits[10]);

    podio::LinkNavigator nav{coll};

    for (size_t i = 0; i < 10; ++i) {
      const auto& hit = hits[i];
      const auto linkedClusters = nav.getLinked(hit);
      REQUIRE(linkedClusters.size() == 1);
      const auto& [cluster, weight] = linkedClusters[0];
      REQUIRE(cluster == clusters[i % 3]);
      REQUIRE(weight == i * 0.1f);
    }

    using Catch::Matchers::UnorderedEquals;
    using podio::detail::links::WeightedObject;
    using WeightedHits = std::vector<WeightedObject<ExampleHit>>;

    auto linkedHits = nav.getLinked(clusters[0]);
    REQUIRE_THAT(linkedHits,
                 UnorderedEquals(WeightedHits{WeightedObject{hits[0], 0.f}, WeightedObject{hits[3], 3 * 0.1f},
                                              WeightedObject{hits[6], 6 * 0.1f}, WeightedObject{hits[9], 9 * 0.1f}}));

    linkedHits = nav.getLinked(clusters[1]);
    REQUIRE_THAT(linkedHits,
                 UnorderedEquals(WeightedHits{WeightedObject{hits[1], 0.1f}, WeightedObject{hits[4], 0.4f},
                                              WeightedObject{hits[7], 0.7f}}));

    const auto [noCluster, noWeight] = nav.getLinked(hits[10])[0];
    REQUIRE_FALSE(noCluster.isAvailable());
  }

  SECTION("same types") {
    std::vector<ExampleCluster> clusters(3);
    auto linkColl = podio::LinkCollection<ExampleCluster, ExampleCluster>{};
    auto link = linkColl.create();
    link.setFrom(clusters[0]);
    link.setTo(clusters[1]);
    link.setWeight(0.5f);

    link = linkColl.create();
    link.setFrom(clusters[0]);
    link.setTo(clusters[2]);
    link.setWeight(0.25f);

    link = linkColl.create();
    link.setFrom(clusters[1]);
    link.setTo(clusters[2]);
    link.setWeight(0.66f);

    auto navigator = podio::LinkNavigator{linkColl};
    auto linkedClusters = navigator.getLinkedTo(clusters[1]);
    REQUIRE(linkedClusters.size() == 1);
    REQUIRE(linkedClusters[0].o == clusters[2]);
    REQUIRE(linkedClusters[0].weight == 0.66f);

    linkedClusters = navigator.getLinkedFrom(clusters[1]);
    REQUIRE(linkedClusters.size() == 1);
    REQUIRE(linkedClusters[0].o == clusters[0]);
    REQUIRE(linkedClusters[0].weight == 0.5f);

    using Catch::Matchers::UnorderedEquals;
    using podio::detail::links::WeightedObject;
    using WeightedObjVec = std::vector<WeightedObject<ExampleCluster>>;
    linkedClusters = navigator.getLinkedTo(clusters[0]);
    REQUIRE_THAT(
        linkedClusters,
        UnorderedEquals(WeightedObjVec{WeightedObject(clusters[1], 0.5f), WeightedObject{clusters[2], 0.25f}}));

    linkedClusters = navigator.getLinkedFrom(clusters[2]);
    REQUIRE_THAT(
        linkedClusters,
        UnorderedEquals(WeightedObjVec{WeightedObject{clusters[0], 0.25f}, WeightedObject{clusters[1], 0.66f}}));
  }
}
