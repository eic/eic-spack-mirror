#ifndef PODIO_SIOREADER_H
#define PODIO_SIOREADER_H

#include "podio/SIOBlock.h"
#include "podio/SIOFrameData.h"
#include "podio/utilities/ReaderCommon.h"

#include <sio/definitions.h>

#include <memory>
#include <string>
#include <string_view>
#include <unordered_map>

namespace podio {

class CollectionIDTable;

/// The SIOReader can be used to read files that have been written with the SIO
/// backend.
///
/// The SIOReader provides the data as SIOFrameData from which a podio::Frame
/// can be constructed. It can be used to read files written by the SIOWriter.
class SIOReader : public ReaderCommon {

public:
  /// Create an SIOReader
  SIOReader();
  /// SIOReader destructor
  ~SIOReader() = default;

  /// The SIOReader is not copy-able
  SIOReader(const SIOReader&) = delete;
  /// The SIOReader is not copy-able
  SIOReader& operator=(const SIOReader&) = delete;

  /// Read the next data entry for a given category.
  ///
  /// @note Given how the SIO files are currently laid out it is in fact not
  /// possible to only read a subset of a Frame. Rather the subset of
  /// collections to read will be an artificial limit on the returned
  /// SIOFrameData. Limiting the collections to read will not improve I/O
  /// performance.
  ///
  /// @param name The category name for which to read the next entry
  /// @param collsToRead (optional) the collection names that should be read. If
  ///             not provided (or empty) all collections will be read
  ///
  /// @returns FrameData from which a podio::Frame can be constructed if the
  ///          category exists and if there are still entries left to read.
  ///          Otherwise a nullptr
  std::unique_ptr<podio::SIOFrameData> readNextEntry(std::string_view name,
                                                     const std::vector<std::string>& collsToRead = {});

  /// Read the desired data entry for a given category.
  ///
  /// @note Given how the SIO files are currently laid out it is in fact not
  /// possible to only read a subset of a Frame. Rather the subset of
  /// collections to read will be an artificial limit on the returned
  /// SIOFrameData. Limiting the collections to read will not improve I/O
  /// performance.
  ///
  /// @param name  The category name for which to read the next entry
  /// @param entry The entry number to read
  /// @param collsToRead (optional) the collection names that should be read. If
  ///             not provided (or empty) all collections will be read
  ///
  /// @returns FrameData from which a podio::Frame can be constructed if the
  ///          category and the desired entry exist. Otherwise a nullptr
  std::unique_ptr<podio::SIOFrameData> readEntry(std::string_view name, const unsigned entry,
                                                 const std::vector<std::string>& collsToRead = {});

  /// Get the number of entries for the given name
  ///
  /// @param name The name of the category
  ///
  /// @returns The number of entries that are available for the category
  unsigned getEntries(std::string_view name) const;

  /// Open the passed file for reading.
  ///
  /// @param filename The path to the file to read from
  void openFile(const std::string& filename);

private:
  void readPodioHeader();

  /// read the TOC record
  bool readFileTOCRecord();

  void readEDMDefinitions();

  sio::ifstream m_stream{}; ///< The stream from which we read

  /// Count how many times each an entry of this name has been read already
  std::unordered_map<std::string, unsigned> m_nameCtr{};

  /// Table of content record where starting points of named entries can be read from
  SIOFileTOCRecord m_tocRecord{};
};

} // namespace podio

#endif // PODIO_SIOREADER_H
