// Copyright 2024, Jefferson Science Associates, LLC.
// Subject to the terms in the LICENSE file found in the top-level directory.


#include "JANA/JEventProcessor.h"
#include <JANA/Topology/JMapArrow.h>

#include <JANA/JEventSource.h>
#include <JANA/JEventUnfolder.h>
#include <JANA/JEvent.h>


JMapArrow::JMapArrow(std::string name, JEventLevel level) {
    SetName(name);
    SetIsParallel(true);
    AddPort("in", level, PortDirection::In);
    AddPort("out", level, PortDirection::Out);
}

void JMapArrow::SetParallelSource(bool is_parallel) {
    m_parallel_source = is_parallel;
}

void JMapArrow::AddUnfolder(JEventUnfolder* unfolder) {
    m_unfolders.push_back(unfolder);
}

void JMapArrow::AddFolder(JEventFolder* folder) {
    m_folders.push_back(folder);
}

void JMapArrow::AddProcessor(JEventProcessor* processor) {
    m_procs.push_back(processor);
}

void JMapArrow::Fire(JEvent* event, OutputData& outputs, size_t& output_count, JArrow::FireResult& status) {

    LOG_DEBUG(m_logger) << "Executing arrow " << GetName() << " for event# " << event->GetEventNumber() << LOG_END;
    if (m_parallel_source) {
        auto* source = event->GetJEventSource();
        if (source != nullptr) {
            JCallGraphEntryMaker cg_entry(*event->GetJCallGraphRecorder(), source->GetTypeName()); // times execution until this goes out of scope
            event->GetJEventSource()->ProcessParallel(*event);
        }
    }
    for (JEventUnfolder* unfolder : m_unfolders) {
        JCallGraphEntryMaker cg_entry(*event->GetJCallGraphRecorder(), unfolder->GetTypeName()); // times execution until this goes out of scope
        unfolder->DoPreprocess(*event);
    }
    for (JEventProcessor* processor : m_procs) {
        JCallGraphEntryMaker cg_entry(*event->GetJCallGraphRecorder(), processor->GetTypeName()); // times execution until this goes out of scope
        if (processor->GetCallbackStyle() == JEventProcessor::CallbackStyle::LegacyMode) {
            processor->DoLegacyProcess(event->shared_from_this());
        }
        else {
            processor->DoMap(*event);
        }
    }
    LOG_DEBUG(m_logger) << "Executed arrow " << GetName() << " for event# " << event->GetEventNumber() << LOG_END;
    outputs[0] = {event, 1};
    output_count = 1;
    status = JArrow::FireResult::KeepGoing;
}

void JMapArrow::Initialize() {
    LOG_DEBUG(m_logger) << "Initializing arrow '" << GetName() << "'" << LOG_END;
    for (auto processor : m_procs) {
        if (processor->GetCallbackStyle() == JEventProcessor::CallbackStyle::LegacyMode) {
            LOG_DEBUG(m_logger) << "Initializing JEventProcessor '" << processor->GetTypeName() << "'" << LOG_END;
            processor->DoInit();
            LOG_INFO(m_logger) << "Initialized JEventProcessor '" << processor->GetTypeName() << "'" << LOG_END;
        }
    }
    LOG_DEBUG(m_logger) << "Initialized arrow '" << GetName() << "'" << LOG_END;
}

void JMapArrow::Finalize() {
    LOG_DEBUG(m_logger) << "Finalizing arrow '" << GetName() << "'" << LOG_END;
    for (auto processor : m_procs) {
        if (processor->GetCallbackStyle() == JEventProcessor::CallbackStyle::LegacyMode) {
            LOG_DEBUG(m_logger) << "Finalizing JEventProcessor " << processor->GetTypeName() << LOG_END;
            processor->DoFinalize();
            LOG_INFO(m_logger) << "Finalized JEventProcessor " << processor->GetTypeName() << LOG_END;
        }
    }
    LOG_DEBUG(m_logger) << "Finalized arrow " << GetName() << LOG_END;
}

