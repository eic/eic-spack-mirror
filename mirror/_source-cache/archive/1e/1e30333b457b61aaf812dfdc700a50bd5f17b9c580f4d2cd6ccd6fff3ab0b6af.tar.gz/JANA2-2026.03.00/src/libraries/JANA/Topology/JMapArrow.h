// Copyright 2024, Jefferson Science Associates, LLC.
// Subject to the terms in the LICENSE file found in the top-level directory.

#pragma once

#include <JANA/Topology/JArrow.h>

class JEventPool;
class JEventSource;
class JEventUnfolder;
class JEventFolder;
class JEventProcessor;
class JEvent;


class JMapArrow : public JArrow {

public:
    enum PortIndex {EVENT_IN=0, EVENT_OUT=1};

private:
    bool m_parallel_source = false;
    std::vector<JEventUnfolder*> m_unfolders;
    std::vector<JEventFolder*> m_folders;
    std::vector<JEventProcessor*> m_procs;

public:
    JMapArrow(std::string name, JEventLevel level);

    void SetParallelSource(bool is_parallel);
    void AddUnfolder(JEventUnfolder* unfolder);
    void AddFolder(JEventFolder* folder);
    void AddProcessor(JEventProcessor* proc);

    void Fire(JEvent* input, OutputData& outputs, size_t& output_count, JArrow::FireResult& status);

    void Initialize() final;
    void Finalize() final;
};

