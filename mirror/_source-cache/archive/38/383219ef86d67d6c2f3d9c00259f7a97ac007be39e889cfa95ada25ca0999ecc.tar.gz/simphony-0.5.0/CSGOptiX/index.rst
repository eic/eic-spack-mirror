CSGOptiX : expt with OptiX 7 geometry and rendering 
======================================================


TODO
-----

* cxr paths need to have the digest in them 
* cxs paths need to keep the digest at pub stage 


3D render scripts using the OptiX 7+ CSG/CSGOptiX machinery
-----------------------------------------------------------

cxr.sh
    script that runs the CSGOptiXRenderTest executable
    this is a basis script that most of the below scripts invoke after setting controlling envvars 

    [not intended to be used bare, this script is invoked from other scripts]

cxr_min.sh 
    minimal variant using CSGOptixRdrTest executable which just invokes CSGOptiX::RenderMain 
    [tested Jun 2023]

cxr_overview.sh
    overview viewpoint by targeting the entire geomery  
    uses envvar MOI=-1 to set an overview viewpoint intended to see the entire geometry
    principal controls are EMM envvar for excluding/selecting solids  

    CSGFoundry::parseMOI/CSGName::parseMOI parses MOI string eg sWorld:0:0 into three integers:
    (export CSGName=INFO to see whats happening)

    Midx 
       mesh index (equivalent for Geant4 LV index or Solid index, selecting a shape) 
    mOrd
       mesh ordinal (when more than one such mesh in geometry this is used to select one of them)
    Iidx 
       instance index      

    [tested Jun 2023]

cxr_scan.sh
    runs one of the other scripts (default cxr_overview.sh) multiple times with different values
    for the EMM envvar which is picked up by the basis cxr.sh script and fed to the executable
    via the "-e" option which is short for --enabledmergedmesh which feeds into a bitset 
    queryable by Opticks::isEnabledMergedMesh  

    [tested Jun 2023]

cxr_table.sh
    rst table creation using snap.py 

    one of the input arguments is a glob pattern that identifies a set of .jpg renders
    which are expected to have .json metadata sidecars 

    the data for the table is collected from .json metadata sidecars to .jpg renders, 
    so this works on laptop after grabbing the rendered .jpg and .json sidecars
    
    [tested Dec 2021]

cxr_solid.sh
    single solid render, for example  ./cxr_solid.sh r0@
    NB here solid is in the CSGSolid sense which corresponds to a GMergedMesh

    The SLA envvar set by the script is passed into the executable via option --solid_label
    which is accessed from Opticks::getSolidLabel within CSGOptiX/tests/CSGOptiXRender.cc
    which uses CSGFoundry::findSolidIdx to select one or more solids based on the solid_label 

    [tested Dec 2021]

cxr_solids.sh
    multiple invokations of cxr_solid.sh for different solids, 
    currently using seq 0 9 for running all JUNO solids::
 
       ./cxr_solid.sh r0@
       ./cxr_solid.sh r1@
       ...

    [tested Dec 2021]

cxr_view.sh
    sets MOI viewpoint (sWaterTube) deep within geometry and invokes ./cxr.sh 

    [tested Jun 2023]

cxr_views.sh
    multiple invokations of cxr_view.sh varying EMM to change included geometry

    [tested Dec 2021]



cxr_flight.sh
    creates sequence of jpg snaps and puts them together into mp4 
 
    TODO: compare with ../bin/flight7.sh AND MERGE OR REMOVE ONE 

../bin/flight7.sh 

    looks to be an update to flight.sh but using the OptiX 7 executable CSGOptiXFlight

    TODO: this is setting CFBASE, that is no longer the way to pick standard geometry 

Flight path rendering should use the CSGOptiX render scripts.






cxr_demo.sh
    renders Demo CSGFoundry geometry created by::

        cd ~/CSG        # c 
        ./CSGDemoTest.sh  

    [tested Dec 2021]

cxr_demos.sh
    perl grabs all geometry names from ../CSG/CSGDemoTest.sh   
    and then runs cxr_demo.sh on every one of them 


cxr_geochain.sh
    renders geometry created by the GeoChain executable that can be 
    anything from a single node to an entire detector geometry 

    This geometry is identified by CFNAME which cxr.sh uses
    for form an override CFBASE envvar /tmp/$USER/opticks/${CFNAME} 





cxr_pub.sh
    pub.py promotes from SRC_BASE=/tmp/$USER/opticks/CSGOptiX/CSGOptiXRender into presentation repo 

cxr_rsync.sh
    SUSPECT HAVE REPLACED USE OF THIS WITH THE MORE CONTROLLABLE pub.py APPROACH see cxr_pub.sh 



2D render scripts
-------------------------

cxs.sh [run/ana/]

    Two modes:

    *run* 
         (default mode on Linux) 
         invokes CSGOptiXSimulateTest executable
    *ana* 
         (local analysis mode, does not work remotely due to matplotlib/pyvista graphics)
         invokes tests/CSGOptiXSimulateTest.py script
         which uses matplotlib and/or pyvista to create mostly 2D geometry
         plots of the positions of intersects onto geometry    

    The *run* and *ana* are often invoked on different machines after *cxs_grab.sh* has
    been used to get the .npy results of *run* onto the local machine.


cxs_grab.sh
    rsyncs from OPTICKS_KEYDIR_GRABBED/CSG_GGeo into local geocache dirs

cxsd.sh
    runs cxs.sh with GDB envvar defined to switch on gdb

cxs_pub.sh
    pub.py promotes from the below SRC_BASE into presentation repo::

         $HOME/$opticks_keydir_grabbed/CSG_GGeo/CSGOptiXSimulateTest 
    
    Shell commands are emitted to stdout that copy images around. 
    Also s5 text is generated for copy/pasting into presentations::

        ./cxs_pub.sh cp | grep uni_acrylic | sh 
        ./cxs_pub.sh s5 | grep uni_acrylic  



admin scripts relevant to both cxs and cxr 
----------------------------------------------

grab.sh 
    rsync .jpg .png .mp4 .json etc.. outputs from P:/tmp/blyth/opticks/CSGOptiX/ to local (eg laptop)::

        cx 
        ./grab.sh  

sync.sh
    sync PWD code to top level remote in directory of same name 
    RSYNC : USE CAREFULLY  

cf.sh
    find commands for manually comparison of renders  

CSGOptiXSimulate
-----------------

* requires OPTICKS_KEYDIR envvar (+OPTICKS_KEY?) pointing to a recent geocache with LS_ori material 

scratch workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CSGOptiX::prepareSimulateParam

1. upload gensteps
2. create seeds from the gensteps (QSeed)
3. set gensteps, seeds, photons refs in Params 

4. OptiX launch
5. download photons

code
-------

tests/CSGOptiXRender.cc
    main that loads and uploads CSGFoundry geometry and creates 
    one or more renders and saves them to jpg   

CSGOptiX.h
    top level struct holding PIP and SBT instances which handle the OptiX geometry

Params.h
    workhorse for communicating between CPU and GPU 

Frame.h
    render pixels holder  

BI.h
    wrapper for OptixBuildInput 
AS.h
    common acceleration structure base struct for GAS and IAS
GAS.h
    bis vector of BI build inputs 
IAS.h
    vector of transforms and d_instances 

GAS_Builder.h
    building OptiX geometry acceleration structure, 
    canonical usage from SBT::createGAS

IAS_Builder.h
    building OptiX instance acceleration structure, 
    canonical usage from SBT::createIAS

Binding.h
    GPU/CPU types, including SbtRecord : RaygenData, MissData, HitGroupData (effectively Prim)

PIP.h
    OptiX render pipeline creation from ptx file

CSGOptiX7.cu
    compiled into ptx that gets loaded by PIP to create the GPU pipeline, with OptiX 7 entry points::
    
    __raygen__rg
    __miss__ms
    __intersection__is
    __closesthit__ch 

SBT.h
    brings together OptiX 7 geometry and render pipeline programs, nexus of control  

    * SBT::setFoundry SBT::createGeom converts the CSGFoundy geometry into an OptiX geometry

Ctx.h
    holder of OptixDeviceContext and Params and Properties instances

Properties.h
    holder of information gleaned from OptiX 7

InstanceId.h
    encode/decode identity info

OPTIX_CHECK.h
    error check macro for optix 7 calls
