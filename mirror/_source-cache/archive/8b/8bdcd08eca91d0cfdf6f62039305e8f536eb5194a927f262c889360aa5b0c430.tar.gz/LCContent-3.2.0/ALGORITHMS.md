# LCContent Algorithm Set for EIC

This document describes the minimal working algorithm set adapted for EIC (Electron-Ion Collider) particle flow reconstruction.

## Philosophy

The EIC minimal set focuses on **core particle flow reconstruction** algorithms needed for basic physics analysis:
- Event input preparation and calibration
- Calorimeter clustering
- Track-cluster association
- Particle identification (muon, electron, photon)
- Particle Flow Object (PFO) construction

Advanced algorithms for performance optimization and specialized physics cases have been disabled to reduce compilation time and library size. These can be re-enabled and adapted for EIC as needed.

## Enabled Algorithm Modules

### LCUtility (6 algorithms)
**Purpose**: Input data preparation and calibration  
**Status**: ✅ **ENABLED** - Essential for all reconstruction

Algorithms:
- `EventPreparation` - Event-level initialization
- `CaloHitPreparation` - Calorimeter hit calibration and organization
- `TrackPreparation` - Track input preparation and validation
- `ClusterPreparation` - Cluster input preparation
- `PfoPreparation` - PFO input preparation
- `TrainingSoftwareCompensation` - Software compensation training

**Rationale**: These algorithms prepare input data and are required by all downstream algorithms.

---

### LCClustering (3 algorithms)
**Purpose**: Basic calorimeter clustering  
**Status**: ✅ **ENABLED** - Core functionality

Algorithms:
- `ClusteringParent` - Parent algorithm coordinating clustering
- `ConeClustering` - Cone-based clustering algorithm
- `ForcedClustering` - Forced clustering for special cases

**Rationale**: Essential for creating calorimeter clusters from hits. EIC calorimeters (imaging + scintillator) require clustering.

---

### LCTrackClusterAssociation (5 algorithms)
**Purpose**: Match tracks to calorimeter clusters  
**Status**: ✅ **ENABLED** - Essential for particle flow

Algorithms:
- `TrackClusterAssociation` - Main track-cluster matching
- `TrackRecovery` - Recover tracks that failed initial matching
- `TrackRecoveryHelix` - Helix-based track recovery
- `TrackRecoveryInteractions` - Account for hadronic interactions
- `LoopingTrackAssociation` - Handle looping tracks in magnetic field

**Rationale**: Track-cluster association is the foundation of particle flow. EIC's tracking detectors and calorimeters require accurate matching.

---

### LCParticleId (5 algorithms)
**Purpose**: Particle identification and classification  
**Status**: ✅ **ENABLED** - Essential for physics

Algorithms:
- `FinalParticleId` - Final particle type assignment
- `MuonReconstruction` - Identify and reconstruct muons
- `PhotonReconstruction` - Identify and reconstruct photons
- `PhotonRecovery` - Recover missed photons
- `PhotonSplitting` - Split merged photon clusters

**Rationale**: Particle ID is critical for EIC physics (e.g., electron ID, hadron separation). These algorithms provide basic PID capabilities.

---

### LCPfoConstruction (3 algorithms)
**Purpose**: Build Particle Flow Objects from clusters and tracks  
**Status**: ✅ **ENABLED** (3/4 algorithms) - Essential for output

Algorithms:
- `PfoCreation` - Create PFOs from matched tracks and clusters
- `PfoCreationParent` - Parent algorithm coordinating PFO creation
- `V0PfoCreation` - Create PFOs for V0 decays (K_s, Lambda)

**Rationale**: PFOs are the final output of particle flow reconstruction. V0 reconstruction is important for EIC physics.

**Note**: `CLICPfoSelectionAlgorithm` was **disabled** as it is CLIC-specific.

---

### LCPlugins (6 plugins)
**Purpose**: Detector-specific functions (geometry, energy corrections, B-field)  
**Status**: ✅ **ENABLED** - Required infrastructure

Plugins:
- `LCBFieldPlugin` - Magnetic field map
- `LCPseudoLayerPlugin` - Geometry layer mapping
- `LCShowerProfilePlugin` - Shower profile calculations
- `LCEnergyCorrectionPlugins` - Energy calibration and corrections
- `LCParticleIdPlugins` - Particle ID helper functions
- `LCSoftwareCompensation` - Software compensation energy correction

**Rationale**: These plugins provide detector-specific functions that algorithms depend on. They can be configured for EIC detector geometry.

---

### LCHelpers (4 helper classes)
**Purpose**: Utility functions used by multiple algorithms  
**Status**: ✅ **ENABLED** - Supporting infrastructure

Helpers:
- `ClusterHelper` - Cluster manipulation utilities
- `FragmentRemovalHelper` - Geometry and distance calculations
- `ReclusterHelper` - Track-cluster compatibility functions
- `SortingHelper` - Sorting and ordering utilities

**Rationale**: These helpers are used by enabled algorithms (especially track-cluster association and plugins). They contain geometry calculations that work for barrel+endcap detectors like EIC.

---

### LCObjects
**Purpose**: Data structure definitions  
**Status**: ✅ **ENABLED** - Header-only library

**Rationale**: Contains shared data structures and constants used throughout LCContent.

---

## Disabled Algorithm Modules

### LCCheating (6 algorithms) - ❌ **DISABLED**
**Purpose**: MC-truth-based "perfect" algorithms for validation  

**Rationale**: 
- Used only for algorithm development and testing
- Not needed for production reconstruction
- Requires MC truth information not always available
- Can be re-enabled for development as needed

---

### LCPersistency (2 algorithms) - ❌ **DISABLED**
**Purpose**: Event I/O in linear collider specific formats  

**Rationale**:
- Designed for ILC/CLIC event formats
- EIC uses different I/O (e.g., eicrecon framework, PODIO)
- Event I/O is handled externally to LCContent

---

### LCMonitoring (4 algorithms) - ❌ **DISABLED**
**Purpose**: Visualization, debugging, and diagnostic tools  

**Rationale**:
- Not needed for production reconstruction
- Adds build dependencies (ROOT graphics)
- Can be re-enabled for debugging specific issues

---

### LCFragmentRemoval (8 algorithms) - ❌ **DISABLED**
**Purpose**: Advanced fragment cleanup and photon merging  

**Rationale**:
- Contains `BeamHaloMuonRemoval` specific to linear collider beam backgrounds
- Advanced photon fragment algorithms are optimization, not essential
- EIC beam backgrounds differ from lepton colliders
- Can be adapted and re-enabled after basic reconstruction works

---

### LCReclustering (7 algorithms) - ❌ **DISABLED**
**Purpose**: Advanced track-driven re-clustering  

**Rationale**:
- Performance optimization beyond basic particle flow
- Adds complexity before basic reconstruction is validated
- Can be re-enabled to improve energy resolution after initial commissioning

---

### LCTopologicalAssociation (16 algorithms) - ❌ **DISABLED**
**Purpose**: Advanced topological cluster merging and splitting  

**Rationale**:
- Largest module with 16 algorithms
- Performance optimization for complex event topologies
- Not essential for basic particle flow
- Designed for e+e- collider event topologies (back-to-back jets)
- EIC event topologies differ (forward-boosted particles, remnant jet)
- Can be adapted algorithm-by-algorithm as needed after basic reconstruction works

---

## Summary Statistics

| Category | Kept | Disabled | Total |
|----------|------|----------|-------|
| **Core Algorithms** | 22 | 0 | 22 |
| **Advanced Algorithms** | 0 | 35 | 35 |
| **Utility/Helpers** | 7 | 0 | 7 |
| **MC-Truth/Debug** | 0 | 10 | 10 |
| **Plugins** | 6 | 0 | 6 |
| **Total** | **35** | **45** | **80** |

**Note**: This includes algorithms, plugins, and helper classes. Pure header files (LCObjects) not counted.

## Build Impact

- **Original LCContent**: ~79 .cc files, ~82 header files
- **EIC Minimal Set**: ~34 .cc files, ~37 header files  
- **Reduction**: ~57% fewer files to compile

## Future Re-enablement Strategy

When re-enabling disabled modules:

1. **Start with LCReclustering** - Most likely to improve performance without major adaptation
2. **Add LCTopologicalAssociation algorithms selectively** - Test one at a time for EIC benefit
3. **Adapt LCFragmentRemoval** - Requires understanding EIC-specific backgrounds
4. **Keep LCCheating disabled** - Only enable for algorithm development
5. **Keep LCPersistency disabled** - EIC has its own I/O
6. **Keep LCMonitoring disabled** - Enable only for specific debugging

## EIC-Specific Considerations

### Geometry Differences
- **Linear Colliders**: Symmetric barrel + endcaps
- **EIC**: Asymmetric detector (forward/backward different)
- **Impact**: Algorithms using geometry assumptions may need tuning

### Energy Scale
- **Linear Colliders**: 250-3000 GeV center-of-mass
- **EIC**: 10-100 GeV typical particle energies
- **Impact**: Energy thresholds and calibrations need adjustment

### Event Topology
- **Linear Colliders**: Back-to-back jets, low multiplicity
- **EIC**: Forward-boosted particles, remnant jets, high forward multiplicity
- **Impact**: Topological algorithms may need adaptation

### Detector Technology
- **EIC ECAL Barrel**: Dual-readout (imaging + scintillating fiber)
- **EIC Hadron Endcaps**: Different from LC HCALs
- **Impact**: Clustering and energy correction parameters need tuning

## Algorithm Registration

All enabled algorithms are registered in `src/LCContent.cc` via the `LC_ALGORITHM_LIST` macro. To use an algorithm in XML steering files:

```xml
<algorithm type="TrackClusterAssociation">
  <!-- algorithm parameters -->
</algorithm>
```

See Pandora documentation for algorithm-specific parameters.
