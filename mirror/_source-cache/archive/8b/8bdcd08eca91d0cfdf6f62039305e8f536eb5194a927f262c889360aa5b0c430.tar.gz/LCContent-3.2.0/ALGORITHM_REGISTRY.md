# EIC LCContent Algorithm Registry

This document lists all algorithm names as registered with Pandora for use in XML configuration files.

## Usage in XML

In Pandora XML steering files, use the **Registered Name** in the `type` attribute:

```xml
<algorithm type="ConeClustering">
  <ShouldUseIsolatedHits>true</ShouldUseIsolatedHits>
  <!-- other parameters -->
</algorithm>
```

## Complete Algorithm List (23 algorithms)

| Registered Name | C++ Class Name | Module | Purpose |
|-----------------|----------------|--------|---------|
| `ClusteringParent` | `ClusteringParentAlgorithm` | LCClustering | Parent algorithm coordinating clustering |
| `ConeClustering` | `ConeClusteringAlgorithm` | LCClustering | Cone-based calorimeter clustering |
| `ForcedClustering` | `ForcedClusteringAlgorithm` | LCClustering | Forced clustering for special cases |
| `FinalParticleId` | `FinalParticleIdAlgorithm` | LCParticleId | Final particle type assignment |
| `MuonReconstruction` | `MuonReconstructionAlgorithm` | LCParticleId | Muon identification and reconstruction |
| `PhotonReconstruction` | `PhotonReconstructionAlgorithm` | LCParticleId | Photon identification and reconstruction |
| `PhotonRecovery` | `PhotonRecoveryAlgorithm` | LCParticleId | Recover missed photons |
| `PhotonSplitting` | `PhotonSplittingAlgorithm` | LCParticleId | Split merged photon clusters |
| `PfoCreation` | `PfoCreationAlgorithm` | LCPfoConstruction | Create PFOs from tracks and clusters |
| `PfoCreationParent` | `PfoCreationParentAlgorithm` | LCPfoConstruction | Parent algorithm for PFO creation |
| `V0PfoCreation` | `V0PfoCreationAlgorithm` | LCPfoConstruction | Create PFOs for V0 decays (K_s, Lambda) |
| `LoopingTrackAssociation` | `LoopingTrackAssociationAlgorithm` | LCTrackClusterAssociation | Handle looping tracks in B-field |
| `TrackClusterAssociation` | `TrackClusterAssociationAlgorithm` | LCTrackClusterAssociation | Main track-cluster matching |
| `TrackRecovery` | `TrackRecoveryAlgorithm` | LCTrackClusterAssociation | Recover failed track matches |
| `TrackRecoveryHelix` | `TrackRecoveryHelixAlgorithm` | LCTrackClusterAssociation | Helix-based track recovery |
| `TrackRecoveryInteractions` | `TrackRecoveryInteractionsAlgorithm` | LCTrackClusterAssociation | Account for hadronic interactions |
| `CaloHitPreparation` | `CaloHitPreparationAlgorithm` | LCUtility | Prepare calorimeter hits |
| `ClusterPreparation` | `ClusterPreparationAlgorithm` | LCUtility | Prepare cluster inputs |
| `EventPreparation` | `EventPreparationAlgorithm` | LCUtility | Event-level initialization |
| `PfoPreparation` | `PfoPreparationAlgorithm` | LCUtility | Prepare PFO inputs |
| `TrackPreparation` | `TrackPreparationAlgorithm` | LCUtility | Prepare track inputs |
| `TrainingSoftwareCompensation` | `TrainingSoftwareCompensation` | LCUtility | Software compensation training |

## Typical XML Algorithm Chain for EIC

A minimal working chain might look like:

```xml
<pandora>
  <!-- Input preparation -->
  <algorithm type="EventPreparation"/>
  <algorithm type="TrackPreparation"/>
  <algorithm type="CaloHitPreparation"/>
  
  <!-- Clustering -->
  <algorithm type="ConeClustering">
    <ShouldUseIsolatedHits>true</ShouldUseIsolatedHits>
    <ShouldUseOnlyECalHits>false</ShouldUseOnlyECalHits>
    <!-- Add parameters here -->
  </algorithm>
  
  <!-- Track-cluster association -->
  <algorithm type="TrackClusterAssociation">
    <!-- Add parameters here -->
  </algorithm>
  
  <!-- Particle ID -->
  <algorithm type="MuonReconstruction"/>
  <algorithm type="PhotonReconstruction"/>
  
  <!-- PFO creation -->
  <algorithm type="PfoCreation">
    <!-- Add parameters here -->
  </algorithm>
</pandora>
```

## Parent Algorithms

Some algorithms are "parent" algorithms that coordinate multiple sub-algorithms:
- `ClusteringParent` - Manages clustering workflow
- `PfoCreationParent` - Manages PFO creation workflow

These typically invoke other algorithms internally and are useful for complex workflows.

## Plugin Registration

Plugins are registered separately via C++ API calls (not in XML):
- `LCBFieldPlugin` - Magnetic field map
- `LCPseudoLayerPlugin` - Geometry layer mapping  
- `LCShowerProfilePlugin` - Shower profile calculations
- Energy correction plugins (registered by name)
- Particle ID plugins (registered by name)

See `LCContent::RegisterBasicPlugins()` and `LCContent::RegisterBFieldPlugin()` in `include/LCContent.h`.

## Source Reference

The registration macro is defined in `src/LCContent.cc` lines 56-78:

```cpp
#define LC_ALGORITHM_LIST(d)                                   \
  d("RegisteredName", CppClassName)                            \
  ...
```

The first parameter is the registered name used in XML, the second is the C++ class.
