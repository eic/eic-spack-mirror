# LCContent (EIC Branch)

Pandora algorithms and tools for EIC (Electron-Ion Collider) event reconstruction

**This is a minimal working set adapted from the original LCContent for lepton colliders.**

## EIC Adaptation

This branch contains a reduced algorithm set optimized for EIC particle flow reconstruction:
- **Essential algorithms retained**: Clustering, track-cluster association, particle ID, PFO construction, and utilities
- **Non-essential algorithms disabled**: MC-truth algorithms, monitoring, advanced topological associations, and linear-collider-specific modules
- **Build time reduced**: Compilation now covers ~23 algorithms instead of 70+

See [ALGORITHMS.md](ALGORITHMS.md) for details on which algorithms are included and which are disabled.

## Original LCContent

LCContent was originally designed for Lepton Collider (ILC/CLIC) event reconstruction and contains comprehensive Pandora particle flow algorithms.

LCContent is distributed under the [GPLv3 License](http://www.gnu.org/licenses/gpl-3.0.en.html)

[![License](https://www.gnu.org/graphics/gplv3-127x51.png)](https://www.gnu.org/licenses/gpl-3.0.en.html)

## License and Copyright
Copyright (C), LCContent Authors

LCContent is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
