/**
 *  @file   LCContent/src/LCContent.cc
 *
 *  @brief  Factory implementations for content intended for use with particle flow reconstruction at EIC
 *          (Electron-Ion Collider). Adapted from LCContent for lepton colliders.
 *
 *  $Log: $
 */

#include "Pandora/Algorithm.h"
#include "Pandora/Pandora.h"

// Core clustering algorithms
#include "LCClustering/ClusteringParentAlgorithm.h"
#include "LCClustering/ConeClusteringAlgorithm.h"
#include "LCClustering/ForcedClusteringAlgorithm.h"

// Particle identification algorithms
#include "LCParticleId/FinalParticleIdAlgorithm.h"
#include "LCParticleId/MuonReconstructionAlgorithm.h"
#include "LCParticleId/PhotonReconstructionAlgorithm.h"
#include "LCParticleId/PhotonRecoveryAlgorithm.h"
#include "LCParticleId/PhotonSplittingAlgorithm.h"

// PFO construction algorithms
#include "LCPfoConstruction/PfoCreationAlgorithm.h"
#include "LCPfoConstruction/PfoCreationParentAlgorithm.h"
#include "LCPfoConstruction/V0PfoCreationAlgorithm.h"

// Plugins for detector-specific functions
#include "LCPlugins/LCBFieldPlugin.h"
#include "LCPlugins/LCEnergyCorrectionPlugins.h"
#include "LCPlugins/LCParticleIdPlugins.h"
#include "LCPlugins/LCPseudoLayerPlugin.h"
#include "LCPlugins/LCShowerProfilePlugin.h"
#include "LCPlugins/LCSoftwareCompensation.h"

// Track-cluster association algorithms
#include "LCTrackClusterAssociation/LoopingTrackAssociationAlgorithm.h"
#include "LCTrackClusterAssociation/TrackClusterAssociationAlgorithm.h"
#include "LCTrackClusterAssociation/TrackRecoveryAlgorithm.h"
#include "LCTrackClusterAssociation/TrackRecoveryHelixAlgorithm.h"
#include "LCTrackClusterAssociation/TrackRecoveryInteractionsAlgorithm.h"

// Utility algorithms for input preparation
#include "LCUtility/CaloHitPreparationAlgorithm.h"
#include "LCUtility/ClusterPreparationAlgorithm.h"
#include "LCUtility/EventPreparationAlgorithm.h"
#include "LCUtility/PfoPreparationAlgorithm.h"
#include "LCUtility/TrackPreparationAlgorithm.h"
#include "LCUtility/TrainingSoftwareCompensation.h"

#include "LCContent.h"

// Macro defining the minimal EIC algorithm set
#define LC_ALGORITHM_LIST(d)                                                                                               \
  d("ClusteringParent", ClusteringParentAlgorithm)                                                                         \
      d("ConeClustering", ConeClusteringAlgorithm)                                                                         \
      d("ForcedClustering", ForcedClusteringAlgorithm)                                                                     \
      d("FinalParticleId", FinalParticleIdAlgorithm)                                                                       \
      d("MuonReconstruction", MuonReconstructionAlgorithm)                                                                 \
      d("PhotonReconstruction", PhotonReconstructionAlgorithm)                                                             \
      d("PhotonRecovery", PhotonRecoveryAlgorithm)                                                                         \
      d("PhotonSplitting", PhotonSplittingAlgorithm)                                                                       \
      d("PfoCreation", PfoCreationAlgorithm)                                                                               \
      d("PfoCreationParent", PfoCreationParentAlgorithm)                                                                   \
      d("V0PfoCreation", V0PfoCreationAlgorithm)                                                                           \
      d("LoopingTrackAssociation", LoopingTrackAssociationAlgorithm)                                                       \
      d("TrackClusterAssociation", TrackClusterAssociationAlgorithm)                                                       \
      d("TrackRecovery", TrackRecoveryAlgorithm)                                                                           \
      d("TrackRecoveryHelix", TrackRecoveryHelixAlgorithm)                                                                 \
      d("TrackRecoveryInteractions", TrackRecoveryInteractionsAlgorithm)                                                   \
      d("CaloHitPreparation", CaloHitPreparationAlgorithm)                                                                 \
      d("ClusterPreparation", ClusterPreparationAlgorithm)                                                                 \
      d("EventPreparation", EventPreparationAlgorithm)                                                                     \
      d("PfoPreparation", PfoPreparationAlgorithm)                                                                         \
      d("TrackPreparation", TrackPreparationAlgorithm)                                                                     \
      d("TrainingSoftwareCompensation", TrainingSoftwareCompensation)

#define LC_ENERGY_CORRECTION_LIST(d)                                                                                   \
  d("CleanClusters", pandora::HADRONIC, lc_content::LCEnergyCorrectionPlugins::CleanCluster)                           \
      d("ScaleHotHadrons", pandora::HADRONIC, lc_content::LCEnergyCorrectionPlugins::ScaleHotHadrons)                  \
          d("MuonCoilCorrection", pandora::HADRONIC, lc_content::LCEnergyCorrectionPlugins::MuonCoilCorrection)

#define LC_PARTICLE_ID_LIST(d)                                                                                         \
  d("LCEmShowerId", lc_content::LCParticleIdPlugins::LCEmShowerId)                                                     \
      d("LCPhotonId", lc_content::LCParticleIdPlugins::LCPhotonId)                                                     \
          d("LCElectronId", lc_content::LCParticleIdPlugins::LCElectronId)                                             \
              d("LCMuonId", lc_content::LCParticleIdPlugins::LCMuonId)

#define FACTORY Factory

//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------

namespace lc_content {

#define LC_CONTENT_CREATE_ALGORITHM_FACTORY(a, b)                                                                      \
  class b##FACTORY : public pandora::AlgorithmFactory {                                                                \
  public:                                                                                                              \
    pandora::Algorithm* CreateAlgorithm() const { return new b; };                                                     \
  };

LC_ALGORITHM_LIST(LC_CONTENT_CREATE_ALGORITHM_FACTORY)

} // namespace lc_content

//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------

#define LC_CONTENT_REGISTER_ALGORITHM(a, b)                                                                            \
  {                                                                                                                    \
    const pandora::StatusCode statusCode(                                                                              \
        PandoraApi::RegisterAlgorithmFactory(pandora, a, new lc_content::b##FACTORY));                                 \
    if (pandora::STATUS_CODE_SUCCESS != statusCode)                                                                    \
      return statusCode;                                                                                               \
  }

pandora::StatusCode LCContent::RegisterAlgorithms(const pandora::Pandora& pandora) {
  LC_ALGORITHM_LIST(LC_CONTENT_REGISTER_ALGORITHM);
  return pandora::STATUS_CODE_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------------------------------

pandora::StatusCode LCContent::RegisterBasicPlugins(const pandora::Pandora& pandora) {
  LC_ENERGY_CORRECTION_LIST(PANDORA_REGISTER_ENERGY_CORRECTION);
  LC_PARTICLE_ID_LIST(PANDORA_REGISTER_PARTICLE_ID);

  PANDORA_RETURN_RESULT_IF(pandora::STATUS_CODE_SUCCESS, !=,
                           PandoraApi::SetPseudoLayerPlugin(pandora, new lc_content::LCPseudoLayerPlugin));
  PANDORA_RETURN_RESULT_IF(pandora::STATUS_CODE_SUCCESS, !=,
                           PandoraApi::SetShowerProfilePlugin(pandora, new lc_content::LCShowerProfilePlugin));

  return pandora::STATUS_CODE_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------------------------------

pandora::StatusCode LCContent::RegisterBFieldPlugin(const pandora::Pandora& pandora, const float innerBField,
                                                    const float muonBarrelBField, const float muonEndCapBField) {
  return PandoraApi::SetBFieldPlugin(pandora,
                                     new lc_content::LCBFieldPlugin(innerBField, muonBarrelBField, muonEndCapBField));
}

//------------------------------------------------------------------------------------------------------------------------------------------

pandora::StatusCode LCContent::RegisterNonLinearityEnergyCorrection(
    const pandora::Pandora& pandora, const std::string& name, const pandora::EnergyCorrectionType energyCorrectionType,
    const pandora::FloatVector& inputEnergyCorrectionPoints, const pandora::FloatVector& outputEnergyCorrectionPoints) {
  return PandoraApi::RegisterEnergyCorrectionPlugin(pandora, name, energyCorrectionType,
                                                    new lc_content::LCEnergyCorrectionPlugins::NonLinearityCorrection(
                                                        inputEnergyCorrectionPoints, outputEnergyCorrectionPoints));
}

//------------------------------------------------------------------------------------------------------------------------------------------

pandora::StatusCode LCContent::RegisterSoftwareCompensationEnergyCorrection(
    const pandora::Pandora& pandora, const std::string& name,
    const lc_content::LCSoftwareCompensationParameters& parameters) {
  return PandoraApi::RegisterEnergyCorrectionPlugin(pandora, name, pandora::HADRONIC,
                                                    new lc_content::LCSoftwareCompensation(parameters));
}
