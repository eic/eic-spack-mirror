# BEGIN PLOT /ALEPH_2002_I569165/d02-x01-y02
Title=$\eta$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT
# BEGIN PLOT /ALEPH_2002_I569165/d03-x01-y02
Title=$\omega$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT
