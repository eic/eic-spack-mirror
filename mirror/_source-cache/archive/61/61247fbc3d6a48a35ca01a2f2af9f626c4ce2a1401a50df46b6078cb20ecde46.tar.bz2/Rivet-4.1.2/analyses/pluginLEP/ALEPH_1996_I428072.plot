# BEGIN PLOT /ALEPH_1996_I428072/d01-x01-y01
Title=Sphericity, $S$ (charged)
XLabel=$S$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{S}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d02-x01-y01
Title=Aplanarity, $A$ (charged)
XLabel=$A$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{A}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d03-x01-y01
Title=1-Thrust, $1-T$ (charged)
XLabel=$1-T$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{(1-T)}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d04-x01-y01
Title=Thrust minor, $m$ (charged)
XLabel=$m$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{m}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d05-x01-y01
Title=Two-jet resolution variable, $Y_3$ (charged)
XLabel=$Y_3$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{Y_3}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d06-x01-y01
Title=Heavy jet mass (charged)
XLabel=$M_h^2/s$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{(M_h^2/s)}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d07-x01-y01
Title=$C$ parameter (charged)
XLabel=$C$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{C}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d08-x01-y01
Title=Oblateness, $M - m$ (charged)
XLabel=$O$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{O}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d09-x01-y01
Title=Scaled momentum, $x_p = |p|/|p_\mathrm{beam}|$ (charged)
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d10-x01-y01
Title=Rapidity w.r.t. thrust axes, $y_T$ (charged)
XLabel=$y_T$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{y_T}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d11-x01-y01
Title=In-plane $p_T$ in GeV w.r.t. sphericity axes (charged)
XLabel=$p_\perp^\mathrm{in}$ / GeV
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{in}}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d12-x01-y01
Title=Out-of-plane $p_T$ in GeV w.r.t. sphericity axes (charged)
XLabel=$p_\perp^\mathrm{out}$ / GeV
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{out}}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d17-x01-y01
Title=Log of scaled momentum, $\log(1/x_p)$ (charged)
XLabel=$\xi_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{\xi_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d18-x01-y01
Title=Charged multiplicity distribution
XLabel=$N_\mathrm{ch}$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}{N_\mathrm{ch}}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d19-x01-y01
Title=Mean charged multiplicity
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d20-x01-y01
Title=Mean charged multiplicity for rapidity $|Y| < 0.5$
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d21-x01-y01
Title=Mean charged multiplicity for rapidity $|Y| < 1.0$
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d22-x01-y01
Title=Mean charged multiplicity for rapidity $|Y| < 1.5$
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d23-x01-y01
Title=Mean charged multiplicity for rapidity $|Y| < 2.0$
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d25-x01-y01
Title=$\pi^\pm$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d26-x01-y01
Title=$K^\pm$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d27-x01-y01
Title=$p$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d28-x01-y01
Title=$\gamma$ spectrum
XLabel=$\xi_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{\xi_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d29-x01-y01
Title=$\pi^0$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d30-x01-y01
Title=$\eta$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d31-x01-y01
Title=$\eta^\prime$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d32-x01-y01
Title=$K^0$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d33-x01-y01
Title=$\Lambda^0$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d34-x01-y01
Title=$\Xi^-$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d35-x01-y01
Title=$\Sigma^\pm(1385)$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d36-x01-y01
Title=$\Xi^0(1530)$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d37-x01-y01
Title=$\rho$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d38-x01-y01
Title=$\omega(782)$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d39-x01-y01
Title=$K^{*0}(892)$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d40-x01-y01
Title=$\phi$ spectrum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d43-x01-y01
Title=$K^{*\pm}(892)$ spectrum
XLabel=$x_E$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}{x_E}$
FullRange=1
# END PLOT


# BEGIN PLOT /ALEPH_1996_I428072/d44-
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y02
Title=Mean $\pi^0$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y03
Title=Mean $\eta$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y04
Title=Mean $\eta^\prime$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y05
Title=Mean $K_S + K_L$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y06
Title=Mean $\rho^0$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y07
Title=Mean $\omega(782)$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y08
Title=Mean $\phi$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y09
Title=Mean $K^{*\pm}$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y10
Title=Mean $K^{*0}$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y11
Title=Mean $\Lambda$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y12
Title=Mean $\Sigma$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y13
Title=Mean $\Xi$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y14
Title=Mean $\Sigma(1385)$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y15
Title=Mean $\Xi(1530)$ multiplicity
# END PLOT

# BEGIN PLOT /ALEPH_1996_I428072/d44-x01-y16
Title=Mean $\Omega^\mp$ multiplicity
# END PLOT

