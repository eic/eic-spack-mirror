# BEGIN PLOT /L3_1992_I336180/d01-x01-y01
Title=The $x_p$ spectrum for inclusive $\eta$ production at the $Z^0$ resonance
XLabel=$x_p=p/p_{\mathrm{beam}}$
YLabel=$1/\sigma_h \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT

# BEGIN PLOT /L3_1992_I336180/d02-x01-y01
Title=The $\xi_p$ spectrum for inclusive $\eta$ production at the $Z^0$ resonance
XLabel=$\xi_p=ln(1/x_p)$
YLabel=$1/\sigma_h \, \mathrm{d}\sigma/\mathrm{d}\xi_p$
# END PLOT


