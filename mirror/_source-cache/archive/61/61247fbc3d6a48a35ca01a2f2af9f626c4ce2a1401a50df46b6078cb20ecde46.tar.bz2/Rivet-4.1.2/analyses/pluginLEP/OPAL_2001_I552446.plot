# BEGIN PLOT /OPAL_2001_I552446/d03-x01-y01
Title=Bengtsson-Zerwas angle (parton level)
XLabel=$|\cos(\chi_\mathrm{BZ})|$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}|\cos(\chi_\mathrm{BZ})|$
LogY=0
RatioPlotYMin=0.9
RatioPlotYMax=1.1
# END PLOT

# BEGIN PLOT /OPAL_2001_I552446/d04-x01-y01
Title=K\"{o}rner-Schierholz-Willrodt angle (parton level)
XLabel=$\cos(\phi_\mathrm{KSW})$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}\,\cos(\phi_\mathrm{KSW})$
LogY=0
RatioPlotYMin=0.9
RatioPlotYMax=1.1
# END PLOT

# BEGIN PLOT /OPAL_2001_I552446/d05-x01-y01
Title=Modified Nachtmann-Reiter angle (parton level)
XLabel=$|\cos(\theta^*_\mathrm{NR})|$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}|\cos(\theta^*_\mathrm{NR})|$
LogY=0
YMin=0.4
RatioPlotYMin=0.9
RatioPlotYMax=1.1
# END PLOT

# BEGIN PLOT /OPAL_2001_I552446/d06-x01-y01
Title=Angle between the two softest jets (parton level)
XLabel=$\cos(\alpha_{34})$
YLabel=$1/\sigma \, \mathrm{d}{\sigma}/\mathrm{d}\,\cos(\alpha_{34})$
LogY=0
RatioPlotYMin=0.9
RatioPlotYMax=1.1
# END PLOT
