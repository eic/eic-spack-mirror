{
  //// DD4hep 
  gSystem->Load("libActsCore.so");
  gSystem->Load("libActsDD4hepPlugin.so");
  gSystem->Load("libGenFind.so");
  gInterpreter->AddIncludePath("/opt/software/local/include");
  gInterpreter->AddIncludePath("/opt/software/local/include/DDG4");

}
