#include "HepMC3/GenEvent.h"
#include "HepMC3/ReaderAscii.h"
#include "HepMC3/WriterAsciiHepMC2.h"
#include "HepMC3/WriterRoot.h"
#include "HepMC3/Print.h"

#include <iostream>

using namespace HepMC3;

void test_hepmc(){

  //-------------------------------------
  WriterAsciiHepMC2 hepmc_output("test_hepmc.hepmc");
  int        events_parsed = 0;
  GenEvent   evt(Units::GEV, Units::MM);
  for (events_parsed = 0; events_parsed < 100; events_parsed++) {

    // type 4 is beam 
    GenParticlePtr p1 =
        std::make_shared<GenParticle>(FourVector(0.0, 0.0, 10.0, 10.0), 11, 4);
    GenParticlePtr p2 = std::make_shared<GenParticle>(FourVector(0.0, 0.0, 0.0, 0.938), 2212, 4);

    double pz_part = 0.1+events_parsed*0.1;
    // type 3 is beam 
    GenParticlePtr p3 =
        std::make_shared<GenParticle>(FourVector(0.1,0.1,pz_part, std::sqrt(pz_part*pz_part + 0.1*0.1*2) ), 11, 1);

    GenVertexPtr v1 = std::make_shared<GenVertex>();
    v1->add_particle_in(p1);
    v1->add_particle_in(p2);

    v1->add_particle_out(p3);
    evt.add_vertex(v1);

    if (events_parsed == 0) {
      std::cout << "First event: " << std::endl;
      Print::listing(evt);
    }

    hepmc_output.write_event(evt);
    if (events_parsed % 10 == 0) {
      std::cout << "Event: " << events_parsed << std::endl;
    }
    evt.clear();
  }
  hepmc_output.close();
  std::cout << "Events parsed and written: " << events_parsed << std::endl;
}


