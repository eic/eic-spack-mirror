#include "Math/Vector3D.h"
#include "Math/Vector4D.h"
#include "TCanvas.h"
#include "TLegend.h"
#include "TMath.h"
#include "TRandom3.h"
#include "TFile.h"
#include "TH1F.h"
#include "TH1D.h"
#include "TTree.h"
#include "TF1.h"

//#include "lcio2/MCParticleData.h"
//#include "lcio2/ReconstructedParticleData.h"

#include "ROOT/RDataFrame.hxx"
#include <vector>
#include <tuple>

#include "Math/GenVector/VectorUtil.h"

// DD4hep
// -----
// In .rootlogon.C
//  gSystem->Load("libDDDetectors");
//  gSystem->Load("libDDG4IO");
//  gInterpreter->AddIncludePath("/opt/software/local/include");
#include "DD4hep/Detector.h"
#include "DDG4/Geant4Data.h"
#include "DDRec/CellIDPositionConverter.h"
#include "DDRec/SurfaceManager.h"
#include "DDRec/Surface.h"


void example_seg_size(const char* fname = "test_tracker_disc.root"){

  TChain* t = new TChain("EVENT");
  t->Add(fname);

  ROOT::RDataFrame d0(*t, {"GEMTrackerHits","MCParticles"});

  std::cout << t->GetBranch("GEMTrackerHits")->GetClassName() << std::endl;
  //std::vector<dd4hep::sim::Geant4Tracker::Hit*>

  auto nhits = [] (const std::vector<dd4hep::sim::Geant4Tracker::Hit*>& hits){ return hits.size(); };

  dd4hep::Detector& detector = dd4hep::Detector::getInstance();
  detector.fromCompact("gem_tracker_disc.xml");
  dd4hep::rec::CellIDPositionConverter cellid_converter(detector);

  dd4hep::rec::SurfaceManager& surfMan = *detector.extension<dd4hep::rec::SurfaceManager>() ;
  //const SurfaceMap& _surfMap = *surfMan.map( "world" ) ;
  const auto& _surfMap = *surfMan.map( "world" ) ;

  //auto delta = [=](const std::vector<dd4hep::sim::Geant4Tracker::Hit*>& hits){

  double degree = TMath::Pi()/180.0;

  auto hit_position = [&](const std::vector<dd4hep::sim::Geant4Tracker::Hit*>& hits){

    for(const auto& h: hits){

      auto hit_pos = (h->position/10.0);
      std::cout << "phi (hit) = " << hit_pos.phi()/degree << std::endl;

      auto cell = h->cellID;
      auto seg_pos = cellid_converter.position(cell);
      std::cout << "phi (seg) = " << seg_pos.phi()/degree << std::endl;

      auto context = cellid_converter.findContext( cell ) ;

      //if( context == nullptr)
      //  return Position() ;
      dd4hep::Readout r  = cellid_converter.findReadout( context->element ) ;
      dd4hep::Segmentation seg = r.segmentation() ;

      auto cell_dim = seg.cellDimensions(cell);
      std::cout << " dim ";
      for(const auto& dim : cell_dim) {
        std::cout << dim << ", ";
      }

      //dd4hep::rec::SurfaceMap::const_iterator
      //const auto si = _surfMap.find( h->cellID ); //cellID of the tracker hit
      //dd4hep::rec::ISurface* surf = (si != _surfMap.end() ?  si->second  : 0);
      //dd4hep::rec::Vector3D pos =  surf->origin();//fit_global(pivot[0],pivot[1],pivot[2]);
      //std::cout << pos.x() << ", " << pos.y() << ", " << pos.z()<< std::endl;
      // transform lcio units to dd4hep units, see documentation for other functions              
      //DDSurfaces::Vector2D fit_local = surf->globalToLocal( dd4hep::mm * fit_global );
    }
    return 0.0; };

  auto d1 = d0.Define("nhits",nhits, {"GEMTrackerHits"});
  auto d2 = d1.Define("delta",hit_position, {"GEMTrackerHits"});

  auto h0 = d2.Histo1D(TH1D("h0", "nhits; ", 20, 0,20), "delta");

  TCanvas*c = new TCanvas();
  h0->DrawClone();

}
