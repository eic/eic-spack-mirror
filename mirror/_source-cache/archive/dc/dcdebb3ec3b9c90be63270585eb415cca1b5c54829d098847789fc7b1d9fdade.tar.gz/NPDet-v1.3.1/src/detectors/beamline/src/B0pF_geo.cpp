#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "DD4hep/Shapes.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace ROOT::Math;

static Ref_t build_magnet(Detector& dtor, xml_h e, SensitiveDetector sens) {
    xml_det_t x_det     = e;
    int       det_id    = x_det.id();
    string    det_name  = x_det.nameStr();
    xml_dim_t pos       = x_det.child(_U(placement));
    double    pos_x     = pos.x();
    double    pos_y     = pos.y();
    double    pos_z     = pos.z();
    double    pos_theta = pos.attr<double>(_U(theta));
    xml_dim_t dims      = x_det.dimensions();
    double    dim_x     = dims.x();
    double    dim_y     = dims.y();
    double    dim_z     = dims.z();
    xml_dim_t apperture = x_det.child(_Unicode(apperture));
    double    app_x     = apperture.x();
    double    app_y     = apperture.y();
    xml_dim_t coil      = x_det.child(_Unicode(coil));
    double    coil_x    = coil.dx();
    double    coil_y    = coil.dy();
    Material  iron      = dtor.material("Iron");
    Material  niobium   = dtor.material("Niobium");

    DetElement sdet(det_name, det_id);
    Assembly   assembly(det_name + "_assembly");

    string module_name = "B0pFMag";

    string vis0 = dd4hep::getAttrOrDefault(x_det, _Unicode(vis), "BlueVis");

    sdet.setAttributes(dtor, assembly, x_det.regionStr(), x_det.limitsStr(), "OrangeVis");

    // -- yoke --
    Box yoke_outer(0.5 * dim_x, 0.5 * dim_y, 0.5 * dim_z);
    Box app_hole(0.5 * app_x, 0.5 * app_y, 1 * dim_z);
    SubtractionSolid yoke(yoke_outer, app_hole);
    Volume yoke_vol("yoke_vol", yoke, iron);
    auto yoke_pv = assembly.placeVolume(yoke_vol);
    yoke_pv.addPhysVolID("element", 1);
    DetElement yoke_de(sdet, "yoke_de", 1);
    yoke_de.setPlacement(yoke_pv);
    yoke_de.setAttributes(dtor, yoke_vol, x_det.regionStr(), x_det.limitsStr(), "BlueVis");
    //yoke_vol.setVisAttributes("BlueVis");

    // -- coil --
    auto rod_pos_up = Transform3D(Translation3D(0.5 * (app_x - coil_y), 0.5 * (app_y - coil_x), 0.0));
    auto rod_pos_down = Transform3D(RotationZ(M_PI) * Translation3D(0.5 * (app_x - coil_y), 0.5 * (app_y - coil_x), 0.0));

    Box long_rod(0.5 * coil_y, 0.5 * coil_x, 0.5 * dim_z);
    Box short_rod(0.5 * coil_y, coil_x, 0.5 * coil_x);
    Box top_rod(0.5 * app_x, 0.5 * coil_y, 0.5 * coil_x);
    UnionSolid half_rod1(long_rod, short_rod, Position(0.0, 0.5 * coil_x, -0.5 * (dim_z + coil_x)));
    UnionSolid half_rod2(half_rod1, short_rod, Position(0.0, 0.5 * coil_x, 0.5 * (dim_z + coil_x)));
    UnionSolid half_rod3(half_rod2, top_rod, Position(-0.5 * (app_x - coil_y), coil_x + 1.5*coil_y, -0.5 * (dim_z + coil_x)));
    UnionSolid half_rod4(half_rod3, top_rod, Position(-0.5 * (app_x - coil_y), coil_x + 1.5*coil_y, 0.5 * (dim_z + coil_x)));
    UnionSolid half_rod5(half_rod4, long_rod, Position(-app_x + coil_y, 0.0, 0.0));
    UnionSolid half_rod6(half_rod5, short_rod, Position(-app_x + coil_y, 0.5 * coil_x, -0.5 * (dim_z + coil_x)));
    UnionSolid half_rod7(half_rod6, short_rod, Position(-app_x + coil_y, 0.5 * coil_x, 0.5 * (dim_z + coil_x)));
    Volume coil_up_vol("coil_up_vol", half_rod7, niobium);
    Volume coil_down_vol("coil_down_vol", half_rod7, niobium);


    auto rod_pv1 = assembly.placeVolume(coil_up_vol, rod_pos_up);
    auto rod_pv2 = assembly.placeVolume(coil_down_vol, rod_pos_down);
    DetElement coil1_de(sdet, "coil1_de", 3);
    DetElement coil2_de(sdet, "coil2_de", 4);
    coil1_de.setAttributes(dtor, coil_up_vol  , x_det.regionStr(), x_det.limitsStr(), "RedVis");
    coil2_de.setAttributes(dtor, coil_down_vol, x_det.regionStr(), x_det.limitsStr(), "RedVis");
    coil1_de.setPlacement(rod_pv1);
    coil2_de.setPlacement(rod_pv2);
    //coil_up_vol.setVisAttributes("RedVis");
    //coil_down_vol.setVisAttributes("RedVis");

    // -- finishing steps
    auto pv = dtor.pickMotherVolume(sdet).placeVolume(assembly, Position(pos_x, pos_y, pos_z));
    pv.addPhysVolID("system", det_id);
    sdet.setPlacement(pv);

    assembly->GetShape()->ComputeBBox();
    return sdet;
}

DECLARE_DETELEMENT(B0pFMag, build_magnet)

