#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "DD4hep/Shapes.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace ROOT::Math;

static Ref_t build_cavity(Detector& dtor, xml_h e, SensitiveDetector sens) {
    xml_det_t x_det     = e;
    int       det_id    = x_det.id();
    string    det_name  = x_det.nameStr();
    xml_dim_t pos       = x_det.child(_U(placement));
    double    pos_x     = pos.x();
    double    pos_y     = pos.y();
    double    pos_z     = pos.z();
    double    pos_theta = pos.attr<double>(_U(theta));
    xml_dim_t dims      = x_det.dimensions();
    double    dim_r     = dims.r();
    double    dim_z     = dims.z();
    xml_dim_t apperture = x_det.child(_Unicode(apperture));
    double    app_r     = apperture.r();
    xml_dim_t x_cavity  = x_det.child(_Unicode(cavity));
    double    r1        = x_cavity.attr<double>(_Unicode(r1));
    double    r2        = x_cavity.attr<double>(_Unicode(r2));
    double    z1        = x_cavity.attr<double>(_Unicode(z1));
    double    z2        = x_cavity.attr<double>(_Unicode(z2));
    Material  niobium   = dtor.material("Niobium");
    Material  titanium  = dtor.material("Titanium");
    Material  helium    = dtor.material("Helium");
    Material  vacuum    = dtor.material("Vacuum");

    DetElement sdet(det_name, det_id);
    Assembly   assembly(det_name + "_assembly");

    string module_name = "Crab_Cavity";

    string vis0 = dd4hep::getAttrOrDefault(x_det, _Unicode(vis), "BlueVis");

    sdet.setAttributes(dtor, assembly, x_det.regionStr(), x_det.limitsStr(), "OrangeVis");

    double shell_thickness = 10.0 * dd4hep::mm;
    double cryostat_thickness = 20.0 * dd4hep::mm;

    // -- Cavity insides
    Tube beampipe_vacuum(0.0, app_r, 1.2 * dim_r);
    Tube cavity1(0.0, r1, 0.5*z1);
    Tube cavity2(0.0, r2, 0.5*(z1 - z2));
    UnionSolid cavity_vacuum1(beampipe_vacuum, cavity1, Transform3D( RotationX(0.5*M_PI) ));
    SubtractionSolid cavity_vacuum2(cavity_vacuum1, cavity2, Transform3D( RotationX(0.5*M_PI) * Translation3D(0.0, 0.0, 0.5*z1) ));
    SubtractionSolid cavity_vacuum3(cavity_vacuum2, cavity2, Transform3D( RotationX(-0.5*M_PI) * Translation3D(0.0, 0.0, 0.5*z1) ));

    Volume vacuum_vol("vacuum_vol", cavity_vacuum3, vacuum);
    auto cavity_vacuum_pv = assembly.placeVolume(vacuum_vol);
    DetElement cavity_vacuum_de(sdet, "vacuum_de", 1);
    cavity_vacuum_de.setPlacement(cavity_vacuum_pv);
    cavity_vacuum_de.setAttributes(dtor, vacuum_vol, x_det.regionStr(), x_det.limitsStr(), "GreenVis");

    // -- Cavity shell
    Tube beampipe(0.0, app_r + 0.5*shell_thickness, 1.2 * dim_r);
    Tube shell1(0.0, r1 + 0.5*shell_thickness, 0.5*(z1 + shell_thickness));
    Tube shell2(0.0, r2 - 0.5*shell_thickness, 0.5*(z1 - z2 - shell_thickness));
    UnionSolid cavity_shell1(beampipe, shell1, Transform3D( RotationX(0.5*M_PI) ));
    SubtractionSolid cavity_shell2(cavity_shell1, shell2, Transform3D( RotationX(0.5*M_PI) * Translation3D(0.0, 0.0, 0.5*z1) ));
    SubtractionSolid cavity_shell3(cavity_shell2, shell2, Transform3D( RotationX(-0.5*M_PI) * Translation3D(0.0, 0.0, 0.5*z1) ));
    SubtractionSolid cavity_shell4(cavity_shell3, cavity_vacuum3);

    Volume shell_vol("shell_vol", cavity_shell4, niobium);
    auto shell_pv = assembly.placeVolume(shell_vol);
    DetElement shell_de(sdet, "shell_de", 2);
    shell_de.setPlacement(shell_pv);
    shell_de.setAttributes(dtor, shell_vol, x_det.regionStr(), x_det.limitsStr(), "RedVis");

    // -- LHe volume
    Tube heliumfill1(0.0, dim_r - 0.5*cryostat_thickness, 0.5 * (dim_z - cryostat_thickness));
    UnionSolid heliumfill2(Box(0.1*dim_r, 0.1*dim_r, 0.1*dim_z), heliumfill1, Transform3D( RotationX(0.5*M_PI) )); // A workaround for boolean shape of boolean shapes not working with tranforms.
    SubtractionSolid heliumfill3(heliumfill2, cavity_shell3);

    Volume helium_vol1("heliumvol", heliumfill3, helium);
    auto helium_pv = assembly.placeVolume(helium_vol1);
    DetElement helium_de(sdet, "helium_de", 3);
    helium_de.setPlacement(helium_pv);
    helium_de.setAttributes(dtor, shell_vol, x_det.regionStr(), x_det.limitsStr(), "GrayVis");

    // -- Cryostat shell
    Tube cryoshell1(0.0, dim_r, 0.5*dim_z);
    UnionSolid cryoshell2(Box(0.1*dim_r, 0.1*dim_r, 0.1*dim_z), cryoshell1, Transform3D( RotationX(0.5*M_PI) ));
    SubtractionSolid cryoshell3(cryoshell2, heliumfill2);
    SubtractionSolid cryoshell4(cryoshell3, cavity_shell3);

    Volume cryo_vol("cryovol", cryoshell4, titanium);
    auto cryo_pv = assembly.placeVolume(cryo_vol);
    DetElement cryo_de(sdet, "cryo_de", 4);
    cryo_de.setPlacement(cryo_pv);
    cryo_de.setAttributes(dtor, cryo_vol, x_det.regionStr(), x_det.limitsStr(), "BlueVis");

    // -- finishing steps
    auto final_pos = Transform3D(Translation3D(pos_x, pos_y, pos_z) * RotationY(pos_theta));
    auto pv = dtor.pickMotherVolume(sdet).placeVolume(assembly, final_pos);
    pv.addPhysVolID("system", det_id);
    sdet.setPlacement(pv);

    assembly->GetShape()->ComputeBBox();
    return sdet;
}

DECLARE_DETELEMENT(CrabCavity, build_cavity)
