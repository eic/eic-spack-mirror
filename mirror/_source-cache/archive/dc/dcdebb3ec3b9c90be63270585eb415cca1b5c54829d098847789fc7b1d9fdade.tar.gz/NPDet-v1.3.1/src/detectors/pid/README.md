Generic PID detectors
=========================

List of references
---------------------------

* [Electron-Ion Collider Detector Requirements and  R&D Handbook](http://www.eicug.org/web/sites/default/files/EIC_HANDBOOK_v1.2.pdf)
* [Performance of the LHCb RICH detector at the LHC](https://doi.org/10.1140/epjc/s10052-013-2431-9)
* [The PHENIX ring imaging Cherenkov detector](https://doi.org/10.1016/S0168-9002(00)00645-8)
* [A ring imaging Cherenkov detector for CLAS12](https://doi.org/10.1016/j.nima.2013.08.012)
* [Design and construction of a Cherenkov detector for Compton polarimetry at the ILC](https://iopscience.iop.org/article/10.1088/1748-0221/7/01/P01019)
* [Bigbite Gas Cherenkov](http://wm-jlab.physics.wm.edu/mediawiki/index.php/Bigbite_Gas_Cherenkov)
* Book: Gaseous Radiation Detectors: Fundamentals and Applications


List of detectors
---------------------------

- Skeleton RICH detector: GenericRICH_geo.cpp



