//==========================================================================
//  Scintillating Tile Endcap H Calorimeter Detector implementation 
//--------------------------------------------------------------------------
//  J.KIM  2020-04-07
//  Created tile-shaped Pb/Sci
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace dd4hep::detail;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup ScintillatingTileEndcapHCAL Scintillating Tile Endcap Hadronic Calorimeter
 *  \brief Type: **ScintillatingTileEndcapHCAL**, Scintillating Tile Endcap Hadronic Calorimeter.
 *  \author J. Kim
 *  \ingroup calorimeters
 *
 * Scintillating Tile Endcap Hadronic Calorimeter.
 *
 * \code
 *   <detector>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t createDetector(Detector& description, xml_h e, SensitiveDetector sens) {
  xml_det_t x_det     = e;
  int       det_id    = x_det.id();
  string    det_name  = x_det.nameStr();
  // Size of Endcap
  double    rmin      = 2.0*cm;
  double    rmax      = 10.0*cm;

  Assembly assembly( det_name+"_assembly" );
  // Number of layers of each tile
  int nlayers = 30;
  // Thickness of plates
  double layer0_thickness = 0.5*mm; //Pb_slice
  double layer1_thickness = 1.5*mm; //Scint_slice
  double total_layer_thickness = layer0_thickness + layer1_thickness;
  // Size of tile
  double width_x = 1*cm;
  double width_y = 1*cm;
  // Visualization Setting
  auto gray_vis = description.visAttributes("GrayVis");
  auto red_vis = description.visAttributes("RedVis");

  DetElement det(det_name, det_id);

  Assembly module_assembly( "module_assembly" );
  PlacedVolume module_PV;

  //Pb tile
  Box lead_layer_shape(width_x/2.0, width_y/2.0,layer0_thickness/2.0);
  Volume lead_layer_Vol("lead_layer_Vol", lead_layer_shape, description.material("Lead"));
  lead_layer_Vol.setVisAttributes(gray_vis);
  //Sci tile
  Box scint_layer_shape(width_x/2.0, width_y/2.0,layer1_thickness/2.0);
  Volume scint_layer_Vol("scint_layer_Vol", scint_layer_shape, description.material("PlasticScint"));
  scint_layer_Vol.setVisAttributes(red_vis);
  // A Stack of Pb and Scintillator tiles 
  for(int ilayer = 0; ilayer < nlayers; ilayer++) {
	double z_layer  = ilayer * total_layer_thickness + layer0_thickness / 2.0;
	auto   lead_PV  = module_assembly.placeVolume(lead_layer_Vol, Position(0.0, 0.0, z_layer));
	lead_PV.addPhysVolID("layer", ilayer).addPhysVolID("slice", 1);
	sens.setType("calorimeter");
        lead_layer_Vol.setSensitiveDetector(sens);
        double dz_scint = layer0_thickness / 2.0 + layer1_thickness / 2.0;
        auto   scint_PV = module_assembly.placeVolume(scint_layer_Vol, Position(0.0, 0.0, z_layer + dz_scint));
        scint_PV.addPhysVolID("layer", ilayer).addPhysVolID("slice", 2);
	sens.setType("calorimeter");
	scint_layer_Vol.setSensitiveDetector(sens);
  }

  // How many 
  int nx = 10;
  int ny = 10;
  // Offset between X and Y
  double offset_x = 0.1*mm;
  double offset_y = 0.1*mm;
  // Position of each stack of Pb/Sc
  double pos_x = 0.0*cm;
  double pos_y = 0.0*cm;
  // Starting Position of each stack of Pb/Sc
  double x_start = (width_x + offset_x)/2.0;
  double y_start = (width_y + offset_x)/2.0;
  // Spacing between stacks and Diagonal length
  double x_spacing = width_x + offset_x;
  double y_spacing = width_y + offset_y;
  double diagonal = width_x*sqrt(2);
  // Limit based on Endcap size
  double limit_inner = rmin + diagonal/2.0;
  double limit_outer = rmax - diagonal/2.0;

  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // Start placing stacks of Pb/Sc
  // Divide 4 sections; X+Y+, X-Y+, X+Y-, X-Y-
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // X+Y+
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  int imod = 0;
  for(int ix = 0; ix<nx; ix++)
  {
	pos_x = x_start + (ix*x_spacing);
	pos_y = y_start;
  	for(int iy = 0; iy<ny; iy++)
	{
		pos_y = y_start + (iy*y_spacing);
		if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner && sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer)
		{
			module_PV = assembly.placeVolume(module_assembly, Position(pos_x,pos_y,0.0));
			imod++;			
			module_PV.addPhysVolID("module", imod);	
		}
		else
			continue;
	}
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // X-Y+
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  for(int ix = 0; ix<nx; ix++)
  {
        pos_x = -x_start - (ix*x_spacing);
        pos_y = y_start;
  	for(int iy = 0; iy<ny; iy++)
        {
                pos_y = y_start + (iy*y_spacing);
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner && sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer) 
                {       
			module_PV = assembly.placeVolume(module_assembly, Position(pos_x,pos_y, 0.0));
                	imod++;
                	module_PV.addPhysVolID("module", imod);
		}
		else
			continue;	
	}
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // X+Y-
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  for(int ix = 0; ix<nx; ix++)
  {
        pos_x = x_start + (ix*x_spacing);
        pos_y = -y_start;
	for(int iy = 0; iy<ny; iy++)
        {               
		pos_y = -y_start - (iy*y_spacing);
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner && sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer)
                {  
  			module_PV = assembly.placeVolume(module_assembly, Position(pos_x,pos_y, 0.0));
                	imod++;                         
                	module_PV.addPhysVolID("module", imod);  
		}
		else
			continue;
	}
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // X-Y-
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  for(int ix = 0; ix<nx; ix++)
  {
	pos_x = -x_start - (ix*x_spacing);
        pos_y = -y_start;
  	for(int iy = 0; iy<ny; iy++)
        {
                pos_y = -y_start - (iy*y_spacing);
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner && sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer) 
                {       
			module_PV = assembly.placeVolume(module_assembly, Position(pos_x,pos_y, 0.0));
                	imod++;
                	module_PV.addPhysVolID("module", imod);
		}
		else
			continue;
	}
  }

  Volume motherVol = description.pickMotherVolume(det);
  PlacedVolume envPV = motherVol.placeVolume(assembly, Position(0, 0, 0));
  envPV.addPhysVolID("system", det_id);
  det.setPlacement(envPV);
  return det;
}
//@}
// clang-format off
DECLARE_DETELEMENT(ScintillatingTileEndcapHCAL, createDetector)
