Generic Tracker Detectors
=========================

Note when using `ddeve`, the default `gGeoManger->fVisLevel` is set to 4.
Some detectors will not be visible with this setting. Do deep visualization
or gGeoManager->SetVisLevel(100); 

- GenericTrackerBarrel_geo.cpp
Status: TBD

- GenericSiliconTrackerBarrel_geo.cpp
Status: Needs work to remove hard coded parameters

- ForwardPlaneTracker_geo.cpp
Status: TBD

- SimpleRomanPot_geo.cpp
Needs work, 4 plane detector

- GEMTrackerDisc_geo.cpp
Needs work, material incomplete

GaplessGEMTrackerDisc_geo.cpp
Status: Needs hard coded numbers moved to compact.

- GenericShape_geo.cpp

- SiliconTrackerBarrel_geo.cpp
Status: TBD

- SimpleSiTrackerDigi.cpp
- SiTrackerRomanPot_geo.cpp
- RPC_sim_7.f
