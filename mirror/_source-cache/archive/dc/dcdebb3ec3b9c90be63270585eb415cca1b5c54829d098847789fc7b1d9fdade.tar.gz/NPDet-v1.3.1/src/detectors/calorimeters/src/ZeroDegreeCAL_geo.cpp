//==========================================================================
//  Zero Degree Calorimeter Detector implementation 
//--------------------------------------------------------------------------
//  J.KIM  2020-05-14
//  Created
//  Modified 2020-05-27 4XY pairs of bar 
//  Modified 2020-05-28 Used Plastic Scintillation instead of GSO scint
//  Modified 2020-06-05 Debugged errors while Geant4 simulation running
//  Modified 2020-06-12 VolumeID - Ran Geant4 simulation w/o errors
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace dd4hep::detail;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup ZeroDegreeCalorimeter Zero-degree calorimeter
 * \brief Type: **ZeroDegreeCAL**.
 * \author J. Kim
 * \ingroup calorimeters
 *
 *
 * \code
 *   <detector id="1" name="ZDC" type="ZeroDegreeCAL" readout="ZDCHits" vis="RedVis">
 *   ... fixme
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t createDetector(Detector& description, xml_h e, SensitiveDetector sens) {
  xml_det_t x_det     = e;
  int       det_id    = x_det.id();
  string    det_name  = x_det.nameStr();

  // Define assembly
  Assembly assembly( det_name+"_assembly" );
  DetElement det(det_name, det_id);
  Assembly module_assembly( "module_assembly" );
  PlacedVolume module_PV;
  Assembly bar_assembly("bar_assembly");
  PlacedVolume pv_bar;

  xml_dim_t  pos          = x_det.position();
  double     x_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(x),0.0);
  double     y_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(y),0.0);
  double     z_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(z),0.0);

  // Dimensions of RHICf/LHCf detector
  double small_tower_length = 20*mm;
  double large_tower_length = 40*mm;
  double offset_btw_towers = 5*mm;
  double bar_width = 1*mm;

  double tungsten_thickness = 7*mm;
  double scintillator_thickness = 3*mm;
  double dz_scint = scintillator_thickness/2.0 + tungsten_thickness/2.0;

  // Visualization Setting
  auto gray_vis = description.visAttributes("GrayVis");
  auto blue_vis = description.visAttributes("BlueVis");
  auto red_vis = description.visAttributes("RedVis");

  // Tungsten plates
  //// Small tower
  Box s_tungsten_layer_shape(small_tower_length/2.0, small_tower_length/2.0,tungsten_thickness/2.0);
  Volume s_tungsten_layer_Vol("s_tungsten_layer_Vol", s_tungsten_layer_shape, description.material("TungstenDens24"));
  s_tungsten_layer_Vol.setVisAttributes(gray_vis);
  //// Large tower
  Box l_tungsten_layer_shape(large_tower_length/2.0, large_tower_length/2.0,tungsten_thickness/2.0);
  Volume l_tungsten_layer_Vol("l_tungsten_layer_Vol", l_tungsten_layer_shape, description.material("TungstenDens24"));
  l_tungsten_layer_Vol.setVisAttributes(gray_vis);

  // Scitillator plates
  //// Small tower
  Box s_scint_layer_shape(small_tower_length/2.0, small_tower_length/2.0,scintillator_thickness/2.0);
  Volume s_scint_layer_Vol("s_scint_layer_Vol", s_scint_layer_shape, description.material("PlasticScint"));
  s_scint_layer_Vol.setVisAttributes(blue_vis);
  //// Large tower
  Box l_scint_layer_shape(large_tower_length/2.0, large_tower_length/2.0,scintillator_thickness/2.0);
  Volume l_scint_layer_Vol("l_scint_layer_Vol", l_scint_layer_shape, description.material("PlasticScint"));
  l_scint_layer_Vol.setVisAttributes(blue_vis);

  // Position layers
  //// Small tower Bundle X
  Box sx_bar(bar_width/2.0, small_tower_length/2.0, bar_width/2.0);
  Volume sx_bar_vol("sx_bar_volume", sx_bar, description.material("PlasticScint"));
  sx_bar_vol.setVisAttributes(red_vis);
  //// Small tower Bundle Y 
  Box sy_bar(small_tower_length/2.0, bar_width/2.0, bar_width/2.0);
  Volume sy_bar_vol("sy_bar_volume", sy_bar, description.material("PlasticScint"));
  sy_bar_vol.setVisAttributes(red_vis);
  //// Large tower Bundle X
  Box lx_bar(bar_width/2.0, large_tower_length/2.0, bar_width/2.0);
  Volume lx_bar_vol("lx_bar_volume", lx_bar, description.material("PlasticScint"));
  lx_bar_vol.setVisAttributes(red_vis);
  //// Large tower Bundle Y
  Box ly_bar(large_tower_length/2.0, bar_width/2.0, bar_width/2.0);
  Volume ly_bar_vol("ly_bar_volume", ly_bar, description.material("PlasticScint"));
  ly_bar_vol.setVisAttributes(red_vis);

  // Place each plate at a time
  // The thickness of tungsten plates are different. 
  // The first 11 layers are 7mm each and the rest is 14mm each.
  // In units of radiation and hadron interaction lengths the total length of a calorimeter
  // 44 X_0 and 1.7 lambda
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  // Small Tower
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  double z_layer = tungsten_thickness/2.0;
  auto   tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 0).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  auto   scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 1).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 2).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 3).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 4).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  double pos_x = -1.0 + bar_width/2.0;
  for(int ix=0; ix<20; ix++)
	{
		pv_bar = module_assembly.placeVolume(sx_bar_vol, Position(pos_x, 0.0, z_layer));
		pv_bar.addPhysVolID("layer", 5+ix).addPhysVolID("slice",3);
		sens.setType("calorimeter");
		sx_bar_vol.setSensitiveDetector(sens);
		pos_x += bar_width;
	}
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  double pos_y = -1.0 + bar_width/2.0;
  for(int iy=0; iy<20; iy++)
        {
                pv_bar = module_assembly.placeVolume(sy_bar_vol, Position(0.0, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 25+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sy_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 45).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 46).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 47).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 48).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = -1.0 + bar_width/2.0;
  for(int ix=0; ix<20; ix++)
        {
                pv_bar = module_assembly.placeVolume(sx_bar_vol, Position(pos_x, 0.0, z_layer));
                pv_bar.addPhysVolID("layer", 49+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = -1.0 + bar_width/2.0;
  for(int iy=0; iy<20; iy++)
        {
                pv_bar = module_assembly.placeVolume(sy_bar_vol, Position(0.0, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 69+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sy_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 89).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 90).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 91).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 92).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 93).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 94).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 95).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 96).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 97).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 98).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 99).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 100).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 101).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 102).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 103).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 104).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 105).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 106).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = -1.0 + bar_width/2.0;
  for(int ix=0; ix<20; ix++)
        {
                pv_bar = module_assembly.placeVolume(sx_bar_vol, Position(pos_x, 0.0, z_layer));
                pv_bar.addPhysVolID("layer", 107+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = -1.0 + bar_width/2.0;
  for(int iy=0; iy<20; iy++)
        {
                pv_bar = module_assembly.placeVolume(sy_bar_vol, Position(0.0, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 127+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sy_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 147).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 148).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 149).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  //////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 150).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 151).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 152).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 153).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 154).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 155).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = -1.0 + bar_width/2.0;
  for(int ix=0; ix<20; ix++)
        {
                pv_bar = module_assembly.placeVolume(sx_bar_vol, Position(pos_x, 0.0, z_layer));
                pv_bar.addPhysVolID("layer", 156+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = -1.0 + bar_width/2.0;
  for(int iy=0; iy<20; iy++)
        {
                pv_bar = module_assembly.placeVolume(sy_bar_vol, Position(0.0, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 176+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                sy_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  scint_PV = module_assembly.placeVolume(s_scint_layer_Vol, Position(0.0, 0.0, z_layer));
  scint_PV.addPhysVolID("layer", 196).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  s_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  tungsten_PV  = module_assembly.placeVolume(s_tungsten_layer_Vol, Position(0.0, 0.0, z_layer));
  tungsten_PV.addPhysVolID("layer", 197).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);


  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  // Large Tower
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  double x_layer = offset_btw_towers/sqrt(2) + (small_tower_length + large_tower_length)/2.0;
  double y_layer = offset_btw_towers/sqrt(2) + (small_tower_length + large_tower_length)/2.0;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer = tungsten_thickness/2.0;
  auto   l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 198).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  auto   l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 199).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 200).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 201).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 202).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int ix=0; ix<40; ix++)
        {
                pv_bar = module_assembly.placeVolume(lx_bar_vol, Position(pos_x, y_layer, z_layer));
                pv_bar.addPhysVolID("layer", 203+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                lx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int iy=0; iy<40; iy++)
        {
                pv_bar = module_assembly.placeVolume(ly_bar_vol, Position(x_layer, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 243+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                ly_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 283).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 284).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  s_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 285).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 286).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int ix=0; ix<40; ix++)
        {
                pv_bar = module_assembly.placeVolume(lx_bar_vol, Position(pos_x, y_layer, z_layer));
                pv_bar.addPhysVolID("layer", 287+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                lx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int iy=0; iy<40; iy++)
        {
                pv_bar = module_assembly.placeVolume(ly_bar_vol, Position(x_layer, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 327+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                ly_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 367).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 368).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 369).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 370).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 371).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 372).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 373).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 374).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 375).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 376).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 377).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 378).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 379).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 380).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 381).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 382).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 383).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 384).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int ix=0; ix<40; ix++)
        {
                pv_bar = module_assembly.placeVolume(lx_bar_vol, Position(pos_x, y_layer, z_layer));
                pv_bar.addPhysVolID("layer", 385+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                lx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int iy=0; iy<40; iy++)
        {
                pv_bar = module_assembly.placeVolume(ly_bar_vol, Position(x_layer, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 425+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                ly_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 465).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 466).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 467).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 468).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 469).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 470).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 471).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 472).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 473).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += tungsten_thickness/2.0 + bar_width/2.0;
  pos_x = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int ix=0; ix<40; ix++)
        {
                pv_bar = module_assembly.placeVolume(lx_bar_vol, Position(pos_x, y_layer, z_layer));
                pv_bar.addPhysVolID("layer", 474+ix).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                lx_bar_vol.setSensitiveDetector(sens);
                pos_x += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += bar_width;
  pos_y = 1.0 + offset_btw_towers/sqrt(2) + bar_width/2.0;
  for(int iy=0; iy<40; iy++)
        {
                pv_bar = module_assembly.placeVolume(ly_bar_vol, Position(x_layer, pos_y, z_layer));
                pv_bar.addPhysVolID("layer", 514+iy).addPhysVolID("slice",3);
                sens.setType("calorimeter");
                ly_bar_vol.setSensitiveDetector(sens);
                pos_y += bar_width;
        }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += 2.0*bar_width;
  l_scint_PV = module_assembly.placeVolume(l_scint_layer_Vol, Position(x_layer,y_layer, z_layer));
  l_scint_PV.addPhysVolID("layer", 554).addPhysVolID("slice", 2);
  sens.setType("calorimeter");
  l_scint_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  z_layer += dz_scint;
  l_tungsten_PV  = module_assembly.placeVolume(l_tungsten_layer_Vol, Position(x_layer, y_layer, z_layer));
  l_tungsten_PV.addPhysVolID("layer", 555).addPhysVolID("slice", 1);
  sens.setType("calorimeter");
  l_tungsten_layer_Vol.setSensitiveDetector(sens);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////

  module_PV = assembly.placeVolume(module_assembly, Position(x_pos,y_pos,z_pos));
  module_PV.addPhysVolID("module", 0);

  Volume motherVol = description.pickMotherVolume(det);
  PlacedVolume envPV = motherVol.placeVolume(assembly, Transform3D(RotationZ(M_PI/4.0), Position(0, 0, 0)));
  //PlacedVolume envPV = motherVol.placeVolume(assembly, Position(0, 0, 0));  
  envPV.addPhysVolID("system", det_id);
  det.setPlacement(envPV);
  return det;
}

DECLARE_DETELEMENT(ZeroDegreeCAL, createDetector)
