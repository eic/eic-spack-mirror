Generic Calorimeters
====================

- EcalBarrel_geo.cpp
Needs better name.
Status: TBD.

- CylindricalEndcapCalorimeter_geo.cpp
- SimpleCalorimeterDigi.cpp

