#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;

using namespace dd4hep;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup HexagonalShashlykSamplingECAL Hexagonal Shashlyk Calorimeter
 *  \brief Type: **HexagonalShashlykSamplingECAL**.
 *  \author Whitney Armstrong
 *  \ingroup calorimeters
 *
 * A Shashlyk calorimeter is layered scintillator and lead with an embedded scintillating fiber collecting the light 
 * from the scintillation layers.
 *
 * \code
 *   <detector>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t createDetector(Detector& desc, xml::Handle_t handle, SensitiveDetector sens) {
    xml::DetElement detElem = handle;

    std::string detName = detElem.nameStr();
    int detID = detElem.id();

    //xml::Component dims = detElem.dimensions();
    //double rInner = dims.rmin();
    //double rOuter1 = dims.rmax1();
    //double rOuter2 = dims.rmax2();
    //double zMin = dims.zmin();
    //double zMax = dims.zmax();

    Material air = desc.air();
    Material PyrexGlass = desc.material("PyrexGlass");

    Assembly assembly( detName+"_assembly" );
    //Cone envShape(0.5 * (zMax - zMin), rInner, rOuter1, rInner, rOuter2);
    //Volume envVol(detName + "_envelope", envShape, air);

    double l_side            = 6.25 * cm;
    double r_nearest         = l_side * std::sqrt(3.0) / 2.0;
    double thickness         = 2.0 * cm;
    double l_side_spacing    = 6.25 * cm + 1.0 * mm;
    double r_nearest_spacing = l_side_spacing * std::sqrt(3.0) / 2.0;
    double y_spacing         = 1.5*l_side_spacing;

    int nx      = 2;
    int ny      = 2;
    int nlayers = 194;

    double layer0_thickness = 0.5*cm;
    double layer1_thickness = 1.5*cm;
    double total_layer_thickness = layer0_thickness + layer1_thickness;

    std::vector<double> ptx     = { r_nearest,        0.0,    -r_nearest,     -r_nearest,     0.0, r_nearest };
    std::vector<double> pty     = { l_side/2.0, l_side, l_side/2.0, -l_side/2.0, -l_side, -l_side/2.0 };
    std::vector<double> sec_x   = { 0.0, 0.0 };
    std::vector<double> sec_y   = { 0.0, 0.0 };
    std::vector<double> sec_z0  = { -layer0_thickness/2.0,  layer0_thickness/2.0 };
    std::vector<double> sec_z1  = { -layer1_thickness/2.0,  layer1_thickness/2.0 };
    std::vector<double> z_scale = { 1.0,1.0};
    std::vector<double> sec_r   = {r_nearest, r_nearest};

    double width_x = (2.0*r_nearest_spacing)*nx + r_nearest_spacing;
    double width_y = (y_spacing)*ny + 0.5*l_side_spacing;

    double offset_x = -(width_x / 2.0) + r_nearest_spacing;
    double offset_y = -(width_y / 2.0) + l_side_spacing;

    auto blue_vis = desc.visAttributes("PurpleVis");
    auto red_vis = desc.visAttributes("RedVis");
    //dd4hep::getAttrOrDefault(desc, _Unicode(vis), "BlueVis")

    Assembly module_assembly( "module_assembly" );
    //Box Pb_wall_shape(width_x/2.0, width_y/2.0,1.2*cm/2.0);
    //ExtrudedPolygon  lead_layer_shape("hex_lead",ptx, pty, sec_z0, sec_x, sec_y, z_scale);
    Polyhedra lead_layer_shape("hex_lead", 6, 0.0, 2.0*M_PI, sec_z0, sec_r);
    Volume lead_layer_Vol("lead_layer_Vol", lead_layer_shape, desc.material("Lead"));
    lead_layer_Vol.setVisAttributes(blue_vis);

    //ExtrudedPolygon  scint_layer_shape("hex_scint",ptx, pty, sec_z1, sec_x, sec_y, z_scale);
    Polyhedra scint_layer_shape("hex_scint", 6, 0.0, 2.0*M_PI, sec_z1, sec_r);
    Volume scint_layer_Vol("hex_scint_vol", scint_layer_shape, desc.material("PlasticScint"));
    scint_layer_Vol.setVisAttributes(red_vis);

    for(int ilayer = 0; ilayer < nlayers; ilayer++) {
      double z_layer  = ilayer * total_layer_thickness + layer0_thickness / 2.0;
      auto   lead_PV  = module_assembly.placeVolume(lead_layer_Vol, Translation3D(0.0, 0.0, z_layer)*RotationZ(M_PI*30.0/180.0));
      lead_PV.addPhysVolID("layer", ilayer).addPhysVolID("slice", 1);
      double dz_scint = layer0_thickness / 2.0 + layer1_thickness / 2.0;
      auto   scint_PV =
          module_assembly.placeVolume(scint_layer_Vol, Translation3D(0.0, 0.0, z_layer + dz_scint)*RotationZ(M_PI*30.0/180.0));
      scint_PV.addPhysVolID("layer", ilayer).addPhysVolID("slice", 2);
    }

    for(int ix =0; ix<nx; ix++){
      for(int iy =0; iy<ny; iy++){
        int imod = ix + iy*nx;
        double extra_x = -(iy%2)*r_nearest_spacing + r_nearest_spacing;
        PlacedVolume module_PV = assembly.placeVolume(
            module_assembly, Position(offset_x + ix * (2.0 * r_nearest_spacing) + extra_x,
                                      offset_y + iy * (y_spacing), 0.0));
        module_PV.addPhysVolID("module", imod);
      }
    }

    //mirrorVol.setVisAttributes(desc.visAttributes(detElem.visStr()));
    //assembly.setVisAttributes(desc.visAttributes(detElem.visStr()));

    DetElement det(detName, detID);
    Volume motherVol = desc.pickMotherVolume(det);
    PlacedVolume envPV = motherVol.placeVolume(assembly, Position(0, 0, 0));
    envPV.addPhysVolID("system", detID);
    det.setPlacement(envPV);
    return det;
}
//@}
// clang-format off
DECLARE_DETELEMENT(HexagonalShashlykSamplingECAL, createDetector)
