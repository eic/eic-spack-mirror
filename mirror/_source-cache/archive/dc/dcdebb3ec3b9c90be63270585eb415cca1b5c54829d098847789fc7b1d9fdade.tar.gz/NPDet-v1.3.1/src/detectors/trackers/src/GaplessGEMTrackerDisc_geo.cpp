#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"

#if defined(USE_ACTSDD4HEP)
#include "ActsDD4hep/ActsExtension.hpp"
#include "ActsDD4hep/ConvertMaterial.hpp"
#else
#include "Acts/Plugins/DD4hep/ActsExtension.hpp"
#include "Acts/Plugins/DD4hep/ConvertDD4hepMaterial.hpp"
#endif

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;

/** \addtogroup trackers Tracking Detectors
 */

/** \addtogroup gaplessGEM Gapless GEM Disc Tracker
 * \brief Type: **GaplessGEMTrackerDisc**.
 * \ingroup trackers
 *
 *  A gapless (overlapping) disc created from wedges of GEM tracker. 
 *
 * \code
 *   <detector>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t create_detector(Detector& lcdd, xml_h e, SensitiveDetector sens)
{
  typedef vector<PlacedVolume> Placements;

  xml_det_t   x_det     = e;
  Material    air       = lcdd.air();
  Material    carbon    = lcdd.material("CarbonFiber");
  Material    silicon   = lcdd.material("SiliconOxide");
  Material    kapton    = lcdd.material("Kapton");
  Material    g10    = lcdd.material("G10");
  int         det_id    = x_det.id();
  string      det_name  = x_det.nameStr();
  PlacedVolume             pv;

  DetElement  sdet(det_name, det_id);
  Assembly    assembly(det_name+"_assembly");

  Acts::ActsExtension* sdet_ae = new Acts::ActsExtension();
  //sdet_ae->addType("endcap", "detector");
  sdet.addExtension<Acts::ActsExtension>(sdet_ae);

  sens.setType("tracker");
  string module_name = "GEM";

  int N_modules = 0;
  std::map<std::string,Volume> modules;
  std::map<std::string, double> module_thicknesses;
  std::map<std::string,DetElement> module_DEs;
  std::map<std::string, double> module_lenghts;

  // First build the unique modules used
  for(xml_coll_t mod( x_det, _U(module) ); mod; ++mod, ++N_modules)  {

    double      mod_rmin   = mod.attr<double>(_Unicode(inner_r));
    double      mod_rmax   = mod.attr<double>(_Unicode(outer_r));
    int         N_segments = mod.attr<int>(Unicode("segments"));
    std::string mod_name   = mod.attr<std::string>(_Unicode(name));
    double      mod_phi    = 2.0 * M_PI / double(N_segments);
    modules[mod_name]      = Assembly(mod_name + "_assembly");
    module_DEs[mod_name]   = DetElement(mod_name + "_de", N_modules + 1);
    //module_DEs[mod_name].setType("compound");
        //Acts::ActsExtension* module_ext = new Acts::ActsExtension();
        //module_ext->addType("sensitive disk", "layer");
        //// the local coordinate systems of modules in dd4hep and acts differ
        //// see http://acts.web.cern.ch/ACTS/latest/doc/group__DD4hepPlugins.html
        //module_DEs[mod_name].addExtension<Acts::ActsExtension>(module_ext);

    double mod_x1 = mod_rmin * std::sin(mod_phi / 2.0);
    double mod_x2 = mod_rmax * std::sin(mod_phi / 2.0);
    double mod_y  = (mod_rmax - mod_rmin)/2.0;
    //std::cout <<  "mod_x1 " << mod_x1 << "\n";
    //std::cout <<  "mod_x2 " << mod_x2 << "\n";
    //std::cout <<  "mod_y " << mod_y << "\n";
    module_lenghts[mod_name]  = mod_y;

    int    N_slices        = 0;
    double total_thickness = 0.0;
    for(xml_coll_t a_slice( mod, _U(slice) ); a_slice; ++a_slice, ++N_slices)  {

      double      slice_thickness = a_slice.attr<double>(_Unicode(thickness));
      std::string slice_mat_name  = a_slice.attr<std::string>(_Unicode(material));
      Material    slice_mat       = lcdd.material(slice_mat_name);
      std::string slice_name      = a_slice.attr<std::string>(_Unicode(name));
      bool        slice_sensitive = dd4hep::getAttrOrDefault(a_slice, _Unicode(sensitive), false);

      //Tube slice_shape(mod_rmin, mod_rmax, slice_thickness/2.0, -mod_phi/2.0,mod_phi/2.0);
      Trd1   slice_shape(mod_x1, mod_x2, slice_thickness / 2.0,mod_y );
      Volume v_slice_shape("v_slice_shape_"+slice_name, slice_shape, slice_mat);
      if(N_modules%3 == 0 ) {
        v_slice_shape.setVisAttributes(lcdd.visAttributes("PurpleVis"));
      }
      if(N_modules%3 == 1 ) {
        v_slice_shape.setVisAttributes(lcdd.visAttributes("GreenVis"));
      }
      if(N_modules%3 == 2 ) {
        v_slice_shape.setVisAttributes(lcdd.visAttributes("OrangeVis"));
      }


      auto   pv_slice_shape = modules[mod_name].placeVolume(
          v_slice_shape,
          Transform3D(Position(0, mod_y, total_thickness + slice_thickness / 2.0+0.1*mm)) *
              RotationX(-M_PI / 2.0));
      pv_slice_shape.addPhysVolID( "slice", N_slices+1 );
      DetElement slice_DE(module_DEs[mod_name],
                          "module_slice_" + std::to_string(N_slices + 1) +
                              std::to_string(N_modules + 1),
                          N_slices + 1);
      slice_DE.setPlacement(pv_slice_shape);

      // Add gem support frames
      int N_frames = 0;
      for(xml_coll_t a_frame( a_slice, _U(frame) ); a_frame; ++a_frame, ++N_frames) { }
      if(N_frames > 0) {
        xml_dim_t  frame_dim    = a_slice.child(_U(frame));
        double     frame_x      = frame_dim.x();
        double     frame_y      = frame_dim.y();
        double     frame_dx      = frame_dim.step_x();
        double     frame_dy      = frame_dim.step_y();
        std::string frame_vs   = frame_dim.attr<std::string>(_Unicode(vis));

        int nx =  2.0*mod_x2/frame_dx+1;
        int ny =  2.0*mod_y/frame_dy+1;
        Box   frame_box_x0(frame_x/2.0, slice_thickness/2.0, mod_y );
        Box   frame_box_y0(mod_x2, slice_thickness/2.0, frame_y/2.0 );
        UnionSolid*  gem_frame0 = new UnionSolid(frame_box_x0,frame_box_y0);
        for (int ix = -nx/2; ix< nx/2; ix++){
          UnionSolid tmp_frame = (*gem_frame0);
          gem_frame0 = new UnionSolid(tmp_frame, frame_box_x0, Position(ix * frame_dx, 0, 0));
        }
        for (int iy = -ny/2; iy< ny/2; iy++){
          UnionSolid tmp_frame = (*gem_frame0);
          gem_frame0 = new UnionSolid(tmp_frame, frame_box_y0, Position(0, 0, iy * frame_dy));
        }

        IntersectionSolid* gem_frame = new IntersectionSolid(*gem_frame0, slice_shape);

        Volume v_gem_frame("v_gem_frame_"+slice_name+std::to_string(N_frames), *gem_frame, g10);
        auto pv_gem_frame = v_slice_shape.placeVolume(v_gem_frame, Position(0, 0, 0));
        DetElement gem_frame_DE(slice_DE,
                            "gem_frame_slice_" + std::to_string(N_slices + 1) + std::to_string(N_modules + 1),
                            N_slices + 1);
        gem_frame_DE.setPlacement(pv_gem_frame);
        gem_frame_DE.setAttributes(lcdd, v_gem_frame, x_det.regionStr(), x_det.limitsStr(), frame_vs);
      }



      if( slice_sensitive ) {
        Vector3D u( 1. , 0. , 0. ) ;
        Vector3D v( 0. , 1. , 0. ) ;
        Vector3D n( 0. , 0. , 1. ) ;
        Vector3D o( 0. , 0. , 0. ) ;
        double inner_thickness = total_thickness + slice_thickness/2.0;
        double outer_thickness = 2.0*slice_thickness;

        SurfaceType type( SurfaceType::Sensitive ) ;
        VolPlane    surf( v_slice_shape, type, inner_thickness , outer_thickness , u,v,n,o ) ;
        v_slice_shape.setSensitiveDetector(sens);
        sens.setType("tracker");

        //Acts::ActsExtension* detlayer = new Acts::ActsExtension();
        //detlayer->addType("axes", "definitions", "XYZ");
        //detlayer->addType("sensitive disk", "layer");
        // the local coordinate systems of modules in dd4hep and acts differ
        // see http://acts.web.cern.ch/ACTS/latest/doc/group__DD4hepPlugins.html
        //slice_DE.addExtension<Acts::ActsExtension>(detlayer);

      } else {
        //Acts::ActsExtension* detlayer = new Acts::ActsExtension();
        //detlayer->addType("passive disk", "layer");
        // the local coordinate systems of modules in dd4hep and acts differ
        // see http://acts.web.cern.ch/ACTS/latest/doc/group__DD4hepPlugins.html
        //slice_DE.addExtension<Acts::ActsExtension>(detlayer);
      }
      total_thickness += slice_thickness+0.1*mm;
    }
    module_thicknesses[mod_name] = total_thickness;
    modules[mod_name]->GetShape()->ComputeBBox() ;
  }

  // -----------------------------------------------------------

  double thickness = 0.01 * dd4hep::cm;
  int    N_layers  = 0;
  for(xml_coll_t lay( x_det, _U(layer) ); lay; ++lay, ++N_layers)  {

    xml_comp_t x_layer     = lay;
    double     inner_r     = x_layer.attr<double>(_Unicode(inner_r));
    double     outer_r     = x_layer.attr<double>(_Unicode(outer_r));
    double     phi0_offset = x_layer.attr<double>(_Unicode(phi0_offset));
    double     z           = x_layer.attr<double>(_Unicode(z));
    int        layer_id    = x_layer.id(); // attr<double>(  _Unicode(z) ) ;

    int    N_modules       = x_layer.attr<int>(_Unicode(Nmodules));
    double z_module_offset = 5.0 * dd4hep::cm;
    double phi_per_module  = 2.0 * M_PI / double(N_modules);
    double mod_y           = outer_r;

    std::vector<std::string> lay_modules;

    for(xml_coll_t mod( lay, _U(module) ); mod; ++mod)  {
      std::string mod_name      = mod.attr<std::string>(_Unicode(name));
      lay_modules.push_back(mod_name);
    }

    int N_mod_types = lay_modules.size();
    Tube   layer_container(inner_r, inner_r + mod_y/std::cos(phi_per_module/2.0) , z_module_offset);
    Volume layer_assembly("layer_assembly_"+std::to_string(layer_id),layer_container,air);
    //Assembly layer_assembly("layer_assembly_"+std::to_string(layer_id));
    DetElement layer_DE( sdet, "layer_"+std::to_string(layer_id+1), layer_id+1 );

        Acts::ActsExtension* detlayer = new Acts::ActsExtension();
        //detlayer->addType("axes", "definitions", "XYZ");
        detlayer->addType("sensitive disk", "layer");
        //detlayer->addValue(200. * cm, "r", "envelope");
        //detlayer->addValue(10. * mm, "z", "envelope");
        layer_DE.addExtension<Acts::ActsExtension>(detlayer);

    for(int i_mod = 0; i_mod < N_modules; i_mod++) {

      string module_name = std::string("gem_layer_module_") + std::to_string(layer_id) +
                           "_module_" + std::to_string(i_mod);
      //Tube   gem_layer_module(inner_r, outer_r, thickness/2.0,-phi_per_module/2.0,phi_per_module/2.0);
      //Volume gem_layer_module_vol("gem_layer_module_vol", gem_layer_module, carbon);
      //
      // i_type alternates between the <module>s inside of the <layer> tag.
      int    i_type          = i_mod % N_mod_types;
      auto   v_mod           = modules[lay_modules[i_type]];
      auto   v_mod_de        = module_DEs[lay_modules[i_type]];
      int    layer_module_id = layer_id * 50 + i_mod + 1;
      double phi_module      = (i_mod)*phi_per_module;


      //Assembly   layer_assembly( layer_name+"_assembly" );
      auto pv_mod = layer_assembly.placeVolume(
          v_mod, RotationZ(phi0_offset + phi_module)*Transform3D(Position(0.0, inner_r, -z_module_offset/2.0 +z_module_offset * (i_mod % 2))));
      pv_mod.addPhysVolID( "module", i_mod+1 );
      //layer_DE.setPlacement(pv);
      auto amod_de = v_mod_de.clone("module_" + std::to_string(i_mod+1), i_mod+1);
      amod_de.setPlacement(pv_mod);
      layer_DE.add(amod_de);
      //layer_DE.setAttributes(lcdd, layer_assembly, "", "", "SiVertexLayerVis");
    }
    auto pv_layer_assembly  = assembly.placeVolume(layer_assembly,Position(0,0,z));
    pv_layer_assembly.addPhysVolID( "layer", layer_id );

    layer_assembly->GetShape()->ComputeBBox() ;
  }

  sdet.setAttributes(lcdd, assembly,x_det.regionStr(),x_det.limitsStr(),x_det.visStr());
  //assembly.setVisAttributes(lcdd.invisible());

  pv = lcdd.pickMotherVolume(sdet).placeVolume(assembly);
  pv.addPhysVolID("system", det_id);      // Set the subdetector system ID.
  sdet.setPlacement(pv);

  assembly->GetShape()->ComputeBBox() ;
  return sdet;
}
//@}
DECLARE_DETELEMENT(GaplessGEMTrackerDisc, create_detector)
