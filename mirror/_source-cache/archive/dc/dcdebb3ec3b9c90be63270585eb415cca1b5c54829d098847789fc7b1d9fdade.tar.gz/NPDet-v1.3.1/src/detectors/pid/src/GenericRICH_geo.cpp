#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"

#include "DD4hep/OpticalSurfaces.h"
#include "DDRec/DetectorData.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;

using namespace dd4hep;

/** \addtogroup PID Particle ID Detectors 
 */

/** \addtogroup GenericRICH A Generic ring imaging cherenkov.
 * \brief Type: **GenericRICH**.
 * \ingroup PID
 *
 * \code
 *   <detector>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t createDetector(Detector& desc, xml::Handle_t handle, SensitiveDetector sens) {
    xml::DetElement detElem = handle;

    std::string detName = detElem.nameStr();
    int detID = detElem.id();

    DetElement det(detName, detID);
    xml::Component dims = detElem.dimensions();
    double rInner1 = dims.rmin1();
    double rInner2 = dims.rmin2();
    double rOuter1 = dims.rmax1();
    double rOuter2 = dims.rmax2();
    double zMin = dims.zmin();
    double zMax = dims.zmax();

    Material air = desc.air();
    Material PyrexGlass = desc.material("PyrexGlass");
    Material N2cherenkov = desc.material("N2cherenkov");

    Cone envShape(0.5 * (zMax - zMin), rInner1, rOuter1, rInner2, rOuter2);
    Volume envVol(detName + "_envelope", envShape, N2cherenkov);

    // ---------------
    // Mirror 
    DetElement   mirror_DE(det,"Mirror_DE",0);
    Tube  mirrorShape(rInner1+1*cm, rOuter2-2*cm, 6*mm/2.0);
    Volume mirrorVol("RICH_mirror_dummy", mirrorShape, PyrexGlass);
    PlacedVolume mirrorPV = envVol.placeVolume(mirrorVol, Position(0, 0, 0.5*(zMax-zMin)-1*cm));
    mirrorPV.addPhysVolID("layer", 2).addPhysVolID("module", 1);
    mirror_DE.setPlacement(mirrorPV);
    //sens.setType("photoncounter");
    //mirrorVol.setSensitiveDetector(sens);
  
    // ---------------

    // ---------------
    // Dummy PMT surface
    //DetElement   pmt_DE(det,"PMT_DE",1);
    //Tube  pmtShape(rInner1+1*cm, rOuter1-2*cm, 4*mm/2.0);
    //Volume pmtVol("pmt_dummy_volume", pmtShape, N2cherenkov);
    //PlacedVolume pmtPV = envVol.placeVolume(pmtVol, Position(0, 0, -0.5 * (zMax - zMin) + 1*cm));
    //pmtPV.addPhysVolID("layer", 1).addPhysVolID("module", 1);
    //pmt_DE.setPlacement(pmtPV);
    //sens.setType("photoncounter");
    //pmtVol.setSensitiveDetector(sens);

    // ---------------
    // Fill the disc with a grid of MCP-PMTs (square)
    // Start from the top of the disc 
    // theta for top left mcp starting point.
    /// \todo  Improve this placement algorithm
    double a_side_mcp    = 10.2 * cm;
    double mcppmt_radius = (rOuter1 - a_side_mcp);
    double theta_start   = std::asin(2.0 * a_side_mcp / mcppmt_radius);
    double first_y_disp  = 2.0 * a_side_mcp / std::tan(theta_start);
    int    N_mcppmt      = std::floor(mcppmt_radius / a_side_mcp);

    Box  mcppmt_shape(10.0*cm/2.0, 10.0*cm/2.0, 1.0*cm/2.0);
    Volume mcppmt_v("mcppmt_v", mcppmt_shape, N2cherenkov);
    mcppmt_v.setVisAttributes(desc.visAttributes("BlueVis"));

    double x_PMTi = -N_mcppmt * a_side_mcp;
    double y_PMTi = first_y_disp;
    int    ix     = 1;
    int    iy     = 1;
    int    in     = 1;
    while(y_PMTi > -mcppmt_radius) {
      while(x_PMTi < mcppmt_radius) {
        double r_PMTi = std::sqrt(x_PMTi*x_PMTi + y_PMTi*y_PMTi);
        if ( (r_PMTi < mcppmt_radius) && (r_PMTi > (rInner1 + a_side_mcp  )) )  {
          PlacedVolume mcppmt_pv =
              envVol.placeVolume(mcppmt_v, Position(x_PMTi, y_PMTi, -0.5 * (zMax - zMin) + 4 * cm));
          DetElement   mcppmt_DE(det,std::string("MCPPMT_DE")+std::to_string(in),in);
          mcppmt_pv.addPhysVolID("layer", 3)
              .addPhysVolID("module", 1)
              .addPhysVolID("x", ix)
              .addPhysVolID("y", iy);
          sens.setType("photoncounter");
          mcppmt_DE.setPlacement(mcppmt_pv);
          mcppmt_v.setSensitiveDetector(sens);
          in++;
          ix++;
        }
        x_PMTi += a_side_mcp;
      }
      x_PMTi = -N_mcppmt*a_side_mcp;
      y_PMTi -= a_side_mcp;
      iy++;
    }


    envVol.setVisAttributes(desc.visAttributes(detElem.visStr()));

    Volume motherVol = desc.pickMotherVolume(det);
    PlacedVolume envPV = motherVol.placeVolume(envVol, Position(0, 0, 0.5 * (zMin + zMax)));
    envPV.addPhysVolID("system", detID);
    det.setPlacement(envPV);

    OpticalSurfaceManager surfMgr = desc.surfaceManager();
    OpticalSurface mirrorSurf  = surfMgr.opticalSurface("MirrorOpticalSurface");
    //OpticalSurface airSurf    = surfMgr.opticalSurface("/world/"+det_name+"#AirSurface");
    //BorderSurface  mirrorBorder_Surf   = BorderSurface(desc, det, "RICHmirror", mirrorSurf, mirrorPV,   envPV);
    SkinSurface mirrorBorder_Surf(desc,mirror_DE,"RICHmirror", mirrorSurf, mirrorVol);
    //BorderSurface  bubbleSurf = BorderSurface(description, sdet, "TankBubble", airSurf,   bubblePlace, tankPlace);
    mirrorBorder_Surf.isValid();
    //tankSurf.isValid();


    return det;
}
//@}

// clang-format off
DECLARE_DETELEMENT(GenericRICH, createDetector)
