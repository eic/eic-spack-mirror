//==========================================================================
//  AIDA Detector description implementation 
//--------------------------------------------------------------------------
// Copyright (C) Organisation europeenne pour la Recherche nucleaire (CERN)
// All rights reserved.
//
// For the licensing terms see $DD4hepINSTALL/LICENSE.
// For the list of contributors see $DD4hepINSTALL/doc/CREDITS.
//
// Author     : Whitney Armstrong
//
//==========================================================================
#ifndef NPDet_PMTHit_H
#define NPDet_PMTHit_H

/// Framework include files
#include "DDG4/Geant4Data.h"

namespace npdet {

  /// PhotoMultiplier Hit definition.
  /** Nearly the same as a tracker hit but stores energy (convertable to wavelength). 
   *
   *  Please note:
   *  ============
   *  The MC truth handling as implemented in the Geant4ParticleHandler
   *  will not work with this class if the object(s) are saved with 
   *  the standard Geant4Output2ROOT event action. If the hit is 
   *  specialized, the output writing also must be specialized if
   *  MC truth handling should be supported.
   *  Otherwise it is sufficient to provide a ROOT dictionary as long as the
   *  base class dd4hep::sim::Geant4HitData is kept.
   *
   *  \author  Whitney Armstrong
   *  \version 1.0
   *  \ingroup DD4HEP_SIMULATION
   */
  class PMTHit  : public dd4hep::sim::Geant4HitData   {

  public:
    ///// dd4hep::sim::Geant4HitData: cellID
    //int64_t cellID = 0;
    ///// dd4hep::sim::Geant4HitData: User flag to classify hits
    //long flag = 0;
    ///// dd4hep::sim::Geant4HitData: Original Geant 4 track identifier of the creating track (debugging)
    //long g4ID = -1;

    
    /// Hit position
    dd4hep::Position      position;
    /// Hit direction
    dd4hep::Direction     momentum;
    /// Length of the track segment contributing to this hit
    double        length = 0;
    /// Monte Carlo / Geant4 information
    dd4hep::sim::Geant4HitData::MonteCarloContrib truth;
    /// Energy of photon
    double        energyDeposit = 0;

  public:
    /// Default constructor
    PMTHit() = default;
    /// Initializing constructor
    PMTHit(int track_id, int pdg_id, double en, double time_stamp)
      : length(0.0), truth(track_id, pdg_id, en, time_stamp, 0.), energyDeposit(en) {}
    /// Default destructor
    virtual ~PMTHit() = default;
    /// Assignment operator
    PMTHit& operator=(const PMTHit& c);
    /// Clear hit content
    PMTHit& clear();
    /// Store Geant4 point and step information into tracker hit structure.
    PMTHit& storePoint(const G4Step* step, const G4StepPoint* pnt);
  };
}

#endif
