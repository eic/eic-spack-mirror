#!/usr/bin/env python
#
from __future__ import absolute_import, unicode_literals
import os
import time
import logging
import DDG4
from DDG4 import OutputLevel as Output
from g4units import keV, GeV, mm, ns, MeV
#
#
logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)
"""

   dd4hep simulation example setup using the python configuration

   @author  M.Frank
   @version 1.0

"""


def run():
  kernel = DDG4.Kernel()
  description = kernel.detectorDescription()
  install_dir = os.environ['DD4hepINSTALL']
  #kernel.loadGeometry(str("file:" + install_dir + "/DDDetectors/compact/SiD.xml"))
  #kernel.loadGeometry(str("file:" + "GenericRICH_example.xml"))
  #kernel.loadGeometry(str("file:" + "ThresholdGasCherenkov_example.xml"))
  kernel.loadGeometry(str("file:" + "HeavyGasCherenkov_example.xml"))
  DDG4.importConstants(description)

  geant4 = DDG4.Geant4(kernel, tracker='Geant4TrackerCombineAction')
  geant4.printDetectors()

  logger.info("#  Configure UI")
  geant4.setupUI('qt',vis=True,macro='macro/vis.mac')

  logger.info("#  Configure G4 magnetic field tracking")
  geant4.setupTrackingField()

  logger.info("#  Setup random generator")
  rndm = DDG4.Action(kernel, 'Geant4Random/Random')
  rndm.Seed = 987654321
  rndm.initialize()
  # rndm.showStatus()

  logger.info("#  Configure Run actions")
  run1 = DDG4.RunAction(kernel, 'Geant4TestRunAction/RunInit')
  run1.Property_int = 12345
  run1.Property_double = -5e15 * keV
  run1.Property_string = 'Startrun: Hello_2'
  logger.info("%s %s %s", run1.Property_string, str(run1.Property_double), str(run1.Property_int))
  run1.enableUI()
  kernel.registerGlobalAction(run1)
  kernel.runAction().adopt(run1)

  logger.info("#  Configure Event actions")
  prt = DDG4.EventAction(kernel, 'Geant4ParticlePrint/ParticlePrint')
  prt.OutputLevel = Output.INFO
  prt.OutputType = 3  # Print both: table and tree
  kernel.eventAction().adopt(prt)

  logger.info("""
  Configure I/O
  """)
  # evt_lcio = geant4.setupLCIOOutput('LcioOutput','CLICSiD_'+time.strftime('%Y-%m-%d_%H-%M'))
  # evt_lcio.OutputLevel = Output.ERROR

  geant4.setupROOTOutput('RootOutput', 'derp_' + time.strftime('%Y-%m-%d_%H-%M'))

  gen = DDG4.GeneratorAction(kernel, "Geant4GeneratorActionInit/GenerationInit")
  kernel.generatorAction().adopt(gen)
  gen.enableUI()

  #gun = DDG4.GeneratorAction(kernel, "Geant4GeneratorWrapper/Gun")
  #gun.Uses = 'G4ParticleGun'
  #gun.Mask = 1
  #kernel.generatorAction().adopt(gun)

  #gen = DDG4.GeneratorAction(kernel, "Geant4ParticleGenerator/ElectronGenerator")
  #gen.Mask = 1 # no idea what this does
  #gen.Particle = 'e-'
  #gen.Energy = 5 * GeV
  #gen.Multiplicity = 1
  #gen.Direction = 'uniform'
  gen = DDG4.GeneratorAction(kernel, "Geant4GeneratorWrapper/GPS")
  gen.Uses = 'G4GeneralParticleSource'
  #gen.OutputLevel = Output.WARNING
  #gen.Mask = 1
  gen.enableUI()
  kernel.generatorAction().adopt(gen)

  gen = DDG4.GeneratorAction(kernel, "Geant4InteractionMerger/InteractionMerger")
  gen.OutputLevel = 0  # generator_output_level
  gen.enableUI()
  kernel.generatorAction().adopt(gen)

  gen = DDG4.GeneratorAction(kernel, "Geant4PrimaryHandler/PrimaryHandler")
  #gen.OutputLevel = 0  # generator_output_level
  gen.enableUI()
  kernel.generatorAction().adopt(gen)

  # Particle handler is critical for saving MCParticles
  part = DDG4.GeneratorAction(kernel, "Geant4ParticleHandler/ParticleHandler")
  kernel.generatorAction().adopt(part)
  # part.SaveProcesses = ['conv','Decay']
  part.SaveProcesses = ['Decay']
  part.MinimalKineticEnergy = 100 * MeV
  #part.OutputLevel = 5  # generator_output_level
  part.enableUI()

  #gen = DDG4.GeneratorAction(kernel, "Geant4IsotropeGenerator/IsotropPi+")
  #gen.Mask = 1
  #gen.Particle = 'e-'
  #gen.Energy = 5 * GeV
  #gen.Multiplicity = 2
  #gen.Distribution = 'cos(theta)'

  #geant4.setupGun('electron','e-',3.0*GeV)


  #logger.info("#  Install vertex smearing for this interaction")
  #gen = DDG4.GeneratorAction(kernel, "Geant4InteractionVertexSmear/SmearPi+")
  #gen.Mask = 1
  #gen.Offset = (20 * mm, 10 * mm, 10 * mm, 0 * ns)
  #gen.Sigma = (4 * mm, 1 * mm, 1 * mm, 0 * ns)
  #kernel.generatorAction().adopt(gen)

  #logger.info("#  Second particle generator: e-")
  #gen = DDG4.GeneratorAction(kernel, "Geant4IsotropeGenerator/IsotropE-")
  #gen.Mask = 2
  #gen.Particle = 'e-'
  #gen.Energy = 25 * GeV
  #gen.Multiplicity = 3
  #gen.Distribution = 'uniform'
  #kernel.generatorAction().adopt(gen)
  #logger.info("  Install vertex smearing for this interaction")
  #gen = DDG4.GeneratorAction(kernel, "Geant4InteractionVertexSmear/SmearE-")
  #gen.Mask = 2
  #gen.Offset = (-20 * mm, -10 * mm, -10 * mm, 0 * ns)
  #gen.Sigma = (12 * mm, 8 * mm, 8 * mm, 0 * ns)
  #kernel.generatorAction().adopt(gen)
  # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  #logger.info("#  Merge all existing interaction records")
  #gen = DDG4.GeneratorAction(kernel, "Geant4InteractionMerger/InteractionMerger")
  #gen.OutputLevel = 4  # generator_output_level
  #gen.enableUI()
  #kernel.generatorAction().adopt(gen)

  #logger.info("#  Finally generate Geant4 primaries")
  #gen = DDG4.GeneratorAction(kernel, "Geant4PrimaryHandler/PrimaryHandler")
  #gen.OutputLevel = 4  # generator_output_level
  #gen.enableUI()
  #kernel.generatorAction().adopt(gen)

  #logger.info("#  ....and handle the simulation particles.")
  #part = DDG4.GeneratorAction(kernel, "Geant4ParticleHandler/ParticleHandler")
  #kernel.generatorAction().adopt(part)
  ## part.SaveProcesses = ['conv','Decay']
  #part.SaveProcesses = ['Decay']
  #part.MinimalKineticEnergy = 100 * MeV
  #part.OutputLevel = 5  # generator_output_level
  #part.enableUI()
  #user = DDG4.Action(kernel, "Geant4TCUserParticleHandler/UserParticleHandler")
  #user.TrackingVolume_Zmax = DDG4.EcalEndcap_zmin
  #user.TrackingVolume_Rmax = DDG4.EcalBarrel_rmin
  #user.enableUI()
  #part.adopt(user)

  logger.info("#  Setup global filters fur use in sensitive detectors")
  #f1 = DDG4.Filter(kernel, 'GeantinoRejectFilter/GeantinoRejector')
  f2 = DDG4.Filter(kernel, 'ParticleRejectFilter/OpticalPhotonRejector')
  f2.particle = 'opticalphoton'
  f3 = DDG4.Filter(kernel, 'ParticleSelectFilter/OpticalPhotonSelector')
  f3.particle = 'opticalphoton'
  #f4 = DDG4.Filter(kernel, 'EnergyDepositMinimumCut')
  #f4.Cut = 10 * MeV
  #f4.enableUI()
  #kernel.registerGlobalFilter(f1)
  kernel.registerGlobalFilter(f2)
  kernel.registerGlobalFilter(f3)
  #kernel.registerGlobalFilter(f4)

  logger.info("#  First the PID detectors")
  seq, act = geant4.setupDetector('LightGasCherenkov','PhotoMultiplierSDAction')
  act.adopt(f2)

  #seq, act = geant4.setupTracker('SiVertexBarrel')
  #seq.adopt(f1)
  ## seq.adopt(f4)
  #act.adopt(f1)

  #seq, act = geant4.setupTracker('SiVertexEndcap')
  #seq.adopt(f1)
  ## seq.adopt(f4)

  #seq, act = geant4.setupTracker('SiTrackerBarrel')
  #seq, act = geant4.setupTracker('SiTrackerEndcap')
  #seq, act = geant4.setupTracker('SiTrackerForward')
  #logger.info("#  Now setup the calorimeters")
  #seq, act = geant4.setupCalorimeter('EcalBarrel')
  #seq, act = geant4.setupCalorimeter('EcalEndcap')
  #seq, act = geant4.setupCalorimeter('HcalBarrel')
  #seq, act = geant4.setupCalorimeter('HcalEndcap')
  #seq, act = geant4.setupCalorimeter('HcalPlug')
  #seq, act = geant4.setupCalorimeter('MuonBarrel')
  #seq, act = geant4.setupCalorimeter('MuonEndcap')
  #seq, act = geant4.setupCalorimeter('LumiCal')
  #seq, act = geant4.setupCalorimeter('BeamCal')

  logger.info("#  Now build the physics list:")
  phys = geant4.setupPhysics('QGSP_BERT')
  geant4.addPhysics(str('Geant4PhysicsList/Myphysics'))

  ph = DDG4.PhysicsList(kernel, 'Geant4OpticalPhotonPhysics/OpticalPhotonPhys')
  ph.VerboseLevel = 2
  ph.enableUI()
  phys.adopt(ph)

  ph = DDG4.PhysicsList(kernel, 'Geant4CerenkovPhysics/CerenkovPhys')
  ph.MaxNumPhotonsPerStep = 10
  ph.MaxBetaChangePerStep = 10.0
  ph.TrackSecondariesFirst = True
  ph.VerboseLevel = 2
  ph.enableUI()
  phys.adopt(ph)


  ## Add special particle types from specialized physics constructor
  #part = geant4.addPhysics('Geant4ExtraParticles/ExtraParticles')
  #part.pdgfile = 'checkout/DDG4/examples/particle.tbl'

  # Add global range cut
  rg = geant4.addPhysics('Geant4DefaultRangeCut/GlobalRangeCut')
  rg.RangeCut = 0.7 * mm

  phys.dump()

  #ui_action = dd4hep.sim.createAction(kernel, "Geant4UIManager/UI")
  #ui_action.HaveVIS = True
  #ui_action.HaveUI = True
  #ui_action.SessionType = qt
  #ui_action.SetupUI = macro
  #kernel.registerGlobalAction(ui_action)

  #ui = geant4.setupUI("qt",vis=True,macro="vis.mac")
  #ui.enableUI()

  kernel.configure()
  kernel.initialize()

  # DDG4.setPrintLevel(Output.DEBUG)
  kernel.run()
  kernel.terminate()


if __name__ == "__main__":
  run()
