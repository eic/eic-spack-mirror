R__LOAD_LIBRARY(libActsDD4hepPlugin.so)
R__LOAD_LIBRARY(libDDG4IO.so)
R__LOAD_LIBRARY(libGenDetectors.so)
#include "DD4hep/Detector.h"
#include "DDG4/Geant4Data.h"
#include "DDRec/CellIDPositionConverter.h"
#include "DDRec/SurfaceManager.h"
#include "DDRec/Surface.h"
#include "ROOT/RDataFrame.hxx"

#include "TCanvas.h"
#include "TChain.h"

#include "Acts/Geometry/TrackingGeometry.hpp"
#include "Acts/Geometry/TrackingVolume.hpp"
#include "Acts/Plugins/DD4hep/ConvertDD4hepDetector.hpp"

/** Example loading ACTs.
 *
 * 
 */
void example_Acts(const char* fname = "test_tracker_disc.root"){

  using namespace ROOT::Math;

  ROOT::EnableImplicitMT(4);
  TChain* t = new TChain("EVENT");
  t->Add(fname);

  ROOT::RDataFrame d0(*t, {"GEMTrackerHits","MCParticles"});

  //How to get the type of the initial branch: (vector<dd4hep::sim::Geant4Tracker::Hit*>)
  //std::cout << t->GetBranch("GEMTrackerHits")->GetClassName() << std::endl;
  
  // -------------------------
  // Get the DD4hep instance
  // Load the compact XML file
  // Initialize the position converter tool
  dd4hep::Detector& detector = dd4hep::Detector::getInstance();
  detector.fromCompact("GEM_sidis.xml");
  dd4hep::rec::CellIDPositionConverter cellid_converter(detector);

  // -------------------------
  // Get the surfaces map
  dd4hep::rec::SurfaceManager& surfMan = *detector.extension<dd4hep::rec::SurfaceManager>() ;
  auto surfMap = surfMan.map( "world" ) ;


  //std::unique_ptr<const Acts::TrackingGeometry>
  auto acts_tracking_geometry =
      Acts::convertDD4hepDetector(detector.world(), Acts::Logging::Level::VERBOSE);

  // std::cout << *acts_tracking_geometry << "\n";

  //if(acts_tracking_geometry->highestTrackingVolume()) {
  //  std::cout << " yooooooo\n";
  //}
  if(acts_tracking_geometry.get()) {
    std::cout << " yooooooo\n";
    if(acts_tracking_geometry->highestTrackingVolume()) {
      std::cout << "\n volume name \n ";
      std::cout << acts_tracking_geometry->highestTrackingVolume()->volumeName() << std::endl;
    } else {
      std::cout << "\nderp\n";
    }
  }

  std::cout << " \n\nDONE ! \n";
}
