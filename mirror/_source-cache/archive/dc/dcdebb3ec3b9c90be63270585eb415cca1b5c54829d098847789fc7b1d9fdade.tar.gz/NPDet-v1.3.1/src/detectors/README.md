Generic Detectors Library
=========================

The goal of this library is to provide all the detectors needed to build up a 
full concept detector. To use the detectors a code snippet needs to be added to 
the compact files. Not everything is a *detector*  since objects like the "beam 
pipe" don't produce output hits. So in this sense this is a *generic detectors 
and apparatus library*.

List of detector categories
---------------------------

* [trackers](trackers/README.md)
* [calorimeters](calorimeters/README.md)
* [beamline](beamline/README.md)

Preliminary Example
-------------------

This code snippet defines the "beam pipe".

```xml
<detectors>
  <detector id="3" name="TestBeampipe" vis="RedVis" type="TestBeampipe" > 
  <beampipe name="CentralBeamPipe"
      material="Beryllium"
      length="CentralBeamPipe_length" 
      inner_radius="CentralBeamPipe_inner_radius"
      z="CentralBeamPipe_z">
    </beampipe>
  </detector>
</detectors>
```
![BeamPipe detector](beamline/doc/beamline_test.png)




