#!/usr/bin/env python
#
from __future__ import absolute_import, unicode_literals
import os
import time
import logging
import DDG4
from DDG4 import OutputLevel as Output
from g4units import keV, GeV, mm, ns, MeV
from pprint import pprint

def run():
  os.environ['G4UI_USE_TCSH'] = "1"
  kernel = DDG4.Kernel()
  description = kernel.detectorDescription()
  kernel.loadGeometry(str("file:" + "GenericRICH_example.xml"))
  DDG4.importConstants(description)

  geant4 = DDG4.Geant4(kernel)
  geant4.printDetectors()

  rootoutput = geant4.setupROOTOutput('RootOutput', 'derp_' + time.strftime('%Y-%m-%d_%H-%M'), mc_truth=True)
  rootoutput.HandleMCTruth = True

  geant4.setupUI('tcsh',vis=False,macro='macro/gps.mac')
  geant4.setupTrackingField()

  # Do not use this gun setup helper!
  #geant4.setupGun('electron','e-',3.0*GeV)

  gen = DDG4.GeneratorAction(kernel, "Geant4GeneratorActionInit/GenerationInit")
  kernel.generatorAction().adopt(gen)
  gen.enableUI()

  gun = DDG4.GeneratorAction(kernel, "Geant4GeneratorWrapper/Gun")
  gun.Uses = 'G4ParticleGun'
  gun.Mask = 1
  kernel.generatorAction().adopt(gun)

  gen = DDG4.GeneratorAction(kernel, "Geant4ParticleGenerator/ElectronGenerator")
  gen.Mask = 1 # no idea what this does
  gen.Particle = 'e-'
  gen.Energy = 5 * GeV
  gen.Multiplicity = 1
  #gen.Direction = 'uniform'

  gen = DDG4.GeneratorAction(kernel, "Geant4InteractionMerger/InteractionMerger")
  gen.OutputLevel = 0  # generator_output_level
  gen.enableUI()
  kernel.generatorAction().adopt(gen)

  gen = DDG4.GeneratorAction(kernel, "Geant4PrimaryHandler/PrimaryHandler")
  #gen.OutputLevel = 0  # generator_output_level
  gen.enableUI()
  kernel.generatorAction().adopt(gen)

  # Particle handler is critical for saving MCParticles
  part = DDG4.GeneratorAction(kernel, "Geant4ParticleHandler/ParticleHandler")
  kernel.generatorAction().adopt(part)
  # part.SaveProcesses = ['conv','Decay']
  part.SaveProcesses = ['Decay']
  part.MinimalKineticEnergy = 100 * MeV
  #part.OutputLevel = 5  # generator_output_level
  part.enableUI()

  #part.adopt(user)
  #user = DDG4.Action(kernel, "Geant4TCUserParticleHandler/UserParticleHandler")
  #user.TrackingVolume_Zmax = DDG4.EcalEndcap_zmin
  #user.TrackingVolume_Rmax = DDG4.EcalBarrel_rmin
  #user.enableUI()

  #f1 = DDG4.Filter(kernel, 'GeantinoRejectFilter/GeantinoRejector')
  f2 = DDG4.Filter(kernel, 'ParticleRejectFilter/OpticalPhotonRejector')
  f2.particle = 'opticalphoton'
  f3 = DDG4.Filter(kernel, 'ParticleSelectFilter/OpticalPhotonSelector')
  f3.particle = 'opticalphoton'
  #f4 = DDG4.Filter(kernel, 'EnergyDepositMinimumCut')
  #f4.Cut = 10 * MeV
  #f4.enableUI()

  #kernel.registerGlobalFilter(f1)
  kernel.registerGlobalFilter(f2)
  kernel.registerGlobalFilter(f3)
  #kernel.registerGlobalFilter(f4)

  seq, act = geant4.setupDetector('ForwardRICH','PhotoMultiplierSDAction')
  act.adopt(f2)

  phys = geant4.setupPhysics('QGSP_BERT')
  geant4.addPhysics(str('Geant4PhysicsList/Myphysics'))
  phys.enableUI()

  ph = DDG4.PhysicsList(kernel, 'Geant4OpticalPhotonPhysics/OpticalPhotonPhys')
  ph.VerboseLevel = 0
  ph.enableUI()
  phys.adopt(ph)

  ph = DDG4.PhysicsList(kernel, 'Geant4CerenkovPhysics/CerenkovPhys')
  ph.MaxNumPhotonsPerStep = 10
  ph.MaxBetaChangePerStep = 10.0
  ph.TrackSecondariesFirst = True
  ph.VerboseLevel = 0
  ph.enableUI()
  phys.adopt(ph)

  #gun.generator()  # Instantiate gun to be able to set properties from G4 prompt
  kernel.configure()
  kernel.initialize()

  # DDG4.setPrintLevel(Output.DEBUG)
  kernel.run()
  kernel.terminate()


if __name__ == "__main__":
  run()
