#ifndef NPdet_SimpleSiTrackerDigi_H
#define NPdet_SimpleSiTrackerDigi_H

#include <vector>
#include <tuple>
#include <random>

namespace npdet {
  namespace trackers {

    template<typename H1, typename H2>
    auto digitize_simple_hits(const std::vector<H1>& hits) -> std::vector<H2> {
      std::vector<H2> digi_hits;

      std::random_device rd;
      std::mt19937 gen(rd());
      std::normal_distribution<> time_dist(0,2.0);
      std::normal_distribution<> adc_dist(5.0,3.0);

      for(const auto& h: hits) {
        auto pos = h->position; //cm

        H2   ahit;
        ahit.cellID0   = (int)h->cellID;
        ahit.cellID1   = (int)h->cellID;
        ahit.channelID = (int)h->cellID;
        // time is not kept from dd4hep hit, instead using z position as crude substitute
        ahit.time = pos.z() + time_dist(gen);
        ahit.adc  = adc_dist(gen);
        digi_hits.push_back(ahit);
      }
      return digi_hits;
    };

  }
}

#endif

