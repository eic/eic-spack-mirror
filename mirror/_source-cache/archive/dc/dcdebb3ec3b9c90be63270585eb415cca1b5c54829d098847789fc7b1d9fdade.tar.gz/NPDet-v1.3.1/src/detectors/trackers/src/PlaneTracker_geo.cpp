#include "DD4hep/DetFactoryHelper.h"

#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include <exception>

using namespace dd4hep;
using namespace dd4hep::rec ;

static Ref_t create_detector(Detector& description, xml_h e, SensitiveDetector sens) {

  xml_det_t x_det     = e;
  xml_dim_t dim       = x_det.dimensions();
  int       det_id    = x_det.id();
  std::string    det_name  = x_det.nameStr();	
  Material  silicon   = description.material("SiliconOxide"); 
  double    x_length  = dim.x();
  double    y_length  = dim.y();
  double    z_length  = dim.z();
  double    rmin      = dim.rmin();
  double    rmax      = dim.rmax();
  xml_dim_t pos       = x_det.position();
  double    x_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(x),0.0);
  double    y_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(y),0.0);
  double    z_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(z),0.0);

  Assembly assembly( det_name+"_assembly" );
  // The top level detector element that this function returns
  DetElement tracker( det_name, x_det.id()  ) ;

  // Create Box and Volume - thin plane
  //Box box(x_length/2.0, y_length/2.0, z_length/2.0);
  //Volume vol("box_volume", box, silicon);

  // Create Tube and Volume - thin tube
  Tube tube(rmin, rmax, z_length, 0, 2*M_PI);
  Volume vol("box_volume", tube, silicon);

    // -------- create a measurement plane for the tracking surface attched to the sensitive volume -----
    Vector3D u( 1. , 0. , 0. ) ;
    Vector3D v( 0. , 1. , 0. ) ;
    Vector3D n( 0. , 0. , 1. ) ;
    //Vector3D o( 0. , 0. , 0. ) ;

    // compute the inner and outer thicknesses that need to be assigned to the tracking surface
    // depending on wether the support is above or below the sensor
    // The tracking surface is used in reconstruction. It provides  material thickness
    // and radation lengths needed for various algorithms, routines, etc.
    double inner_thickness = z_length/2.0;
    double outer_thickness = z_length/2.0;
    
    SurfaceType type( SurfaceType::Sensitive ) ;
    VolPlane    surf( vol, type, inner_thickness , outer_thickness , u,v,n ) ; //,o ) ;
     
    PlacedVolume pv_box = assembly.placeVolume(vol, Position(x_pos,y_pos,z_pos));
    pv_box.addPhysVolID("module", 0);
    sens.setType("tracker");
    vol.setSensitiveDetector(sens);

  Volume motherVol = description.pickMotherVolume(tracker);
  auto   pv        = motherVol.placeVolume(assembly, Position(x_pos,y_pos,z_pos));
  pv.addPhysVolID("system", det_id);
  tracker.setPlacement(pv);

  return tracker;
}
//@}
DECLARE_DETELEMENT(PlaneTracker,create_detector)
