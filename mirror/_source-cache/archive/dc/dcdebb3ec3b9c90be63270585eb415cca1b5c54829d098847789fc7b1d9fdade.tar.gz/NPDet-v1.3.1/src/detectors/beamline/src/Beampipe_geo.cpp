//==========================================================================
//
//      <detector name ="DetName" type="Beampipe" >
//      <layer id="#(int)" inner_r="#(double)" outer_z="#(double)" >
//      <slice material="string" thickness="#(double)" >         
//      </layer>
//      </detector>
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "TMath.h"

using namespace std;
using namespace dd4hep;

static Ref_t create_detector(Detector& det, xml_h e, SensitiveDetector sens)  {

  using namespace ROOT::Math;
  xml_det_t  x_det     = e;
  string     det_name  = x_det.nameStr();
  Material   air       = det.air();
  DetElement sdet        (det_name,x_det.id());
  Assembly   assembly    (det_name+"_assembly");
  Material   m_Al    = det.material("Aluminum");
  Material   m_Be    = det.material("Beryllium");

  PlacedVolume pv;
  int n = 0;
  //std::cout << "    BEAM PIPE \n";

  // Final Focusing Quads (FFQ)
  // these are just guesses
  double upstream_e_FFQ_face   = 2.5*m;
  double downstream_e_FFQ_face = 3.0*m;
  double e_FFQ_length          = 0.75*m;

  struct { 
    double length            = 0.60*m;
    double inner_radius      = 3.0*cm;
    double Au_thickness      = 0.01*mm;
    double Be1_thickness     = 0.5*mm;
    double coolant_thickness = 1.0*mm;
    double Be2_thickness     = 0.6*mm;
    double z_position        = 0.0*mm;
  } bp0_pars;

  struct { 
    double length            = 0.8*m;
    double inner_radius      = 3.0*cm;
    double inner_radius2     = 6.0*cm;
    double Au_thickness      = 0.01*mm;
    double Be1_thickness     = 0.5*mm;
    double coolant_thickness = 1.0*mm;
    double Be2_thickness     = 0.6*mm;
    double z_position        = 0.0*mm;
    double taper_angle       = 0.100*rad;
  } bp1_pars;
  bp1_pars.z_position = bp0_pars.length/2.0 + bp1_pars.length/2.0;
  bp1_pars.inner_radius2 = bp1_pars.inner_radius + bp1_pars.length*TMath::Sin(bp1_pars.taper_angle);

  struct { 
    double length            = 0.20*m;
    double inner_radius      = 6.0*cm;
    double inner_radius2     = 3.1*cm;
    double Au_thickness      = 0.01*mm;
    double Be1_thickness     = 0.5*mm;
    double coolant_thickness = 1.0*mm;
    double Be2_thickness     = 0.6*mm;
    double z_position        = 0.0*mm;
    double taper_angle       = 0.150*rad;
  } bp2_pars;
  bp2_pars.inner_radius  = bp1_pars.inner_radius2;
  bp2_pars.z_position    = bp0_pars.length/2.0 + bp1_pars.length + bp2_pars.length/2.0;
  bp2_pars.inner_radius2 = bp2_pars.inner_radius - bp2_pars.length*TMath::Sin(bp2_pars.taper_angle);

  // get the parameters
  for(xml_coll_t bp(x_det,"beampipe"); bp; ++bp)  {
    //std::cout << bp << std::endl;
    xml_comp_t beampipe_comp = bp;
    if(beampipe_comp.nameStr() == std::string("CentralBeamPipe")) {
      //std::cout << " CentralBeamPipe\n";
      bp0_pars.inner_radius = getAttrOrDefault<double>(beampipe_comp,_Unicode(inner_raius),bp0_pars.inner_radius);
    }
  }

  Tube  s_bp0(bp0_pars.inner_radius, bp0_pars.inner_radius+2.0*mm, bp0_pars.length/2.0);//,2.0*TMath::Pi()+0.01);
  Cone  s_bp1( bp1_pars.length/2.0, bp1_pars.inner_radius, bp1_pars.inner_radius+2.0*mm, bp1_pars.inner_radius2, bp1_pars.inner_radius2+2.0*mm);
  Cone  s_bp2( bp2_pars.length/2.0, bp2_pars.inner_radius, bp2_pars.inner_radius+2.0*mm, bp2_pars.inner_radius2, bp2_pars.inner_radius2+2.0*mm);

  Transform3D tr1( ROOT::Math::EulerAngles(0.0, 0.0*rad, 0.0), XYZVector{0,0,0}   );
  Transform3D tr_bp1( ROOT::Math::EulerAngles(0.0, 0.0*rad, 0.0), XYZVector{0,0,bp1_pars.z_position}   );
  Transform3D tr_bp2( ROOT::Math::EulerAngles(0.0, 0.0*rad, 0.0), XYZVector{0,0,bp2_pars.z_position}   );

  Volume  v_bp0( "tub0", s_bp0, m_Be);
  pv = assembly.placeVolume(v_bp0,tr1);
  Volume  v_bp1( "pb1", s_bp1, m_Al);
  pv = assembly.placeVolume(v_bp1,tr_bp1);
  Volume  v_bp2( "pb2", s_bp2, m_Al);
  pv = assembly.placeVolume(v_bp2,tr_bp2);

  // ion upstream 

  struct { 
    double length            = 0.6*m;
    double inner_radius      = 3.0*cm;
    double inner_radius2     = 6.0*cm;
    double Au_thickness      = 0.01*mm;
    double Be1_thickness     = 0.5*mm;
    double coolant_thickness = 1.0*mm;
    double Be2_thickness     = 0.6*mm;
    double z_position        = 0.0*mm;
    double taper_angle       = 0.100*rad;
  } bp3_pars;
  bp3_pars.z_position = bp0_pars.length/2.0 + bp3_pars.length/2.0;
  bp3_pars.inner_radius2 = bp3_pars.inner_radius + bp3_pars.length*TMath::Sin(bp3_pars.taper_angle);

  struct { 
    double length            = 0.20*m;
    double inner_radius      = 6.0*cm;
    double inner_radius2     = 3.0*cm;
    double Au_thickness      = 0.01*mm;
    double Be1_thickness     = 0.5*mm;
    double coolant_thickness = 1.0*mm;
    double Be2_thickness     = 0.6*mm;
    double z_position        = 0.0*mm;
    double taper_angle       = 0.150*rad;
  } bp4_pars;

  bp4_pars.inner_radius  = bp3_pars.inner_radius2;
  bp4_pars.length        = (bp4_pars.inner_radius - bp4_pars.inner_radius2)/(TMath::Sin(bp4_pars.taper_angle));
  bp4_pars.z_position    = bp0_pars.length/2.0 + bp3_pars.length + bp4_pars.length/2.0;

  Cone  s_bp3( bp3_pars.length/2.0, bp3_pars.inner_radius, bp3_pars.inner_radius+2.0*mm, bp3_pars.inner_radius2, bp3_pars.inner_radius2+2.0*mm);
  Cone  s_bp4( bp4_pars.length/2.0, bp4_pars.inner_radius, bp4_pars.inner_radius+2.0*mm, bp4_pars.inner_radius2, bp4_pars.inner_radius2+2.0*mm);

  Transform3D tr_bp3( ROOT::Math::EulerAngles(0.0, 180.0*degree, 0.0), XYZVector{0,0,-bp3_pars.z_position}   );
  Transform3D tr_bp4( ROOT::Math::EulerAngles(0.0, 180.0*degree, 0.0), XYZVector{0,0,-bp4_pars.z_position}   );

  Volume  v_bp3( "pb3", s_bp3, m_Al);
  pv = assembly.placeVolume(v_bp3,tr_bp3);
  Volume  v_bp4( "pb4", s_bp4, m_Al);
  pv = assembly.placeVolume(v_bp4,tr_bp4);

  v_bp0.setVisAttributes(det,"GrayVis");
  v_bp1.setVisAttributes(det,"RedVis");
  v_bp2.setVisAttributes(det,"GrayVis");
  v_bp3.setVisAttributes(det,"RedVis");
  v_bp4.setVisAttributes(det,"GrayVis");

  // ------------------------------------------
  // ion downstream exit  pipe
  double ion_sep_flange_pos = bp0_pars.length/2.0 + bp1_pars.length + bp2_pars.length;
  //std::cout << "ion_sep_flange_pos " << ion_sep_flange_pos/cm << " m\n";

  double ion_exit_pipe_inner_radius = 1.5*cm;
  double ion_exit_pipe_length = 7.0*m;
  double ion_exit_pipe_angle  = 0.01154*rad;
  double ion_crossing_angle   = 0.05*rad;
  double ion_exit_pipe_zpos   = bp0_pars.length/2.0 + bp1_pars.length + bp2_pars.length + ion_exit_pipe_length/2.0;
  double ion_exit_pipe_inner_radius2 = ion_exit_pipe_inner_radius + ion_exit_pipe_length*TMath::Sin(ion_exit_pipe_angle);
  Cone        s_ion_exit(ion_exit_pipe_length/2.0,ion_exit_pipe_inner_radius, ion_exit_pipe_inner_radius+2.0*mm, ion_exit_pipe_inner_radius2, ion_exit_pipe_inner_radius2 + 2.0*mm);

  XYZVector  ion_exit_pos{0,0,ion_exit_pipe_zpos};
  RotationY  ion_exit_rot( -1.0*ion_crossing_angle);
  XYZVector  ion_exit_pos2 = ion_exit_rot*ion_exit_pos;
  Transform3D tr_ion_exit(ion_exit_rot , ion_exit_pos2   );
  Volume      v_ion_exit("ion_exit_pipe", s_ion_exit, m_Al);
  pv = assembly.placeVolume(v_ion_exit,tr_ion_exit);
  v_ion_exit.setVisAttributes(det,"OrangeVis");

  // ------------------------------------------
  // ion upstream entrance pipe
  double ion_enter_pipe_inner_radius  = 1.5*cm;
  double ion_enter_pipe_length        = 7.0*m;
  double ion_enter_pipe_angle         = 0.01154*rad;
  double ion_enter_pipe_zpos          = bp0_pars.length/2.0 + bp3_pars.length + ion_enter_pipe_length/2.0;
  double ion_enter_pipe_inner_radius2 = ion_enter_pipe_inner_radius + ion_enter_pipe_length*TMath::Sin(ion_enter_pipe_angle);
  // note the order of the radii are switched here: 
  Cone        s_ion_enter(ion_enter_pipe_length/2.0, 
                          ion_enter_pipe_inner_radius2, ion_enter_pipe_inner_radius2 + 2.0*mm,
                          ion_enter_pipe_inner_radius, ion_enter_pipe_inner_radius+2.0*mm);
  XYZVector  ion_enter_pos{0,0,-ion_enter_pipe_zpos};
  RotationY  ion_enter_rot( -1.0*ion_crossing_angle);
  XYZVector  ion_enter_pos2 = ion_enter_rot*ion_enter_pos;
  Transform3D tr_ion_enter(ion_enter_rot , ion_enter_pos2   );
  Volume      v_ion_enter("ion_enter_pipe", s_ion_enter, m_Al);
  pv = assembly.placeVolume(v_ion_enter,tr_ion_enter);
  v_ion_enter.setVisAttributes(det,"OrangeVis");

  // -------------------------------
  // FFQs
  double e_FFQ0_z_pos = upstream_e_FFQ_face + e_FFQ_length/2.0;
  Tube  s_FFQ0(3.0*cm, 8.0*cm, e_FFQ_length/2.0);
  Transform3D tr_FFQ0( XYZVector{0,0, -e_FFQ0_z_pos}  );
  Volume      v_FFQ0("ion_enter_pipe", s_FFQ0, m_Al);
  pv = assembly.placeVolume(v_FFQ0,tr_FFQ0);
  v_FFQ0.setVisAttributes(det,"BlueVis");

  //for(xml_coll_t i(x_det,_U(layer)); i; ++i, ++n)  {
  //  xml_comp_t x_layer = i;
  //  string  l_name = det_name+_toString(n,"_layer%d");
  //  double  z    = x_layer.outer_z();
  //  double  rmin = x_layer.inner_r();
  //  double  z_offset = 0.0;
  //  if(x_layer.hasAttr(_Unicode(z_offset))) {
  //    z_offset = x_layer.z_offset();
  //  }
  //  double  r    = rmin;
  //  DetElement layer(sdet,_toString(n,"layer%d"),x_layer.id());
  //  int m = 0;

  //  printout(INFO, "GenericShapeJLEIC", "Creating a Generic Layer");
  //  for(xml_coll_t j(x_layer,_U(slice)); j; ++j, ++m)  {
  //    xml_comp_t x_slice = j;
  //    Material mat = det.material(x_slice.materialStr());
  //    string s_name= l_name+_toString(m,"_slice%d");
  //    double thickness = x_slice.thickness();
  //    Tube   s_tub(r, r+thickness,z);//,2.0*TMath::Pi()+0.01);
  //    Volume s_vol(s_name, s_tub, mat);

  //    r += thickness;
  //    s_vol.setVisAttributes(det,x_det.visStr());
  //    pv = assembly.placeVolume(s_vol,Position(0, 0, z_offset));
  //    // Slices have no extra id. Take the ID of the layer!
  //    pv.addPhysVolID("slice",m);
  //    printout(INFO, "GenericShapeJLEIC", "Creating Generic Slice");
  //  }
  //  //cout << l_name << " " << rmin << " " << r << " " << z << endl;
  //    
  //}

  pv = det.pickMotherVolume(sdet).placeVolume(assembly);
  pv.addPhysVolID("system",sdet.id()).addPhysVolID("barrel",0);
  sdet.setPlacement(pv);
  assembly->GetShape()->ComputeBBox() ;
  return sdet;
}

DECLARE_DETELEMENT(JLEICBeampipe,create_detector)
