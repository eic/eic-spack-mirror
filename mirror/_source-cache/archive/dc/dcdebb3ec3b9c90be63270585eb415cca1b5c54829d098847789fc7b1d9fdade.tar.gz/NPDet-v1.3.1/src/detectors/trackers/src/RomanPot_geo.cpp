#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "DD4hep/Shapes.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace ROOT::Math;

/** \addtogroup trackers Tracking Detectors
 *
 *
 */

/** \addtogroup romanpot Roman Pot Tracker
 * \brief Type: **RomanPot**, for small angle detection.
 * \ingroup trackers
 *
 *  The Roman pot is a movable detector in the forward direction that integrates with the beampipe vacuum. 
 *
 * \code
 *   <detector id = "1" name = "MyRomanPot" type = "RomanPot" readout =
 *             "ForwardRomanPotHits" vis = "InvisibleWithDaughters">
 *     <dimensions x = "3.0*cm" y = "3.0*cm" delta = "0.5*cm" />
 *     <frame x = "10.0*cm" y = "5.0*cm" z = "2*cm" />
 *     <position z_offset = "0.0*m" rotation = "false" vmax = "10*cm" v = "2.0*cm" />
 *     <layer repeat = "5">
 *       <slice material="Carbon"  thickness="0.5*mm"  vis = "BlueVis" />
 *       <slice material="Silicon" thickness="0.3*mm"  vis = "GreenVis" sensitive = "true"  />
 *       <slice material="Carbon"  thickness="0.5*mm"  vis = "BlueVis" />
 *       <slice material="Vacuum"  thickness="1.0*mm"  vis="InvisibleWithDaughters" />
 *     </layer>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t build_detector(Detector& dtor, xml_h e, SensitiveDetector sens) {
  xml_det_t  x_det        = e;
  //Layering   layering     (e);
  int        det_id       = x_det.id();
  string     det_name     = x_det.nameStr();
  xml_dim_t  dim          = x_det.dimensions();
  double     pixel_x      = dim.x();
  double     pixel_y      = dim.y();
  double     delta        = dim.delta();
  xml_dim_t  frame_dim    = x_det.child(_U(frame));
  double     frame_x      = frame_dim.x();
  double     frame_y      = frame_dim.y();
  double     frame_z      = frame_dim.z();
  string     frame_vis    = dd4hep::getAttrOrDefault(frame_dim, _Unicode(vis), "RPLayerVis");
  xml_dim_t  pos          = x_det.position();
  double     zoffset      = pos.z_offset();
  double     x_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(x),0.0);
  double     y_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(y),0.0);
  double     z_pos        = dd4hep::getAttrOrDefault(pos, _Unicode(z),0.0);
  bool       rotated      = pos.attr<bool>(_Unicode(rotation));
  double     pos_out      = pos.attr<double>(_Unicode(vmax));
  double     curr_pos     = pos.attr<double>(_Unicode(v));
  Material   vacuum       = dtor.material("Vacuum");
  Material   aluminum     = dtor.material("Aluminum");
  Material   frame_mat    = dtor.material("Aluminum");

  DetElement sdet(det_name, det_id);
  Assembly   assembly(det_name + "_assembly");

  sens.setType("tracker");
  string module_name = "RomanPot";

  string vis0 = dd4hep::getAttrOrDefault(x_det, _Unicode(vis), "BlueVis");

  sdet.setAttributes(dtor, assembly, x_det.regionStr(), x_det.limitsStr(), x_det.visStr());

  double rp_detector_tube_length    = frame_x + pos_out; // TODO: Shortest possible tube given the RP dimensions. Will probably change in the future.
  double rp_detector_tube_thickness = 5.0 * dd4hep::mm;
  double rp_detector_tube_radius    = 0.55*sqrt(frame_z * frame_z + frame_y * frame_y); // TODO: Tightest possible fit. Will probably change in the future.
  Tube   rp_detector_vacuum_tube(0.0, rp_detector_tube_radius + rp_detector_tube_thickness, rp_detector_tube_length);
  Tube   rp_detector_vacuum_tube2(0.0, rp_detector_tube_radius, rp_detector_tube_length);

  // These are currently hardcoded. Will probably change in the future.
  double rp_chamber_thickness = 10.0 * dd4hep::mm;
  double rp_chamber_radius    = 5.0 * dd4hep::cm;
  double rp_chamber_length    = rp_detector_tube_radius*1.5;

  // All the rotation and translation shenanigans related to RP unit orientation happen here.
  // `rot1` and `rot2` are used for in construction of the tubes, `shift_pos1` and `shift_pos2`
  // properly transform the RP detector positions.
  auto rot1 = rotated ? Rotation3D(RotationX(0.5*M_PI)) : Rotation3D(RotationY(0.5*M_PI));
  auto rot2 = rotated ? Rotation3D(RotationX(-0.5*M_PI)) : Rotation3D(RotationY(-0.5*M_PI));
  auto shift_pos1 = rotated ? Transform3D(RotationZ(0.5 * M_PI) * Translation3D(curr_pos + 0.5 * frame_x, 0.0, 0.0))
                            : Transform3D(Translation3D(curr_pos + 0.5 * frame_x, 0, 0));
  auto shift_pos2 = rotated ? Transform3D(RotationZ(-0.5 * M_PI) * Translation3D(curr_pos + 0.5 * frame_x, 0.0, 0.0))
                            : Transform3D(RotationZ(M_PI) * Translation3D(curr_pos + 0.5 * frame_x, 0, 0));
  auto det_offset = Position(0.5*(pixel_x + delta - frame_x), 0, 0);

  // Construct the RP enclosure shell.
  Tube   rp_beam_pipe_tube(rp_chamber_radius, rp_chamber_radius + rp_chamber_thickness, rp_chamber_length/2.0);
  Tube   rp_beam_vacuum_tube(0.0,  rp_chamber_radius + rp_chamber_thickness, rp_chamber_length);
  Tube   rp_beam_vacuum_tube2(0.0, rp_chamber_radius, rp_chamber_length);
  UnionSolid rp_chamber_tee_outer1(rp_beam_vacuum_tube, rp_detector_vacuum_tube, rot1);
  UnionSolid rp_chamber_tee_outer(rp_chamber_tee_outer1, rp_detector_vacuum_tube, rot2);
  UnionSolid rp_chamber_tee_inner1(rp_beam_vacuum_tube2, rp_detector_vacuum_tube2, rot1);
  UnionSolid rp_chamber_tee_inner(rp_chamber_tee_inner1, rp_detector_vacuum_tube2, rot2);
  //SubtractionSolid shell(rp_chamber_tee_outer,rp_chamber_tee_inner);
  Volume           rp_chamber_vol("rp_chamber_walls_vol", rp_chamber_tee_outer, aluminum);
  Volume           rp_vacuum_vol("rp_chamber_vacuum_vol", rp_chamber_tee_inner, vacuum);

  auto chamber_pv = assembly.placeVolume(rp_chamber_vol);
  auto vacuum_pv  = rp_chamber_vol.placeVolume(rp_vacuum_vol);
  vacuum_pv.addPhysVolID("element", 1);
  rp_chamber_vol.setVisAttributes(vis0.c_str());
  rp_vacuum_vol.setVisAttributes(vis0.c_str());
  //rp_vacuum_vol.setVisAttributes(dtor.invisible());

  DetElement vacuum_DE(sdet, "vacuum_DE", 1);
  // Make the enclosure box for the detector frame
  Box frame_box_full(0.5 * frame_x, 0.5 * frame_y, 0.5 * frame_z);
  Box det_cutoff(0.5 * (pixel_x + delta), 0.5 * (pixel_y + delta), 0.5 * frame_z);
  // Make the cutout where whe detector will sit
  // The frame with a hole for the detector
  SubtractionSolid frame_box(frame_box_full, det_cutoff, det_offset); 
  // Here we assum there is only one unique layer which is repeated.
  // Layer
  xml_comp_t x_layer          = x_det.child(_U(layer));
  const int repeat = x_layer.repeat();
  double layer_thickness =  0.0;
  for (xml_coll_t si(x_layer, _U(slice)); si; ++si) {
    xml_comp_t x_slice         = si;
    layer_thickness += x_slice.thickness();
  }
  std::cout << " layer thickness = " << layer_thickness << " \n";
  double total_thickness = repeat*layer_thickness;
  // --- d1 ---
  //
  Volume       frame_box_full1_vol("frame_box_full1", frame_box_full, vacuum);
  PlacedVolume frame_box_full1_pv = rp_vacuum_vol.placeVolume(frame_box_full1_vol, shift_pos1);
  DetElement   frame1_DE(vacuum_DE, "frame_DE1", 1);
  frame_box_full1_pv.addPhysVolID("frame", 1);

  frame1_DE.setAttributes(dtor, frame_box_full1_vol, x_det.regionStr(), x_det.limitsStr(), frame_vis);

  Volume       frame1_vol("xsensor_frame1", frame_box, frame_mat);
  PlacedVolume frame1_pv = frame_box_full1_vol.placeVolume(frame1_vol);

  // Loop over layers
  double     layer_pos_offset = -0.5 * total_thickness;
  int        layer_num        = 1;
  // How many times does the layer repeat. Defined in the compact description.
  for (int j = 0; j < repeat; j++) {
    string layer_name = _toString(layer_num, "layer1_%d");
    // double layer_thickness =
    //    layering.layer(layer_num - 1)->thickness(); // Get the thickness of the current layer.
    Position   layer_pos = Position(0, 0, layer_pos_offset + 0.5 * layer_thickness);
    Box        layer_box(0.5 * (pixel_x + delta), 0.5 * (pixel_y + delta), layer_thickness / 2.0);
    Volume     layer_vol(layer_name, layer_box, vacuum);
    DetElement layer(frame1_DE, layer_name, layer_num);
    layer.setAttributes(dtor, layer_vol, x_det.regionStr(), x_det.limitsStr(), frame_vis);

    // Loop over slices within the layer
    double slice_pos_offset = -0.5 * layer_thickness;
    int    slice_num        = 1;
    for (xml_coll_t si(x_layer, _U(slice)); si; ++si) {
      xml_comp_t x_slice         = si;
      string     slice_name      = _toString(slice_num, "slice1_%d");
      double     slice_thickness = x_slice.thickness();
      Position   slice_pos       = Position(0, 0, slice_pos_offset + 0.5 * slice_thickness);
      Box        slice_box       = x_slice.isSensitive()
                          ? Box(0.5 * pixel_x, 0.5 * pixel_y, slice_thickness / 2.0)
                          : Box(0.5 * (pixel_x), 0.5 * (pixel_y), slice_thickness / 2.0);
      Volume slice_vol(slice_name, slice_box, dtor.material(x_slice.materialStr()));
      string slice_vis = dd4hep::getAttrOrDefault(x_slice, _Unicode(vis), "BlueVis");
      slice_vol.setVisAttributes(slice_vis.c_str());
      DetElement slice(layer, slice_name, slice_num);
      if (x_slice.isSensitive()) {
        Vector3D    u(1., 0., 0.);
        Vector3D    v(0., 1., 0.);
        Vector3D    n(0., 0., 1.);
        Vector3D    o(0., 0., 0.);
        double      inner_thickness = slice_pos_offset + slice_thickness / 2.0;
        double      outer_thickness = layer_thickness - inner_thickness;
        SurfaceType type(SurfaceType::Sensitive);
        VolPlane    surf(slice_vol, type, inner_thickness, outer_thickness, u, v, n, o);
        slice_vol.setSensitiveDetector(sens);
        sens.setType("tracker");
      }
      slice.setAttributes(dtor, slice_vol, x_det.regionStr(), x_det.limitsStr(), slice_vis);
      // Place the slice.
      PlacedVolume slice_pv = layer_vol.placeVolume(slice_vol, slice_pos);
      slice_pv.addPhysVolID("slice", slice_num );
      slice.setPlacement(slice_pv);
      slice_pos_offset += slice_thickness; // Move the position offset for the next slice.
      ++slice_num;
    }
    // Place the layer.
    PlacedVolume layer_pv = frame_box_full1_vol.placeVolume(layer_vol, layer_pos + det_offset);
    layer_pv.addPhysVolID("layer", layer_num );
    layer.setPlacement(layer_pv);
    layer_pos_offset += layer_thickness;
    ++layer_num;
  }

  // --- d2 ---
  //Volume       frame2_vol("xsensor_frame2", frame_box, frame_mat);
  //PlacedVolume frame2_pv = rp_vacuum_vol.placeVolume(frame2_vol, shift_pos2);
  //DetElement   frame2_DE(vacuum_DE, "frame_DE2", 2);
  //frame2_pv.addPhysVolID("frame", 2);
  //frame2_DE.setAttributes(dtor, frame2_vol, x_det.regionStr(), x_det.limitsStr(), "RedVis");

  Volume       frame_box_full2_vol("frame_box_full2", frame_box_full, vacuum);
  PlacedVolume frame_box_full2_pv = rp_vacuum_vol.placeVolume(frame_box_full2_vol, shift_pos2);
  DetElement   frame2_DE(vacuum_DE, "frame_DE2", 2);
  frame_box_full2_pv.addPhysVolID("frame", 2);
  frame2_DE.setAttributes(dtor, frame_box_full2_vol, x_det.regionStr(), x_det.limitsStr(), frame_vis);

  Volume       frame2_vol("xsensor_frame2", frame_box, frame_mat);
  PlacedVolume frame2_pv = frame_box_full2_vol.placeVolume(frame2_vol);

  //  Loop over layers
  layer_pos_offset = -0.5 * total_thickness;
  layer_num        = 1;
  for (int j = 0; j < repeat; j++) {
    string layer_name = _toString(layer_num, "layer2_%d");
    // double     layer_thickness = layering.layer(layer_num - 1)->thickness(); // Get the thickness
    // of the current layer.
    Position   layer_pos = Position(0, 0, layer_pos_offset + 0.5 * layer_thickness);
    Box        layer_box(0.5 * (pixel_x + delta), 0.5 * (pixel_y + delta), layer_thickness / 2.0);
    Volume     layer_vol(layer_name, layer_box, vacuum);
    DetElement layer(frame2_DE, layer_name, layer_num);
    layer.setAttributes(dtor, layer_vol, x_det.regionStr(), x_det.limitsStr(),
                        frame_vis);

    // Loop over slices within the layer
    double slice_pos_offset = -0.5 * layer_thickness;
    int    slice_num        = 1;
    for (xml_coll_t si(x_layer, _U(slice)); si; ++si) {
      xml_comp_t x_slice         = si;
      string     slice_name      = _toString(slice_num, "slice2_%d");
      double     slice_thickness = x_slice.thickness();
      Position   slice_pos       = Position(0, 0, slice_pos_offset + 0.5 * slice_thickness);
      Box        slice_box       = x_slice.isSensitive()
                          ? Box(0.5 * pixel_x, 0.5 * pixel_y, slice_thickness / 2.0)
                          : Box(0.5 * pixel_x, 0.5 * pixel_y, slice_thickness / 2.0);
      Volume slice_vol(slice_name, slice_box, dtor.material(x_slice.materialStr()));
      string slice_vis = dd4hep::getAttrOrDefault(x_slice, _Unicode(vis), "BlueVis");
      slice_vol.setVisAttributes(slice_vis.c_str());
      DetElement slice(layer, slice_name, slice_num);
      if (x_slice.isSensitive()) {
        Vector3D    u(1., 0., 0.);
        Vector3D    v(0., 1., 0.);
        Vector3D    n(0., 0., 1.);
        Vector3D    o(0., 0., 0.);
        double      inner_thickness = slice_pos_offset + slice_thickness / 2.0;
        double      outer_thickness = layer_thickness - inner_thickness;
        SurfaceType type(SurfaceType::Sensitive);
        VolPlane    surf(slice_vol, type, inner_thickness, outer_thickness, u, v, n, o);
        slice_vol.setSensitiveDetector(sens);
        sens.setType("tracker");
      }
      slice.setAttributes(dtor, slice_vol, x_det.regionStr(), x_det.limitsStr(), slice_vis);
      // Place the slice.
      PlacedVolume slice_pv = layer_vol.placeVolume(slice_vol, slice_pos);
      slice_pv.addPhysVolID("slice", slice_num );
      slice.setPlacement(slice_pv);
      slice_pos_offset += slice_thickness; // Move the position offset for the next slice.
      ++slice_num;
    }
    // Place the layer.
    PlacedVolume layer_pv = frame_box_full2_vol.placeVolume(layer_vol, layer_pos + det_offset);
    layer_pv.addPhysVolID("layer", layer_num );
    layer.setPlacement(layer_pv);
    layer_pos_offset += layer_thickness;
    ++layer_num;
    }

  auto assembly_pv = dtor.pickMotherVolume(sdet).placeVolume(assembly, Position(x_pos, y_pos, z_pos + zoffset));
  assembly_pv.addPhysVolID("system", det_id);
  sdet.setPlacement(assembly_pv);

  assembly->GetShape()->ComputeBBox();
  return sdet;
}
//@}
DECLARE_DETELEMENT(RomanPot, build_detector)
