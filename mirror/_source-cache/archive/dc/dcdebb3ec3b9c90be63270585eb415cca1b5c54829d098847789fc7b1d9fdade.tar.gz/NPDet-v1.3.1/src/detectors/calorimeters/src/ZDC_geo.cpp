//==========================================================================
//  Zero Degree Calorimeter Detector implementation 
//--------------------------------------------------------------------------
//  Build two towers of ZDC - small and large
//  Sampling type calorimeter
//  J.KIM
//  Created  2020-07-21 
//  Modified 2020-07-22
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"
#include "Math/Transform3D.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace dd4hep::detail;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup ZeroDegreeCalorimeter Zero-degree calorimeter
 * \brief Type: **ZeroDegreeCAL**.
 * \author J. Kim
 * \ingroup calorimeters
 *
 *
 * \code
 *	<detector id="1" name="smallZDC" type="ZDC" readout="ZDCHits" vis="RedVis">   
 *  	<detector id="2" name="largeZDC" type="ZDC" readout="ZDCHits" vis="RedVis">
 *   
 * \endcode
 *
 * @{
 */
static Ref_t createDetector(Detector& lcdd, xml_h e, SensitiveDetector sens) {
  	xml_det_t  x_det     = e;
	int        det_id    = x_det.id();
  	string     det_name  = x_det.nameStr();
  	xml_dim_t  pos       = x_det.position();
  	double     x_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(x),0.0);
  	double     y_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(y),0.0);
  	double     z_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(z),0.0);
	xml_dim_t  dim       = x_det.dimensions();
	double     pixel_x   = dim.x();
	double     pixel_y   = dim.y();
	Material   air       = lcdd.material("Air");	
	double     z         = z_pos;
	double     zmin      = z_pos;
	DetElement det(det_name, det_id);
	
	int layer_num = 1;
	int slice_num = 1;
	double totWidth = Layering(x_det).totalThickness();
	Box envelope (pixel_x/2.0, pixel_y/2.0,totWidth);
	Volume envelopeVol(det_name+"_envelope",envelope,air); 
	PlacedVolume pv;
	
	xml_comp_t x_layer = x_det.child(_U(layer));

	// Read layers
	for(xml_coll_t c(x_det,_U(layer)); c; ++c)
	{
		xml_comp_t x_layer = c;
		int repeat = x_layer.repeat();
		double layerWidth = 0;
		for(xml_coll_t l(x_layer,_U(slice)); l; ++l)
			layerWidth += xml_comp_t(l).thickness();

		// Loop over repeat#
		for(int i=0; i< repeat; i++)
		{
			double zlayer = z;
			string layer_name = det_name + _toString(layer_num,"_layer%d");
			Volume layer_vol(layer_name,Box(pixel_x/2.0, pixel_y/2.0,layerWidth/2.0),air);

			// Loop over slices
			for(xml_coll_t l(x_layer,_U(slice)); l; ++l)
			{
				xml_comp_t x_slice = l;
				double w = x_slice.thickness();
				string slice_name = layer_name + _toString(slice_num,"slice%d");
				Material slice_mat = lcdd.material(x_slice.materialStr());		
				Volume slice_vol (slice_name,Box(pixel_x/2.0, pixel_y/2.0,w/2.0),slice_mat);
				if(x_slice.isSensitive())
				{
					sens.setType("calorimeter");
					slice_vol.setSensitiveDetector(sens);
				}
				slice_vol.setAttributes(lcdd,x_slice.regionStr(), x_slice.limitsStr(), x_slice.visStr());
				pv = layer_vol.placeVolume(slice_vol, Transform3D(RotationZ(M_PI/2.0),Position(0.0,0.0,z-zlayer-layerWidth/2.0+w/2.0)));
				pv.addPhysVolID("slice", slice_num);
				z += w;
				++slice_num;
			}
			string layer_vis = dd4hep::getAttrOrDefault(x_layer, _Unicode(vis), "InvisibleWithDaughters");
			layer_vol.setAttributes(lcdd, x_layer.regionStr(), x_layer.limitsStr(), layer_vis);
			pv = envelopeVol.placeVolume(layer_vol, Transform3D(RotationZ(M_PI/4.0), Position(0,0,zlayer-zmin-totWidth/2.0+layerWidth/2.0)));
			pv.addPhysVolID("layer", layer_num);
			++layer_num;
		}
	}
	envelopeVol.setAttributes(lcdd,x_det.regionStr(), x_det.limitsStr(), "InvisibleWithDaughters");

	Volume motherVol = lcdd.pickMotherVolume(det);
	PlacedVolume phv = motherVol.placeVolume(envelopeVol, Position(x_pos,y_pos,z_pos+totWidth/2.0));
	phv.addPhysVolID("system", det.id());
	det.setPlacement(phv);

	return det;
}

DECLARE_DETELEMENT(ZDC, createDetector)
