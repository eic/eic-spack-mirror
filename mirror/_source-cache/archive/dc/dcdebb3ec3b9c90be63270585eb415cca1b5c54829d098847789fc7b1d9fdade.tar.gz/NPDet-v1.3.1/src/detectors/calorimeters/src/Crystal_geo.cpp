//==========================================================================
//  Crystal Endcap EM Calorimeter Detector implementation 
//--------------------------------------------------------------------------
// J.KIM  2020-07-30
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "XML/Layering.h"
#include <math.h>

using namespace std;
using namespace dd4hep;
using namespace dd4hep::detail;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup CrystalEndcapECAL Crystal calorimeter
 * \brief Type: **CrystalEndcapECAL**.
 * \author J. Kim
 * \ingroup calorimeters
 *
 *
 * \code
 *   <detector id="CrystalEndcap_ID" name="ElectronECAL" type="crystal" readout="EcalHits" vis="GreenVis">
 *               <position x="CrystalEndcap_x_pos" y="CrystalEndcap_y_pos" z="CrystalEndcap_z_pos"/>
 *               <dimensions rmin="CrystalEndcap_rmin" rmax="CrystalEndcap_rmax" x="CrystalBox_x_length" y="CrystalBox_y_length" z="CrystalBox_z_length"/>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t create_detector(Detector& description, xml_h e, SensitiveDetector sens) {
  xml_det_t x_det     = e;
  xml_dim_t dim       = x_det.dimensions();
  int       det_id    = x_det.id();
  string    det_name  = x_det.nameStr();
  Material  PbWO4     = description.material("PbWO4");
  double    rmin      = dim.rmin();
  double    rmax      = dim.rmax();
  double    pixel_x   = dim.x();
  double    pixel_y   = dim.y();
  double    pixel_z   = dim.z();
  xml_dim_t pos       = x_det.position();
  double    x_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(x),0.0);
  double    y_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(y),0.0);
  double    z_pos     = dd4hep::getAttrOrDefault(pos, _Unicode(z),0.0);
  double    totWidth  = pixel_z;

  Assembly    assembly(det_name);
  DetElement  endcap_DE(det_name,det_id);

  // Fill with box-shaped crystals forming a grid.
  Assembly box_assembly("box_assembly");
  PlacedVolume pv_box;

  // Gap between box-shaped crystals
  double offset_x = 0.1*mm;
  double offset_y = 0.1*mm;
  double offset_diagonal = pixel_x*sqrt(2)/2.0 + offset_x;
  // Limits
  double limit_inner = rmin + offset_diagonal;
  double limit_outer = rmax - offset_diagonal;
  // Number of crystals in a grid
  int nx = floor(rmax/pixel_x);
  int ny = floor(rmax/pixel_y);
  // X or Y spacing increasement
  double x_spacing = pixel_x + offset_x;
  double y_spacing = pixel_y + offset_y;
  // initial positions in X or Y.
  double pos_x = 0.0*mm;
  double pos_y = 0.0*mm;

  // Create Box and Volume
  Box box(pixel_x/2.0, pixel_y/2.0, pixel_z/2.0);
  Volume vol("box_volume", box, PbWO4);
 
  ////////////////////////////////////////////////////////////////////////////////////
  // Divide tube into 4 sections; top left, top right, bottom left, and bottom right
  ////////////////////////////////////////////////////////////////////////////////////
  // Top left
  ////////////////////////////////////////////////////////////////////////////////////
  int i_module = 0;
  pos_y = pixel_y/2.0 + offset_y/2.0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = pixel_x/2.0 + offset_x/2.0;

        if(ix==0)
	{
		pos_x = x_start;
		if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                	pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
		else{
			continue;
                }
	}
	else
        {
		// Move to +X
                pos_x += x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner)
                {
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",1).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to +Y  
  pos_y += y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Top right
  ////////////////////////////////////////////////////////////////////////////////////
  // Initialize position in Y
  pos_y = pixel_y/2.0 + offset_y/2.0;
  i_module=0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = pixel_x/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = - x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else    
        {
		// Move to -X
                pos_x -= x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",2).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to +Y
  pos_y += y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Bottom left
  ////////////////////////////////////////////////////////////////////////////////////  
  // It's below the first row of the section of Top left
  // That's why ny goes up to ny -2 (the first row of Bottom left starts one row less)
  pos_y = -y_spacing/2.0 - offset_y/2.0;
  i_module=0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = pixel_x/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else
        {
		// Move to +X
                pos_x += x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",3).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to -Y
  pos_y -= y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Bottom right
  ////////////////////////////////////////////////////////////////////////////////////
  // Again it's below the first row of the section of Top left
  // That's why ny goes up to ny -2 (the first row of Bottom left starts one row less)
  pos_y = -y_spacing/2.0 - offset_y/2.0;
  i_module=0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++)
  {
        double x_start = pixel_x/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = - x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else
        {
		// Move to -X
                pos_x -= x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",4).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to -Y
  pos_y -= y_spacing;
  }
  ////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////

  Volume motherVol = description.pickMotherVolume(endcap_DE);
  auto   pv        = motherVol.placeVolume(assembly, Position(x_pos,y_pos,z_pos-totWidth/2.0));
  pv.addPhysVolID("system", det_id);
  endcap_DE.setPlacement(pv);
  return endcap_DE;
}
//@}
DECLARE_DETELEMENT(Crystal,create_detector)
