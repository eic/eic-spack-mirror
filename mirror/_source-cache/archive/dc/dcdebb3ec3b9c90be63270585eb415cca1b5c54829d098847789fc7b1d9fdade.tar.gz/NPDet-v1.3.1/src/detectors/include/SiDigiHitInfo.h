#ifndef SiDigiHitInfo_HH
#define SiDigiHitInfo_HH



namespace npdet {
  namespace digi {

    struct SiDigiHitInfo {
      int64_t volumeID;
      int64_t cellID;
      double  pathLength;
      double  EDep;
      ROOT::Math::XYZTVector position;
      ROOT::Math::XYZTVector momentum;
    };

  }
}

#endif

