#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include <XML/Helper.h>
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;

using namespace dd4hep;

/** \addtogroup PID Particle ID Detectors 
 */

/** \addtogroup HexagonalScintPreShower Hexagonal preshower detector.
 * \brief Type: **HexagonalScintPreShower**.
 * \ingroup PID
 *
 *
 * \code
 *   <detector>
 *   </detector>
 * \endcode
 * @{
 */
static Ref_t createDetector(Detector& desc, xml::Handle_t handle, SensitiveDetector sens) {
    xml::DetElement detElem = handle;

    std::string detName = detElem.nameStr();
    int detID = detElem.id();

    xml::Component dims = detElem.dimensions();
    double rInner = dims.rmin();
    double rOuter1 = dims.rmax1();
    double rOuter2 = dims.rmax2();
    double zMin = dims.zmin();
    double zMax = dims.zmax();

    Material air = desc.air();
    Material PyrexGlass = desc.material("PyrexGlass");

    Assembly assembly( detName+"_assembly" );
    //Cone envShape(0.5 * (zMax - zMin), rInner, rOuter1, rInner, rOuter2);
    //Volume envVol(detName + "_envelope", envShape, air);

    double l_side            = 6.25 * cm;
    double r_nearest         = l_side * std::sqrt(3.0) / 2.0;
    double thickness         = 2.0 * cm;
    double l_side_spacing    = 6.25 * cm + 1.0 * mm;
    double r_nearest_spacing = l_side_spacing * std::sqrt(3.0) / 2.0;
    double y_spacing         = 1.5*l_side_spacing;

    std::vector<double> ptx     = { r_nearest,        0.0,    -r_nearest,     -r_nearest,     0.0, r_nearest };
    std::vector<double> pty     = { l_side/2.0, l_side, l_side/2.0, -l_side/2.0, -l_side, -l_side/2.0 };
    std::vector<double> sec_x   = { 0.0, 0.0 };
    std::vector<double> sec_y   = { 0.0, 0.0 };
    std::vector<double> sec_z   = { -thickness/2.0, thickness/2.0 };
    std::vector<double> z_scale = { 1.0, 1.0 };
    std::vector<double> sec_r   = {r_nearest, r_nearest};

    int nx = 10;
    int ny = 10;

    double width_x = (2.0*r_nearest_spacing)*nx + r_nearest_spacing;
    double width_y = (y_spacing)*ny + 0.5*l_side_spacing;

    double offset_x = -(width_x / 2.0) + r_nearest_spacing;
    double offset_y = -(width_y / 2.0) + l_side_spacing;

    Box Pb_wall_shape(width_x/2.0, width_y/2.0,1.2*cm/2.0);
    Volume Pb_wall_Vol("Pb_preshower_wall", Pb_wall_shape, desc.material("Lead"));
    PlacedVolume Pb_wall_PV = assembly.placeVolume(Pb_wall_Vol, Position(0.0,0.0, -5.0*cm));

    //ExtrudedPolygon  mirrorShape("hex_scint",ptx, pty, sec_z, sec_x, sec_y, z_scale);
    Polyhedra hexScintShape("hex_lead", 6, 0.0, 2.0*M_PI, sec_z, sec_r);
    Volume scintVol("hex_scint_volume", hexScintShape, PyrexGlass);
    scintVol.setSensitiveDetector(sens);
    sens.setType("calorimeter");

    for(int ix =0; ix<nx; ix++){
      for(int iy =0; iy<ny; iy++){
        double extra_x = -(iy%2)*r_nearest_spacing + r_nearest_spacing;
        PlacedVolume mirrorPV = assembly.placeVolume(
            scintVol, Translation3D(offset_x + ix * (2.0 * r_nearest_spacing) + extra_x,
                                offset_y + iy * (y_spacing), 
                                0.0)*RotationZ(M_PI*30.0/180.0));
      }
    }

    scintVol.setVisAttributes(desc.visAttributes(detElem.visStr()));
    assembly.setVisAttributes(desc.visAttributes(detElem.visStr()));

    DetElement det(detName, detID);
    Volume motherVol = desc.pickMotherVolume(det);
    PlacedVolume envPV = motherVol.placeVolume(assembly, Position(0, 0, 0.5 * (zMin + zMax)));
    envPV.addPhysVolID("system", detID);
    det.setPlacement(envPV);
    return det;
}
//@}
// clang-format off
DECLARE_DETELEMENT(HexagonalScintPreShower, createDetector)
