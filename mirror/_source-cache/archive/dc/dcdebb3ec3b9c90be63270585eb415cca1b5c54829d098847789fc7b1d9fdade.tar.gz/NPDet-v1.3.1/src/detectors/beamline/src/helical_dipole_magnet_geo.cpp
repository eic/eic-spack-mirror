#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "DD4hep/Shapes.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"
#include "XML/Layering.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
using namespace ROOT::Math;

static Ref_t build_magnet(Detector& dtor, xml_h e, SensitiveDetector sens) {
    xml_det_t x_det     = e;
    int       det_id    = x_det.id();
    string    det_name  = x_det.nameStr();
    xml_dim_t pos       = x_det.child(_U(placement));
    double    pos_x     = pos.x();
    double    pos_y     = pos.y();
    double    pos_z     = pos.z();
    double    pos_theta = pos.attr<double>(_U(theta));
    double    pos_psi   = pos.attr<double>(_U(psi));
    xml_dim_t dims      = x_det.dimensions();
    double    dim_r     = dims.r();
    double    dim_z     = dims.z();
    xml_dim_t apperture = x_det.child(_Unicode(apperture));
    double    app_r     = apperture.r();
    xml_dim_t coil      = x_det.child(_Unicode(coil));
    double    coil_y    = coil.dy();
    Material  aluminum  = dtor.material("Aluminum");
    Material  niobium   = dtor.material("Niobium");

    DetElement sdet(det_name, det_id);
    Assembly   assembly(det_name + "_assembly");

    string module_name = "Spin_polarizer";

    string vis0 = dd4hep::getAttrOrDefault(x_det, _Unicode(vis), "BlueVis");

    sdet.setAttributes(dtor, assembly, x_det.regionStr(), x_det.limitsStr(), "OrangeVis");

    int N = 45;
    double segment_length = dim_z/(2*N);
    double shell_delta = 10.0*dd4hep::mm;
   
    UnionSolid coil_rod;

    Tube shell_tube(app_r, dim_r, 0.5*dim_z);
    Tube coil_segment(app_r + shell_delta, app_r + coil_y, segment_length/2, M_PI/N);

    coil_rod = UnionSolid(coil_segment, coil_segment, Transform3D( RotationZ(M_PI) ));

    for (double a = -M_PI/3; a < M_PI/3; a += 4*M_PI/N){
        coil_rod = UnionSolid(coil_rod, coil_segment, Transform3D(RotationZ(a)));
    }

    for (double a = -M_PI/3; a < M_PI/3; a += 4*M_PI/N){
        coil_rod = UnionSolid(coil_rod, coil_segment, Transform3D(RotationZ(M_PI + a)));
    }

    for (int i = 1; i < 2*N; i++){
        for (double a = -M_PI/3; a < M_PI/3; a += 4*M_PI/N){
            coil_rod = UnionSolid(coil_rod, coil_segment, Transform3D( RotationZ(a + i*M_PI/N) * Translation3D(0, 0, i*segment_length) ));
            coil_rod = UnionSolid(coil_rod, coil_segment, Transform3D( RotationZ(M_PI + a + i*M_PI/N) * Translation3D(0, 0, i*segment_length) ));
        }
    }

    SubtractionSolid shell(shell_tube, coil_rod, Position(0.0, 0.0, -0.5*(dim_z - segment_length)));

    Volume coil_vol("coil_vol", coil_rod, niobium);
    auto coil_pv = assembly.placeVolume(coil_vol, Position(0, 0, -0.5*(dim_z - segment_length)));
    DetElement coil_de(sdet, "coil_de", 2);
    coil_de.setAttributes(dtor, coil_vol, x_det.regionStr(), x_det.limitsStr(), "RedVis");
    coil_de.setPlacement(coil_pv);

    Volume shell_vol("shell_vol", shell, niobium);
    auto shell_pv = assembly.placeVolume(shell_vol);
    DetElement shell_de(sdet, "shell_de", 2);
    shell_de.setAttributes(dtor, shell_vol, x_det.regionStr(), x_det.limitsStr(), "BlueVis");
    shell_de.setPlacement(shell_pv);

    // -- finishing steps
    auto final_pos = Transform3D(Translation3D(pos_x, pos_y, pos_z) * RotationY(pos_theta) * RotationZ(pos_psi));
    auto pv = dtor.pickMotherVolume(sdet).placeVolume(assembly, final_pos);
    pv.addPhysVolID("system", det_id);
    sdet.setPlacement(pv);

    assembly->GetShape()->ComputeBBox();
    return sdet;
}

DECLARE_DETELEMENT(HelicalDipole, build_magnet)
