#include "DD4hep/DetFactoryHelper.h"
#include "DD4hep/Printout.h"
#include "DD4hep/Shapes.h"
#include "TMath.h"
#include "DDRec/Surface.h"
#include "DDRec/DetectorData.h"

using namespace std;
using namespace dd4hep;
using namespace dd4hep::rec;
//using namespace DD4hep::Geometry;
//using namespace DD4hep::DDRec;
//using namespace DDSurfaces;

static Ref_t create_detector(Detector& lcdd, xml_h e, SensitiveDetector sens)
{
  typedef vector<PlacedVolume> Placements;

  xml_det_t   x_det     = e;
  Material    air       = lcdd.air();
  Material    carbon    = lcdd.material("CarbonFiber");
  Material    silicon   = lcdd.material("SiliconOxide");
  Material    aluminum  = lcdd.material("Aluminum");
  Material    vacuum    = lcdd.material("Vacuum");
  Material supp_mat     = carbon;
  Material sens_mat     = silicon;

  int         det_id    = x_det.id();
  string      det_name  = x_det.nameStr();
  PlacedVolume             pv;

  DetElement  sdet(    det_name, det_id);
  Assembly    assembly(det_name + "_assembly");

  sens.setType("tracker");
  string module_name = "RomanPot";

  double z_offset    = x_det.attr<double>(  _Unicode(zoffset) );
  double nz    = ( x_det.hasAttr(_Unicode(nz)) ) ? x_det.attr<double>(_Unicode(zoffset)) : 5.0;
  std::cout << " NZ = " << nz << std::endl;

  double thickness = 0.01*dd4hep::cm;

  double rp_chamber_thickness = 5.0*dd4hep::mm;
  double rp_chamber_radius    = 5.0*dd4hep::cm;
  double rp_chamber_length    = 50.0*dd4hep::cm;
  Tube    rp_beam_pipe_tube(rp_chamber_radius, rp_chamber_radius+rp_chamber_thickness, rp_chamber_length/2.0);
  Tube    rp_beam_vacuum_tube(0.0, rp_chamber_radius+rp_chamber_thickness, rp_chamber_length/2.0);
  Tube    rp_beam_vacuum_tube2(0.0, rp_chamber_radius, rp_chamber_length/2.0);

  double rp_detector_tube_radius    = 2.5*dd4hep::cm;
  double rp_detector_tube_length    = 20.0*dd4hep::cm;
  Tube    rp_detector_tube(rp_detector_tube_radius, rp_detector_tube_radius+rp_chamber_thickness, rp_detector_tube_length/2.0);
  Tube    rp_detector_vacuum_tube(0.0, rp_detector_tube_radius+rp_chamber_thickness, rp_detector_tube_length/2.0);
  Tube    rp_detector_vacuum_tube2(0.0, rp_detector_tube_radius, rp_detector_tube_length/2.0);

  //ROOT::Math::RotationX   rX(M_PI);
  ROOT::Math::Rotation3D rot_X( ROOT::Math::RotationX(M_PI/2.0) );
  ROOT::Math::Rotation3D rot_Y( ROOT::Math::RotationY(M_PI/2.0) );

  UnionSolid rp_chamber_tee1(rp_beam_vacuum_tube, rp_detector_vacuum_tube, rot_X);
  UnionSolid rp_chamber_tee12(rp_chamber_tee1, rp_detector_vacuum_tube, rot_Y);

  UnionSolid rp_chamber_tee2(rp_beam_vacuum_tube2, rp_detector_vacuum_tube2, rot_X);
  UnionSolid rp_chamber_tee22(rp_chamber_tee2, rp_detector_vacuum_tube2, rot_Y);

  SubtractionSolid  sub1(rp_chamber_tee12,rp_chamber_tee22);
  Volume  rp_chamber_vol("rp_chamber_walls_vol", sub1, aluminum);

  Volume  rp_vacuum_vol("rp_chamber_vacuum_vol", rp_chamber_tee22, vacuum);

  //DetElement chamberwalls_DE( sdet, "chamber_walls_volume", 1 );
  pv = assembly.placeVolume( rp_chamber_vol );//, Transform3D(RotationZ(phi0_offset),Position(0.0,0.0,z)) );
  //pv.addPhysVolID( "layer", 1 );
  //chamberwalls_DE.setPlacement(pv);
  //chamberwalls_DE.setAttributes(lcdd, rp_chamber_vol, "", "", "RedVis");
  
  //DetElement chamber_DE( sdet, "chamber_volume", 1 );
  pv = assembly.placeVolume( rp_vacuum_vol );//, Transform3D(RotationZ(phi0_offset),Position(0.0,0.0,z)) );
  pv.addPhysVolID( "layer", 2 );
  //chamber_DE.setPlacement(pv);
  //chamber_DE.setAttributes(lcdd, rp_vacuum_vol, "", "", "BlueVis");
  //chamber_DE.setAttributes(lcdd, layer_assembly, "", "", "SiVertexLayerVis");

  double supp_x_half = 1.0*dd4hep::cm;
  double supp_y_half = 1.0*dd4hep::cm;
  double supp_thickness = 1.0*dd4hep::mm;
  double supp_gap_half_width = 1.0*dd4hep::mm;
  double sens_thickness = 0.1*dd4hep::mm;

  Box supp_box( supp_x_half,     supp_y_half,     supp_thickness/2.0 );
  Box sens_box( supp_x_half-supp_gap_half_width, supp_y_half-supp_gap_half_width, sens_thickness/2.0 );


  // -------- create a measurement plane for the tracking surface attched to the sensitive volume -----
  Vector3D u( 1. , 0. , 0. ) ;
  Vector3D v( 0. , 1. , 0. ) ;
  Vector3D n( 0. , 0. , 1. ) ;
  //Vector3D o( 0. , 0. , 0. ) ;

  // compute the inner and outer thicknesses that need to be assigned to the tracking surface
  // depending on wether the support is above or below the sensor
  // The tracking surface is used in reconstruction. It provides  material thickness
  // and radation lengths needed for various algorithms, routines, etc.
  double inner_thickness = supp_thickness/2.0;
  double outer_thickness = supp_thickness/2.0;

  double z_shift  = 5.0*dd4hep::mm;
  double xy_shift = 15.0*dd4hep::mm;

  SurfaceType type( SurfaceType::Sensitive ) ;

  //for(int ii = 0; ii<4; ii++) {
  //}

  // ------------- x1
  Volume      support1_vol( "xsenseor_supp", supp_box, supp_mat  );
  Volume      sensor1_vol(  "xsenseor_sens", sens_box, sens_mat );
  VolPlane    surf1( sensor1_vol, type, inner_thickness , outer_thickness , u,v,n ) ; //,o ) ;
  sensor1_vol.setSensitiveDetector(sens);

  DetElement layer1_DE( sdet, "layer1_DE", 1 );
  pv = rp_vacuum_vol.placeVolume( support1_vol, Position(xy_shift,0, -z_shift) );
  pv.addPhysVolID("layer", 1 );  
  layer1_DE.setPlacement( pv ) ;

  DetElement  mod1(  layer1_DE , "module_1", 1 );
  pv = support1_vol.placeVolume(sensor1_vol, Position(0,0,0));
  pv.addPhysVolID("module", 1 );  
  mod1.setPlacement( pv );

  // ------------- x2
  Volume      support2_vol( "xsenseor_supp", supp_box, supp_mat  );
  Volume      sensor2_vol(  "xsenseor_sens", sens_box, sens_mat );
  VolPlane    surf2( sensor2_vol, type, inner_thickness , outer_thickness , u,v,n ) ; //,o ) ;
  sensor2_vol.setSensitiveDetector(sens);

  DetElement layer2_DE( sdet, "layer2_DE", 2 );
  pv = rp_vacuum_vol.placeVolume( support2_vol, Position(-xy_shift,0, -z_shift) );
  pv.addPhysVolID("layer", 2 );  
  layer2_DE.setPlacement( pv ) ;

  DetElement  mod2(  layer2_DE , "module_2", 2 );
  pv = support2_vol.placeVolume(sensor2_vol, Position(0,0,0));
  pv.addPhysVolID("module", 2 );  
  mod2.setPlacement( pv );

  // -------------x3 
  Volume      support3_vol( "xsenseor_supp", supp_box, supp_mat  );
  Volume      sensor3_vol(  "xsenseor_sens", sens_box, sens_mat );
  VolPlane    surf3( sensor3_vol, type, inner_thickness , outer_thickness , u,v,n ) ; //,o ) ;
  sensor3_vol.setSensitiveDetector(sens);

  DetElement layer3_DE( sdet, "layer3_DE", 3 );
  pv = rp_vacuum_vol.placeVolume( support3_vol, Position(0,xy_shift, z_shift) );
  pv.addPhysVolID("layer", 3 );  
  layer3_DE.setPlacement( pv ) ;

  DetElement  mod3(  layer3_DE , "module_3", 3 );
  pv = support3_vol.placeVolume(sensor3_vol, Position(0,0,0));
  pv.addPhysVolID("module", 3 );  
  mod3.setPlacement( pv );

  // -------------x4 
  Volume      support4_vol( "xsenseor_supp", supp_box, supp_mat  );
  Volume      sensor4_vol(  "xsenseor_sens", sens_box, sens_mat );
  VolPlane    surf4( sensor4_vol, type, inner_thickness , outer_thickness , u,v,n ) ; //,o ) ;
  sensor4_vol.setSensitiveDetector(sens);

  DetElement layer4_DE( sdet, "layer4_DE", 4 );
  pv = rp_vacuum_vol.placeVolume( support4_vol, Position(0,-xy_shift, z_shift) );
  pv.addPhysVolID("layer", 4 );  
  layer4_DE.setPlacement( pv ) ;

  DetElement  mod4(  layer4_DE , "module_4", 4 );
  pv = support4_vol.placeVolume(sensor4_vol, Position(0,0,0));
  pv.addPhysVolID("module", 4 );  
  mod4.setPlacement( pv );



  //sdet.setAttributes(lcdd, assembly,x_det.regionStr(),x_det.limitsStr(),x_det.visStr());
  //assembly.setVisAttributes(lcdd.invisible());

  pv = lcdd.pickMotherVolume(sdet).placeVolume(assembly, Position(0,0,z_offset));
  pv.addPhysVolID("system", det_id);      // Set the subdetector system ID.
  sdet.setPlacement(pv);

  assembly->GetShape()->ComputeBBox() ;
  return sdet;
}

DECLARE_DETELEMENT(SiTrackerRomanPot, create_detector)
