//==========================================================================
//  Crystal Endcap EM Calorimeter Detector implementation 
//--------------------------------------------------------------------------
//
// Authors     : W.Armstrong
//
//==========================================================================
// J.KIM  2020-04-01
// Added box assembly of volumes
//==========================================================================
#include "DD4hep/DetFactoryHelper.h"
#include "XML/Layering.h"
#include <math.h>

using namespace std;
using namespace dd4hep;
using namespace dd4hep::detail;

/** \addtogroup calorimeters Calorimeters 
 */

/** \addtogroup CrystalEndcapECAL Crystal calorimeter
 * \brief Type: **CrystalEndcapECAL**.
 * \author J. Kim
 * \ingroup calorimeters
 *
 *
 * \code
 *   <detector id="1" name="ForwardElectronECAL" type="CrystalEndcapECAL" readout="EcalEndcapHits" vis="RedVis">
 *     <dimensions rmin="12.0*cm" rmax="60.0*cm" zmin="-10.0*cm" zmax="10.0*cm"/>
 *     <comment>Electromagnetic Calorimeter Endcaps</comment>
 *   </detector>
 * \endcode
 *
 * @{
 */
static Ref_t create_detector(Detector& description, xml_h e, SensitiveDetector sens) {
  xml_det_t x_det     = e;
  xml_dim_t dim       = x_det.dimensions();
  int       det_id    = x_det.id();
  string    det_name  = x_det.nameStr();
  Material  PbWO4     = description.material("PbWO4");
  double    rmin      = dim.rmin();
  double    rmax      = dim.rmax();
  double    zmin      = dim.zmin();
  double    zmax      = dim.zmax();
  double    thickness = zmax - zmin;
  double    z_pos     = zmin + thickness / 2.0;

  Assembly    assembly(det_name);
  DetElement  endcap_DE(det_name,det_id);

  // Create a tube to represent the calorimeter 
  Tube   tube(rmin, rmax, thickness / 2.0);
  Volume Vol("tube_volume", tube, PbWO4);
  //auto   PV = assembly.placeVolume(Vol, Position(0.0, 0.0, 0.0));
  //PV.addPhysVolID("layer", 0);
  //sens.setType("calorimeter");
  //Vol.setSensitiveDetector(sens);

  // Tube is filled with box-shaped crystals forming a grid.
  Assembly box_assembly("box_assembly");
  PlacedVolume pv_box;

  // Box-shaped crystal dimension
  double box_x_width = 2*cm;
  double box_y_width = 2*cm;
  double box_z_length = 20*cm;
  // Gap between box-shaped crystals
  double offset_x = 1*mm;
  double offset_y = 1*mm;
  double offset_diagonal = box_x_width*sqrt(2)/2.0 + 0.1*cm;
  // Limits
  double limit_inner = rmin + offset_diagonal;
  double limit_outer = rmax - offset_diagonal;
  // Number of crystals in a grid
  int nx = floor(rmax/box_x_width);
  int ny = floor(rmax/box_y_width);
  // X or Y spacing increasement
  double x_spacing = box_x_width + offset_x;
  double y_spacing = box_y_width + offset_y;
  // initial positions in X or Y.
  double pos_x = 0*cm;
  double pos_y = 0*cm;

  // Create Box and Volume
  Box box(box_x_width/2.0, box_y_width/2.0, box_z_length/2.0);
  Volume vol("box_volume", box, PbWO4);
 
  ////////////////////////////////////////////////////////////////////////////////////
  // Divide tube into 4 sections; top left, top right, bottom left, and bottom right
  ////////////////////////////////////////////////////////////////////////////////////
  // Top left
  ////////////////////////////////////////////////////////////////////////////////////
  int i_module = 0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = box_x_width/2.0 + offset_x/2.0;

        if(ix==0)
	{
		pos_x = x_start;
		if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                	pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
		else{
			continue;
                }
	}
	else
        {
		// Move to +X
                pos_x += x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner)
                {
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",1).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to +Y  
  pos_y += y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Top right
  ////////////////////////////////////////////////////////////////////////////////////
  // Initialize position in Y
  pos_y = 0.0;
  i_module=0;
  for(int iy=0; iy<ny-1; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = box_x_width/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = - x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else    
        {
		// Move to -X
                pos_x -= x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",2).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to +Y
  pos_y += y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Bottom left
  ////////////////////////////////////////////////////////////////////////////////////  
  // It's below the first row of the section of Top left
  // That's why ny goes up to ny -2 (the first row of Bottom left starts one row less)
  pos_y = -y_spacing;
  i_module=0;
  for(int iy=0; iy<ny-2; iy++){
  for(int ix=0; ix<nx; ix++){
        double x_start = box_x_width/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else
        {
		// Move to +X
                pos_x += x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",3).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to -Y
  pos_y -= y_spacing;
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // Bottom right
  ////////////////////////////////////////////////////////////////////////////////////
  // Again it's below the first row of the section of Top left
  // That's why ny goes up to ny -2 (the first row of Bottom left starts one row less)
  pos_y = -y_spacing;
  i_module=0;
  for(int iy=0; iy<ny-2; iy++){
  for(int ix=0; ix<nx; ix++)
  {
        double x_start = box_x_width/2.0 + offset_x/2.0;

        if(ix==0)
        {
                pos_x = - x_start;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        else
        {
		// Move to -X
                pos_x -= x_spacing;
                if(sqrt((pos_x*pos_x) + (pos_y*pos_y)) < limit_outer && sqrt((pos_x*pos_x) + (pos_y*pos_y)) > limit_inner){
                        pv_box = assembly.placeVolume(vol, Position(pos_x,pos_y,0.0));
                        i_module++;
                }
                else{
                        continue;
                }
        }
        pv_box.addPhysVolID("sector",4).addPhysVolID("module",i_module);
        sens.setType("calorimeter");
        vol.setSensitiveDetector(sens);
  }
  // Move to -Y
  pos_y -= y_spacing;
  }
  ////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////

  Volume motherVol = description.pickMotherVolume(endcap_DE);
  auto   pv        = motherVol.placeVolume(assembly, Position(0.0, 0.0, z_pos));
  pv.addPhysVolID("system", det_id);
  endcap_DE.setPlacement(pv);
  return endcap_DE;
}
//@}
DECLARE_DETELEMENT(CrystalEndcapECAL,create_detector)
