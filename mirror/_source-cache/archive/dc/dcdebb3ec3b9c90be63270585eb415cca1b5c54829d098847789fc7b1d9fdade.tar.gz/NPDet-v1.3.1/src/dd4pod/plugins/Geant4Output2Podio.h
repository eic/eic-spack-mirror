#ifndef DD4HEP_DDG4_GEANT4Output2Podio_H
#define DD4HEP_DDG4_GEANT4Output2Podio_H

#include "DDG4/Geant4OutputAction.h"
#include "DDG4/EventParameters.h"

//#include "podio/GenericParameters.h"
#include "podio/CollectionBase.h"
#include "podio/CollectionIDTable.h"

#include "podio/EventStore.h"
#include "podio/ROOTWriter.h"

#include <set>
#include <memory>

namespace dd4pod {
class Geant4Particle;
class Geant4ParticleCollection;
}
class G4ParticleTable;

namespace dd4hep {


  class ComponentCast;

  namespace sim {

    template <class T = podio::EventStore> void EventParameters::extractParameters(T& event){
      auto& lcparameters = event.getEventMetaData();

      for(auto const& ival: this->intParameters()) {
        lcparameters.setValues(ival.first, ival.second);
      }
      for(auto const& ival: this->fltParameters()) {
        lcparameters.setValues(ival.first, ival.second);
      }
      for(auto const& ival: this->strParameters()) {
        lcparameters.setValues(ival.first, ival.second);
      }
    }

    class Geant4Particle;

    /** Saves output to podio data model.
     *
     * Uses the podio data model "dd4pod" as the output. 
     */
    class Geant4Output2Podio: public Geant4OutputAction {
    protected:
     G4ParticleTable* m_particleTable = nullptr;

     void
     ConstructParticle(dd4pod::Geant4ParticleCollection* col,
                       dd4hep::sim::Geant4Particle*      part);

     /// Flag if Monte-Carlo truth should be followed and checked
     bool m_handleMCTruth = true;

     /// Property: vector with disabled collections
     std::vector<std::string> m_disabledCollections;

     // map collection names to a boolean for quick enable/disable check
     std::set<std::string> m_disableList;

     /// Property: vector with disabled collections
     bool m_disableParticles = false;

     /// Store all calorimeter contributions. Will dramatically increase output data size
     bool m_storeCalorimeterContributions = false;

     int              m_runNo{0};
     int              m_runNumberOffset{0};
     int              m_eventNumberOffset{0};
     std::map< std::string, std::string > m_runHeader;
     std::map< std::string, std::string > m_eventParametersInt;
     std::map< std::string, std::string > m_eventParametersFloat;
     std::map< std::string, std::string > m_eventParametersString;

     std::unique_ptr<podio::EventStore> m_store;
     std::unique_ptr<podio::ROOTWriter> m_writer;

     std::map<std::string, podio::CollectionBase*>               m_col_map;
     std::vector<std::pair<std::string, podio::CollectionBase*>> m_collections;
     std::vector<std::pair<std::string, podio::CollectionBase*>>
                               m_readCollections;
     podio::CollectionIDTable* m_collectionIDs;

     // Create a podio collection on the event store
     template <class CollectionType>
     void createCollection(const std::string& name) {
       m_store->create<CollectionType>(name);
       m_writer->registerForWrite(name);
       printout(DEBUG, "Geant4Output2Podio", "Created collection %s", name.c_str());
     }

     void initEventStore(OutputContext<G4Event>& ctxt);
     void saveParticles(const Geant4ParticleMap* parts);

    public:
      Geant4Output2Podio(Geant4Context* context, const std::string& nam);
      virtual ~Geant4Output2Podio();
      
      ///// Fill single EVENT branch entry (Geant4 collection data)
      //int fill(const std::string& nam, const ComponentCast& type, void* ptr);

      /// Callback to store the Geant4 run information
      virtual void beginRun(const G4Run* run);

      /// Callback to store the Geant4 run information
      virtual void endRun(const G4Run* run);

      /// Callback to store the Geant4 run information
      virtual void saveRun(const G4Run*  run );

      /// Callback to store each Geant4 hit collection
      virtual void saveCollection(OutputContext<G4Event>& ctxt, G4VHitsCollection* collection);

      /// Callback to store the Geant4 event
      virtual void saveEvent(OutputContext<G4Event>& ctxt);

      /// Commit data at end of filling procedure
      virtual void commit(OutputContext<G4Event>& ctxt);

    protected:
      /// Fill event parameters in Podio event
      template <typename T>
      void saveEventParameters(const std::map<std::string, std::string >& parameters);
    };

    /// Fill event parameters in Podio event
    template <typename T>
    inline void Geant4Output2Podio::saveEventParameters(const std::map<std::string, std::string >& parameters)  {
      for(std::map<std::string, std::string >::const_iterator iter = parameters.begin(), endIter = parameters.end() ; iter != endIter ; ++iter)  {
        T parameter;
        std::istringstream iss(iter->second);
        if ( (iss >> parameter).fail() ) {
          printout(FATAL,"saveEventParameters","+++ Event parameter %s: FAILED to convert to type :%s",iter->first.c_str(),typeid(T).name());
          continue;
        }
      	auto& evtMD = m_store->getEventMetaData();
      	evtMD.setValue(iter->first,parameter);
      }
    }

    /// Fill event parameters in Podio event - std::string specialization
    template <>
    inline void Geant4Output2Podio::saveEventParameters<std::string>(const std::map<std::string, std::string >& parameters)  {
      for(std::map<std::string, std::string >::const_iterator iter = parameters.begin(), endIter = parameters.end() ; iter != endIter ; ++iter)  {
      	auto& evtMD = m_store->getEventMetaData();
	      evtMD.setValue(iter->first,iter->second);
      }
    }

  }    // End namespace sim
}      // End namespace dd4hep
#endif // DD4HEP_DDG4_GEANT4Output2Podio_H
