Getting Started
===============

Installation
------------

Singularity Container
~~~~~~~~~~~~~~~~~~~~~

The easiest way to use this library is the with the `eic_container <https://eicweb.phy.anl.gov/containers/eic_container>`_.

.. warning:: need to add brief instructions here.



Building from source
~~~~~~~~~~~~~~~~~~~~

The following are needed before building `NPDet`

 * `DD4hep <(https://github.com/AIDAsoft/DD4hep>`_
 * `ROOT <https://root.cern.ch>`_
 * `GEANT4 <http://geant4.cern.ch>`_

.. code-block:: bash

   git clone https://eicweb.phy.anl.gov/EIC/NPDet.git
   mkdir npdet_build && cd npdet_build
   cmake ../NPDet/. -DCMAKE_INSTALL_PREFIX=$HOME # or where ever
   make -j4
   make install

Development
-----------


.. warning:: need to add brief how to for container development.

