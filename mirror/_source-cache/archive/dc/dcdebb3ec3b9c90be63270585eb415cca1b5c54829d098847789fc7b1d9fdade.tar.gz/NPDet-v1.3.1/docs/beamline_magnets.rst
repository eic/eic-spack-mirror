Beamline magnet elements
========================

These detector elements don't directly serve a role in particle detection, but have to be included to accomodate for particle-matter interactions. The provided magnet types are :ref:`dipole <dip>` and :ref:`quadrupole <quad>` magnets and :ref:`spin rotators <snake>`.

.. _dip:

Dipole magnets
~~~~~~~~~~~~~~

Magnets generating dipole field used for beam steering and spectrometry.

example use:

.. code-block:: XML
  
   <detector id="3" name="B0PF_BeamlineMagnet" type="B0pFMag">
    <placement x="B0PF_XPosition" y="0*m" z="B0PF_CenterPosition" theta="B0PF_RotationAngle" />
    <dimensions x="B0PF_InnerRadius*4" y="B0PF_InnerRadius*4" z="B0PF_Length*0.5" />
    <apperture x="B0PF_InnerRadius*2" y="B0PF_InnerRadius*2" />
    <coil dx="0.1*m" dy="0.03*m" />
  </detector>

.. _quad:

Quadrupole magnets
~~~~~~~~~~~~~~~~~~

Magnets used for bea focusing, loosely based on design shown `here <https://indico.cern.ch/event/763185/contributions/3415423/attachments/1914495/3164671/MT26-Thu-Af-Or22-07_JLab_Renuka.pdf>`_. More information can be also found at reference discussing the `EIC design <https://doi.org/10.1109/TASC.2019.2896376>`_.

example use:

.. code-block:: XML

   <detector id="1" name="quad_example" vis="RedVis" type="QuadMagnet">
      <placement x="0*m" y="0*m" z="0*m" theta="0.0" />
      <dimensions r="0.2*m" z="3.8*m" />
      <coil dx="8*cm" dy="2.5*cm" />
      <apperture r="0.131*m" />
    </detector>


.. _snake:

Helical dipole magnets
~~~~~~~~~~~~~~~~~~~~~~

These beamline elements are used for spin rotation. See this `reference <https://doi.org/10.1063/1.2750932>`_ for more information.

.. image:: images/D-helix.png
   :width: 400

example use:

.. code-block:: XML

   <detector id="1" name="spinp_example" vis="RedVis" type="HelicalDipole">
      <placement x="0*m" y="0*m" z="0*m" theta="0.0" psi="0.0" />
      <dimensions r="0.2*m" z="2.3*m" />
      <coil dy="2.5*cm" />
      <apperture r="0.131*m" />
    </detector>
