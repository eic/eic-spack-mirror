.. toctree::
   :maxdepth: 2

   intro
   getting_started
   detectors/detectors
   beamline_magnets
   InputEvents
   Tips_and_Tricks
   topside/topside
   Reference Documentation <https://eic.phy.anl.gov/npdet/ref_doc/>
