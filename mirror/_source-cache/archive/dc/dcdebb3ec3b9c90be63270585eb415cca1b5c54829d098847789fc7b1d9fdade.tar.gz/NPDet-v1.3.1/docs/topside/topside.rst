#########
TOPSiDE
#########


**This site is currently under construction. Come back later!!!**


*****************************
Tracking
*****************************

Vertex Trackers
#################

Silicon Vertex Tracker Barrel
*****************************
   
.. figure:: ../images/topside_vertex_tracker.png
   :width: 600
   
   Silicon vertex tracker barrel with soi and usfd detectors and a simple stave.



*****************************
Particle Identification (PID)
*****************************

RICH
####################

.. image:: ../images/topside_rich.png
   :width: 600

.. code-block:: xml

    <detector id="1" name="ForwardRICH" type="GenericRICH" 
              readout="ForwardRICHHits" vis="RedVis" material="N2cherenkov">
      <dimensions rmin1="30*cm" rmin2="30*cm" rmax1="80*cm" rmax2="80*cm" zmin="20*cm"  zmax="120*cm"/>
    </detector>

Optical surfaces are `defined in the detector 
construction. <https://eicweb.phy.anl.gov/EIC/NPDet/-/blob/master/src/GenericDetectors/pid/src/GenericRICH_geo.cpp#L129>`_
Their optical properites of surfaces are defined in the detector description: 

.. code-block:: xml

    <surfaces>
      <opticalsurface finish="polished" model="glisur" name="MirrorOpticalSurface" type="dielectric_metal" value="0">
        <property name="REFLECTIVITY" ref="REFLECTIVITY_mirror"/>
        <property name="RINDEX"       coldim="2" values="1.034*eV  1.5   4.136*eV  1.5"/>
      </opticalsurface>
    </surfaces>



