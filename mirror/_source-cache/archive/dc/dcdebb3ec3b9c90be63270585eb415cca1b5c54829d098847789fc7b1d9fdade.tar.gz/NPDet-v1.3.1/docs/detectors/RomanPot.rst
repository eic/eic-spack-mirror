Roman Pot
#########

A pair of Roman Pot-style detectors for detection of particles scattered by very small angles, typically in forward and far-forward regions.

Generic information about design of Roman pot detectors can be found in references describing units used at LHC `ref 1`_ and `ref 2`_.

.. image:: ../images/RP.png
   :width: 400

Example use:

.. code-block:: XML

   <detector id = "1" name = "MyRomanPot" type = "RomanPot" readout =
              "ForwardRomanPotHits" vis = "RedVis">
      <dimensions x = "3.0*cm" y = "3.0*cm" delta = "0.005*cm" />
      <frame x = "10.0*cm" y = "5.0*cm" z = "2*cm" />
      <position z_offset = "0.0*m" rotation = "false" vmax = "10*cm" v = "2.0*cm" />
      <layer repeat = "5">
        <slice material = "Carbon"  thickness = "0.5*mm"  vis = "BlueVis" />
        <slice material = "Silicon" thickness = "0.03*cm" vis = "GreenVis" sensitive = "true"  />
        <slice material = "Carbon"  thickness = "0.5*mm"  vis = "BlueVis" />
        <slice material = "Vacuum"  thickness = "1.0*mm"  vis = "InvisibleWithDaughters" />
      </layer>
    </detector>

Detector description variables
******************************

.. image:: ../images/rp_schem.pdf
   :width: 400

dimensions
    Dimensions of the sensitive detector.

    x
        Width of the detector.
    y
        Height of the detector.
    delta
        Separation gap - the distance between the inner edges of the active area substrate.

frame
    Dimensions of the frame that houses the sensitive detector.

    x
        Width of the frame.
    y
        Height of the frame.
    z
        thickness of the frame.

position
    Positioning of the whole detector pair relative to the beamline.

    z_offset
        Distance along the beamline.

        rotation
            Boolean which determines whether the detector pair is horizontal (false) or vertical (true).
        vmax
            Furthest distance of the detector from the beam (used to create the full unit unclosure).
        v
            Current insertion depth of the detectors (distance of the inner edge relative to the beam axis).

    layer
        Material stack used for the sensitive detector.

        repeat
            Number of layers in a single detectors.

.. _ref 1: https://doi.org/10.1016/j.nima.2007.08.034
.. _ref 2: https://accelconf.web.cern.ch/e06/PAPERS/MOPLS013.PDF
