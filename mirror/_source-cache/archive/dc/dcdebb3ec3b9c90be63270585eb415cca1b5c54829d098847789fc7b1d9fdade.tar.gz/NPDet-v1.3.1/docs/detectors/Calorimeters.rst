************
Calorimeters
************

Crystal Calorimeters
####################

For the backward electron direction
***********************************

From Tanja Horn's talk at 1st EIC Yellow Report Workshop at Temple University. The title of talk is Electromagnetic calorimetry technologies for EIC. The 
`presentation file <https://indico.bnl.gov/event/7449/contributions/35966/attachments/27177/41430/EIC-DWG-Calo-03192020.pdf>`_ can be found (Page 4 Electron Endcap EMCAL).

* Homogeneous calorimetry (inner part)

  #. PbWO4 :math:`(12\mathrm{cm} < R < 60 \mathrm{cm})` 

  #. Dimension: :math:`2\times 2 \times 20 \mathrm{cm}^3`

  #. Performance: :math:`\sim 2\%/\sqrt(E)+0.7\%`

  #. Estimated # of blocks for EIC: 2500

* Implemeted in

  #. GenericDetectors/calorimeters/compact/CrystalEndcapECAL_example.xml 

  #. `GenericDetectors/calorimeters/src/CrystalEndcapECAL_geo.cpp <https://argonne_mep.gitlab.io/eic/NPDet/group___crystal_endcap_e_c_a_l.html>`_

Zero Degree Calorimeters
########################

For neutrons and photons
************************

Form Yuji Goto (RIKEN)'s talk at 1st EIC Yellow Report Workshop at Temple University. 
The title of talk is Zero Degree Calorimetry. 
The `presentation <https://indico.bnl.gov/event/7449/contributions/35872/attachments/27171/41417/YRWS_2003.pdf>`_ can be found.

Detector configuration of RHICf detector
========================================
* Tungsten (Grey)
* Scintillator (Blue)
* Scintillator position (Red)

.. image:: ../images/ZDC.png
   :width: 500px

Longitudinal structure
======================
.. image:: ../images/Longitudinal_structure_of_ZDC_detector.png
   :width: 500px

Detector Description
====================
* Two towers with the same layer structure

  #. Small tower: 20mm x 20 mm

  #. Large tower: 40mm x 40 mm

  #. Tungsten absorbers, Plastic Scintillators, and Scintillator position layers 

Define section:
~~~~~~~~~~~~~~~

.. code-block:: XML

        <define>
                <constant name="offset_ZDC"    value="5.0*mm"/>
                <constant name="st_length"     value="20.0*mm"/>
                <constant name="lt_length"     value="40.0*mm"/>
                <constant name="st_ZDC_x_pos"  value="0.0*m"/>   <!-- value="0.60*m"  -->
                <constant name="st_ZDC_y_pos"  value="0.0*m"/>
                <constant name="st_ZDC_z_pos"  value="1.0*m"/>   <!-- value="34.0*m"  -->
                <constant name="lt_ZDC_x_pos"  value="0.0*m"/>   <!-- value="0.60*m"  -->
                <constant name="lt_ZDC_y_pos"  value="offset_ZDC + (st_length+lt_length)/sqrt(2)"/>
                <constant name="lt_ZDC_z_pos"  value="1.0*m"/>  <!-- value="34.0*m"  -->
        </define>

Detector section:
~~~~~~~~~~~~~~~~~

.. code-block:: XML

        <detector id="1" name="smallZDC" type="ZDC" readout="ZDCHits" vis="RedVis">
                <position x="st_ZDC_x_pos" y="st_ZDC_y_pos" z="st_ZDC_z_pos"/>
                <dimensions x = "st_length" y = "st_length"/>
                <layer repeat="2">
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                </layer>
                <layer repeat="1">
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                        <slice name="SciFi_belt"     material="PlasticScint"   thickness="1*mm" vis = "RedVis"  sensitive = "true"/>
                        <slice name="SciFi_belt"     material="PlasticScint"   thickness="1*mm" vis = "RedVis"  sensitive = "true"/>
                </layer>
                <layer repeat="2">
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                </layer>
                <layer repeat="2">
                        <slice name="SciFi_belt"     material="PlasticScint"   thickness="1*mm" vis = "RedVis"  sensitive = "true"/>
                </layer>
                <layer repeat="7">
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                </layer>
                <layer repeat="1">
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                </layer>
                <layer repeat="2">
                        <slice name="SciFi_belt"     material="PlasticScint"   thickness="1*mm" vis = "RedVis"  sensitive = "true"/>
                </layer>
                <layer repeat="3">
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                </layer>
                <layer repeat="2">
                        <slice name="SciFi_belt"     material="PlasticScint"   thickness="1*mm" vis = "RedVis"  sensitive = "true"/>
                </layer>
                <layer repeat="1">
                        <slice name="Scint_slice"    material="PlasticScint"   thickness="3*mm" vis = "BlueVis" sensitive = "true"/>
                        <slice name="Tungsten_slice" material="TungstenDens24" thickness="7*mm" vis = "GrayVis"/>
                </layer>
        </detector>

        <detector id="2" name="largeZDC" type="ZDC" readout="ZDCHits" vis="RedVis">
                <position x="lt_ZDC_x_pos" y="lt_ZDC_y_pos" z="lt_ZDC_z_pos"/>
                <dimensions x = "lt_length" y = "lt_length"/>
                <layer>

                </layer>
        </detector>

Access Variables
~~~~~~~~~~~~~~~~

* Volume ID that obtained from Cell ID using dd4hep::VolumeManagerContext.identifier

.. code-block:: cpp

  auto volID = [&] (const std::vector<dd4hep::sim::Geant4Calorimeter::Hit*>& hits) {
        std::vector<double> result;
        for(const auto& h: hits) {
                auto volcontext = cellid_converter.findContext(h->cellID);
                result.push_back(volcontext->identifier);
        }
  return result;
  };

* Volume ID that obtained from Cell ID using dd4hep::VolumeManagerContext.element and Readout/Segmentation 

.. code-block:: cpp

  auto volID = [&] (const std::vector<dd4hep::sim::Geant4Calorimeter::Hit*>& hits) {
        std::vector<double> result;
        for(const auto& h: hits) {
                auto volcontext = cellid_converter.findContext(h->cellID);
                dd4hep::Readout r = cellid_converter.findReadout(volcontext->element);
                dd4hep::Segmentation seg = r.segmentation();
                result.push_back(seg.volumeID(h->cellID));
        }
  return result;
  };


.. include:: EMCalorimeterSoLID.rst
