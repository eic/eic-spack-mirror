
SoLID ElectroMagnetic Calorimeter
#################################

A electromagnetic calorimeter for the SoLID detector. It is a ring-shape detector with hexgonal modules.

Example use:

.. code-block:: XML

    <detector id="3" name="LAECPreShower" type="EMCalorimeterSoLID" readout="LAEC_PrShHits" vis="PurpleVis" >
      <comment>Large Angle Electromagnetic Calorimeter (LAEC) Preshower for SIDIS</comment>
      <dimensions rmin="83*cm" rmax="140*cm" z0="-65*cm" rmod="6.25*cm" rtol="1.0*cm" />
      <layer repeat="1" vis="InvisibleWithDaughters">
        <slice material = "Lead"  thickness = "1.12*cm" vis="BlueVis"/>
        <slice material = "EJ204" thickness = "6.25*cm" vis="PurpleVis" sensitive="yes"/>
      </layer>
    </detector>

    <detector id="4" name="LAECShower" type="EMCalorimeterSoLID" readout="LAEC_ShHits" vis="PurpleVis" >
      <comment>Large Angle Electromagnetic Calorimeter (LAEC) Shower for SIDIS</comment>
      <dimensions rmin="83*cm" rmax="140*cm" z0="-57*cm" rmod="6.25*cm" rtol="1.0*cm" />
      <layer repeat="194" vis="GreenVis">
        <slice material = "Lead"  thickness = "0.05*cm"/>
        <slice material = "EJ204" thickness = "0.15*cm" sensitive="yes" limits="cal_limits"/>
        <slice material = "Air"   thickness = "0.012*2*cm"/>
      </layer>
    </detector>

Detector description variables
******************************

dimensions
    Dimensions of the sensitive detector

    rmin
        Inner radius of the detector
    rmax
        Outer raidus of the detector
    z0
        Z position (along the beam line) of the front surface of the detector
    rmod
        Outer radius (side length) of the hexgonal module
    rtol
        Extrusion Tolerance for putting modules inside the detector ring

layer
    Layer definition of the hexgonal modules

    repeat
        Number of the same slices to stack along z
    slice
        Slice definition in the layer

        material
            slice material
        thickness
            slice thickness

