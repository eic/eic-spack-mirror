#########
Detectors
#########

`NPdet` is detector toolkit for full simulations of Nuclear Physics experiments.

**This site is currently under construction. Come back later!!!**

.. include:: Calorimeters.rst
.. include:: Trackers.rst
   

*****************************
Particle Identification (PID)
*****************************

Generic Gaseous RICH
####################

A generic gas RICH detector for hadron PID in the forward dectection is shown in the figure below.
The simple design uses a plane mirror to reflect cherenkov photons (green) onto an array of MCP-PMT detectors (blue).
The optical properties of the mirror are defined in  a properites block as `shown here <https://eicweb.phy.anl.gov/EIC/NPDet/-/blob/master/src/GenericDetectors/pid/compact/GenericRICH_example.xml#L23>`_.

.. image:: ../images/topside_rich.png
   :width: 600

.. code-block:: xml

    <detector id="1" name="ForwardRICH" type="GenericRICH" 
              readout="ForwardRICHHits" vis="RedVis" material="N2cherenkov">
      <dimensions rmin1="30*cm" rmin2="30*cm" rmax1="80*cm" rmax2="80*cm" zmin="20*cm"  zmax="120*cm"/>
    </detector>

Optical surfaces are `defined in the detector 
construction. <https://eicweb.phy.anl.gov/EIC/NPDet/-/blob/master/src/GenericDetectors/pid/src/GenericRICH_geo.cpp#L129>`_
Their optical properites of surfaces are defined in the detector description: 

.. code-block:: xml

    <surfaces>
      <opticalsurface finish="polished" model="glisur" name="MirrorOpticalSurface" type="dielectric_metal" value="0">
        <property name="REFLECTIVITY" ref="REFLECTIVITY_mirror"/>
        <property name="RINDEX"       coldim="2" values="1.034*eV  1.5   4.136*eV  1.5"/>
      </opticalsurface>
    </surfaces>



