###############
Tips and Tricks
###############

*************
Code Snippets 
*************

Access Variables
################

**Volume ID** from **Cell ID**
******************************

* Volume ID that obtained from Cell ID using dd4hep::VolumeManagerContext.identifier

.. code-block:: cpp

  auto volID = [&] (const std::vector<dd4hep::sim::Geant4Calorimeter::Hit*>& hits) {
        std::vector<double> result;
        for(const auto& h: hits) {
                auto volcontext = cellid_converter.findContext(h->cellID);
                result.push_back(volcontext->identifier);
        }
  return result;
  };

* Volume ID that obtained from Cell ID using dd4hep::VolumeManagerContext.element and Readout/Segmentation 

.. code-block:: cpp

  auto volID = [&] (const std::vector<dd4hep::sim::Geant4Calorimeter::Hit*>& hits) {
        std::vector<double> result;
        for(const auto& h: hits) {
                auto volcontext = cellid_converter.findContext(h->cellID);
                dd4hep::Readout r = cellid_converter.findReadout(volcontext->element);
                dd4hep::Segmentation seg = r.segmentation();
                result.push_back(seg.volumeID(h->cellID));
        }
  return result;
  };


***
FAQ
***

DD4hep
######

What is the difference between **Volume ID** and **Cell ID**?
*************************************************************

  Both are unique IDs, but in the case of volume ID, it is associated with a physical placement of a volume (in G4 or tgeo).
  The cell ID is used to further identify the subgeometry allocated to a volume through a segmentation. 
  The volume ID is related to the cell ID through the readout's ``id`` tag.

  `See dd4hep CellID Descriptors documentation <https://dd4hep.web.cern.ch/dd4hep/usermanuals/DD4hepManual/DD4hepManualch2.html#x3-310002.12.1>`_


What is a **segmentation**?
***************************

  A segmentation is a virtual geometry that is used to subdivide a volume. This 
  avoids creating many small volumes to uniquely identify sensitive elements of 
  a volume. An example would be a silicon detector with many channels at a fine 
  pitch. Instead of create each pixel as a box of silicon, one silicon box is 
  logically divide through the segmentation mechanism of DD4hep. 

  For a list of segmentations `look at the headers in DDSegmentation <https://github.com/AIDASoft/DD4hep/tree/master/DDCore/include/DDSegmentation>`_.


What is a **readout**?
**********************
  A readout is associated with a senstive detector in DD4hep and is used by 
  setting the ``detector``'s ``readout`` attribute.  The attribute value is the 
  name of a readout defined in the ``readouts``.

.. code-block:: XML

  <readouts>
    <readout name="ECalHits">
      <segmentation type="CartesianGridXY" grid_size_x="10.0*cm" grid_size_y="10.0*cm" />
      <id>system:5,layer:9,module:8,x:32:-16,y:-16</id>
    </readout>
  </readouts>

How do I run the GEANT4 simulation?
***********************************

  todo

How can I visualize the GEANT4 simulation?
******************************************

  todo

How can I visualize the detector geometry?
******************************************

  todo






