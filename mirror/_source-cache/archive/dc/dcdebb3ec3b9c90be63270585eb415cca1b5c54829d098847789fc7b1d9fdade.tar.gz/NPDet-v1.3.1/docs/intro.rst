Introduction
============

`NPdet` is detector toolkit for full simulations of Nuclear Physics experiments.

**This site is currently under construction. Come back later!!!**

Overview
--------


A detector library for simulation and reconstruction based on 
[DD4hep](https://github.com/AIDAsoft/DD4hep). This library makes  full detector 
simulation and reconstruction easier by providing a set of flexible 
**parameterized detectors**. From these detectors, a full blown 
concept-detector can be created.

