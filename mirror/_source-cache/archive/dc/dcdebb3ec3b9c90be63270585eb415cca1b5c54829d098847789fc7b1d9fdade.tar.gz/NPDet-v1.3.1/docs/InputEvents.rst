Input Event Format
==================

Use Hepmc3
