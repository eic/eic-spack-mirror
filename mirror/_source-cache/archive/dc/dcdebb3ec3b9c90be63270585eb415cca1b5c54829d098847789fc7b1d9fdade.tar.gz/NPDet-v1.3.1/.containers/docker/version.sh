#!/bin/bash

cat ../../VERSION

