NPdet - Nuclear Physics Detector Library
========================================

A collection of detectors for simulating and building Nuclear Physics experiments.

Overview
--------

A detector library for simulation and reconstruction based on 
[DD4hep](https://github.com/AIDAsoft/DD4hep). This library makes  full detector 
simulation and reconstruction easier by providing a set of flexible 
**parameterized detectors**. From these detectors, a full blown 
concept-detector can be created.


Documentation
-------------

- [User Manual found here](https://eic.phy.anl.gov/npdet/)
- [Reference API documentation](https://eic.phy.anl.gov/npdet/ref_doc)

Writing documentation:
- [restructured text syntax .rst](https://thomas-cokelaer.info/tutorials/sphinx/rest_syntax.html)

### Tutorials


Installation
------------

### Singularity Container

The easiest way to use this library is the with the  [eic_container](https://eicweb.phy.anl.gov/containers/eic_container/).

### Building

The following are needed before building `NPDet`
* [DD4hep](https://github.com/AIDAsoft/DD4hep)
* [ROOT](https://root.cern.ch)
* [GEANT4](http://geant4.cern.ch)

```
git clone https://eicweb.phy.anl.gov/EIC/NPDet.git
mkdir npdet_build && cd npdet_build
cmake ../NPDet/. -DCMAKE_INSTALL_PREFIX=$HOME # or where ever
make -j4
make install
```

Related Projects and Useful Links
---------------------------------

- [FCCSW](https://github.com/HEP-FCC/FCCSW),
- [PODIO](https://github.com/HEP-FCC/podio)
- [HepMC3](https://gitlab.cern.ch/hepmc/HepMC3.git)

