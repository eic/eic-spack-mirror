/***********************************************************************************\
* (c) Copyright 1998-2025 CERN for the benefit of the LHCb and ATLAS collaborations *
*                                                                                   *
* This software is distributed under the terms of the Apache version 2 licence,     *
* copied verbatim in the file "LICENSE".                                            *
*                                                                                   *
* In applying this licence, CERN does not waive the privileges and immunities       *
* granted to it by virtue of its status as an Intergovernmental Organization        *
* or submit itself to any jurisdiction.                                             *
\***********************************************************************************/
#pragma once

#include <GaudiKernel/IAlgManager.h>
#include <GaudiKernel/IAlgResourcePool.h>
#include <GaudiKernel/IAlgorithm.h>
#include <GaudiKernel/Service.h>
#include <atomic>
#include <bitset>
#include <boost/dynamic_bitset.hpp>
#include <list>
#include <map>
#include <mutex>
#include <string>
#include <string_view>
#include <tbb/concurrent_queue.h>
#include <unordered_map>
#include <vector>

/** @class AlgResourcePool AlgResourcePool.h GaudiHive/AlgResourcePool.h

    The AlgResourcePool is a concrete implementation of the IAlgResourcePool interface.
    It either creates all instances up front or lazily.
    Internal bookkeeping is done via hashes of the algorithm names.

    @author Benedikt Hegner
*/
class AlgResourcePool : public extends<Service, IAlgResourcePool> {
public:
  // Standard constructor
  using extends::extends;
  // Standard destructor
  ~AlgResourcePool() override;

  StatusCode start() override;
  StatusCode initialize() override;
  /// Acquire a certain algorithm using its name
  StatusCode acquireAlgorithm( std::string_view name, IAlgorithm*& algo, bool blocking = false ) override;
  /// Release a certain algorithm
  StatusCode releaseAlgorithm( std::string_view name, IAlgorithm*& algo ) override;
  /// Acquire a certain resource
  StatusCode acquireResource( std::string_view name ) override;
  /// Release a certain resource
  StatusCode releaseResource( std::string_view name ) override;

  std::list<IAlgorithm*> getFlatAlgList() override;
  std::list<IAlgorithm*> getTopAlgList() override;

  StatusCode stop() override;
  StatusCode finalize() override;

private:
  typedef tbb::concurrent_bounded_queue<IAlgorithm*> concurrentQueueIAlgPtr;
  typedef boost::dynamic_bitset<>                    state_type;

  std::mutex m_resource_mutex;

  state_type                                m_available_resources{ 0 };
  std::map<size_t, concurrentQueueIAlgPtr*> m_algqueue_map;
  std::map<size_t, state_type>              m_resource_requirements;
  std::map<size_t, size_t>                  m_n_of_allowed_instances;
  std::map<size_t, unsigned int>            m_n_of_created_instances;
  std::map<std::string_view, unsigned int>  m_resource_indices;

  /// Decode the top Algorithm list
  StatusCode decodeTopAlgs();

  /// Recursively flatten an algList
  StatusCode flattenSequencer( IAlgorithm* sequencer, std::list<IAlgorithm*>& alglist,
                               unsigned int recursionDepth = 0 );

  /// Dump recorded Algorithm instance misses
  void dumpInstanceMisses() const;
  /// Counters for Algorithm instance misses
  std::unordered_map<std::string_view, unsigned int> m_algInstanceMisses;

  Gaudi::Property<bool>                     m_lazyCreation{ this, "CreateLazily", false, "" };
  Gaudi::Property<std::vector<std::string>> m_topAlgNames{
      this, "TopAlg", {}, "Names of the algorithms to be passed to the algorithm manager" };
  Gaudi::Property<bool> m_overrideUnClonable{ this, "OverrideUnClonable", false,
                                              "Override the un-clonability of algorithms. Use with caution!" };
  Gaudi::Property<bool> m_countAlgInstMisses{
      this, "CountAlgorithmInstanceMisses", false,
      "Count and print out algorithm instance misses. Useful for finding ways to improve throughput scalability." };

  /// The list of all algorithms created within the Pool which are not top
  std::list<IAlgorithm*> m_algList;

  /// The list of top algorithms
  std::list<IAlgorithm*> m_topAlgList;

  /// The flat list of algorithms w/o clones
  std::list<IAlgorithm*> m_flatUniqueAlgList;
};
