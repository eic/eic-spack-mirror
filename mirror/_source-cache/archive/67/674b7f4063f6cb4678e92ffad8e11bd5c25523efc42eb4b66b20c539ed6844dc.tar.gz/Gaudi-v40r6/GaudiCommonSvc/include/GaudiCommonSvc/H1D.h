/***********************************************************************************\
* (c) Copyright 1998-2019 CERN for the benefit of the LHCb and ATLAS collaborations *
*                                                                                   *
* This software is distributed under the terms of the Apache version 2 licence,     *
* copied verbatim in the file "LICENSE".                                            *
*                                                                                   *
* In applying this licence, CERN does not waive the privileges and immunities       *
* granted to it by virtue of its status as an Intergovernmental Organization        *
* or submit itself to any jurisdiction.                                             *
\***********************************************************************************/
#pragma once

#include "Generic1D.h"
#include <AIDA/IHistogram1D.h>
#include <Gaudi/Histograming/Sink/Utils.h>
#include <GaudiKernel/DataObject.h>
#include <TH1D.h>

#include <nlohmann/json.hpp>

#include <mutex>

namespace Gaudi {

  /**@class Histogram1D
   *
   * AIDA implementation for 1 D histograms using ROOT THD1
   *
   * @author  M.Frank
   */
  class GAUDI_API Histogram1D : public DataObject, public Gaudi::Generic1D<AIDA::IHistogram1D, TH1D> {
  private:
    void init( const std::string& title, bool initialize_axis = true );
    void initSums();

  protected:
    /// cache sumwx  when setting contents since I don't have bin mean
    double m_sumwx = 0;

  public:
    /// Standard constructor
    Histogram1D();
    /// Standard constructor with initialization. The histogram representation will be adopted
    Histogram1D( TH1D* rep );

    /// Adopt ROOT histogram representation
    void adoptRepresentation( TObject* rep ) override;
    /// set bin content (entries and centre are not used )
    virtual bool setBinContents( int i, int entries, double height, double error, double centre );
    // overwrite reset
    bool reset() override;
    // free function reset
    friend void reset( Histogram1D& h ) { h.reset(); }
    /// conversion to json via nlohmann library
    friend void to_json( nlohmann::json& j, Gaudi::Histogram1D const& h ) { j = *h.m_rep.get(); }
    /// set histogram statistics
    virtual bool setStatistics( int allEntries, double eqBinEntries, double mean, double rms );
    /// Fill the Profile1D with a value and the corresponding weight.
    bool fill( double x, double weight ) override;
    /// Update histogram RMS
    bool setRms( double rms );
    /// Create new histogram from any AIDA based histogram
    void copyFromAida( const AIDA::IHistogram1D& h );
    /// Retrieve reference to class defininition identifier
    const CLID&        clID() const override { return classID(); }
    static const CLID& classID() { return CLID_H1D; }
    /** Serialization mechanism, Serialize the object for reading.
     * @param s the StreamBuffer containing the data to be read
     * @return the resulting StreamBuffer, after reading
     */
    StreamBuffer& serialize( StreamBuffer& s );

    /** Serialization mechanism, Serialize the object for writing.
     * @param s the StreamBuffer where to write the data
     * @return the resulting StreamBuffer, after wrinting
     */
    StreamBuffer& serialize( StreamBuffer& s ) const;

  private:
    std::mutex m_fillSerialization;

  }; // end class Histogram1D
} // end namespace Gaudi
