/***********************************************************************************\
* (c) Copyright 1998-2026 CERN for the benefit of the LHCb and ATLAS collaborations *
*                                                                                   *
* This software is distributed under the terms of the Apache version 2 licence,     *
* copied verbatim in the file "LICENSE".                                            *
*                                                                                   *
* In applying this licence, CERN does not waive the privileges and immunities       *
* granted to it by virtue of its status as an Intergovernmental Organization        *
* or submit itself to any jurisdiction.                                             *
\***********************************************************************************/
#pragma once

#include "details.h"
#include "utilities.h"
#include <GaudiKernel/FunctionalFilterDecision.h>
#include <GaudiKernel/GaudiException.h>
#include <tuple>
#include <utility>

// Adapt an Algorithm (by default, Gaudi::Algorithm) so that derived classes
//   a) do not need to access the event store, and have to explicitly
//      state their data dependencies
//   b) are encouraged not to have state which depends on the events
//      (eg. histograms, counters will have to be mutable)

namespace Gaudi ::Functional {

  namespace details {

    template <typename Signature, typename Traits_, bool isLegacy>
    struct Transformer;

    // general N -> 1 algorithms
    template <typename Out, typename... In, typename Traits_>
    struct Transformer<Out( const In&... ), Traits_, true>
        : DataHandleMixin<std::tuple<Out>, filter_evtcontext<In...>, Traits_> {
      using DataHandleMixin<std::tuple<Out>, filter_evtcontext<In...>, Traits_>::DataHandleMixin;

      // derived classes can NOT implement execute
      StatusCode execute() override final {
        return details::execute( *this, [&] {
          put( std::get<0>( this->m_outputs ),
               filter_evtcontext_t<In...>::apply( *this, Gaudi::Hive::currentContext(), this->m_inputs ) );
          return FilterDecision::PASSED;
        } );
      }

      // instead they MUST implement this operator
      virtual Out operator()( const In&... ) const = 0;
    };

    template <typename Out, typename... In, typename Traits_>
    struct Transformer<Out( const In&... ), Traits_, false>
        : DataHandleMixin<std::tuple<Out>, filter_evtcontext<In...>, Traits_> {
      using DataHandleMixin<std::tuple<Out>, filter_evtcontext<In...>, Traits_>::DataHandleMixin;

      // derived classes can NOT implement execute
      StatusCode execute( const EventContext& ctx ) const override final {
        return details::execute( *this, [&] {
          put( std::get<0>( this->m_outputs ), filter_evtcontext_t<In...>::apply( *this, ctx, this->m_inputs ) );
          return FilterDecision::PASSED;
        } );
      }

      // instead they MUST implement this operator
      virtual Out operator()( const In&... ) const = 0;
    };

    //
    // general N -> M algorithms
    //
    template <typename Signature, typename Traits_, bool isLegacy>
    struct MultiTransformer;

    template <typename... Out, typename... In, typename Traits_>
    struct MultiTransformer<std::tuple<Out...>( const In&... ), Traits_, true>
        : DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_> {
      using DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_>::DataHandleMixin;

      // derived classes can NOT implement execute
      StatusCode execute() override final {
        return details::execute( *this, [&] {
          std::apply(
              [this]( auto&... ohandle ) {
                std::apply( [&ohandle...](
                                auto&&... data ) { ( put( ohandle, std::forward<decltype( data )>( data ) ), ... ); },
                            filter_evtcontext_t<In...>::apply( *this, Gaudi::Hive::currentContext(), this->m_inputs ) );
              },
              this->m_outputs );
          return FilterDecision::PASSED;
        } );
      }

      // instead they MUST implement this operator
      virtual std::tuple<Out...> operator()( const In&... ) const = 0;
    };

    template <typename... Out, typename... In, typename Traits_>
    struct MultiTransformer<std::tuple<Out...>( const In&... ), Traits_, false>
        : DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_> {
      using DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_>::DataHandleMixin;

      // derived classes can NOT implement execute
      StatusCode execute( const EventContext& ctx ) const override final {
        return details::execute( *this, [&] {
          std::apply(
              [this, &ctx]( auto&... ohandle ) {
                std::apply( [&ohandle...](
                                auto&&... data ) { ( put( ohandle, std::forward<decltype( data )>( data ) ), ... ); },
                            filter_evtcontext_t<In...>::apply( *this, ctx, this->m_inputs ) );
              },
              this->m_outputs );
          return FilterDecision::PASSED;
        } );
      }

      // instead they MUST implement this operator
      virtual std::tuple<Out...> operator()( const In&... ) const = 0;
    };

    //
    // general N -> M algorithms with filter functionality
    //
    template <typename Signature, typename Traits_>
    struct MultiTransformerFilter;

    template <typename... Out, typename... In, typename Traits_>
    struct MultiTransformerFilter<std::tuple<Out...>( const In&... ), Traits_>
        : DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_> {
      using DataHandleMixin<std::tuple<Out...>, filter_evtcontext<In...>, Traits_>::DataHandleMixin;

      // derived classes can NOT implement execute
      StatusCode execute( const EventContext& ctx ) const override final {
        return details::execute( *this, [&] {
          return std::apply(
                     [&]( auto&... ohandle ) {
                       return std::apply(
                           [&ohandle...]( bool passed, auto&&... data ) {
                             ( put( ohandle, std::forward<decltype( data )>( data ) ), ... );
                             return passed;
                           },
                           filter_evtcontext_t<In...>::apply( *this, ctx, this->m_inputs ) );
                     },
                     this->m_outputs )
                     ? FilterDecision::PASSED
                     : FilterDecision::FAILED;
        } );
      }

      // instead they MUST implement this operator
      virtual std::tuple<bool, Out...> operator()( const In&... ) const = 0;
    };
  } // namespace details

  template <typename Signature, typename Traits_ = Traits::useDefaults>
  using Transformer = details::Transformer<Signature, Traits_, details::isLegacy<Traits_>>;

  template <typename Signature, typename Traits_ = Traits::useDefaults>
  using MultiTransformer = details::MultiTransformer<Signature, Traits_, details::isLegacy<Traits_>>;

  template <typename Signature, typename Traits_ = Traits::useDefaults>
  using MultiTransformerFilter = details::MultiTransformerFilter<Signature, Traits_>;

} // namespace Gaudi::Functional
