/***********************************************************************************\
* (c) Copyright 1998-2025 CERN for the benefit of the LHCb and ATLAS collaborations *
*                                                                                   *
* This software is distributed under the terms of the Apache version 2 licence,     *
* copied verbatim in the file "LICENSE".                                            *
*                                                                                   *
* In applying this licence, CERN does not waive the privileges and immunities       *
* granted to it by virtue of its status as an Intergovernmental Organization        *
* or submit itself to any jurisdiction.                                             *
\***********************************************************************************/
#pragma once

#include <Gaudi/PluginService.h>
#include <GaudiKernel/CommonMessaging.h>
#include <GaudiKernel/DataObjID.h>
#include <GaudiKernel/IAlgTool.h>
#include <GaudiKernel/IAuditorSvc.h>
#include <GaudiKernel/IDataProviderSvc.h>
#include <GaudiKernel/IMessageSvc.h>
#include <GaudiKernel/IMonitorSvc.h>
#include <GaudiKernel/IProperty.h>
#include <GaudiKernel/IService.h>
#include <GaudiKernel/IStateful.h>
#include <GaudiKernel/ISvcLocator.h>
#include <GaudiKernel/IToolSvc.h>
#include <GaudiKernel/PropertyHolder.h>
#include <GaudiKernel/ToolHandle.h>

#include <GaudiKernel/DataHandle.h>
#include <GaudiKernel/DataHandleHolderBase.h>
#include <GaudiKernel/IDataHandleHolder.h>
#include <list>
#include <vector>

template <class T>
class DataObjectHandle;
class ToolHandleInfo;
class ToolSvc;
class ToolVisitor;

/** @class AlgTool AlgTool.h GaudiKernel/AlgTool.h
 *
 *  Base class from which all the concrete tool classes
 *  should be derived. Specific methods for doing something
 *  useful should be implemented in the concrete tools.
 *  Sub-types of this class could implement an additional
 *  interface for behavior common to sets of concrete tools
 *  (for example vertexers).
 *
 *  @author Gloria Corti
 *  @author Pere Mato
 */
class GAUDI_API AlgTool
    : public DataHandleHolderBase<
          PropertyHolder<CommonMessaging<implements<IAlgTool, IDataHandleHolder, IProperty, IStateful>>>> {
  friend ToolSvc;
  friend class ToolVisitor;

public:
  using Factory = Gaudi::PluginService::Factory<IAlgTool*( const std::string&, const std::string&, const IInterface* )>;

  /// Query for a given interface
  void const* i_cast( const InterfaceID& riid ) const override;

  /// Retrieve full identifying name of the concrete tool object.
  const std::string& name() const override;

  /// Retrieve type (concrete class) of the sub-algtool.
  const std::string& type() const override;

  /// Retrieve parent of the sub-algtool.
  const IInterface* parent() const override;

  // State machine implementation
  StatusCode                 configure() override { return StatusCode::SUCCESS; }
  StatusCode                 initialize() override;
  StatusCode                 start() override;
  StatusCode                 stop() override;
  StatusCode                 finalize() override;
  StatusCode                 terminate() override { return StatusCode::SUCCESS; }
  StatusCode                 reinitialize() override;
  StatusCode                 restart() override;
  Gaudi::StateMachine::State FSMState() const override { return m_state; }
  Gaudi::StateMachine::State targetFSMState() const override { return m_targetState; }

  /// Initialize AlgTool
  StatusCode sysInitialize() override;

  /// Start AlgTool
  StatusCode sysStart() override;

  /// Stop AlgTool
  StatusCode sysStop() override;

  /// Finalize AlgTool
  StatusCode sysFinalize() override;

  /// Initialize AlgTool
  StatusCode sysReinitialize() override;

  /// Start AlgTool
  StatusCode sysRestart() override;

public:
  /** Standard Constructor.
   *  @param type the concrete class of the sub-algtool
   *  @param name the full name of the concrete sub-algtool
   *  @param parent the parent of the concrete sub-algtool
   */
  AlgTool( std::string type, std::string name, const IInterface* parent );

  /// Retrieve pointer to service locator.
  SmartIF<ISvcLocator>& serviceLocator() const override;

  /// shortcut for the method service locator
  ISvcLocator* svcLoc() const { return serviceLocator(); }

  /** accessor to event service  service
   *  @return pointer to detector service
   */
  IDataProviderSvc* evtSvc() const;

  /// The standard ToolSvc service, Return a pointer to the service if present
  IToolSvc* toolSvc() const;

  /// Return a pointer to the service identified by name (or "type/name")
  SmartIF<IService> service( std::string_view name, const bool createIf = true, const bool quiet = false ) const;

  template <typename T>
  SmartIF<T> service( std::string_view name, const bool createIf = true, const bool quiet = false ) const {
    return SmartIF<T>( service( name, createIf, quiet ) );
  }

protected:
  template <typename I>
  void declareInterface( I* i ) {
    m_interfaceList.emplace_back( I::interfaceID(), i );
  }

public:
  using PropertyHolderImpl::declareProperty;

  template <class T>
  Gaudi::Details::PropertyBase* declareProperty( const std::string& name, ToolHandle<T>& hndl,
                                                 const std::string& doc = "none" ) {
    this->declareTool( hndl, hndl.typeAndName() ).ignore();
    return PropertyHolderImpl::declareProperty( name, hndl, doc );
  }

  template <class T>
  StatusCode declareTool( ToolHandle<T>& handle, bool createIf = true ) {
    return this->declareTool( handle, handle.typeAndName(), createIf );
  }

  template <class T>
  StatusCode declareTool( ToolHandle<T>& handle, const std::string& toolTypeAndName, bool createIf = true ) {

    StatusCode sc = handle.initialize( toolTypeAndName, handle.isPublic() ? nullptr : this, createIf );
    if ( !sc ) {
      throw GaudiException{ std::string{ "Cannot create handle for " } + ( handle.isPublic() ? "public" : "private" ) +
                                " tool " + toolTypeAndName,
                            name(), sc };
    }

    m_toolHandles.push_back( &handle );

    return sc;
  }

  // declare ToolHandleArrays to the AlgTool
  template <class T>
  Gaudi::Details::PropertyBase* declareProperty( const std::string& name, ToolHandleArray<T>& hndlArr,
                                                 const std::string& doc = "none" ) {
    addToolsArray( hndlArr );
    return PropertyHolderImpl::declareProperty( name, hndlArr, doc );
  }

  template <class T>
  void addToolsArray( ToolHandleArray<T>& hndlArr ) {
    m_toolHandleArrays.push_back( &hndlArr );
  }

public:
  void acceptDHVisitor( IDataHandleVisitor* ) const override;

public:
  void registerTool( IAlgTool* tool ) const {
    if ( msgLevel( MSG::DEBUG ) ) debug() << "Registering tool " << tool->name() << endmsg;
    m_tools.push_back( tool );
  }

  void deregisterTool( IAlgTool* tool ) const {
    auto it = std::find( m_tools.begin(), m_tools.end(), tool );
    if ( it != m_tools.end() ) {
      if ( msgLevel( MSG::DEBUG ) ) debug() << "De-Registering tool " << tool->name() << endmsg;
      m_tools.erase( it );
    } else {
      if ( msgLevel( MSG::DEBUG ) ) debug() << "Could not de-register tool " << tool->name() << endmsg;
    }
  }

  const std::vector<IAlgTool*>& tools() const;

protected:
  std::vector<IAlgTool*>& tools();

  /// Hook for for derived classes to provide a custom visitor for data handles.
  std::unique_ptr<IDataHandleVisitor> m_updateDataHandles;

private:
  // place IAlgTools defined via ToolHandles in m_tools
  void initToolHandles() const;

public:
  /// Access the auditor service
  IAuditorSvc* auditorSvc() const;

  /** @brief Access the monitor service
   *
   *   @attention Note that this method will return a NULL pointer if no monitor service is
   *              configured to be present. You must take this possibility into account when
   *              using the pointer
   *   @return Pointer to the Monitor service
   *   @retval NULL No monitor service is present
   *   @retval non-NULL A monitor service is present and available to be used
   */
  inline IMonitorSvc* monitorSvc() const {
    // If not already located try to locate it without forcing a creation
    if ( !m_pMonitorSvc ) m_pMonitorSvc = service( m_monitorSvcName, false, true );
    return m_pMonitorSvc.get();
  }

  /** Declare monitoring information
      @param name Monitoring information name known to the external system
      @param var  Monitoring Listener address (the item to monitor...)
      @param desc Textual description of the information being monitored
  */
  template <class T>
  void declareInfo( const std::string& name, const T& var, const std::string& desc ) const {
    IMonitorSvc* mS = monitorSvc();
    if ( mS ) mS->declareInfo( name, var, desc, this );
  }

  /** Declare monitoring information (special case)
      @param name Monitoring information name known to the external system
      @param format Format information
      @param var  Monitoring Listener address
      @param size Monitoring Listener address size
      @param desc Textual description of the information being monitored
  */
  void declareInfo( const std::string& name, const std::string& format, const void* var, int size,
                    const std::string& desc ) const {
    IMonitorSvc* mS = monitorSvc();
    if ( mS ) mS->declareInfo( name, format, var, size, desc, this );
  }

  // Standard destructor.
  ~AlgTool() override;

private:
  typedef std::list<std::pair<InterfaceID, void*>> InterfaceList;

  std::string       m_type;             ///< AlgTool type (concrete class name)
  const std::string m_name;             ///< AlgTool full name
  const IInterface* m_parent = nullptr; ///< AlgTool parent

  mutable SmartIF<ISvcLocator>      m_svcLocator;  ///< Pointer to Service Locator service
  mutable SmartIF<IDataProviderSvc> m_evtSvc;      ///< Event data service
  mutable SmartIF<IToolSvc>         m_ptoolSvc;    ///< Tool service
  mutable SmartIF<IMonitorSvc>      m_pMonitorSvc; ///< Online Monitoring Service
  mutable SmartIF<IAuditorSvc>      m_pAuditorSvc; ///< Auditor Service

  InterfaceList m_interfaceList; ///< Interface list

  // Properties
  // initialize output level from MessageSvc and initialize messaging (before enabling update handler)
  Gaudi::Property<int> m_outputLevel{
      this, "OutputLevel", setUpMessaging(),
      [this]( Gaudi::Details::PropertyBase& ) { this->updateMsgStreamOutputLevel( this->m_outputLevel ); },
      "output level" };

  Gaudi::Property<std::string> m_monitorSvcName{ this, "MonitorService", "MonitorSvc",
                                                 "name to use for Monitor Service" };

  Gaudi::Property<bool> m_auditorInitialize{ this, "AuditInitialize", false, "trigger auditor on initialize()" };
  Gaudi::Property<bool> m_auditorStart{ this, "AuditStart", false, "trigger auditor on start()" };
  Gaudi::Property<bool> m_auditorStop{ this, "AuditStop", false, "trigger auditor on stop()" };
  Gaudi::Property<bool> m_auditorFinalize{ this, "AuditFinalize", false, "trigger auditor on finalize()" };
  Gaudi::Property<bool> m_auditorReinitialize{ this, "AuditReinitialize", false, "trigger auditor on reinitialize()" };
  Gaudi::Property<bool> m_auditorRestart{ this, "AuditRestart", false, "trigger auditor on restart()" };

  // tools used by tool
  mutable std::vector<IAlgTool*>             m_tools;
  mutable std::vector<BaseToolHandle*>       m_toolHandles;
  mutable std::vector<GaudiHandleArrayBase*> m_toolHandleArrays;
  mutable bool m_toolHandlesInit = false; /// flag indicating whether ToolHandle tools have been added to m_tools

  Gaudi::StateMachine::State m_state       = Gaudi::StateMachine::CONFIGURED; ///< state of the Tool
  Gaudi::StateMachine::State m_targetState = Gaudi::StateMachine::CONFIGURED; ///< state of the Tool
};
