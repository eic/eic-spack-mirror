#!/usr/bin/env gaudirun.py
#####################################################################################
# (c) Copyright 1998-2025 CERN for the benefit of the LHCb and ATLAS collaborations #
#                                                                                   #
# This software is distributed under the terms of the Apache version 2 licence,     #
# copied verbatim in the file "LICENSE".                                            #
#                                                                                   #
# In applying this licence, CERN does not waive the privileges and immunities       #
# granted to it by virtue of its status as an Intergovernmental Organization        #
# or submit itself to any jurisdiction.                                             #
#####################################################################################
"""
Reference optionfile which shows in a simple way how to take advantage of the
Gaudi components desicated to concurrency.
The components are:
 o HiveWhiteBoard: a convenient way to collect several TES (one per "processing
 slot"), accessible in a thread safe way, keeps a catalogue of the products
 written on each processing slot. The number of slots in the whiteboard
 determines also the number of events processed simultaneously by the scheduler.
 o AvalancheSchedulerSvc: state machine of the algorithms interfaced with the
 TBB runtime. It is responsible for the submission of the algorithms. An
 algorithm is marked ready for submission when its needed input is available.
 It deals the asynchronous termination of algorithms with a "receiver" thread
 and a thread safe queue.
 o HiveSlimEventLoopMgr: an event factory. Pushes new events and pops finished
 events to/from the scheduler. It does not manage algorithms/streams.
 o AlgResourcePool: Service managing the creation of algorithms (through the
 algorithm manager), including clones. It also manages the algorithms according
 to the resources they need (parameter NeededResources - vector of strings - of
 the Algorithm class).
 o InertMessageSvc: as the TBBMsgSvc, it manages the printing of the messages in
 a multithreaded environment.

The CPUCruncher is not a component dealing with concurrency, but a useful
entity to test it. It's an algorithm that simply wastes cpu.

"""

from Configurables import (
    AlgResourcePool,
    AvalancheSchedulerSvc,
    ContextEventCounterData,
    ContextEventCounterPtr,
    CPUCruncher,
    GPUCruncher,
    CPUCrunchSvc,
    HiveSlimEventLoopMgr,
    HiveWhiteBoard,
)
from Gaudi.Configuration import *

# metaconfig -------------------------------------------------------------------
# It's confortable to collect the relevant parameters at the top of the optionfile
evtslots = 48
evtMax = 50
cardinality = 16
threads = 16
gpuThreads = 4
# -------------------------------------------------------------------------------

# The configuration of the whiteboard ------------------------------------------
# It is useful to call it EventDataSvc to replace the usual data service with
# the whiteboard transparently.

whiteboard = HiveWhiteBoard("EventDataSvc", EventSlots=evtslots)

# -------------------------------------------------------------------------------

# Event Loop Manager -----------------------------------------------------------
# It's called slim since it has less functionalities overall than the good-old
# event loop manager. Here we just set its outputlevel to DEBUG.

slimeventloopmgr = HiveSlimEventLoopMgr(
    SchedulerName="AvalancheSchedulerSvc", OutputLevel=WARNING
)

# -------------------------------------------------------------------------------

# AvalancheScheduler -----------------------------------------------------------
# We just decide how many algorithms in flight we want to have and how many
# threads in the pool. The default value is -1, which is for TBB equivalent
# to take over the whole machine.

scheduler = AvalancheSchedulerSvc(
    ThreadPoolSize=threads, NumOffloadThreads=gpuThreads, OutputLevel=WARNING
)

# -------------------------------------------------------------------------------

# Algo Resource Pool -----------------------------------------------------------
# Nothing special here, we just set the debug level.
AlgResourcePool(OutputLevel=WARNING)

CPUCrunchSvc(shortCalib=True)

# -------------------------------------------------------------------------------

# Set up of the crunchers, daily business --------------------------------------

a1 = CPUCruncher("A1")
a1.outKeys = ["/Event/a1"]

a2 = CPUCruncher("A2")
a2.inpKeys = ["/Event/a1"]
a2.outKeys = ["/Event/a2"]

a3 = CPUCruncher("A3")
a3.inpKeys = ["/Event/a1"]
a3.outKeys = ["/Event/a3"]

ga1 = GPUCruncher("GA1")
ga1.inpKeys = ["/Event/a1"]
ga1.outKeys = ["/Event/ga1"]

ga2 = GPUCruncher("GA2")
ga2.inpKeys = ["/Event/ga1"]
ga2.outKeys = ["/Event/ga2"]

a4 = CPUCruncher("A4")
a4.inpKeys = ["/Event/a2", "/Event/a3", "/Event/ga2"]
# a4.inpKeys = ["/Event/a2", "/Event/a3",]
a4.outKeys = ["/Event/a4"]

for algo in [a1, a2, a3, a4, ga1, ga2]:
    algo.Cardinality = cardinality
    algo.OutputLevel = INFO
    algo.varRuntime = 0.001
    algo.avgRuntime = 0.001

for algo in [ga1, ga2]:
    algo.avgRuntime = 10.0
    algo.varRuntime = 1.00
    algo.Cardinality = 0

ctrp = ContextEventCounterPtr("CNT*", Cardinality=1, OutputLevel=INFO)
ctrd = ContextEventCounterData("CNT&", Cardinality=1, OutputLevel=INFO)

# Application Manager ----------------------------------------------------------
# We put everything together and change the type of message service

ApplicationMgr(
    EvtMax=evtMax,
    EvtSel="NONE",
    ExtSvc=[whiteboard],
    EventLoop=slimeventloopmgr,
    TopAlg=[a1, a2, a3, a4, ga1, ga2, ctrp, ctrd],
    # TopAlg=[a1, a2, a3, a4, ctrp, ctrd],
    MessageSvcType="InertMessageSvc",
)

# -------------------------------------------------------------------------------
