// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include <memory>
#include <vector>

namespace Acts {

class SpacePointContainer;
template <typename T, bool read_only>
class SpacePointColumnProxy;
template <typename T>
using MutableSpacePointColumnProxy = SpacePointColumnProxy<T, false>;
template <typename T>
using ConstSpacePointColumnProxy = SpacePointColumnProxy<T, true>;

namespace detail::sp {

// These classes should have gone into `SpacePointContainer` but a compiler bug
// prevents that

class ColumnHolderBase {
 public:
  virtual ~ColumnHolderBase() = default;

  virtual std::unique_ptr<ColumnHolderBase> copy() const = 0;

  virtual std::size_t size() const = 0;
  virtual void reserve(std::size_t size) = 0;
  virtual void resize(std::size_t size) = 0;
  virtual void clear() = 0;
  virtual void emplace_back() = 0;
  virtual void copyFrom(const ColumnHolderBase &source, std::size_t sourceIndex,
                        std::size_t destinationIndex) = 0;
};

template <typename T>
class ColumnHolder /*final*/ : public ColumnHolderBase {
 public:
  using Value = T;
  using Container = std::vector<Value>;
  using MutableProxy = MutableSpacePointColumnProxy<Value>;
  using ConstProxy = ConstSpacePointColumnProxy<Value>;

  ColumnHolder() = default;
  explicit ColumnHolder(Value defaultValue)
      : m_default(std::move(defaultValue)) {}

  MutableProxy proxy(SpacePointContainer &container) {
    return MutableProxy(container, m_data);
  }
  ConstProxy proxy(const SpacePointContainer &container) const {
    return ConstProxy(container, m_data);
  }

  std::unique_ptr<ColumnHolderBase> copy() const final {
    return std::make_unique<ColumnHolder<T>>(*this);
  }

  std::size_t size() const final { return m_data.size(); }
  void reserve(std::size_t size) final { m_data.reserve(size); }
  void clear() final { m_data.clear(); }
  void resize(std::size_t size) final { m_data.resize(size, m_default); }
  void emplace_back() final { m_data.emplace_back(m_default); }
  void copyFrom(const ColumnHolderBase &source, std::size_t sourceIndex,
                std::size_t destinationIndex) final {
    const auto &typedSource = static_cast<const ColumnHolder<T> &>(source);
    m_data[destinationIndex] = typedSource.m_data[sourceIndex];
  }

 private:
  Value m_default{};
  Container m_data;
};

}  // namespace detail::sp
}  // namespace Acts
