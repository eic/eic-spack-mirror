// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Definitions/Direction.hpp"
#include "Acts/Definitions/TrackParametrization.hpp"
#include "Acts/EventData/MultiComponentTrackParameters.hpp"
#include "Acts/EventData/detail/CorrectedTransformationFreeToBound.hpp"
#include "Acts/MagneticField/MagneticFieldProvider.hpp"
#include "Acts/Material/IVolumeMaterial.hpp"
#include "Acts/Propagator/ConstrainedStep.hpp"
#include "Acts/Propagator/StepperConcept.hpp"
#include "Acts/Propagator/StepperStatistics.hpp"
#include "Acts/Propagator/detail/LoopStepperUtils.hpp"
#include "Acts/Propagator/detail/SteppingHelper.hpp"
#include "Acts/Surfaces/Surface.hpp"
#include "Acts/Utilities/Intersection.hpp"
#include "Acts/Utilities/Logger.hpp"
#include "Acts/Utilities/Result.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <sstream>

#include <boost/container/small_vector.hpp>

namespace Acts {

namespace detail {

struct MaxMomentumComponent {
  template <typename component_range_t>
  auto operator()(const component_range_t& cmps) const {
    return std::ranges::max_element(cmps, [&](const auto& a, const auto& b) {
      return std::abs(a.state.pars[eFreeQOverP]) >
             std::abs(b.state.pars[eFreeQOverP]);
    });
  }
};

struct MaxWeightComponent {
  template <typename component_range_t>
  auto operator()(const component_range_t& cmps) {
    return std::ranges::max_element(cmps, [&](const auto& a, const auto& b) {
      return a.weight < b.weight;
    });
  }
};

template <typename component_chooser_t>
struct SingleComponentReducer {
  template <typename stepper_state_t>
  static std::size_t index(const stepper_state_t& s) {
    return static_cast<std::size_t>(std::distance(
        s.components.begin(), component_chooser_t{}(s.components)));
  }

  template <typename stepper_state_t>
  static Vector3 position(const stepper_state_t& s) {
    return component_chooser_t{}(s.components)
        ->state.pars.template segment<3>(eFreePos0);
  }

  template <typename stepper_state_t>
  static Vector3 direction(const stepper_state_t& s) {
    return component_chooser_t{}(s.components)
        ->state.pars.template segment<3>(eFreeDir0);
  }

  template <typename stepper_state_t>
  static double qOverP(const stepper_state_t& s) {
    const auto cmp = component_chooser_t{}(s.components);
    return cmp->state.pars[eFreeQOverP];
  }

  template <typename stepper_state_t>
  static double absoluteMomentum(const stepper_state_t& s) {
    const auto cmp = component_chooser_t{}(s.components);
    return s.particleHypothesis.extractMomentum(cmp->state.pars[eFreeQOverP]);
  }

  template <typename stepper_state_t>
  static Vector3 momentum(const stepper_state_t& s) {
    const auto cmp = component_chooser_t{}(s.components);
    return s.particleHypothesis.extractMomentum(cmp->state.pars[eFreeQOverP]) *
           cmp->state.pars.template segment<3>(eFreeDir0);
  }

  template <typename stepper_state_t>
  static double charge(const stepper_state_t& s) {
    const auto cmp = component_chooser_t{}(s.components);
    return s.particleHypothesis.extractCharge(cmp->state.pars[eFreeQOverP]);
  }

  template <typename stepper_state_t>
  static double time(const stepper_state_t& s) {
    return component_chooser_t{}(s.components)->state.pars[eFreeTime];
  }

  template <typename stepper_state_t>
  static FreeVector pars(const stepper_state_t& s) {
    return component_chooser_t{}(s.components)->state.pars;
  }
};

}  // namespace detail

using MaxMomentumReducerLoop =
    detail::SingleComponentReducer<detail::MaxMomentumComponent>;
using MaxWeightReducerLoop =
    detail::SingleComponentReducer<detail::MaxWeightComponent>;

/// @brief Stepper based on a single-component stepper, but can handle
/// Multi-Component Tracks (e.g., for the GSF). Internally, this only
/// manages a vector of states of the single stepper. This simplifies
/// implementation, but has several drawbacks:
/// * There are certain redundancies between the global State and the
/// component states
/// * The components do not share a single magnetic-field-cache
/// @tparam sstepper_t The single-component stepper type to use
/// @tparam component_reducer_t How to map the multi-component state to a single
/// component
template <Concepts::SingleStepper single_stepper_t,
          typename component_reducer_t = MaxWeightReducerLoop>
class MultiStepperLoop final {
  /// Single stepper instance
  single_stepper_t m_singleStepper;

  /// Limits the number of steps after at least one component reached the
  /// surface
  std::size_t m_stepLimitAfterFirstComponentOnSurface = 50;

  /// The logger (used if no logger is provided by caller of methods)
  std::unique_ptr<const Acts::Logger> m_logger;

  /// Small vector type for speeding up some computations where we need to
  /// accumulate stuff of components. We think 16 is a reasonable amount here.
  template <typename T>
  using SmallVector = boost::container::small_vector<T, 16>;

 public:
  /// @brief Typedef to the Single-Component Eigen Stepper
  using SingleStepper = single_stepper_t;

  /// @brief Typedef to the Single-Component Stepper Options
  using SingleOptions = typename SingleStepper::Options;

  /// @brief Typedef to the State of the single component Stepper
  using SingleState = typename SingleStepper::State;

  /// @brief Typedef to the Config of the single component Stepper
  using SingleConfig = typename SingleStepper::Config;

  /// Type alias for bound track parameters
  using BoundParameters = MultiComponentBoundTrackParameters;
  /// Type alias for jacobian matrix
  using Jacobian = BoundMatrix;
  /// Type alias for covariance matrix
  using Covariance = BoundMatrix;

  /// @brief The reducer type
  using Reducer = component_reducer_t;

  /// @brief How many components can this stepper manage?
  static constexpr int maxComponents = std::numeric_limits<int>::max();

  /// Configuration for the multi-stepper loop.
  struct Config : public SingleStepper::Config {
    /// Limits the number of steps after at least one component reached the
    /// surface
    std::size_t stepLimitAfterFirstComponentOnSurface = 50;
  };

  struct Options : public SingleOptions {
    using SingleOptions::SingleOptions;
  };

  /// State container for multi-component stepping.
  struct State {
    /// The struct that stores the individual components
    struct Component {
      /// Individual component state for propagation
      SingleState state;
      /// Statistical weight of this component
      double weight;
      /// Intersection status of this component
      IntersectionStatus status;

      /// Constructor for a multi-stepper component
      /// @param state_ The single state for this component
      /// @param weight_ The weight of this component
      /// @param status_ The intersection status of this component
      Component(SingleState state_, double weight_, IntersectionStatus status_)
          : state(std::move(state_)), weight(weight_), status(status_) {}
    };

    /// Options for the propagation
    Options options;

    /// Particle hypothesis
    ParticleHypothesis particleHypothesis = ParticleHypothesis::pion();

    /// The components of which the state consists
    SmallVector<Component> components;

    /// Whether to transport covariance
    bool covTransport = false;
    /// Accumulated path length
    double pathAccumulated = 0.;
    /// Number of steps taken
    std::size_t steps = 0;

    /// Step-limit counter which limits the number of steps when one component
    /// reached a surface
    std::optional<std::size_t> stepCounterAfterFirstComponentOnSurface;

    /// The stepper statistics
    StepperStatistics statistics;

    /// Constructor from the initial bound track parameters
    ///
    /// @param [in] optionsIn is the options object for the stepper
    ///
    /// @note the covariance matrix is copied when needed
    explicit State(const Options& optionsIn) : options(optionsIn) {}
  };

  /// Constructor from a magnetic field and a optionally provided Logger
  /// TODO this requires that every stepper can be constructed like this...
  /// @param bField Magnetic field provider to use for propagation
  /// @param logger Logger instance for debugging output
  explicit MultiStepperLoop(std::shared_ptr<const MagneticFieldProvider> bField,
                            std::unique_ptr<const Logger> logger =
                                getDefaultLogger("GSF", Logging::INFO))
      : m_singleStepper(std::move(bField)), m_logger(std::move(logger)) {}

  /// Constructor from a configuration and optionally provided Logger
  /// @param config Configuration object containing stepper settings
  /// @param logger Logger instance for debugging output
  explicit MultiStepperLoop(const Config& config,
                            std::unique_ptr<const Logger> logger =
                                getDefaultLogger("MultiStepperLoop",
                                                 Logging::INFO))
      : m_singleStepper(config),
        m_stepLimitAfterFirstComponentOnSurface(
            config.stepLimitAfterFirstComponentOnSurface),
        m_logger(std::move(logger)) {}

  /// Get the single stepper instance
  /// @return Reference to the single stepper instance used internally
  const SingleStepper& singleStepper() const { return m_singleStepper; }

  /// Create a state object for multi-stepping
  /// @param options The propagation options
  /// @return Initialized state object for multi-stepper
  State makeState(const Options& options) const {
    State state(options);
    return state;
  }

  /// Initialize the stepper state from multi-component bound track parameters
  /// @param state The stepper state to initialize
  /// @param par The multi-component bound track parameters
  void initialize(State& state, const BoundParameters& par) const {
    if (par.empty()) {
      throw std::invalid_argument(
          "Cannot construct MultiEigenStepperLoop::State with empty "
          "multi-component parameters");
    }

    state.particleHypothesis = par.particleHypothesis();

    const auto surface = par.referenceSurface().getSharedPtr();

    state.components.clear();
    state.components.reserve(par.size());

    for (std::size_t i = 0; i < par.size(); ++i) {
      const auto& [weight, singlePars] = par[i];
      auto& cmp = state.components.emplace_back(
          m_singleStepper.makeState(state.options), weight,
          IntersectionStatus::onSurface);
      m_singleStepper.initialize(cmp.state, singlePars);
    }

    state.covTransport = par.hasCovariance();
  }

  /// A proxy struct which allows access to a single component of the
  /// multi-component state. It has the semantics of a const reference, i.e.
  /// it requires a const reference of the single-component state it
  /// represents
  using ConstComponentProxy =
      detail::LoopComponentProxyBase<const typename State::Component,
                                     MultiStepperLoop>;

  /// A proxy struct which allows access to a single component of the
  /// multi-component state. It has the semantics of a mutable reference, i.e.
  /// it requires a mutable reference of the single-component state it
  /// represents
  using ComponentProxy =
      detail::LoopComponentProxy<typename State::Component, MultiStepperLoop>;

  /// Creates an iterable which can be plugged into a range-based for-loop to
  /// iterate over components
  /// @param state Multi-component stepper state to iterate over
  /// @note Use a for-loop with by-value semantics, since the Iterable returns a
  /// proxy internally holding a reference
  /// @return Iterable range object that can be used in range-based for-loops
  auto componentIterable(State& state) const {
    struct Iterator {
      using difference_type [[maybe_unused]] = std::ptrdiff_t;
      using value_type [[maybe_unused]] = ComponentProxy;
      using reference [[maybe_unused]] = ComponentProxy;
      using pointer [[maybe_unused]] = void;
      using iterator_category [[maybe_unused]] = std::forward_iterator_tag;

      typename decltype(state.components)::iterator it;
      const State& s;

      // clang-format off
      auto& operator++() { ++it; return *this; }
      auto operator==(const Iterator& other) const { return it == other.it; }
      auto operator*() const { return ComponentProxy(*it, s); }
      // clang-format on
    };

    struct Iterable {
      State& s;

      // clang-format off
      auto begin() { return Iterator{s.components.begin(), s}; }
      auto end() { return Iterator{s.components.end(), s}; }
      // clang-format on
    };

    return Iterable{state};
  }

  /// Creates an constant iterable which can be plugged into a range-based
  /// for-loop to iterate over components
  /// @param state Multi-component stepper state to iterate over (const)
  /// @note Use a for-loop with by-value semantics, since the Iterable returns a
  /// proxy internally holding a reference
  /// @return Const iterable range object for read-only iteration over components
  auto constComponentIterable(const State& state) const {
    struct ConstIterator {
      using difference_type [[maybe_unused]] = std::ptrdiff_t;
      using value_type [[maybe_unused]] = ConstComponentProxy;
      using reference [[maybe_unused]] = ConstComponentProxy;
      using pointer [[maybe_unused]] = void;
      using iterator_category [[maybe_unused]] = std::forward_iterator_tag;

      typename decltype(state.components)::const_iterator it;
      const State& s;

      // clang-format off
      auto& operator++() { ++it; return *this; }
      auto operator==(const ConstIterator& other) const { return it == other.it; }
      auto operator*() const { return ConstComponentProxy{*it}; }
      // clang-format on
    };

    struct Iterable {
      const State& s;

      // clang-format off
      auto begin() const { return ConstIterator{s.components.cbegin(), s}; }
      auto end() const { return ConstIterator{s.components.cend(), s}; }
      // clang-format on
    };

    return Iterable{state};
  }

  /// Get the number of components
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  /// @return Number of components in the multi-component state
  std::size_t numberComponents(const State& state) const {
    return state.components.size();
  }

  /// Remove missed components from the component state
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  void removeMissedComponents(State& state) const {
    auto [beg, end] =
        std::ranges::remove_if(state.components, [](const auto& cmp) {
          return cmp.status == IntersectionStatus::unreachable;
        });

    state.components.erase(beg, end);
  }

  /// Reweight the components
  ///
  /// @param [in,out] state The stepping state (thread-local cache)
  void reweightComponents(State& state) const {
    double sumOfWeights = 0.0;
    for (const auto& cmp : state.components) {
      sumOfWeights += cmp.weight;
    }
    for (auto& cmp : state.components) {
      cmp.weight /= sumOfWeights;
    }
  }

  /// Reset the number of components
  ///
  /// @param [in,out] state  The stepping state (thread-local cache)
  void clearComponents(State& state) const { state.components.clear(); }

  /// Add a component to the Multistepper
  ///
  /// @param [in,out] state  The stepping state (thread-local cache)
  /// @param [in] pars Parameters of the component to add
  /// @param [in] weight Weight of the component to add
  ///
  /// @note: It is not ensured that the weights are normalized afterwards
  /// @note The component is initialized through the single stepper, so its
  /// jacobians are set whenever @p pars carries a covariance.
  /// @note The returned component-proxy is only garantueed to be valid until
  /// the component number is again modified
  /// @return ComponentProxy for the newly added component or error
  ComponentProxy addComponent(State& state, const BoundTrackParameters& pars,
                              double weight) const {
    auto& cmp =
        state.components.emplace_back(m_singleStepper.makeState(state.options),
                                      weight, IntersectionStatus::onSurface);
    m_singleStepper.initialize(cmp.state, pars);
    // the component starts here, but on the trajectory the multi state is on
    cmp.state.pathAccumulated = state.pathAccumulated;

    return ComponentProxy{state.components.back(), state};
  }

  /// Get the field for the stepping, it checks first if the access is still
  /// within the Cell, and updates the cell if necessary.
  ///
  /// @param [in,out] state is the propagation state associated with the track
  ///                 the magnetic field cell is used (and potentially updated)
  /// @param [in] pos is the field position
  ///
  /// @note This uses the cache of the first component stored in the state
  /// @return Magnetic field vector at the given position or error
  Result<Vector3> getField(State& state, const Vector3& pos) const {
    return m_singleStepper.getField(state.components.front().state, pos);
  }

  /// Global particle position accessor
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Global position vector from the reduced component state
  Vector3 position(const State& state) const {
    return Reducer::position(state);
  }

  /// Momentum direction accessor
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Normalized momentum direction vector from the reduced component state
  Vector3 direction(const State& state) const {
    return Reducer::direction(state);
  }

  /// QoP access
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Charge over momentum (q/p) value from the reduced component state
  double qOverP(const State& state) const { return Reducer::qOverP(state); }

  /// Absolute momentum accessor
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Absolute momentum magnitude from the reduced component state
  double absoluteMomentum(const State& state) const {
    return Reducer::absoluteMomentum(state);
  }

  /// Momentum accessor
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Momentum vector from the reduced component state
  Vector3 momentum(const State& state) const {
    return Reducer::momentum(state);
  }

  /// Charge access
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Electric charge value from the reduced component state
  double charge(const State& state) const { return Reducer::charge(state); }

  /// Particle hypothesis
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Particle hypothesis used for this multi-component state
  ParticleHypothesis particleHypothesis(const State& state) const {
    return state.particleHypothesis;
  }

  /// Time access
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return Time coordinate from the reduced component state
  double time(const State& state) const { return Reducer::time(state); }

  /// Update surface status
  ///
  /// It checks the status to the reference surface & updates
  /// the step size accordingly
  ///
  /// @param [in,out] state The stepping state (thread-local cache)
  /// @param [in] surface The surface provided
  /// @param [in] index The surface intersection index
  /// @param [in] navDir The navigation direction
  /// @param [in] boundaryTolerance The boundary check for this status update
  /// @param [in] surfaceTolerance Surface tolerance used for intersection
  /// @param [in] stype The step size type to be set
  /// @param [in] logger A @c Logger instance
  /// @return IntersectionStatus indicating the overall status of all components relative to the surface
  IntersectionStatus updateSurfaceStatus(
      State& state, const Surface& surface, std::uint8_t index,
      Direction navDir, const BoundaryTolerance& boundaryTolerance,
      double surfaceTolerance, ConstrainedStep::Type stype,
      const Logger& logger = getDummyLogger()) const {
    using Status = IntersectionStatus;

    std::array<int, 3> counts = {0, 0, 0};

    for (auto& component : state.components) {
      component.status = detail::updateSingleSurfaceStatus<SingleStepper>(
          m_singleStepper, component.state, surface, index, navDir,
          boundaryTolerance, surfaceTolerance, stype, logger);
      ++counts[static_cast<std::size_t>(component.status)];
    }

    // If at least one component is on a surface, we can remove all missed
    // components before the step. If not, we must keep them for the case that
    // all components miss and we need to retarget
    if (counts[static_cast<std::size_t>(Status::onSurface)] > 0) {
      removeMissedComponents(state);
      reweightComponents(state);
    }

    ACTS_VERBOSE("Component status wrt "
                 << surface.geometryId() << " at {"
                 << surface.center(state.options.geoContext).transpose()
                 << "}:\t" << [&]() {
                      std::stringstream ss;
                      for (auto& component : state.components) {
                        ss << component.status << "\t";
                      }
                      return ss.str();
                    }());

    // Switch on stepCounter if one or more components reached a surface, but
    // some are still in progress of reaching the surface
    if (!state.stepCounterAfterFirstComponentOnSurface &&
        counts[static_cast<std::size_t>(Status::onSurface)] > 0 &&
        counts[static_cast<std::size_t>(Status::reachable)] > 0) {
      state.stepCounterAfterFirstComponentOnSurface = 0;
      ACTS_VERBOSE("started stepCounterAfterFirstComponentOnSurface");
    }

    // If there are no components onSurface, but the counter is switched on
    // (e.g., if the navigator changes the target surface), we need to switch it
    // off again
    if (state.stepCounterAfterFirstComponentOnSurface &&
        counts[static_cast<std::size_t>(Status::onSurface)] == 0) {
      state.stepCounterAfterFirstComponentOnSurface.reset();
      ACTS_VERBOSE("switch off stepCounterAfterFirstComponentOnSurface");
    }

    // This is a 'any_of' criterium. As long as any of the components has a
    // certain state, this determines the total state (in the order of a
    // somewhat importance)
    if (counts[static_cast<std::size_t>(Status::reachable)] > 0) {
      return Status::reachable;
    } else if (counts[static_cast<std::size_t>(Status::onSurface)] > 0) {
      state.stepCounterAfterFirstComponentOnSurface.reset();
      return Status::onSurface;
    } else {
      return Status::unreachable;
    }
  }

  /// Update step size
  ///
  /// This method intersects the provided surface and update the navigation
  /// step estimation accordingly (hence it changes the state). It also
  /// returns the status of the intersection to trigger onSurface in case
  /// the surface is reached.
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  /// @param oIntersection [in] The ObjectIntersection to layer, boundary, etc
  /// @param direction [in] The propagation direction
  /// @param stype [in] The step size type to be set
  template <typename object_intersection_t>
  void updateStepSize(State& state, const object_intersection_t& oIntersection,
                      Direction direction, ConstrainedStep::Type stype) const {
    const Surface& surface = *oIntersection.object();

    for (auto& component : state.components) {
      auto intersection = surface.intersect(
          component.state.options.geoContext,
          m_singleStepper.position(component.state),
          direction * m_singleStepper.direction(component.state),
          BoundaryTolerance::None())[oIntersection.index()];

      m_singleStepper.updateStepSize(component.state, intersection, direction,
                                     stype);
    }
  }

  /// Update step size - explicitly with a double
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  /// @param stepSize [in] The step size value
  /// @param stype [in] The step size type to be set
  void updateStepSize(State& state, double stepSize,
                      ConstrainedStep::Type stype) const {
    for (auto& component : state.components) {
      m_singleStepper.updateStepSize(component.state, stepSize, stype);
    }
  }

  /// Get the step size
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @param stype [in] The step size type to be returned
  /// @note This returns the smallest step size of all components. It uses
  /// std::abs for comparison to handle backward propagation and negative
  /// step sizes correctly.
  /// @return Smallest step size among all components for the requested type
  double getStepSize(const State& state, ConstrainedStep::Type stype) const {
    return std::ranges::min_element(
               state.components,
               [=](const auto& a, const auto& b) {
                 return std::abs(a.state.stepSize.value(stype)) <
                        std::abs(b.state.stepSize.value(stype));
               })
        ->state.stepSize.value(stype);
  }

  /// Release the step-size for all components
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  /// @param [in] stype The step size type to be released
  void releaseStepSize(State& state, ConstrainedStep::Type stype) const {
    for (auto& component : state.components) {
      m_singleStepper.releaseStepSize(component.state, stype);
    }
  }

  /// Output the Step Size of all components into one std::string
  ///
  /// @param state [in,out] The stepping state (thread-local cache)
  /// @return String representation of all component step sizes concatenated
  std::string outputStepSize(const State& state) const {
    std::stringstream ss;
    for (const auto& component : state.components) {
      ss << component.state.stepSize.toString() << " || ";
    }

    return ss.str();
  }

  /// Get the stepper statistics
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return The statistics since the last initialization
  const StepperStatistics& statistics(const State& state) const {
    return state.statistics;
  }

  /// Get the path length
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return The weighted path length of the components
  double pathLength(const State& state) const { return state.pathAccumulated; }

  /// Check if the state carries a covariance
  ///
  /// @param state [in] The stepping state (thread-local cache)
  /// @return True if the covariance is transported
  bool hasCovariance(const State& state) const { return state.covTransport; }

  /// Get the bound parameters at the current position
  ///
  /// The mixture combines the bound parameters of the components. Components
  /// that cannot be expressed on @p surface are ignored unless all fail.
  ///
  /// @note It does not check if the components are on @p surface. Use
  ///       @ref transportToBound to put them there.
  ///
  /// @param [in] state The stepping state (thread-local cache)
  /// @param [in] surface The surface of the parameters
  /// @return The bound mixture, or a failure if no component can be
  ///         expressed on @p surface
  Result<BoundParameters> boundParameters(const State& state,
                                          const Surface& surface) const;

  /// @brief If necessary fill additional members needed for
  /// transportToCurvilinear
  ///
  /// @param [in, out] state The stepping state (thread-local cache)
  /// @return true if nothing is missing after this call, false otherwise.
  bool prepareCurvilinearState(State& state) const {
    static_cast<void>(state);
    return true;
  }

  /// Get the curvilinear parameters at the current position
  ///
  /// @note This is done as a simple average over the free representation
  /// and covariance of the components.
  ///
  /// @param [in] state The stepping state (thread-local cache)
  /// @return The curvilinear mixture
  BoundParameters curvilinearParameters(const State& state) const;

  /// Transport the covariance of each component to its curvilinear frame
  ///
  /// @param [in,out] state State of the stepper
  /// @return The jacobian of the component the reducer selects, which also
  ///         provides the position and direction of the state
  Jacobian transportToCurvilinear(State& state) const {
    const std::size_t selected = Reducer::index(state);
    Jacobian jacobian = Jacobian::Identity();
    for (std::size_t i = 0; i < state.components.size(); ++i) {
      Jacobian cmpJacobian =
          m_singleStepper.transportToCurvilinear(state.components[i].state);
      if (i == selected) {
        jacobian = cmpJacobian;
      }
    }
    return jacobian;
  }

  /// Put each component on a surface and transport its covariance there
  ///
  /// The components are intersected with @p surface first, because a
  /// propagation can end when only the mean of the components reached it.
  /// Components that cannot be expressed on @p surface are ignored unless all
  /// fail.
  ///
  /// @param [in,out] state State of the stepper
  /// @param [in] surface The surface to transport the components to
  /// @param [in] freeToBoundCorrection Flag steering non-linear correction during global to local correction
  /// @return The jacobian of the component the reducer selects, which also
  ///         provides the position and direction of the state, or a failure
  ///         if this component cannot be expressed on @p surface
  Result<Jacobian> transportToBound(
      State& state, const Surface& surface,
      const FreeToBoundCorrection& freeToBoundCorrection =
          FreeToBoundCorrection(false)) const;

  /// Perform a Runge-Kutta track parameter propagation step
  ///
  /// @param [in,out] state The state of the stepper
  /// @param propDir is the direction of propagation
  /// @param material is the material properties
  /// @return the result of the step
  ///
  /// The state contains the desired step size. It can be negative during
  /// backwards track propagation, and since we're using an adaptive
  /// algorithm, it can be modified by the stepper class during propagation.
  Result<double> step(State& state, Direction propDir,
                      const IVolumeMaterial* material) const;
};

}  // namespace Acts

#include "MultiStepperLoop.ipp"
