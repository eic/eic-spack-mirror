// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Definitions/Tolerance.hpp"
#include "Acts/Geometry/GeometryContext.hpp"
#include "Acts/Geometry/GeometryIdentifier.hpp"
#include "Acts/Geometry/TrackingGeometryVisitor.hpp"
#include "Acts/Geometry/TrackingVolume.hpp"
#include "Acts/Geometry/TrackingVolumeVisitorConcept.hpp"
#include "Acts/Surfaces/SurfaceVisitorConcept.hpp"
#include "Acts/Utilities/Logger.hpp"
#include "Acts/Utilities/Result.hpp"

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>

namespace Acts {

class Layer;
class Surface;
class Portal;
class PerigeeSurface;
class IMaterialDecorator;
class TrackingVolume;
class TrackingGeometryVisitor;
class TrackingGeometryMutableVisitor;

namespace detail {
/// Transparent hash for string-keyed associative containers, allowing
/// heterogeneous lookup with @c std::string_view without constructing a
/// temporary @c std::string.
struct TransparentStringHash {
  using is_transparent = void;

  std::size_t operator()(std::string_view sv) const {
    return std::hash<std::string_view>{}(sv);
  }
};

/// Map from portal tag to portal, with transparent string lookup.
using PortalTagMap = std::unordered_map<std::string, const Portal*,
                                        TransparentStringHash, std::equal_to<>>;

/// Map from surface to the portal (Gen3) it represents.
using PortalSurfaceMap = std::unordered_map<const Surface*, const Portal*>;

/// Map from surface to the boundary surface (Gen1) it represents.
using BoundarySurfaceMap =
    std::unordered_map<const Surface*, const BoundarySurfaceT<TrackingVolume>*>;
}  // namespace detail

// Forward declaration only, the implementation is hidden in the .cpp file.
class Gen1GeometryClosureVisitor;

///  @class TrackingGeometry
///
///  The TrackingGeometry class is the owner of the constructed TrackingVolumes.
///
///  It enables both, a global search for an asociatedVolume
///  (respectively, if existing, a global search of an associated Layer or the
///  next associated Layer), such as a continuous navigation by BoundarySurfaces
///  between the confined TrackingVolumes.
class TrackingGeometry {
  /// Give the GeometryBuilder friend rights
  friend class TrackingGeometryBuilder;

 public:
  /// Constructor
  ///
  /// @param highestVolume is the world volume
  /// @param materialDecorator is a dediated decorator that can assign
  ///        surface or volume based material to the TrackingVolume
  /// @param hook Identifier hook to be applied to surfaces
  /// @param logger instance of a logger (defaulting to the "silent" one)
  /// @param close If true, run the Gen1 geometry closure
  explicit TrackingGeometry(
      const std::shared_ptr<TrackingVolume>& highestVolume,
      const IMaterialDecorator* materialDecorator = nullptr,
      const GeometryIdentifierHook& hook = {},
      const Logger& logger = getDummyLogger(), bool close = true);

  /// Destructor
  ~TrackingGeometry();

  /// Access to the world volume
  /// @return plain pointer to the world volume
  const TrackingVolume* highestTrackingVolume() const;

  /// Access to the world volume
  /// @return plain pointer to the world volume
  TrackingVolume* highestTrackingVolume();

  /// Access to the world volume
  /// @return shared pointer to the world volume
  std::shared_ptr<const TrackingVolume> highestTrackingVolumePtr() const;

  /// resolve the lowest tracking Volume for a global position
  ///
  /// Without a @p direction and @p associatedSurface the lookup is purely
  /// position based, and which of the adjacent volumes is returned for a
  /// position on a boundary between volumes is unspecified.
  ///
  /// If @p associatedSurface is given and is a boundary surface (Gen1) or a
  /// portal surface (Gen3), the boundary ambiguity is resolved along
  /// @p direction: the volume being entered is returned. Otherwise the surface
  /// does not act as a boundary and the lookup is position based as above.
  ///
  /// @pre If @p associatedSurface is given, the position has to be on it
  ///      within the given @p tolerance, ignoring the surface bounds.
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param gp is the global position of the call
  /// @param direction is the direction used to resolve the volume if the
  ///        position is on a boundary between volumes
  /// @param associatedSurface is the surface the position lies on, used to
  ///        identify a boundary crossing
  /// @param tolerance is the search tolerance for the volume lookup and the
  ///        on-surface check of the associated surface
  ///
  /// @return plain pointer to the lowest TrackingVolume, `nullptr` if there
  ///         is no volume at the position (or in the given direction)
  /// @retval SurfaceError::GlobalPositionNotOnSurface if
  ///         @p associatedSurface is a boundary surface or portal, but the
  ///         position is outside of its bounds. This can happen for positions
  ///         grazing a volume edge within the lookup tolerance.
  Result<const TrackingVolume*> resolveLowestTrackingVolume(
      const GeometryContext& gctx, const Vector3& gp,
      const std::optional<Vector3>& direction = std::nullopt,
      const Surface* associatedSurface = nullptr,
      double tolerance = s_onSurfaceTolerance) const;

  /// return the lowest tracking Volume for a global position
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param gp is the global position of the call
  ///
  /// @return plain pointer to the lowest TrackingVolume, `nullptr` if there
  ///         is no volume at the position
  ///
  /// @deprecated Use @ref resolveLowestTrackingVolume instead, which can
  ///             resolve boundaries along a direction and reports failures
  ///             instead of returning `nullptr`.
  [[deprecated(
      "Use resolveLowestTrackingVolume instead")]] const TrackingVolume*
  lowestTrackingVolume(const GeometryContext& gctx, const Vector3& gp) const;

  /// Forward the associated Layer information
  ///
  /// @param gctx is the context for this request (e.g. alignment)
  /// @param gp is the global position of the call
  ///
  /// @return plain pointer to assocaiated layer
  const Layer* associatedLayer(const GeometryContext& gctx,
                               const Vector3& gp) const;

  /// @brief Visit all reachable surfaces
  ///
  /// @tparam visitor_t Type of the callable visitor
  ///
  /// @param visitor The callable. Will be called for each reachable surface
  /// that is found, a selection of the surfaces can be done in the visitor
  /// @param restrictToSensitives If true, only sensitive surfaces are visited
  ///
  /// @note If a context is needed for the visit, the visitor has to provide
  /// this, e.g. as a private member
  template <SurfaceVisitor visitor_t>
  void visitSurfaces(visitor_t&& visitor, bool restrictToSensitives) const {
    highestTrackingVolume()->template visitSurfaces<visitor_t>(
        std::forward<visitor_t>(visitor), restrictToSensitives);
  }

  /// @brief Visit all sensitive surfaces
  ///
  /// @tparam visitor_t Type of the callable visitor
  ///
  /// @param visitor The callable. Will be called for each sensitive surface
  /// that is found, a selection of the surfaces can be done in the visitor
  ///
  /// @note If a context is needed for the visit, the visitor has to provide
  /// this, e.g. as a private member
  template <SurfaceVisitor visitor_t>
  void visitSurfaces(visitor_t&& visitor) const {
    visitSurfaces(std::forward<visitor_t>(visitor), true);
  }

  /// @brief Visit all reachable tracking volumes
  ///
  /// @tparam visitor_t Type of the callable visitor
  ///
  /// @param visitor The callable. Will be called for each reachable volume
  /// that is found, a selection of the volumes can be done in the visitor
  ///
  /// @note If a context is needed for the visit, the visitor has to provide
  /// this, e.g. as a private member
  template <TrackingVolumeVisitor visitor_t>
  void visitVolumes(visitor_t&& visitor) const {
    highestTrackingVolume()->template visitVolumes<visitor_t>(
        std::forward<visitor_t>(visitor));
  }

  /// @copydoc TrackingVolume::apply
  void apply(TrackingGeometryVisitor& visitor) const;

  /// @copydoc TrackingVolume::apply
  void apply(TrackingGeometryMutableVisitor& visitor);

  /// @brief Apply an arbitrary callable as a visitor to the tracking volume
  ///
  /// @param callable The callable to apply
  ///
  /// @note The visitor can be overloaded on any of the arguments that
  ///       the methods in @c TrackingGeometryVisitor receive.
  template <typename Callable>
  void apply(Callable&& callable)
    requires(detail::callableWithAnyMutable<Callable>() &&
             !detail::callableWithAnyConst<Callable>())
  {
    detail::TrackingGeometryLambdaMutableVisitor visitor{
        std::forward<Callable>(callable)};
    apply(visitor);
  }

  /// @brief Apply an arbitrary callable as a visitor to the tracking volume
  ///
  /// @param callable The callable to apply
  ///
  /// @note The visitor can be overloaded on any of the arguments that
  ///       the methods in @c TrackingGeometryMutableVisitor receive.
  template <typename Callable>
  void apply(Callable&& callable) const
    requires(detail::callableWithAnyConst<Callable>())
  {
    detail::TrackingGeometryLambdaVisitor visitor{
        std::forward<Callable>(callable)};
    apply(visitor);
  }

  /// Search for a volume with the given identifier.
  ///
  /// @param id is the geometry identifier of the volume
  /// @retval nullptr if no such volume exists
  /// @retval pointer to the found volume otherwise.
  const TrackingVolume* findVolume(GeometryIdentifier id) const;

  /// Search for the first volume with the given name.
  ///
  /// @param name is the volume name to search for
  /// @retval nullptr if no volume carries the name
  /// @retval pointer to the first matching volume otherwise.
  const TrackingVolume* findVolumeByName(std::string_view name) const;

  /// Search for a surface with the given identifier.
  ///
  /// @param id is the geometry identifier of the surface
  /// @retval nullptr if no such surface exists
  /// @retval pointer to the found surface otherwise.
  const Surface* findSurface(GeometryIdentifier id) const;

  /// Search for a portal that was tagged with the given label during the
  /// blueprint construction (see @ref Acts::PortalDesignatorBlueprintNode).
  ///
  /// @param tag the tag assigned to the portal
  /// @retval nullptr if no portal carries the tag
  /// @retval pointer to the tagged portal otherwise.
  const Portal* findPortal(std::string_view tag) const;

  /// Access to the GeometryIdentifier - Surface association map
  /// @return Const reference to the geometry ID to surface map
  const std::unordered_map<GeometryIdentifier, const Surface*>&
  geoIdSurfaceMap() const;

  /// @param helper The visualization helper that implement the output
  /// @param gctx The geometry context
  /// @param viewConfig Global view config
  /// @param portalViewConfig View config for portals
  /// @param sensitiveViewConfig View configuration for sensitive surfaces
  /// @deprecated Use the ViewConfigFunc overload instead
  [[deprecated("Use the ViewConfigFunc overload instead")]]
  void visualize(IVisualization3D& helper, const GeometryContext& gctx,
                 const ViewConfig& viewConfig,
                 const ViewConfig& portalViewConfig,
                 const ViewConfig& sensitiveViewConfig) const;

  /// Visualize a tracking geometry including substructure
  /// @param helper The visualization helper that implement the output
  /// @param gctx The geometry context
  /// @param func Function determining the ViewConfig for each GeometryObject
  void visualize(IVisualization3D& helper, const GeometryContext& gctx,
                 const ViewConfigFunc& func = defaultGeometryColoring) const;

  /// Which *type* of geometry this represents: Gen1 or Gen3
  enum class GeometryVersion { Gen1, Gen3 };

  /// Return the *generation* of this `TrackingGeometry`
  /// @return the generation of this `TrackingGeometry`
  GeometryVersion geometryVersion() const;

 private:
  // the known world
  std::shared_ptr<TrackingVolume> m_world;
  // lookup containers
  std::unordered_map<GeometryIdentifier, const TrackingVolume*> m_volumesById;
  std::unordered_map<GeometryIdentifier, const Surface*> m_surfacesById;
  detail::PortalTagMap m_portalsByTag;
  // surface to portal / boundary surface association, built once at
  // construction so that the boundary aware volume lookup does not have to
  // scan the portals and boundary surfaces of a volume
  detail::PortalSurfaceMap m_portalsBySurface;
  detail::BoundarySurfaceMap m_boundariesBySurface;
};

}  // namespace Acts
