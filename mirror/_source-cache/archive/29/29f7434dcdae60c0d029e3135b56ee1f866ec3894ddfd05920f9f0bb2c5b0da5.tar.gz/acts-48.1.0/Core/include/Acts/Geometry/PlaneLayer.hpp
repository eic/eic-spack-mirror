// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Geometry/ApproachDescriptor.hpp"
#include "Acts/Geometry/Layer.hpp"
#include "Acts/Surfaces/PlaneSurface.hpp"

#include <memory>

namespace Acts {

class PlanarBounds;
class SurfaceArray;

/// @class PlaneLayer
///
/// Class to describe a planar detector layer for tracking,
/// it inherits from both, Layer base class and PlaneSurface class
///
class PlaneLayer : virtual public PlaneSurface, public Layer {
 public:
  /// Factory for a shared plane layer
  ///
  /// @param transform which places the layer in the global frame
  /// @param pbounds the planar bounds that define the layer dimensions
  /// @param surfaceArray is the surface array that holds the sensitive surfaces
  /// @param thickness is the thickness of the layer (normal direction to plane)
  /// @param ad is the approach descriptor for describing the approach surface
  /// @param laytyp is the layer type
  ///
  /// @return shared pointer to a PlaneLayer
  static std::shared_ptr<PlaneLayer> create(
      const Transform3& transform, std::shared_ptr<const PlanarBounds> pbounds,
      std::unique_ptr<SurfaceArray> surfaceArray, double thickness = 0.,
      std::unique_ptr<ApproachDescriptor> ad = nullptr,
      LayerType laytyp = active);

  PlaneLayer() = delete;
  PlaneLayer(const PlaneLayer& pla) = delete;
  ~PlaneLayer() override = default;
  PlaneLayer& operator=(const PlaneLayer&) = delete;

  /// Transforms the layer into a Surface representation for extrapolation
  /// @return returns a reference to a PlaneSurface
  const PlaneSurface& surfaceRepresentation() const override;

  /// Non-const version of surface representation access
  /// @return Mutable reference to the plane surface
  PlaneSurface& surfaceRepresentation() override;

 private:
  /// private helper method to build approach surfaces
  void buildApproachDescriptor();

 protected:
  /// Private constructor for a PlaneLayer is called by create(args*)
  ///
  /// @param transform which places the layer in the global frame
  /// @param pbounds the planar bounds that define the layer dimensions
  /// @param surfaceArray is the surface array that holds the sensitive surfaces
  /// @param thickness is the thickness of the layer (normal direction to plane)
  /// @param ades is the approach descriptor for describing the approach surface
  /// @param laytyp is the layer type
  PlaneLayer(const Transform3& transform,
             std::shared_ptr<const PlanarBounds>& pbounds,
             std::unique_ptr<SurfaceArray> surfaceArray, double thickness = 0.,
             std::unique_ptr<ApproachDescriptor> ades = nullptr,
             LayerType laytyp = active);

  /// Private constructor for a PlaneLayer, is called by create(arge*
  ///
  /// @param pla is the plain layer to be coped
  /// @param shift is the additional shift applied after copying
  PlaneLayer(const PlaneLayer& pla, const Transform3& shift);
};

}  // namespace Acts
