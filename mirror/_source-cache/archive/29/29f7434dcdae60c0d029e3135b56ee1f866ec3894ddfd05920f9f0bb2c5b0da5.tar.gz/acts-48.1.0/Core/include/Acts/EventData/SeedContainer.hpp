// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/EventData/SeedColumns.hpp"
#include "Acts/EventData/SpacePointContainer.hpp"
#include "Acts/EventData/Types.hpp"
#include "Acts/Utilities/detail/ContainerIterator.hpp"

#include <cassert>
#include <vector>

namespace Acts {

template <bool read_only>
class SeedProxy;

/// Mutable proxy to a seed allowing modification
using MutableSeedProxy = SeedProxy<false>;
/// Const proxy to a seed for read-only access
using ConstSeedProxy = SeedProxy<true>;

/// A container of seeds. Individual seeds are modeled as a sequence of N space
/// points which are addressed via an index into the space point container.
/// Individual seeds are addressed via index. A proxy object simplifies the
/// handling.
class SeedContainer {
 public:
  /// Type alias for seed index type
  using Index = SeedIndex;
  /// Type alias for mutable seed proxy
  using MutableProxy = MutableSeedProxy;
  /// Type alias for const seed proxy
  using ConstProxy = ConstSeedProxy;

  /// Constructs and empty seed container.
  SeedContainer() noexcept;

  /// Constructs a copy of the given seed container.
  /// @param other The seed container to copy.
  SeedContainer(const SeedContainer &other) noexcept;

  /// Move constructs a seed container.
  /// @param other The seed container to move.
  SeedContainer(SeedContainer &&other) noexcept;

  /// Detructs the seed container.
  ~SeedContainer() noexcept = default;

  /// Assignment operator for copying a seed container.
  /// @param other The seed container to copy.
  /// @return A reference to this seed container.
  SeedContainer &operator=(const SeedContainer &other) noexcept;

  /// Move assignment operator for a seed container.
  /// @param other The seed container to move.
  /// @return A reference to this seed container.
  SeedContainer &operator=(SeedContainer &&other) noexcept;

  /// Returns the size of the seed container, i.e., the number of seeds
  /// contained in it.
  /// @return The number of seeds in the container.
  Index size() const noexcept { return m_size; }

  /// Checks if the seed container is empty.
  /// @return True if the container is empty, false otherwise.
  bool empty() const noexcept { return size() == 0; }

  /// Reserves space for the given number of seeds.
  /// @param size The number of seeds to reserve space for.
  /// @param averageSpacePoints The average number of space points per seed.
  void reserve(Index size, float averageSpacePoints = 3) noexcept;

  /// Clears the seed container, removing all seeds and space points.
  void clear() noexcept;

  /// Assigns the mutable space point container to be used by this seed
  /// container by value. This can be used to either copy or move-assign a
  /// container. The ownership of the space point container is transferred to
  /// this seed container.
  /// @param spacePointContainer The space point container to assign.
  void assignSpacePointContainer(
      SpacePointContainer &&spacePointContainer) noexcept;

  /// Assigns the mutable space point container to be used by this seed
  /// container by reference. Note that the ownership of the space point
  /// container is not transferred and the user must ensure that the space point
  /// container remains valid for the lifetime of this seed container.
  /// @param spacePointContainer The space point container to assign.
  void assignSpacePointContainer(
      SpacePointContainer &spacePointContainer) noexcept;

  /// Assigns the const space point container to be used by this seed container
  /// by const reference. Note that the ownership of the space point container
  /// is not transferred and the user must ensure that the space point container
  /// remains valid for the lifetime of this seed container.
  /// @param spacePointContainer The space point container to assign.
  void assignSpacePointContainer(
      const SpacePointContainer &spacePointContainer) noexcept;

  /// Assigns the mutable space point container to be used by this seed
  /// container by shared pointer. The ownership of the space point container is
  /// shared between this seed container and the user.
  /// @param spacePointContainer The space point container to assign.
  void assignSpacePointContainer(
      const std::shared_ptr<SpacePointContainer> &spacePointContainer) noexcept;

  /// Assigns the const space point container to be used by this seed container
  /// by shared pointer. The ownership of the space point container is shared
  /// between this seed container and the user.
  /// @param spacePointContainer The space point container to assign.
  void assignSpacePointContainer(
      const std::shared_ptr<const SpacePointContainer>
          &spacePointContainer) noexcept;

  /// Checks if a space point container has been assigned to this seed
  /// container.
  /// @return True if a space point container has been assigned.
  bool hasSpacePointContainer() const noexcept;

  /// Checks if a mutable space point container has been assigned to this seed
  /// container.
  /// @return True if a mutable space point container has been assigned.
  bool hasMutableSpacePointContainer() const noexcept;

  /// Returns a const reference to the assigned space point container.
  /// @return A const reference to the assigned space point container.
  /// @throws std::logic_error if no space point container has been assigned.
  const SpacePointContainer &spacePointContainer() const;

  /// Returns a mutable reference to the assigned space point container.
  /// @return A mutable reference to the assigned space point container.
  /// @throws std::logic_error if no mutable space point container has been assigned.
  SpacePointContainer &mutableSpacePointContainer();

  /// Creates a new seed.
  /// @return A mutable proxy to the newly created seed.
  MutableProxy createSeed() noexcept;

  /// Copies the specified columns from another seed to this seed
  /// @param index The index of the seed to copy to in this container.
  /// @param otherContainer The seed container to copy from.
  /// @param otherIndex The index of the seed to copy from in the other container.
  /// @param columnsToCopy The columns to copy from the other seed.
  void copyFrom(Index index, const SeedContainer &otherContainer,
                Index otherIndex, SeedColumns columnsToCopy);

  /// Returns a mutable proxy to the seed at the given index.
  /// If the index is out of range, an exception is thrown.
  /// @param index The index of the seed to access.
  /// @return A mutable proxy to the seed at the given index.
  /// @throws std::out_of_range if the index is out of range.
  MutableProxy at(Index index);

  /// Returns a const proxy to the seed at the given index.
  /// If the index is out of range, an exception is thrown.
  /// @param index The index of the seed to access.
  /// @return A const proxy to the seed at the given index.
  /// @throws std::out_of_range if the index is out of range.
  ConstProxy at(Index index) const;

  /// Returns a mutable proxy to the seed at the given index.
  /// @param index The index of the seed to access.
  /// @return A mutable proxy to the seed at the given index.
  MutableProxy operator[](Index index) noexcept;

  /// Returns a const proxy to the seed at the given index.
  /// @param index The index of the seed to access.
  /// @return A const proxy to the seed at the given index.
  ConstProxy operator[](Index index) const noexcept;

  /// Type alias for iterator template over seed container
  template <bool read_only>
  using Iterator = detail::ContainerIterator<
      SeedContainer,
      std::conditional_t<read_only, ConstSeedProxy, MutableSeedProxy>, Index,
      read_only>;

  /// Type alias for mutable iterator over seeds
  using iterator = Iterator<false>;
  /// Type alias for const iterator over seeds
  using const_iterator = Iterator<true>;

  /// Get mutable iterator to the beginning of seeds
  /// @return Mutable iterator to the first seed
  iterator begin() noexcept { return {*this, 0}; }
  /// Get mutable iterator to the end of seeds
  /// @return Mutable iterator past the last seed
  iterator end() noexcept { return {*this, size()}; }

  /// Get const iterator to the beginning of seeds
  /// @return Const iterator to the first seed
  const_iterator begin() const noexcept { return {*this, 0}; }
  /// Get const iterator to the end of seeds
  /// @return Const iterator past the last seed
  const_iterator end() const noexcept { return {*this, size()}; }

 private:
  template <bool>
  friend class SeedProxy;

  std::uint32_t m_size{0};
  std::vector<std::uint32_t> m_spacePointOffsets;
  std::vector<std::uint8_t> m_spacePointCounts;
  std::vector<float> m_qualities;
  std::vector<float> m_vertexZs;
  std::vector<SpacePointIndex> m_spacePoints;

  std::shared_ptr<const SpacePointContainer> m_sharedConstSpacePointContainer;
  SpacePointContainer *m_mutableSpacePointContainer{nullptr};
  const SpacePointContainer *m_constSpacePointContainer{nullptr};
};

}  // namespace Acts

#include "Acts/EventData/SeedContainer.ipp"
