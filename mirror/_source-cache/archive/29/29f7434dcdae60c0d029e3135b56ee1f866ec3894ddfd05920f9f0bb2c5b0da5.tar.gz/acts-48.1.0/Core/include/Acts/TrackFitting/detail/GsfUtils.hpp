// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Direction.hpp"
#include "Acts/Definitions/TrackParametrization.hpp"
#include "Acts/EventData/BoundTrackParameters.hpp"
#include "Acts/EventData/MultiTrajectoryHelpers.hpp"
#include "Acts/EventData/Types.hpp"
#include "Acts/Propagator/detail/PointwiseMaterialInteraction.hpp"
#include "Acts/Surfaces/Surface.hpp"
#include "Acts/TrackFitting/BetheHeitlerApprox.hpp"
#include "Acts/TrackFitting/GsfComponent.hpp"
#include "Acts/Utilities/AlgebraHelpers.hpp"
#include "Acts/Utilities/Intersection.hpp"
#include "Acts/Utilities/Logger.hpp"
#include "Acts/Utilities/Zip.hpp"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <iomanip>
#include <map>
#include <ostream>
#include <tuple>
#include <vector>

namespace Acts::detail::Gsf {

/// The tolerated difference to 1 to accept weights as normalized
constexpr static double s_normalizationTolerance = 1.e-4;

template <typename component_range_t, typename projector_t>
bool weightsAreNormalized(const component_range_t &cmps,
                          const projector_t &proj,
                          double tol = s_normalizationTolerance) {
  double sumOfWeights = 0.0;

  for (auto &&cmp : cmps) {
    sumOfWeights += proj(cmp);
  }

  return std::abs(sumOfWeights - 1.0) < tol;
}

template <typename component_range_t, typename projector_t>
void normalizeWeights(component_range_t &cmps, const projector_t &proj) {
  double sumOfWeights = 0.0;

  // we need decltype(auto) here to support proxy-types with reference
  // semantics, otherwise there is a `cannot bind ... to ...` error
  for (auto &&cmp : cmps) {
    assert(std::isfinite(proj(cmp)) && "weight not finite in normalization");
    sumOfWeights += proj(cmp);
  }

  assert(sumOfWeights > 0 && "sum of weights is not > 0");

  for (auto &&cmp : cmps) {
    proj(cmp) /= sumOfWeights;
  }
}

// A class that prints information about the state on construction and
// destruction, it also contains some assertions in the constructor and
// destructor. It can be removed without change of behaviour, since it only
// holds const references
template <typename propagator_state_t, typename stepper_t, typename navigator_t>
class ScopedGsfInfoPrinterAndChecker {
  const propagator_state_t &m_state;
  const stepper_t &m_stepper;
  const navigator_t &m_navigator;
  double m_p_initial;
  const Logger &m_logger;

  const Logger &logger() const { return m_logger; }

  void print_component_stats() const {
    std::size_t i = 0;
    for (auto cmp : m_stepper.constComponentIterable(m_state.stepping)) {
      const auto &singleStepper = cmp.singleStepper(m_stepper);
      ACTS_VERBOSE(
          "  #" << i++
                << " pos: " << singleStepper.position(cmp.state()).transpose()
                << ", dir: " << singleStepper.direction(cmp.state()).transpose()
                << ", weight: " << cmp.weight() << ", status: " << cmp.status()
                << ", qop: " << singleStepper.qOverP(cmp.state())
                << ", det(cov): "
                << singleStepper.covariance(cmp.state()).value().determinant());
    }
  }

  void checks(bool onStart) const {
    const auto cmps = m_stepper.constComponentIterable(m_state.stepping);
    [[maybe_unused]] const bool allFinite =
        std::all_of(cmps.begin(), cmps.end(),
                    [](auto cmp) { return std::isfinite(cmp.weight()); });
    [[maybe_unused]] const bool allNormalized = weightsAreNormalized(
        cmps, [](const auto &cmp) { return cmp.weight(); });
    [[maybe_unused]] const bool zeroComponents =
        m_stepper.numberComponents(m_state.stepping) == 0;

    if (onStart) {
      assert(!zeroComponents && "no cmps at the start");
      assert(allFinite && "weights not finite at the start");
      assert(allNormalized && "not normalized at the start");
    } else {
      assert(!zeroComponents && "no cmps at the end");
      assert(allFinite && "weights not finite at the end");
      assert(allNormalized && "not normalized at the end");
    }
  }

 public:
  ScopedGsfInfoPrinterAndChecker(const propagator_state_t &state,
                                 const stepper_t &stepper,
                                 const navigator_t &navigator,
                                 const Logger &logger)
      : m_state(state),
        m_stepper(stepper),
        m_navigator(navigator),
        m_p_initial(stepper.absoluteMomentum(state.stepping)),
        m_logger{logger} {
    // Some initial printing
    checks(true);
    ACTS_VERBOSE("Gsf step "
                 << state.steps << " at mean position "
                 << stepper.position(state.stepping).transpose()
                 << " with direction "
                 << stepper.direction(state.stepping).transpose()
                 << " and momentum " << stepper.absoluteMomentum(state.stepping)
                 << " and charge " << stepper.charge(state.stepping));
    ACTS_VERBOSE("Propagation is in " << state.options.direction << " mode");
    print_component_stats();
  }

  ~ScopedGsfInfoPrinterAndChecker() {
    if (m_navigator.currentSurface(m_state.navigation)) {
      const auto p_final = m_stepper.absoluteMomentum(m_state.stepping);
      ACTS_VERBOSE("Component status at end of step:");
      print_component_stats();
      ACTS_VERBOSE("Delta Momentum = " << std::setprecision(5)
                                       << p_final - m_p_initial);
    }
    checks(false);
  }
};

double calculateDeterminant(
    const double *fullCalibratedCovariance,
    TrackStateTraits<kMeasurementSizeMax, true>::Covariance predictedCovariance,
    BoundSubspaceIndices projector, unsigned int calibratedSize);

/// Reweight the components according to `R. Frühwirth, "Track fitting
/// with non-Gaussian noise"`. See also the implementation in Athena at
/// PosteriorWeightsCalculator.cxx
/// @note The weights are not renormalized!
template <typename traj_t>
void computePosteriorWeights(const traj_t &mt,
                             const std::vector<TrackIndexType> &tips,
                             std::map<TrackIndexType, double> &weights) {
  // Helper Function to compute detR

  // Find minChi2, this can be used to factor some things later in the
  // exponentiation
  const auto minChi2 =
      mt.getTrackState(
            *std::ranges::min_element(tips,
                                      [&](const auto &a, const auto &b) {
                                        return mt.getTrackState(a).chi2() <
                                               mt.getTrackState(b).chi2();
                                      }))
          .chi2();

  //! [posterior weights]
  // Loop over the tips and compute new weights
  for (auto tip : tips) {
    const auto state = mt.getTrackState(tip);
    const double chi2 = state.chi2() - minChi2;
    const double detR = calculateDeterminant(
        state.effectiveCalibratedCovariance().data(),
        state.predictedCovariance(), state.projectorSubspaceIndices(),
        state.calibratedSize());

    if (detR <= 0) {
      // If the determinant is not positive, just leave the weight as it is
      continue;
    }

    const double factor = std::sqrt(1. / detR) * safeExp(-0.5 * chi2);

    if (!std::isfinite(factor)) {
      // If something is not finite here, just leave the weight as it is
      continue;
    }

    weights.at(tip) *= factor;
  }
  //! [posterior weights]
}

/// Enumeration type to allow templating on the state we want to project on with
/// a MultiTrajectory
enum class StatesType { ePredicted, eFiltered, eSmoothed };

inline std::ostream &operator<<(std::ostream &os, StatesType type) {
  constexpr static std::array names = {"predicted", "filtered", "smoothed"};
  os << names[static_cast<int>(type)];
  return os;
}

/// @brief Projector type which maps a MultiTrajectory-Index to a tuple of
/// [weight, parameters, covariance]. Therefore, it contains a MultiTrajectory
/// and for now a std::map for the weights
template <StatesType type, typename traj_t>
struct MultiTrajectoryProjector {
  const traj_t &mt;
  const std::map<TrackIndexType, double> &weights;

  auto operator()(TrackIndexType idx) const {
    const auto proxy = mt.getTrackState(idx);
    switch (type) {
      case StatesType::ePredicted:
        return std::tuple(weights.at(idx), proxy.predicted(),
                          proxy.predictedCovariance());
      case StatesType::eFiltered:
        return std::tuple(weights.at(idx), proxy.filtered(),
                          proxy.filteredCovariance());
      case StatesType::eSmoothed:
        return std::tuple(weights.at(idx), proxy.smoothed(),
                          proxy.smoothedCovariance());
      default:
        throw std::invalid_argument(
            "Incorrect StatesType, should be ePredicted"
            ", eFiltered, or eSmoothed.");
    }
  }
};

/// Small Helper class that allows to carry a temporary value until we decide to
/// update the actual value. The temporary value is deliberately only accessible
/// with a mutable reference
template <typename T>
class Updatable {
  T m_tmp{};
  T m_val{};

 public:
  Updatable() : m_tmp(0), m_val(0) {}

  T &tmp() { return m_tmp; }
  void update() { m_val = m_tmp; }

  const T &val() const { return m_val; }
};

/// Remove components with low weights and renormalize from the component
/// cache
/// TODO This function does not expect normalized components, but this
/// could be redundant work...
void removeLowWeightComponents(std::vector<GsfComponent> &cmps,
                               double weightCutoff);

template <typename traj_t>
struct TemporaryStates {
  traj_t traj;
  std::vector<TrackIndexType> tips;
  std::map<TrackIndexType, double> weights;

  void clear() {
    traj.clear();
    tips.clear();
    weights.clear();
  }
};

/// Function that updates the stepper from the MultiTrajectory
template <typename traj_t, typename propagator_state_t, typename stepper_t>
void updateStepper(propagator_state_t &state, const stepper_t &stepper,
                   const TemporaryStates<traj_t> &tmpStates,
                   double weightCutoff) {
  auto cmps = stepper.componentIterable(state.stepping);
  for (auto [idx, cmp] : zip(tmpStates.tips, cmps)) {
    // we set ignored components to missed, so we can remove them after
    // the loop
    if (tmpStates.weights.at(idx) < weightCutoff) {
      cmp.status() = IntersectionStatus::unreachable;
      continue;
    }

    auto proxy = tmpStates.traj.getTrackState(idx);

    // The same update the KF and the single-stepper CKF apply after a filter
    // step, so a component ends up in the same state a single stepper would
    cmp.update(
        stepper, MultiTrajectoryHelpers::freeFiltered(state.geoContext, proxy),
        proxy.filtered(), proxy.filteredCovariance(), proxy.referenceSurface());
    cmp.weight() = tmpStates.weights.at(idx);
  }

  stepper.removeMissedComponents(state.stepping);

  // TODO we have two normalization passes here now, this can probably be
  // optimized
  detail::Gsf::normalizeWeights(
      cmps, [&](auto cmp) -> double & { return cmp.weight(); });
}

/// Function that updates the stepper from the ComponentCache
template <typename propagator_state_t, typename stepper_t>
void updateStepper(propagator_state_t &state, const stepper_t &stepper,
                   const Surface &surface,
                   const std::vector<GsfComponent> &componentCache) {
  // Clear components before adding new ones
  stepper.clearComponents(state.stepping);

  // Finally loop over components
  for (const auto &[weight, pars, cov] : componentCache) {
    // Add the component to the stepper
    BoundTrackParameters bound(surface.getSharedPtr(), pars, cov,
                               stepper.particleHypothesis(state.stepping));

    stepper.addComponent(state.stepping, std::move(bound), weight);
  }
}

double applyBetheHeitler(
    const GeometryContext &geoContext, const Surface &surface,
    Direction direction, const BoundTrackParameters &initialParameters,
    double initialWeight, const BetheHeitlerApprox &betheHeitlerApprox,
    std::vector<BetheHeitlerApprox::Component> &betheHeitlerCache,
    double weightCutoff, std::vector<GsfComponent> &componentCache,
    std::size_t &nInvalidBetheHeitler, double &maxPathXOverX0,
    const Logger &logger);

/// Apply the multiple scattering to the state
template <typename propagator_state_t, typename stepper_t>
Result<void> applyMultipleScattering(propagator_state_t &state,
                                     const stepper_t &stepper,
                                     const Surface &surface,
                                     const MaterialUpdateMode &updateMode,
                                     const Logger &logger) {
  for (auto cmp : stepper.componentIterable(state.stepping)) {
    auto singleState = cmp.singleState(state);
    const auto &singleStepper = cmp.singleStepper(stepper);

    const Result<detail::PointwiseMaterialEffects> materialInteractionRes =
        detail::performMaterialInteraction(
            singleState, singleStepper, surface, updateMode,
            NoiseUpdateMode::addNoise, true, false, logger);
    if (!materialInteractionRes.ok()) {
      ACTS_DEBUG("Error performing material interaction: "
                 << materialInteractionRes.error());
      return materialInteractionRes.error();
    }

    assert(singleStepper.covariance(singleState.stepping)
               .value()
               .array()
               .isFinite()
               .all() &&
           "covariance not finite after multi scattering");
  }

  return Result<void>::success();
}

}  // namespace Acts::detail::Gsf
