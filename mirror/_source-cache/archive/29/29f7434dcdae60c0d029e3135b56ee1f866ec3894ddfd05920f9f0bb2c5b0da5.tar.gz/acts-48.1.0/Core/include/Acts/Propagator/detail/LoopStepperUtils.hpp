// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Surfaces/Surface.hpp"

#include <type_traits>

namespace Acts::detail {

/// A helper struct to store a reference to a single-component state and its
/// associated navigation state and options
template <typename stepping_t, typename navigation_t, typename options_t,
          typename geoctx_t>
struct SinglePropState {
  stepping_t& stepping;
  navigation_t& navigation;
  options_t& options;
  geoctx_t& geoContext;

  SinglePropState(stepping_t& s, navigation_t& n, options_t& o, geoctx_t& g)
      : stepping(s), navigation(n), options(o), geoContext(g) {}
};

/// A template class which contains all const member functions, that should be
/// available both in the mutable ComponentProxy and the ConstComponentProxy.
/// @tparam component_t Must be a const or mutable State::Component.
template <typename component_t, typename loop_stepper_t>
struct LoopComponentProxyBase {
  using SingleStepper = typename loop_stepper_t::SingleStepper;
  using SingleState = typename loop_stepper_t::SingleState;

  static_assert(std::is_same_v<std::remove_const_t<component_t>,
                               typename loop_stepper_t::State::Component>);

  component_t& cmp;

  explicit LoopComponentProxyBase(component_t& c) : cmp(c) {}

  // These are the const accessors, which are shared between the mutable
  // ComponentProxy and the ConstComponentProxy
  const auto& state() const { return cmp.state; }
  auto status() const { return cmp.status; }
  auto weight() const { return cmp.weight; }

  template <typename propagator_state_t>
  auto singleState(const propagator_state_t& state) const {
    using DeducedStepping = decltype(state.stepping.components.front().state);
    static_assert(std::is_same_v<SingleState, DeducedStepping>);

    return SinglePropState<const SingleState, const decltype(state.navigation),
                           const decltype(state.options),
                           const decltype(state.geoContext)>(
        cmp.state, state.navigation, state.options, state.geoContext);
  }

  const SingleStepper& singleStepper(const loop_stepper_t& stepper) const {
    return stepper.singleStepper();
  }
};

/// A proxy struct which allows access to a single component of the
/// multi-component state. It has the semantics of a mutable reference, i.e.
/// it requires a mutable reference of the single-component state it
/// represents
template <typename component_t, typename loop_stepper_t>
struct LoopComponentProxy
    : LoopComponentProxyBase<component_t, loop_stepper_t> {
  using State = typename loop_stepper_t::State;
  using Base = LoopComponentProxyBase<component_t, loop_stepper_t>;

  using SingleState = typename loop_stepper_t::SingleState;
  using SingleStepper = typename loop_stepper_t::SingleStepper;
  using Covariance = typename loop_stepper_t::Covariance;

  // Import the const accessors from ComponentProxyBase
  using Base::cmp;
  using Base::singleState;
  using Base::singleStepper;
  using Base::state;
  using Base::status;
  using Base::weight;

  // The multi-component state of the stepper
  const State& all_state;

  LoopComponentProxy(typename State::Component& c, const State& s)
      : Base(c), all_state(s) {}

  // These are the mutable accessors, the const ones are inherited from the
  // ComponentProxyBase
  auto& state() { return cmp.state; }
  auto& status() { return cmp.status; }
  auto& weight() { return cmp.weight; }

  template <typename propagator_state_t>
  auto singleState(propagator_state_t& state) {
    using DeducedStepping = decltype(state.stepping.components.front().state);
    static_assert(std::is_same_v<SingleState, DeducedStepping>);

    return SinglePropState<SingleState, decltype(state.navigation),
                           decltype(state.options), decltype(state.geoContext)>(
        cmp.state, state.navigation, state.options, state.geoContext);
  }

  /// Update the component to the parameters of a filter step
  ///
  /// It goes through the single stepper, so that the component ends up in the
  /// same state a single-stepper fitter leaves its state in. A single state
  /// caches values that follow from its parameters, and a plain write to
  /// @c pars() leaves those stale.
  ///
  /// @param stepper the multi-stepper this component belongs to
  /// @param freeParams the new free parameters
  /// @param boundParams the same parameters, bound to @p surface
  /// @param covariance the new covariance
  /// @param surface the surface the parameters are bound to
  void update(const loop_stepper_t& stepper, const FreeVector& freeParams,
              const BoundVector& boundParams, const Covariance& covariance,
              const Surface& surface) {
    singleStepper(stepper).update(cmp.state, freeParams, boundParams,
                                  covariance, surface);
  }
};

}  // namespace Acts::detail
