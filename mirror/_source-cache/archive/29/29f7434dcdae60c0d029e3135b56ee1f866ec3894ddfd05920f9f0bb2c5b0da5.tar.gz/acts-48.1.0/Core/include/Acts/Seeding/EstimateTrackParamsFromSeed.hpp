// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Definitions/TrackParametrization.hpp"
#include "Acts/Definitions/Units.hpp"
#include "Acts/Geometry/GeometryContext.hpp"
#include "Acts/Seeding/TrackParamsEstimationError.hpp"
#include "Acts/Surfaces/Surface.hpp"
#include "Acts/Utilities/Result.hpp"

#include <cstddef>
#include <span>

namespace Acts {

/// @defgroup est_track_params Estimate track parameters from seed
///
/// The implemented method is based on the conformal map transformation. It
/// estimates the full free track parameters, i.e. (x, y, z, t, dx, dy, dz, q/p)
/// at the bottom space point. The magnetic field (which can be along any
/// direction) is also necessary for the momentum estimation.
///
/// It resembles the method used in ATLAS for the track parameters estimated
/// from seed, i.e. the function InDet::SiTrackMaker_xk::getAtaPlane here:
/// https://acode-browser.usatlas.bnl.gov/lxr/source/athena/InnerGeometry/InDetRecTools/SiTrackMakerTool_xk/src/SiTrackMaker_xk.cxx
///
/// @{

/// Estimate free track parameters from three space points.
///
/// Optionally estimates the tangents at the three space points from helix fit.
/// This can be used as an input for the strip space point calibration, which
/// requires the track tangents at each space point as input.
///
/// @param sp0 is the bottom space point
/// @param t0 is the time of the bottom space point
/// @param sp1 is the middle space point
/// @param sp2 is the top space point
/// @param bField is the magnetic field vector
/// @param tangent0 is the output tangent at the bottom space point
/// @param tangent1 is the output tangent at the middle space point
/// @param tangent2 is the output tangent at the top space point
///
/// @return the free parameters
FreeVector estimateTrackParamsFromSeed(const Vector3& sp0, double t0,
                                       const Vector3& sp1, const Vector3& sp2,
                                       const Vector3& bField,
                                       Vector3* tangent0 = nullptr,
                                       Vector3* tangent1 = nullptr,
                                       Vector3* tangent2 = nullptr);

/// Estimate bound track parameters from three space points
///
/// @param gctx is the geometry context
/// @param surface is the surface of the bottom space point. The estimated bound
///                track parameters will be represented at this surface.
/// @param sp0 is the bottom space point
/// @param t0 is the time of the bottom space point
/// @param sp1 is the middle space point
/// @param sp2 is the top space point
/// @param bField is the magnetic field vector
///
/// @return bound parameters
Result<BoundVector> estimateTrackParamsFromSeed(
    const GeometryContext& gctx, const Surface& surface, const Vector3& sp0,
    double t0, const Vector3& sp1, const Vector3& sp2, const Vector3& bField);

/// Configuration for the estimation of the covariance matrix of the track
/// parameters with `estimateTrackParamCovariance`.
struct EstimateTrackParamCovarianceConfig {
  /// The initial sigmas for the track parameters
  BoundVector initialSigmas = {1. * UnitConstants::mm,
                               1. * UnitConstants::mm,
                               1. * UnitConstants::degree,
                               1. * UnitConstants::degree,
                               1. * UnitConstants::e / UnitConstants::GeV,
                               1. * UnitConstants::ns};

  /// The initial sigma for the q/pt
  /// @note The resulting q/p sigma is added to the one in `initialSigmas`
  double initialSigmaQoverPt = 0. * UnitConstants::e / UnitConstants::GeV;

  /// The initial relative uncertainty sigma(pt)/pt
  /// @note The resulting q/p sigma is added to the one in `initialSigmas`
  double initialSigmaPtRel = 0.1;

  /// The inflation factors for the variances of the track parameters
  BoundVector initialVarInflation = {1., 1., 1., 1., 1., 1.};
  /// The inflation factor for time uncertainty if the time parameter was not
  /// estimated
  double noTimeVarInflation = 100.;
};

/// Estimate the covariance matrix of the given track parameters based on the
/// provided configuration. The assumption is that we can model the uncertainty
/// of the track parameters as a diagonal matrix with the provided initial
/// sigmas. The inflation factors are used to inflate the initial variances
/// based on the provided configuration. The uncertainty of q/p is estimated
/// based on the relative uncertainty of the q/pt and the theta uncertainty.
///
/// @param config is the configuration for the estimation
/// @param params is the track parameters
/// @param hasTime is true if the track parameters have time
///
/// @return the covariance matrix of the track parameters
BoundMatrix estimateTrackParamCovariance(
    const EstimateTrackParamCovarianceConfig& config, const BoundVector& params,
    bool hasTime);

/// Estimate free track parameters from an ordered set of N >= 3 space points.
///
/// Least-squares generalization of @ref estimateTrackParamsFromSeed. A Taubin
/// circle fit transverse to the field, optionally refined geometrically, and a
/// linear fit of the field coordinate against the transverse arc length. Points
/// are taken in track order and are not sorted.
///
/// The parameters are expressed at `spacePoints[referenceIndex]`, by default
/// the first one. The fit itself does not depend on that choice: every point
/// contributes to the same helix, and the reference only selects where it is
/// evaluated. Reporting at a point deeper in the detector lets a downstream
/// track finder start where the hit density, and with it the combinatorics, is
/// lower, at the cost of a longer extrapolation back to the beam line.
///
/// A vanishing curvature degenerates to a line and only the direction is
/// estimated. Without a field q/p stays zero.
///
/// Weights are relative (e.g. inverse-variance) factors on every fit stage. An
/// empty span means uniform, a non-empty one must match `spacePoints` in size.
///
/// @param spacePoints the ordered global space point positions
/// @param bField the homogeneous magnetic field vector
/// @param t0 the time assigned to the reference point (eFreeTime)
/// @param geometricRefineIterations number of Gauss-Newton refinement
///        iterations on top of the algebraic circle fit (0 disables it)
/// @param weights optional per-point weights for all fit stages
///        (empty span = uniform)
/// @param referenceIndex index of the space point the parameters are expressed
///        at; must be a valid index into `spacePoints`
/// @return the free parameters at the reference point, or an error
Result<FreeVector> estimateTrackParamsFromSpacePoints(
    std::span<const Vector3> spacePoints, const Vector3& bField, double t0 = 0,
    std::size_t geometricRefineIterations = 0,
    std::span<const double> weights = {}, std::size_t referenceIndex = 0);

/// @}

}  // namespace Acts
