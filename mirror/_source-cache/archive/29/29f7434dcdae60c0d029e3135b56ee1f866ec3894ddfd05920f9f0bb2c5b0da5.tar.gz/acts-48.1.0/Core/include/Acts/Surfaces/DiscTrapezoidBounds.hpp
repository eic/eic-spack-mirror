// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Surfaces/DiscBounds.hpp"
#include "Acts/Surfaces/SurfaceBounds.hpp"
#include "Acts/Utilities/MathHelpers.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <iosfwd>
#include <numbers>
#include <vector>

namespace Acts {

/// @class DiscTrapezoidBounds
///
/// Class to describe the bounds for a planar DiscSurface.
/// By providing an argument for hphisec, the bounds can
/// be restricted to a phi-range around the center position.
///
class DiscTrapezoidBounds : public DiscBounds {
 public:
  /// @enum BoundValues
  /// Enumeration for the bound values
  enum BoundValues : int {
    eHalfLengthXminR = 0,
    eHalfLengthXmaxR = 1,
    eMinR = 2,
    eMaxR = 3,
    eAveragePhi = 4,
    eStereo = 5,
    eSize = 6
  };

  /// Constructor for a symmetric Trapezoid giving min X length, max X length,
  /// Rmin and R max
  /// @param halfXminR half length in X at min radius
  /// @param halfXmaxR half length in X at maximum radius
  /// @param minR inner radius
  /// @param maxR outer radius
  /// @param avgPhi average phi value
  /// @param stereo optional stereo angle applied
  explicit DiscTrapezoidBounds(double halfXminR, double halfXmaxR, double minR,
                               double maxR,
                               double avgPhi = std::numbers::pi / 2.,
                               double stereo = 0.) noexcept(false);

  /// Constructor - from fixed size array
  ///
  /// @param values The parameter values
  explicit DiscTrapezoidBounds(
      const std::array<double, eSize>& values) noexcept(false)
      : m_values(values) {
    checkConsistency();
  }

  /// @copydoc SurfaceBounds::type
  BoundsType type() const final { return eDiscTrapezoid; }

  /// @copydoc SurfaceBounds::isCartesian
  bool isCartesian() const final { return false; }

  /// @copydoc SurfaceBounds::boundToCartesianJacobian
  SquareMatrix2 boundToCartesianJacobian(const Vector2& lposition) const final;

  /// @copydoc SurfaceBounds::boundToCartesianMetric
  SquareMatrix2 boundToCartesianMetric(const Vector2& lposition) const final;

  /// Return the bound values as dynamically sized vector
  /// @return this returns a copy of the internal values
  std::vector<double> values() const final;

  /// @copydoc SurfaceBounds::inside
  bool inside(const Vector2& lposition) const final;

  /// @copydoc SurfaceBounds::closestPoint
  Vector2 closestPoint(const Vector2& lposition,
                       const SquareMatrix2& metric) const final;

  using SurfaceBounds::inside;

  /// @copydoc SurfaceBounds::center
  Vector2 center() const final;

  /// Output Method for std::ostream
  /// @param sl The output stream to write to
  /// @return Reference to the output stream after writing
  std::ostream& toStream(std::ostream& sl) const final;

  /// Access to the bound values
  /// @param bValue the class nested enum for the array access
  /// @return The value of the specified bound parameter
  double get(BoundValues bValue) const { return m_values[bValue]; }

  /// This method returns inner radius
  /// @return Minimum radius of the disc trapezoid
  double rMin() const final { return get(eMinR); }

  /// This method returns outer radius
  /// @return Maximum radius of the disc trapezoid
  double rMax() const final { return get(eMaxR); }

  /// This method returns the center radius
  /// @return Center radius calculated from inner and outer bounds
  double rCenter() const {
    const double rmin = get(eMinR);
    const double rmax = get(eMaxR);
    const double hxmin = get(eHalfLengthXminR);
    const double hxmax = get(eHalfLengthXmaxR);
    const double hmin = fastCathetus(rmin, hxmin);
    const double hmax = fastCathetus(rmax, hxmax);
    return 0.5 * (hmin + hmax);
  }

  /// This method returns the stereo angle
  /// @return Stereo angle of the disc trapezoid
  double stereo() const { return get(eStereo); }

  /// This method returns the halfPhiSector which is covered by the disc
  /// @return Half phi sector angle covered by the disc trapezoid
  double halfPhiSector() const {
    const double minHalfPhi = std::asin(get(eHalfLengthXminR) / get(eMinR));
    const double maxHalfPhi = std::asin(get(eHalfLengthXmaxR) / get(eMaxR));
    return std::max(minHalfPhi, maxHalfPhi);
  }

  /// This method returns the half length in Y (this is Rmax -Rmin)
  /// @return Half length in Y direction calculated from radial bounds
  double halfLengthY() const {
    const double rmin = get(eMinR);
    const double rmax = get(eMaxR);
    const double hxmin = get(eHalfLengthXminR);
    const double hxmax = get(eHalfLengthXmaxR);
    const double hmin = fastCathetus(rmin, hxmin);
    const double hmax = fastCathetus(rmax, hxmax);
    return 0.5 * (hmax - hmin);
  }

  /// Returns true for full phi coverage - obviously false here
  /// @return Always false since disc trapezoids have limited phi coverage
  bool coversFullAzimuth() const final { return false; }

  /// Checks if this is inside the radial coverage
  /// given the a tolerance
  /// @param R The radius value to check
  /// @param tolerance The tolerance for the check
  /// @return True if radius is within bounds (plus tolerance), false otherwise
  bool insideRadialBounds(double R, double tolerance = 0.) const final {
    return (R + tolerance > get(eMinR) && R - tolerance < get(eMaxR));
  }

  /// Return a reference radius for binning
  /// @return Average radius for binning purposes
  double binningValueR() const final { return 0.5 * (get(eMinR) + get(eMaxR)); }

  /// Return a reference phi for binning
  /// @return Average phi angle for binning purposes
  double binningValuePhi() const final { return get(eAveragePhi); }

  /// This method returns the xy coordinates of the four corners of the
  /// bounds in module coorindates (in xy)
  ///
  /// @param ignoredSegments is an ignored parameter only used for
  /// curved bound segments
  ///
  /// @return vector for vertices in 2D
  std::vector<Vector2> vertices(unsigned int ignoredSegments = 0u) const final;

 private:
  std::array<double, eSize> m_values;

  /// Dreived maximum y value
  double m_ymax = 0;

  /// Check the input values for consistency, will throw a logic_exception
  /// if consistency is not given
  void checkConsistency() noexcept(false);

  /// Private helper method to convert a local position
  /// into its Cartesian representation
  ///
  /// @param lposition The local position in polar coordinates
  Vector2 toLocalCartesian(const Vector2& lposition) const;
};

}  // namespace Acts
