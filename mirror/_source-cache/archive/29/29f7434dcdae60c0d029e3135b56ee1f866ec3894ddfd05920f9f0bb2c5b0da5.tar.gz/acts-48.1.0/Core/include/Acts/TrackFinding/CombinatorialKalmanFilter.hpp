// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Common.hpp"
#include "Acts/EventData/MultiTrajectory.hpp"
#include "Acts/EventData/MultiTrajectoryHelpers.hpp"
#include "Acts/EventData/TrackStatePropMask.hpp"
#include "Acts/EventData/TransformationHelpers.hpp"
#include "Acts/EventData/Types.hpp"
#include "Acts/Geometry/GeometryContext.hpp"
#include "Acts/MagneticField/MagneticFieldContext.hpp"
#include "Acts/Propagator/ActorList.hpp"
#include "Acts/Propagator/ConstrainedStep.hpp"
#include "Acts/Propagator/PropagatorState.hpp"
#include "Acts/Propagator/StandardAborters.hpp"
#include "Acts/Propagator/StepperConcept.hpp"
#include "Acts/Propagator/detail/LoopProtection.hpp"
#include "Acts/Propagator/detail/PointwiseMaterialInteraction.hpp"
#include "Acts/TrackFinding/CombinatorialKalmanFilterError.hpp"
#include "Acts/TrackFinding/CombinatorialKalmanFilterExtensions.hpp"
#include "Acts/TrackFitting/BetheHeitlerApprox.hpp"
#include "Acts/TrackFitting/GsfOptions.hpp"
#include "Acts/TrackFitting/detail/GsfComponentMerging.hpp"
#include "Acts/TrackFitting/detail/GsfUtils.hpp"
#include "Acts/Utilities/CalibrationContext.hpp"
#include "Acts/Utilities/Logger.hpp"
#include "Acts/Utilities/Result.hpp"

#include <functional>
#include <limits>
#include <memory>
#include <stdexcept>
#include <type_traits>

namespace Acts {

/// @addtogroup track_finding
/// @{

/// Combined options for the combinatorial Kalman filter.
///
/// @tparam source_link_iterator_t Type of the source link iterator
/// @tparam track_container_t Type of the track container
template <typename track_container_t>
struct CombinatorialKalmanFilterOptions {
  /// Type alias for track state container backend
  using TrackStateContainerBackend =
      typename track_container_t::TrackStateContainerBackend;
  /// Type alias for track state proxy from the container
  using TrackStateProxy = typename track_container_t::TrackStateProxy;

  /// PropagatorOptions with context
  ///
  /// @param gctx The geometry context for this track finding/fitting
  /// @param mctx The magnetic context for this track finding/fitting
  /// @param cctx The calibration context for this track finding/fitting
  /// @param extensions_ The extension struct
  /// @param pOptions The plain propagator options
  /// @param mScattering Whether to include multiple scattering
  /// @param eLoss Whether to include energy loss
  CombinatorialKalmanFilterOptions(
      const GeometryContext& gctx, const MagneticFieldContext& mctx,
      std::reference_wrapper<const CalibrationContext> cctx,
      CombinatorialKalmanFilterExtensions<track_container_t> extensions_,
      const PropagatorPlainOptions& pOptions, bool mScattering = true,
      bool eLoss = true)
      : geoContext(gctx),
        magFieldContext(mctx),
        calibrationContext(cctx),
        extensions(extensions_),
        propagatorPlainOptions(pOptions),
        multipleScattering(mScattering),
        energyLoss(eLoss) {}

  /// Contexts are required and the options must not be default-constructible.
  CombinatorialKalmanFilterOptions() = delete;

  /// Context object for the geometry
  std::reference_wrapper<const GeometryContext> geoContext;
  /// Context object for the magnetic field
  std::reference_wrapper<const MagneticFieldContext> magFieldContext;
  /// context object for the calibration
  std::reference_wrapper<const CalibrationContext> calibrationContext;

  /// The filter extensions
  CombinatorialKalmanFilterExtensions<track_container_t> extensions;

  /// The trivial propagator options
  PropagatorPlainOptions propagatorPlainOptions;

  /// The target surface
  /// @note This is useful if the filtering should be terminated at a
  ///       certain surface
  const Surface* targetSurface = nullptr;

  /// Whether to consider multiple scattering.
  bool multipleScattering = true;

  /// Whether to consider energy loss.
  bool energyLoss = true;

  /// Skip the pre propagation call. This effectively skips the first surface
  /// @note This is useful if the first surface should not be considered in a second reverse pass
  bool skipPrePropagationUpdate = false;

  /// Whether to record track states on material-only (non-sensitive) surfaces.
  /// Material effects are applied either way, only the record is dropped.
  /// @note Keep enabled if the surfaces themselves are needed, e.g. for a refit
  ///       with the `DirectNavigator`.
  bool recordMaterialStates = true;
};

/// Options for the combinatorial Kalman filter with bremsstrahlung recovery.
///
/// These extend the plain options with the parameters that are only meaningful
/// when the filter runs with a multi-component (GSF-like) stepper. Keeping them
/// in a dedicated type means the single-component configuration cannot even
/// name them.
///
/// @tparam track_container_t Type of the track container
template <typename track_container_t>
struct BremCombinatorialKalmanFilterOptions
    : public CombinatorialKalmanFilterOptions<track_container_t> {
  /// Reuse the base-class constructors.
  using CombinatorialKalmanFilterOptions<
      track_container_t>::CombinatorialKalmanFilterOptions;

  /// Maximum number of components which the GSF should handle
  std::size_t maxComponents = 12;

  /// When to discard components
  double weightCutoff = 1e-4;

  /// How to reduce the states that are stored in the multi trajectory
  ComponentMergeMethod mergeMethod = ComponentMergeMethod::eMaxWeight;

  /// The Bethe-Heitler approximation for bremsstrahlung energy loss
  std::shared_ptr<const BetheHeitlerApprox> betheHeitlerApprox;
};

/// Result container for the combinatorial Kalman filter actor.
///
/// @tparam track_container_t Type of the track container storing results
template <typename track_container_t>
struct CombinatorialKalmanFilterResult {
  /// Track state container backend type
  using TrackStateContainerBackend =
      typename track_container_t::TrackStateContainerBackend;
  /// Track proxy type
  using TrackProxy = typename track_container_t::TrackProxy;
  /// Track state proxy type
  using TrackStateProxy = typename track_container_t::TrackStateProxy;

  /// The track container to store the found tracks
  track_container_t* tracks{nullptr};

  /// Fitted states that the actor has handled.
  TrackStateContainerBackend* trackStates{nullptr};

  /// Indices into `tracks` which mark active branches
  std::vector<TrackProxy> activeBranches;

  /// Indices into `tracks` which mark active branches
  std::vector<TrackProxy> collectedTracks;

  /// Track state candidates buffer which can be used by the track state creator
  std::vector<TrackStateProxy> trackStateCandidates;

  /// Transport jacobians of skipped material surfaces, folded into the next
  /// recorded track state to keep the jacobian chain intact
  BoundMatrix accumulatedJacobian = BoundMatrix::Identity();

  /// Indicator if track finding has been done
  bool finished = false;

  /// Path limit aborter
  PathLimitReached pathLimitReached;
};

/// Combinatorial Kalman filter to find tracks.
///
/// @tparam propagator_t Type of the propagator
///
/// The CombinatorialKalmanFilter contains an Actor and a Sequencer sub-class.
/// The Sequencer has to be part of the Navigator of the Propagator in order to
/// initialize and provide the measurement surfaces.
///
/// The Actor is part of the Propagation call and does the Kalman update.
/// Updater and Calibrator are given to the Actor for further use:
/// - The Updater is the implemented kalman updater formalism, it
///   runs via a visitor pattern through the measurements.
///
/// Measurements are not required to be ordered for the
/// CombinatorialKalmanFilter, measurement ordering needs to be figured out by
/// the navigation of the propagator.
///
/// The void components are provided mainly for unit testing.
///
template <typename propagator_t, typename track_container_t>
class CombinatorialKalmanFilter {
 public:
  /// Constructor with propagator and logging level
  /// @param pPropagator The propagator used for the track finding
  /// @param _logger The logger for messages
  explicit CombinatorialKalmanFilter(propagator_t pPropagator,
                                     std::unique_ptr<const Logger> _logger =
                                         getDefaultLogger("CKF", Logging::INFO))
      : m_propagator(std::move(pPropagator)),
        m_logger(std::move(_logger)),
        m_actorLogger{m_logger->cloneWithSuffix("Actor")},
        m_updaterLogger{m_logger->cloneWithSuffix("Updater")} {}

 private:
  using BoundState = std::tuple<BoundTrackParameters, BoundMatrix, double>;
  using TrackStateContainerBackend =
      typename track_container_t::TrackStateContainerBackend;
  using TrackProxy = typename track_container_t::TrackProxy;
  using TrackStateProxy = typename track_container_t::TrackStateProxy;

  static constexpr bool IsMultiStepper =
      Concepts::MultiStepper<typename propagator_t::Stepper>;
  using TemporaryStates = detail::Gsf::TemporaryStates<VectorMultiTrajectory>;

  /// Single component bound state tuple containing parameters, Jacobian, and
  /// path length
  using SingleBoundState =
      std::tuple<BoundTrackParameters, BoundMatrix, double>;

  /// The propagator for the transport and material update
  propagator_t m_propagator;

  std::unique_ptr<const Logger> m_logger;
  std::shared_ptr<const Logger> m_actorLogger;
  std::shared_ptr<const Logger> m_updaterLogger;

  const Logger& logger() const { return *m_logger; }

  /// @brief Propagator Actor plugin for the CombinatorialKalmanFilter
  ///
  /// The CombinatorialKalmanFilter Actor does not rely on the measurements to
  /// be sorted along the track.
  class Actor {
   public:
    using BoundState = std::tuple<BoundTrackParameters, BoundMatrix, double>;
    /// Broadcast the result_type
    using result_type = CombinatorialKalmanFilterResult<track_container_t>;

    using BranchStopperResult = CombinatorialKalmanFilterBranchStopperResult;

    /// The target surface aborter
    SurfaceReached targetReached{std::numeric_limits<double>::lowest()};

    /// Whether to consider multiple scattering.
    bool multipleScattering = true;

    /// Whether to consider energy loss.
    bool energyLoss = true;

    /// Skip the pre propagation call. This effectively skips the first surface
    bool skipPrePropagationUpdate = false;

    /// @see CombinatorialKalmanFilterOptions::recordMaterialStates
    bool recordMaterialStates = true;

    /// Calibration context for the finding run
    const CalibrationContext* calibrationContextPtr{nullptr};

    CombinatorialKalmanFilterExtensions<track_container_t> extensions;

    /// End of world aborter
    EndOfWorldReached endOfWorldReached;

    /// Volume constraint aborter
    VolumeConstraintAborter volumeConstraintAborter;

    /// State that is only meaningful when the filter runs with a
    /// multi-component stepper (bremsstrahlung recovery).
    struct BremState {
      /// Maximum number of components which the GSF should handle
      std::size_t maxComponents = 12;
      /// When to discard components
      double weightCutoff = 1e-4;
      /// How to reduce the states that are stored in the multi trajectory
      ComponentMergeMethod mergeMethod = ComponentMergeMethod::eMaxWeight;
      /// The Bethe-Heitler approximation for bremsstrahlung energy loss
      const BetheHeitlerApprox* betheHeitlerApprox{nullptr};

      /// Scratch buffers reused across surfaces during the multi-component
      /// update. Owned by `findTracks` and wired in before propagation.
      TemporaryStates* temporaryStates{nullptr};
      /// Bethe-Heitler approximation components cache
      std::vector<BetheHeitlerApprox::Component>* betheHeitlerCache{nullptr};
      /// GsfComponent cache for the multi-component update
      std::vector<GsfComponent>* componentCache{nullptr};
    };
    /// Empty stand-in for the single-component stepper.
    struct NoBremState {};

    /// Bremsstrahlung-only state, gated on the stepper type so it adds no
    /// storage in the single-component case.
    [[no_unique_address]] std::conditional_t<IsMultiStepper, BremState,
                                             NoBremState> brem;

    /// Actor logger instance
    const Logger* actorLogger{nullptr};
    /// Updater logger instance
    const Logger* updaterLogger{nullptr};

    const Logger& logger() const { return *actorLogger; }

    /// @brief CombinatorialKalmanFilter actor operation
    ///
    /// @tparam propagator_state_t Type of the Propagator state
    /// @tparam stepper_t Type of the stepper
    ///
    /// @param state is the mutable propagator state object
    /// @param stepper is the stepper in use
    /// @param navigator is the navigator in use
    /// @param result is the mutable result state object
    template <typename propagator_state_t, typename stepper_t,
              typename navigator_t>
    Result<void> act(propagator_state_t& state, const stepper_t& stepper,
                     const navigator_t& navigator, result_type& result,
                     const Logger& /*logger*/) const {
      ACTS_VERBOSE("CKF Actor called");

      assert(result.trackStates && "No MultiTrajectory set");

      if (state.stage == PropagatorStage::prePropagation &&
          skipPrePropagationUpdate) {
        ACTS_VERBOSE("Skip pre-propagation update (first surface)");
        return Result<void>::success();
      }
      if (state.stage == PropagatorStage::postPropagation) {
        ACTS_VERBOSE("Skip post-propagation action");
        return Result<void>::success();
      }

      ACTS_VERBOSE("CombinatorialKalmanFilter step");

      assert(!result.activeBranches.empty() && "No active branches");
      assert(!result.finished && "Should never reach this when finished");

      // Initialize path limit reached aborter
      if (result.pathLimitReached.internalLimit ==
          std::numeric_limits<double>::max()) {
        detail::setupLoopProtection(state, stepper, result.pathLimitReached,
                                    true, logger());
      }

      // Update:
      // - Waiting for a current surface
      if (const Surface* surface = navigator.currentSurface(state.navigation);
          surface != nullptr) {
        // There are three scenarios:
        // 1) The surface is in the measurement map
        // -> Select source links
        // -> Perform the kalman update for selected non-outlier source links
        // -> Add track states in multitrajectory. Multiple states mean branch
        // splitting.
        // -> Call branch stopper to justify each branch
        // -> If there is non-outlier state, update stepper information
        // 2) The surface is not in the measurement map but with material or is
        // an active surface
        // -> Add a hole or passive material state in multitrajectory
        // -> Call branch stopper to justify the branch
        // 3) The surface is neither in the measurement map nor with material
        // -> Do nothing
        ACTS_VERBOSE("Perform filter step");
        auto res = filter(*surface, state, stepper, navigator, result);
        if (!res.ok()) {
          ACTS_DEBUG("Error in filter: " << res.error().message());
          return res.error();
        }

        if (result.finished) {
          ACTS_VERBOSE("CKF Actor returns after filter step");
          return Result<void>::success();
        }
      }

      assert(!result.activeBranches.empty() && "No active branches");

      const bool isEndOfWorldReached =
          endOfWorldReached.checkAbort(state, stepper, navigator, logger());
      const bool isVolumeConstraintReached = volumeConstraintAborter.checkAbort(
          state, stepper, navigator, logger());
      const bool isPathLimitReached = result.pathLimitReached.checkAbort(
          state, stepper, navigator, logger());
      const bool isTargetReached =
          targetReached.checkAbort(state, stepper, navigator, logger());
      if (isEndOfWorldReached || isVolumeConstraintReached ||
          isPathLimitReached || isTargetReached) {
        if (isEndOfWorldReached) {
          ACTS_VERBOSE("End of world reached");
        } else if (isVolumeConstraintReached) {
          ACTS_VERBOSE("Volume constraint reached");
        } else if (isPathLimitReached) {
          ACTS_VERBOSE("Path limit reached");
        } else if (isTargetReached) {
          ACTS_VERBOSE("Target surface reached");

          // Bind the parameter to the target surface
          auto transportRes =
              stepper.transportToBound(state.stepping, *targetReached.surface);
          if (!transportRes.ok()) {
            ACTS_DEBUG("Error while transporting to the target surface: "
                       << transportRes.error() << " "
                       << transportRes.error().message());
            return transportRes.error();
          }
          auto res =
              stepper.boundParameters(state.stepping, *targetReached.surface);
          if (!res.ok()) {
            ACTS_DEBUG("Error while binding to the target surface: "
                       << res.error() << " " << res.error().message());
            return res.error();
          }

          const auto& boundParams = *res;
          auto currentBranch = result.activeBranches.back();
          // Assign the fitted parameters
          if constexpr (!IsMultiStepper) {
            currentBranch.parameters() = boundParams.parameters();
            currentBranch.covariance() = *boundParams.covariance();
          } else {
            const auto singleParams = boundParams.merge(brem.mergeMethod);
            currentBranch.parameters() = singleParams.parameters();
            currentBranch.covariance() = *singleParams.covariance();
          }
          currentBranch.setReferenceSurface(
              boundParams.referenceSurface().getSharedPtr());

          stepper.releaseStepSize(state.stepping,
                                  ConstrainedStep::Type::Navigator);
        }

        // Record the active branch and remove it from the list
        storeLastActiveBranch(result);
        result.activeBranches.pop_back();

        // Reset propagation state to track state at next active branch
        auto resetRes = reset(state, stepper, navigator, result);
        if (!resetRes.ok()) {
          return resetRes.error();
        }
      }

      return Result<void>::success();
    }

    template <typename propagator_state_t, typename stepper_t,
              typename navigator_t>
    bool checkAbort(propagator_state_t& /*state*/, const stepper_t& /*stepper*/,
                    const navigator_t& /*navigator*/, const result_type& result,
                    const Logger& /*logger*/) const {
      return result.finished;
    }

    /// @brief CombinatorialKalmanFilter actor operation: reset propagation
    ///
    /// @tparam propagator_state_t Type of Propagator state
    /// @tparam stepper_t Type of the stepper
    /// @tparam navigator_t Type of the navigator
    ///
    /// @param state is the mutable propagator state object
    /// @param stepper is the stepper in use
    /// @param navigator is the navigator in use
    /// @param result is the mutable result state object
    template <typename propagator_state_t, typename stepper_t,
              typename navigator_t>
    Result<void> reset(propagator_state_t& state, const stepper_t& stepper,
                       const navigator_t& navigator,
                       result_type& result) const {
      if (result.activeBranches.empty()) {
        ACTS_VERBOSE("Stop CKF with " << result.collectedTracks.size()
                                      << " found tracks");
        result.finished = true;

        return Result<void>::success();
      }

      auto currentBranch = result.activeBranches.back();
      auto currentState = currentBranch.outermostTrackState();

      ACTS_VERBOSE("Propagation jumps to branch with tip = "
                   << currentBranch.tipIndex());

      // Reset the stepping state
      if constexpr (!IsMultiStepper) {
        stepper.initialize(state.stepping, currentState.filtered(),
                           currentState.filteredCovariance(),
                           stepper.particleHypothesis(state.stepping),
                           currentState.referenceSurface());
      } else {
        const MultiComponentBoundTrackParameters multiBoundParameters(
            currentState.referenceSurface().getSharedPtr(),
            currentState.filtered(), currentState.filteredCovariance(),
            stepper.particleHypothesis(state.stepping));

        stepper.initialize(state.stepping, multiBoundParameters);
      }

      // `initialize` re-roots the jacobian chain at this branch
      result.accumulatedJacobian = BoundMatrix::Identity();

      // Reset the navigation state
      // Set targetSurface to nullptr for forward filtering
      auto navInitRes = navigator.initialize(
          state.navigation, {.position = stepper.position(state.stepping),
                             .direction = stepper.direction(state.stepping),
                             .propagationDirection = state.options.direction,
                             .startSurface = &currentState.referenceSurface(),
                             .targetSurface = nullptr});
      if (!navInitRes.ok()) {
        ACTS_DEBUG("Navigation initialization failed: " << navInitRes.error());
        return navInitRes.error();
      }

      // No Kalman filtering for the starting surface, but still need
      // to consider the material effects here
      const Result<void> materialRes = performMaterialInteraction(
          state, stepper, currentState.referenceSurface(),
          detail::determineMaterialUpdateMode(state, navigator,
                                              MaterialUpdateMode::PostUpdate));
      if (!materialRes.ok()) {
        ACTS_DEBUG("Material interaction failed during reset: "
                   << materialRes.error().message());
        return materialRes.error();
      }

      // Set path limit based on loop protection
      detail::setupLoopProtection(state, stepper, result.pathLimitReached, true,
                                  logger());

      // Set path limit based on target surface
      targetReached.checkAbort(state, stepper, navigator, logger());

      return Result<void>::success();
    }

    /// @brief CombinatorialKalmanFilter actor operation:
    /// - filtering for all measurement(s) on surface
    /// - store selected track states in multiTrajectory
    /// - update propagator state to the (last) selected track state
    ///
    /// @tparam propagator_state_t Type of the Propagator state
    /// @tparam stepper_t Type of the stepper
    /// @tparam navigator_t Type of the navigator
    ///
    /// @param surface The surface where the update happens
    /// @param state The mutable propagator state object
    /// @param stepper The stepper in use
    /// @param navigator The navigator in use
    /// @param result The mutable result state object
    template <typename propagator_state_t, typename stepper_t,
              typename navigator_t>
    Result<void> filter(const Surface& surface, propagator_state_t& state,
                        const stepper_t& stepper, const navigator_t& navigator,
                        result_type& result) const {
      using PM = TrackStatePropMask;

      const bool isSensitive = surface.isSensitive();
      const bool hasMaterial = surface.hasMaterial();
      const bool isMaterialOnly = hasMaterial && !isSensitive;
      bool expectMeasurements = isSensitive;

      if (isSensitive) {
        ACTS_VERBOSE("Measurement surface " << surface.geometryId()
                                            << " detected.");
      } else if (isMaterialOnly) {
        ACTS_VERBOSE("Material surface " << surface.geometryId()
                                         << " detected.");
      } else {
        ACTS_VERBOSE("Passive surface " << surface.geometryId()
                                        << " detected.");
        return Result<void>::success();
      }

      // Transport the covariance to the surface
      BoundMatrix jacobian;
      if (isMaterialOnly) {
        jacobian = stepper.transportToCurvilinear(state.stepping);
      } else {
        auto transportRes = stepper.transportToBound(state.stepping, surface);
        if (!transportRes.ok()) {
          return transportRes.error();
        }
        jacobian = *transportRes;
      }

      // Update state and stepper with pre material effects
      const Result<void> materialPreRes = performMaterialInteraction(
          state, stepper, surface,
          detail::determineMaterialUpdateMode(state, navigator,
                                              MaterialUpdateMode::PreUpdate));
      if (!materialPreRes.ok()) {
        ACTS_DEBUG("Material interaction failed during reset: "
                   << materialPreRes.error().message());
        return materialPreRes.error();
      }

      if (isMaterialOnly && !recordMaterialStates) {
        ACTS_VERBOSE("Skip material track state on surface "
                     << surface.geometryId());

        if constexpr (IsMultiStepper) {
          // the post material effects read the components on the surface
          auto transportRes = stepper.transportToBound(state.stepping, surface);
          if (!transportRes.ok()) {
            return transportRes.error();
          }
          jacobian = *transportRes * jacobian;
        }

        // keep the jacobian segment the transport above just closed
        result.accumulatedJacobian = jacobian * result.accumulatedJacobian;

        // apply the post material effects and return early, skipping the
        // track state creation below
        const Result<void> materialPostRes = performMaterialInteraction(
            state, stepper, surface,
            detail::determineMaterialUpdateMode(
                state, navigator, MaterialUpdateMode::PostUpdate));
        if (!materialPostRes.ok()) {
          ACTS_DEBUG("Material interaction failed during post-update: "
                     << materialPostRes.error().message());
        }
        return materialPostRes;
      }

      // Bind the transported state to the current surface
      auto boundStateRes = [&]() -> Result<SingleBoundState> {
        if constexpr (!IsMultiStepper) {
          auto res = stepper.boundParameters(state.stepping, surface);
          if (!res.ok()) {
            return res.error();
          }
          return Result<SingleBoundState>::success(
              {std::move(*res), jacobian, stepper.pathLength(state.stepping)});
        } else {
          // This triggers a second covariance transport which is wasteful in
          // terms of compute. But the multi stepper might filter bound
          // components and we cannot easily match stepper components to bound
          // parameter components right now to make use of the same track as
          // above.
          // TODO this should be revisited
          auto transportRes = stepper.transportToBound(state.stepping, surface);
          if (!transportRes.ok()) {
            return transportRes.error();
          }
          jacobian = *transportRes * jacobian;
          auto res = stepper.boundParameters(state.stepping, surface);
          if (!res.ok()) {
            return res.error();
          }
          const auto singleParams = res->merge(brem.mergeMethod);
          return Result<SingleBoundState>::success(
              {singleParams, jacobian, stepper.pathLength(state.stepping)});
        }
      }();
      if (!boundStateRes.ok()) {
        return boundStateRes.error();
      }
      auto& boundState = *boundStateRes;

      if (!recordMaterialStates) {
        // prepend the jacobians of the surfaces skipped since the last state
        std::get<1>(boundState) =
            std::get<1>(boundState) * result.accumulatedJacobian;
        result.accumulatedJacobian = BoundMatrix::Identity();
      }

      auto currentBranch = result.activeBranches.back();
      TrackIndexType prevTip = currentBranch.tipIndex();

      using TrackStatesResult = Result<CkfTypes::BranchVector<TrackIndexType>>;
      TrackStatesResult tsRes = TrackStatesResult::success({});
      if (isSensitive) {
        // extend trajectory with measurements associated to the current surface
        // which may create extra trajectory branches if more than one
        // measurement is selected.
        tsRes = extensions.createTrackStates(
            state.geoContext, *calibrationContextPtr, surface, boundState,
            prevTip, result.trackStateCandidates, *result.trackStates,
            logger());
      }

      if (tsRes.ok() && !(*tsRes).empty()) {
        const CkfTypes::BranchVector<TrackIndexType>& newTrackStateList =
            *tsRes;
        const Result<unsigned int> procRes =
            processNewTrackStates(state, stepper, newTrackStateList, result);
        if (!procRes.ok()) {
          ACTS_DEBUG("Processing of selected track states failed: "
                     << procRes.error().message());
          return procRes.error();
        }
        unsigned int nBranchesOnSurface = *procRes;

        if (nBranchesOnSurface == 0) {
          ACTS_VERBOSE("All branches on surface " << surface.geometryId()
                                                  << " have been stopped");

          Result<void> resetRes = reset(state, stepper, navigator, result);
          if (!resetRes.ok()) {
            return resetRes.error();
          }

          return Result<void>::success();
        }

        // `currentBranch` is invalidated after `processNewTrackStates`
        currentBranch = result.activeBranches.back();
        prevTip = currentBranch.tipIndex();
      } else {
        if (!tsRes.ok()) {
          if (static_cast<CombinatorialKalmanFilterError>(
                  tsRes.error().value()) ==
              CombinatorialKalmanFilterError::NoMeasurementExpected) {
            // recoverable error returned by track state creator
            expectMeasurements = false;
          } else {
            ACTS_DEBUG("Track state creation failed on surface "
                       << surface.geometryId() << ": " << tsRes.error());
            return tsRes.error();
          }
        }

        if (expectMeasurements) {
          ACTS_VERBOSE("Detected hole after measurement selection on surface "
                       << surface.geometryId());
        }

        const auto stateMask = PM::Predicted | PM::Jacobian;

        // Add a hole or material track state to the multitrajectory
        TrackIndexType currentTip =
            addNonSourcelinkState(stateMask, boundState, result, isSensitive,
                                  expectMeasurements, prevTip);
        currentBranch.tipIndex() = currentTip;
        auto currentState = currentBranch.outermostTrackState();
        if (expectMeasurements) {
          currentBranch.nHoles()++;
        }

        BranchStopperResult branchStopperResult =
            extensions.branchStopper(currentBranch, currentState);

        // Check the branch
        if (branchStopperResult == BranchStopperResult::Continue) {
          // Remembered the active branch and its state
        } else {
          // No branch on this surface
          if (branchStopperResult == BranchStopperResult::StopAndKeep) {
            storeLastActiveBranch(result);
          }
          // Remove the branch from list
          result.activeBranches.pop_back();

          // Branch on the surface has been stopped - reset
          ACTS_VERBOSE("Branch on surface " << surface.geometryId()
                                            << " has been stopped");

          Result<void> resetRes = reset(state, stepper, navigator, result);
          if (!resetRes.ok()) {
            return resetRes.error();
          }

          return Result<void>::success();
        }
      }

      auto currentState = currentBranch.outermostTrackState();

      if (currentState.typeFlags().isOutlier()) {
        // We don't need to update the stepper given an outlier state
        ACTS_VERBOSE("Outlier state detected on surface "
                     << surface.geometryId());
      } else if (currentState.typeFlags().isMeasurement()) {
        // If there are measurement track states on this surface
        // Update stepping state using filtered parameters of last track
        // state on this surface
        updateStepper(state, stepper, currentState);
        ACTS_VERBOSE("Stepping state is updated with filtered parameter:");
        ACTS_VERBOSE("-> " << currentState.filtered().transpose()
                           << " of track state with tip = "
                           << currentState.index());
      }

      // Update state and stepper with post material effects
      const Result<void> materialPostRes = performMaterialInteraction(
          state, stepper, surface,
          detail::determineMaterialUpdateMode(state, navigator,
                                              MaterialUpdateMode::PostUpdate));
      if (!materialPostRes.ok()) {
        ACTS_DEBUG("Material interaction failed during post-update: "
                   << materialPostRes.error().message());
        return materialPostRes.error();
      }

      return Result<void>::success();
    }

    /// Process new, incompomplete track states and set the filtered state
    ///
    /// @note will process the given list of new states, run the updater
    ///     or share the predicted state for states flagged as outliers
    ///     and add them to the list of active branches
    ///
    /// @tparam propagator_state_t Type of the Propagator state
    /// @tparam stepper_t Type of the stepper
    /// @param state The mutable propagator state object
    /// @param stepper The stepper in use
    /// @param newTrackStateList index list of new track states
    /// @param result which contains among others the new states, and the list of active branches
    /// @return the number of newly added branches or an error
    template <typename propagator_state_t, typename stepper_t>
    Result<unsigned int> processNewTrackStates(
        propagator_state_t& state, const stepper_t& stepper,
        const CkfTypes::BranchVector<TrackIndexType>& newTrackStateList,
        result_type& result) const {
      using PM = TrackStatePropMask;

      unsigned int nBranchesOnSurface = 0;

      auto rootBranch = result.activeBranches.back();

      // Build the new branches by forking the root branch. Reverse the order
      // to process the best candidate first
      CkfTypes::BranchVector<TrackProxy> newBranches;
      for (auto it = newTrackStateList.rbegin(); it != newTrackStateList.rend();
           ++it) {
        // Keep the root branch as the first branch, make a copy for the
        // others
        auto shallowCopy = [&] {
          auto sc = rootBranch.container().makeTrack();
          sc.copyFromShallow(rootBranch);
          return sc;
        };
        auto newBranch =
            (it == newTrackStateList.rbegin()) ? rootBranch : shallowCopy();
        newBranch.tipIndex() = *it;
        newBranches.push_back(newBranch);
      }

      // Remove the root branch
      result.activeBranches.pop_back();

      // Update and select from the new branches
      for (TrackProxy newBranch : newBranches) {
        auto trackState = newBranch.outermostTrackState();
        TrackStateTypeMap typeFlags = trackState.typeFlags();

        if (typeFlags.isOutlier()) {
          // No Kalman update for outlier
          // Set the filtered parameter index to be the same with predicted
          // parameter
          trackState.shareFrom(PM::Predicted, PM::Filtered);
          // Increment number of outliers
          newBranch.nOutliers()++;
        } else if (typeFlags.isMeasurement()) {
          // Allocate the filtered parameters right before they are written
          trackState.addComponents(PM::Filtered);
          // Kalman update
          const auto updateRes = kalmanUpdate(state, stepper, trackState);
          if (!updateRes.ok()) {
            ACTS_DEBUG("Update step failed: " << updateRes.error().message());
            return updateRes.error();
          }
          ACTS_VERBOSE("Appended measurement track state with tip = "
                       << newBranch.tipIndex());
          // Increment number of measurements
          newBranch.nMeasurements()++;
          newBranch.nDoF() += trackState.calibratedSize();
          newBranch.chi2() += trackState.chi2();
        } else {
          ACTS_WARNING("Cannot handle this track state flags");
          continue;
        }

        result.activeBranches.push_back(newBranch);

        BranchStopperResult branchStopperResult =
            extensions.branchStopper(newBranch, trackState);

        // Check if need to stop this branch
        if (branchStopperResult == BranchStopperResult::Continue) {
          // Record the number of branches on surface
          nBranchesOnSurface++;
        } else {
          // Record the number of stopped branches
          if (branchStopperResult == BranchStopperResult::StopAndKeep) {
            storeLastActiveBranch(result);
          }
          // Remove the branch from list
          result.activeBranches.pop_back();
        }
      }

      return nBranchesOnSurface;
    }

    /// @brief CombinatorialKalmanFilter actor operation: add a hole or material track state
    ///
    /// @param stateMask The bitmask that instructs which components to allocate
    /// @param boundState The bound state on current surface
    /// @param result is the mutable result state object and which to leave invalid
    /// @param isSensitive The surface is sensitive or passive
    /// @param expectMeasurements True if measurements where expected for this surface
    /// @param prevTip The index of the previous state
    ///
    /// @return The tip of added state
    TrackIndexType addNonSourcelinkState(TrackStatePropMask stateMask,
                                         const BoundState& boundState,
                                         result_type& result, bool isSensitive,
                                         bool expectMeasurements,
                                         TrackIndexType prevTip) const {
      using PM = TrackStatePropMask;

      // Add a track state
      auto trackStateProxy =
          result.trackStates->makeTrackState(stateMask, prevTip);
      ACTS_VERBOSE("Create "
                   << (isSensitive
                           ? (expectMeasurements ? "Hole"
                                                 : "noMeasurementExpected")
                           : "Material")
                   << " output track state #" << trackStateProxy.index()
                   << " with mask: " << stateMask);

      const auto& [boundParams, jacobian, pathLength] = boundState;
      // Fill the track state
      trackStateProxy.predicted() = boundParams.parameters();
      trackStateProxy.predictedCovariance() = boundParams.covariance().value();
      trackStateProxy.jacobian() = jacobian;
      trackStateProxy.pathLength() = pathLength;
      // Set the surface
      trackStateProxy.setReferenceSurface(
          boundParams.referenceSurface().getSharedPtr());

      // Set the track state flags
      auto typeFlags = trackStateProxy.typeFlags();
      if (trackStateProxy.referenceSurface().hasMaterial()) {
        typeFlags.setHasMaterial();
      }
      typeFlags.setHasParameters();
      if (isSensitive) {
        if (expectMeasurements) {
          typeFlags.setIsHole();
        } else {
          typeFlags.setHasNoExpectedHit();
        }
      }

      // Set the filtered parameter index to be the same with predicted
      // parameter
      trackStateProxy.shareFrom(PM::Predicted, PM::Filtered);

      return trackStateProxy.index();
    }

    void storeLastActiveBranch(result_type& result) const {
      auto currentBranch = result.activeBranches.back();
      TrackIndexType currentTip = currentBranch.tipIndex();

      ACTS_VERBOSE("Storing track "
                   << currentBranch.index() << " with tip index " << currentTip
                   << ". nMeasurements = " << currentBranch.nMeasurements()
                   << ", nOutliers = " << currentBranch.nOutliers()
                   << ", nHoles = " << currentBranch.nHoles());

      result.collectedTracks.push_back(currentBranch);
    }

    template <typename propagator_state_t, typename stepper_t>
    Result<void> performMaterialInteraction(
        propagator_state_t& state, const stepper_t& stepper,
        const Surface& surface, MaterialUpdateMode updateMode) const {
      if (!surface.hasMaterial()) {
        return Result<void>::success();
      }

      if constexpr (!IsMultiStepper) {
        const Result<detail::PointwiseMaterialEffects> materialInteractionRes =
            detail::performMaterialInteraction(
                state, stepper, surface, updateMode, NoiseUpdateMode::addNoise,
                multipleScattering, energyLoss, logger());
        if (!materialInteractionRes.ok()) {
          ACTS_DEBUG("Material interaction failed during reset: "
                     << materialInteractionRes.error().message());
          return materialInteractionRes.error();
        }

        return Result<void>::success();
      } else {
        if (ACTS_CHECK_BIT(updateMode, MaterialUpdateMode::PostUpdate)) {
          brem.betheHeitlerCache->clear();
          brem.componentCache->clear();
          std::size_t nInvalidBetheHeitler = 0;
          double maxPathXOverX0 = 0;

          for (auto cmp : stepper.componentIterable(state.stepping)) {
            const auto boundParamsRes =
                cmp.singleStepper(stepper).boundParameters(cmp.state(),
                                                           surface);
            if (!boundParamsRes.ok()) {
              ACTS_DEBUG(
                  "Failed to transform free to bound parameters for "
                  "Bethe-Heitler approximation: "
                  << boundParamsRes.error());
              continue;
            }

            const BoundTrackParameters& bound = *boundParamsRes;

            detail::Gsf::applyBetheHeitler(
                state.options.geoContext, surface, state.options.direction,
                bound, cmp.weight(), *brem.betheHeitlerApprox,
                *brem.betheHeitlerCache, brem.weightCutoff,
                *brem.componentCache, nInvalidBetheHeitler, maxPathXOverX0,
                logger());
          }

          if (brem.componentCache->empty()) {
            ACTS_WARNING(
                "No components left after applying energy loss. "
                "Is the weight cutoff "
                << brem.weightCutoff << " too high?");
            ACTS_WARNING("Return to propagator without applying energy loss");
            return Result<void>::success();
          }

          // reduce component number
          const auto finalCmpNumber =
              std::min(static_cast<std::size_t>(stepper.maxComponents),
                       brem.maxComponents);
          extensions.mixtureReducer(*brem.componentCache, finalCmpNumber,
                                    surface);

          detail::Gsf::removeLowWeightComponents(*brem.componentCache,
                                                 brem.weightCutoff);

          detail::Gsf::updateStepper(state, stepper, surface,
                                     *brem.componentCache);
        }

        return detail::Gsf::applyMultipleScattering(state, stepper, surface,
                                                    updateMode, logger());
      }
    }

    template <typename propagator_state_t, typename stepper_t>
    Result<void> kalmanUpdate(propagator_state_t& state,
                              const stepper_t& stepper,
                              TrackStateProxy& trackState) const {
      if constexpr (!IsMultiStepper) {
        return extensions.updater(state.geoContext, trackState, *updaterLogger);
      } else {
        using PrtProjector = detail::Gsf::MultiTrajectoryProjector<
            detail::Gsf::StatesType::ePredicted, TrackStateContainerBackend>;
        using FltProjector = detail::Gsf::MultiTrajectoryProjector<
            detail::Gsf::StatesType::eFiltered, TrackStateContainerBackend>;

        const auto& surface = trackState.referenceSurface();

        auto& temporaryStates = *brem.temporaryStates;
        temporaryStates.clear();

        for (auto cmp : stepper.componentIterable(state.stepping)) {
          auto& singleState = cmp.singleState(state).stepping;
          const auto& singleStepper = cmp.singleStepper(stepper);

          TrackStatePropMask mask = TrackStatePropMask::Predicted |
                                    TrackStatePropMask::Jacobian |
                                    TrackStatePropMask::Calibrated;
          TrackStateProxy trackStateProxy =
              temporaryStates.traj.makeTrackState(mask, kTrackIndexInvalid);

          // TODO call calibrator again?

          trackStateProxy.setReferenceSurface(surface.getSharedPtr());
          // Bind the transported state to the current surface
          auto transportRes =
              singleStepper.transportToBound(singleState, surface);
          if (!transportRes.ok()) {
            ACTS_ERROR("Transport to surface "
                       << surface.geometryId()
                       << " failed: " << transportRes.error());
            return transportRes.error();
          }
          auto res = singleStepper.boundParameters(singleState, surface);
          if (!res.ok()) {
            ACTS_ERROR("Bind to surface " << surface.geometryId()
                                          << " failed: " << res.error());
            return res.error();
          }
          const auto& boundParams = *res;

          // Fill the track state
          trackStateProxy.predicted() = boundParams.parameters();
          trackStateProxy.predictedCovariance() = *boundParams.covariance();
          trackStateProxy.allocateCalibrated(trackState.calibratedSize());
          trackStateProxy.setProjectorSubspaceIndices(
              trackState.projectorSubspaceIndices());
          trackStateProxy.effectiveCalibrated() =
              trackState.effectiveCalibrated();
          trackStateProxy.effectiveCalibratedCovariance() =
              trackState.effectiveCalibratedCovariance();

          // Allocate the filtered parameters right before they are written
          trackStateProxy.addComponents(TrackStatePropMask::Filtered);

          const auto updateRes = extensions.updater(
              state.geoContext, trackStateProxy, *updaterLogger);
          if (!updateRes.ok()) {
            return updateRes.error();
          }

          temporaryStates.tips.push_back(trackStateProxy.index());
          temporaryStates.weights[trackStateProxy.index()] = cmp.weight();
        }

        detail::Gsf::computePosteriorWeights(temporaryStates.traj,
                                             temporaryStates.tips,
                                             temporaryStates.weights);

        detail::Gsf::normalizeWeights(temporaryStates.tips,
                                      [&](auto idx) -> double& {
                                        return temporaryStates.weights.at(idx);
                                      });

        const auto [prtMean, prtCov] = detail::Gsf::mergeGaussianMixture(
            temporaryStates.tips,
            PrtProjector{temporaryStates.traj, temporaryStates.weights},
            surface, brem.mergeMethod);
        trackState.predicted() = prtMean;
        trackState.predictedCovariance() = prtCov;

        const auto [fltMean, fltCov] = detail::Gsf::mergeGaussianMixture(
            temporaryStates.tips,
            FltProjector{temporaryStates.traj, temporaryStates.weights},
            surface, brem.mergeMethod);
        trackState.filtered() = fltMean;
        trackState.filteredCovariance() = fltCov;

        return Result<void>::success();
      }
    }

    template <typename propagator_state_t, typename stepper_t>
    void updateStepper(propagator_state_t& state, const stepper_t& stepper,
                       const TrackStateProxy& currentState) const {
      if constexpr (!IsMultiStepper) {
        stepper.update(state.stepping,
                       MultiTrajectoryHelpers::freeFiltered(
                           state.options.geoContext, currentState),
                       currentState.filtered(),
                       currentState.filteredCovariance(),
                       currentState.referenceSurface());
      } else {
        // Conincidentially the temporaryStates correspond to the currentState
        // but it seems fragile to rely on that. It would be better to store the
        // multi bound parameters on the track state and recover them here. This
        // would also behave better in case of branching.
        // TODO revisit this
        detail::Gsf::updateStepper(state, stepper, *brem.temporaryStates,
                                   brem.weightCutoff);
      }
    }
  };

  /// Void path limit reached aborter to replace the default since the path
  /// limit is handled in the CKF actor internally.
  struct StubPathLimitReached {
    double internalLimit{};

    template <typename propagator_state_t, typename stepper_t,
              typename navigator_t>
    bool checkAbort(propagator_state_t& /*state*/, const stepper_t& /*stepper*/,
                    const navigator_t& /*navigator*/,
                    const Logger& /*logger*/) const {
      return false;
    }
  };

 public:
  /// Options for this filter instantiation, selected by the stepper: the plain
  /// @ref CombinatorialKalmanFilterOptions for a single-component stepper, and
  /// @ref BremCombinatorialKalmanFilterOptions (bremsstrahlung recovery) for a
  /// multi-component stepper.
  using Options = std::conditional_t<
      IsMultiStepper, BremCombinatorialKalmanFilterOptions<track_container_t>,
      CombinatorialKalmanFilterOptions<track_container_t>>;

  /// Combinatorial Kalman Filter implementation, calls the Kalman filter
  ///
  /// @param initialParameters The initial track parameters
  /// @param tfOptions CombinatorialKalmanFilterOptions steering the track
  ///                  finding
  /// @param trackContainer Track container in which to store the results
  /// @param rootBranch The track to be used as the root branch
  ///
  /// @note The input measurements are given in the form of @c SourceLinks.
  ///       It's @c calibrator_t's job to turn them into calibrated measurements
  ///       used in the track finding.
  ///
  /// @return a container of track finding result for all the initial track
  /// parameters
  Result<std::vector<TrackProxy>> findTracks(
      const BoundTrackParameters& initialParameters, const Options& tfOptions,
      track_container_t& trackContainer, TrackProxy rootBranch) const {
    // Create the ActorList
    using CombinatorialKalmanFilterActor = Actor;
    using Actors = ActorList<CombinatorialKalmanFilterActor>;

    // Create relevant options for the propagation options
    using PropagatorOptions = typename propagator_t::template Options<Actors>;
    PropagatorOptions propOptions(tfOptions.geoContext,
                                  tfOptions.magFieldContext);

    // Set the trivial propagator options
    propOptions.setPlainOptions(tfOptions.propagatorPlainOptions);

    // Catch the actor
    auto& combKalmanActor =
        propOptions.actorList.template get<CombinatorialKalmanFilterActor>();
    combKalmanActor.targetReached.surface = tfOptions.targetSurface;
    combKalmanActor.multipleScattering = tfOptions.multipleScattering;
    combKalmanActor.energyLoss = tfOptions.energyLoss;
    combKalmanActor.skipPrePropagationUpdate =
        tfOptions.skipPrePropagationUpdate;
    combKalmanActor.recordMaterialStates = tfOptions.recordMaterialStates;
    combKalmanActor.actorLogger = m_actorLogger.get();
    combKalmanActor.updaterLogger = m_updaterLogger.get();
    combKalmanActor.calibrationContextPtr = &tfOptions.calibrationContext.get();

    // copy delegates to calibrator, updater, branch stopper
    combKalmanActor.extensions = tfOptions.extensions;

    // Scratch buffers for the multi-component (bremsstrahlung) path. They must
    // outlive the propagation below; they are left untouched by a
    // single-component stepper.
    TemporaryStates temporaryStates;
    std::vector<BetheHeitlerApprox::Component> betheHeitlerCache;
    std::vector<GsfComponent> componentCache;

    // The bremsstrahlung parameters only exist on the multi-component options.
    if constexpr (IsMultiStepper) {
      combKalmanActor.brem.maxComponents = tfOptions.maxComponents;
      combKalmanActor.brem.weightCutoff = tfOptions.weightCutoff;
      combKalmanActor.brem.mergeMethod = tfOptions.mergeMethod;
      combKalmanActor.brem.betheHeitlerApprox =
          tfOptions.betheHeitlerApprox.get();

      combKalmanActor.brem.temporaryStates = &temporaryStates;
      combKalmanActor.brem.betheHeitlerCache = &betheHeitlerCache;
      combKalmanActor.brem.componentCache = &componentCache;
    }

    auto propState =
        m_propagator.template makeState<PropagatorOptions, NoTargetAborter,
                                        StubPathLimitReached>(propOptions);

    if constexpr (!IsMultiStepper) {
      const auto initResult =
          m_propagator.template initialize<decltype(propState), NoTargetAborter,
                                           StubPathLimitReached>(
              propState, initialParameters, nullptr);
      if (!initResult.ok()) {
        ACTS_DEBUG("Propagation initialization failed: " << initResult.error());
        return initResult.error();
      }
    } else {
      const MultiComponentBoundTrackParameters multiBoundInitialParameters(
          initialParameters.referenceSurface().getSharedPtr(),
          initialParameters.parameters(), initialParameters.covariance(),
          initialParameters.particleHypothesis());

      const auto initResult =
          m_propagator.template initialize<decltype(propState), NoTargetAborter,
                                           StubPathLimitReached>(
              propState, multiBoundInitialParameters, nullptr);
      if (!initResult.ok()) {
        ACTS_DEBUG("Propagation initialization failed: " << initResult.error());
        return initResult.error();
      }
    }

    auto& r =
        propState
            .template get<CombinatorialKalmanFilterResult<track_container_t>>();
    r.tracks = &trackContainer;
    r.trackStates = &trackContainer.trackStateContainer();

    // make sure the right particle hypothesis is set on the root branch
    rootBranch.setParticleHypothesis(initialParameters.particleHypothesis());

    r.activeBranches.push_back(rootBranch);

    auto propagationResult = m_propagator.propagate(propState);

    auto result = m_propagator.makeResult(
        std::move(propState), propagationResult, propOptions, false);

    if (!result.ok()) {
      ACTS_DEBUG("Propagation failed: " << result.error() << " "
                                        << result.error().message()
                                        << " with the initial parameters: \n"
                                        << initialParameters.parameters());
      return result.error();
    }

    auto& propRes = *result;

    // Get the result of the CombinatorialKalmanFilter
    auto combKalmanResult =
        std::move(propRes.template get<
                  CombinatorialKalmanFilterResult<track_container_t>>());

    // Check if track finding finished properly
    if (!combKalmanResult.finished) {
      ACTS_DEBUG("CombinatorialKalmanFilter failed: "
                 << "Propagation reached max steps "
                 << "with the initial parameters: "
                 << initialParameters.parameters().transpose());
      return CombinatorialKalmanFilterError::PropagationReachesMaxSteps;
    }

    return std::move(combKalmanResult.collectedTracks);
  }

  /// Combinatorial Kalman Filter implementation, calls the Kalman filter
  ///
  /// @param initialParameters The initial track parameters
  /// @param tfOptions CombinatorialKalmanFilterOptions steering the track
  ///                  finding
  /// @param trackContainer Track container in which to store the results
  /// @note The input measurements are given in the form of @c SourceLinks.
  ///       It's @c calibrator_t's job to turn them into calibrated measurements
  ///       used in the track finding.
  ///
  /// @return a container of track finding result for all the initial track
  /// parameters
  Result<std::vector<TrackProxy>> findTracks(
      const BoundTrackParameters& initialParameters, const Options& tfOptions,
      track_container_t& trackContainer) const {
    auto rootBranch = trackContainer.makeTrack();
    return findTracks(initialParameters, tfOptions, trackContainer, rootBranch);
  }
};

/// @}

}  // namespace Acts
