// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Material/ISurfaceMaterial.hpp"
#include "Acts/Material/MaterialSlab.hpp"
#include "Acts/Utilities/BinUtility.hpp"
#include "Acts/Utilities/MultiAxisSpec.hpp"

#include <iosfwd>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

namespace Acts {

/// @addtogroup material
/// @{

///
/// @brief proxy to SurfaceMaterial hand over BinUtility or other suitable
/// binning description
///
/// The ProtoSurfaceMaterial class acts as a proxy to the SurfaceMaterial
/// to mark the layers and surfaces on which the material should be mapped on
/// at construction time of the geometry and to hand over the granularity of
/// of the material map with the bin Utility.
template <typename BinningType>
class ProtoSurfaceMaterialT : public ISurfaceMaterial {
 public:
  /// Constructor without binningType - homogeneous material
  ProtoSurfaceMaterialT() = default;

  /// Constructor with BinningType
  /// @param binning a binning description for the material map binning
  /// @param materialKey Optional stable identity of the material assignment
  /// @param mappingType is the type of surface mapping associated to the surface
  explicit ProtoSurfaceMaterialT(
      const BinningType& binning,
      MappingType mappingType = MappingType::Default,
      std::optional<std::string> materialKey = std::nullopt)
      : ISurfaceMaterial(1., mappingType),
        m_binning(binning),
        m_materialKey(std::move(materialKey)) {
    if (m_materialKey && m_materialKey->empty()) {
      throw std::invalid_argument("Material key must not be empty");
    }
  }

  /// Copy constructor
  ///
  /// @param smproxy The source proxy
  ProtoSurfaceMaterialT(const ProtoSurfaceMaterialT<BinningType>& smproxy) =
      default;

  /// Copy move constructor
  ///
  /// @param smproxy The source proxy
  ProtoSurfaceMaterialT(ProtoSurfaceMaterialT<BinningType>&& smproxy) noexcept =
      default;

  /// Destructor
  ~ProtoSurfaceMaterialT() override = default;

  /// Assignment operator
  ///
  /// @param smproxy The source proxy
  /// @return Reference to this object
  ProtoSurfaceMaterialT<BinningType>& operator=(
      const ProtoSurfaceMaterialT<BinningType>& smproxy) = default;

  /// Assignment move operator
  ///
  /// @param smproxy The source proxy
  /// @return Reference to this object
  ProtoSurfaceMaterialT<BinningType>& operator=(
      ProtoSurfaceMaterialT<BinningType>&& smproxy) noexcept = default;

  /// Scale operation - dummy implementation
  ///
  /// @return Reference to this object
  ProtoSurfaceMaterialT<BinningType>& scale(double /*factor*/) final {
    return (*this);
  }

  /// Stable identity of the material assignment, if configured
  /// @return Optional stable material assignment key
  const std::optional<std::string>& materialKey() const {
    return m_materialKey;
  }

  /// Return the BinUtility
  /// @return Reference to the binning
  const BinningType& binning() const { return (m_binning); }

  /// Return method for full material description of the Surface - from local
  /// coordinates
  ///
  /// @return will return dummy material
  const MaterialSlab& materialSlab(const Vector2& /*lp*/) const final {
    return (m_materialSlab);
  }

  /// @copydoc ISurfaceMaterial::localAxisDirections() const
  std::vector<AxisDirection> localAxisDirections() const final { return {}; }

  using ISurfaceMaterial::materialSlab;

  /// Output Method for std::ostream, to be overloaded by child classes
  ///
  /// @param sl is the output stream
  /// @return The output stream
  std::ostream& toStream(std::ostream& sl) const final {
    sl << "Acts::ProtoSurfaceMaterial : " << std::endl;
    sl << m_binning << std::endl;
    return sl;
  }

 private:
  /// A binning description
  BinningType m_binning;

  std::optional<std::string> m_materialKey;

  /// Dummy material properties
  MaterialSlab m_materialSlab = MaterialSlab::Nothing();
};

/// @brief Type alias for a prototype surface material using BinUtility
/// A surface material implementation that uses BinUtility for binning
using ProtoSurfaceMaterial = ProtoSurfaceMaterialT<Acts::BinUtility>;

/// @brief Type alias for a prototype surface material using a multi-axis
/// binning description
/// A surface material implementation that carries a MultiAxisSpec2D whose
/// deferred axes are resolved against the surface during material mapping
using ProtoGridSurfaceMaterial = ProtoSurfaceMaterialT<MultiAxisSpec2D>;

/// @}

}  // namespace Acts
