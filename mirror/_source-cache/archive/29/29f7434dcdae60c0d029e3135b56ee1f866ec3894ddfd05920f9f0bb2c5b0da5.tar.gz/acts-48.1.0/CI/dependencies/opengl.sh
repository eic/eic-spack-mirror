#!/bin/bash
# This file locates the the OpenGL library and adds it to the packages.yaml file.
# OpenGL needs to be supplied to spack as an *external*, which means that spack uses
# it in dependency resolution, but does not attempt to build it.

set -u
set -e

packages_file=$(spack location -r)/etc/spack/packages.yaml
echo "Packages file: $packages_file"
stat "$packages_file" || true

if ! command -v sudo &> /dev/null
then
    SUDO=""
else
    SUDO="sudo"
fi

os=$(spack arch --family)

echo "OS: $os"

if [[ "$os" == *ubuntu* ]]; then

  # Redundant under GitHub Actions, where .github/actions/dependencies applies the
  # mirror up front; kept for entry points that call setup.sh directly and never
  # see that action (GitLab CI). Idempotent, so the double call is free.
  "$(dirname "${BASH_SOURCE[0]}")/apt_mirror.sh"

  # `apt-get update` alone costs ~10 s (the universe index is ~19 MB), and all we
  # need out of apt is the headers under /usr. Skip the whole thing when the
  # image already ships them, so this becomes free once the CI images do.
  if dpkg-query -W -f='${Status}' libgl1-mesa-dev 2>/dev/null | grep -q "^install ok installed$"; then
    echo "libgl1-mesa-dev already installed, skipping apt"
  else
    ${SUDO} apt-get update
    ${SUDO} apt-get install -y --no-install-recommends libgl1-mesa-dev
  fi

  if [[ "$os" == *ubuntu24* ]]; then
    version="4.6"
  elif [[ "$os" == *ubuntu20* ]]; then
    version="4.5"
  else
    echo "Unknown OS version, default OpenGL version"
    version="4.5"
  fi

  cat <<EOF > "$packages_file"
packages:
  opengl:
    buildable: false
    externals:
    - prefix: /usr/
      spec: opengl@${version}
EOF
  cat "$packages_file"

elif [[ "$os" == *almalinux* ]]; then
  ${SUDO} dnf install -y mesa-libGLU
  cat <<EOF > "$packages_file"
packages:
  opengl:
    buildable: false
    externals:
    - prefix: /usr/
      spec: opengl@4.6
EOF
  cat "$packages_file"

elif [[ "$os" == *darwin* ]]; then

  echo "Nothing to do on Darwin"

fi
