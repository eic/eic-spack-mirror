#[[
Copyright (c) 2014-2024 Key4hep-Project.

This file is part of Key4hep.
See https://key4hep.github.io/key4hep-doc/ for further info.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
]]
# 3.22 is required by the DL_PATHS option of catch_discover_tests, see
# test/unittests/CMakeLists.txt
CMAKE_MINIMUM_REQUIRED(VERSION 3.22)

project(k4ActsTracking LANGUAGES CXX)

SET( ${PROJECT_NAME}_VERSION_MAJOR 0 )
SET( ${PROJECT_NAME}_VERSION_MINOR 7 )
SET( ${PROJECT_NAME}_VERSION_PATCH 0 )

SET( ${PROJECT_NAME}_VERSION  "${${PROJECT_NAME}_VERSION_MAJOR}.${${PROJECT_NAME}_VERSION_MINOR}.${${PROJECT_NAME}_VERSION_PATCH}" )

# The GNN track finding code depends on Torch, onnxruntime and the Acts Gnn
# plugin. Guard it behind an option so that the package can also be built
# without those dependencies.
option(K4ACTSTRACKING_BUILD_GNN
  "Build the GNN track finding code (requires Torch, onnxruntime and the Acts Gnn plugin)"
  OFF)
include(cmake/MaybeBuildActs.cmake)

find_package(EDM4HEP 1.2 REQUIRED)
find_package(k4FWCore REQUIRED)
set(ACTS_COMPONENTS Core PluginDD4hep PluginEDM4hep)
if(K4ACTSTRACKING_BUILD_GNN)
  list(APPEND ACTS_COMPONENTS PluginGnn)
endif()
find_package(Acts REQUIRED COMPONENTS ${ACTS_COMPONENTS})
find_package(DD4hep REQUIRED COMPONENTS DDCore DDRec)
find_package(TBB REQUIRED)
if(K4ACTSTRACKING_BUILD_GNN)
  # The GNN track finding needs OnnxEdgeClassifier to pass the node features in
  # the configured order (acts#6142), which is in main but not in v48.0.1.
  if(Acts_VERSION VERSION_LESS 48.1.0)
    message(FATAL_ERROR "K4ACTSTRACKING_BUILD_GNN needs Acts >= 48.1.0 (or main), found ${Acts_VERSION}")
  endif()
  find_package(onnxruntime REQUIRED)
  find_package(Torch REQUIRED)
endif()

include(GNUInstallDirs)

include(cmake/Key4hepConfig.cmake)

#---------------------------------------------------------------

include(CTest)

add_subdirectory(k4ActsTracking)
if(K4ACTSTRACKING_BUILD_GNN)
  add_subdirectory(GNNTrackFinding)
endif()
add_subdirectory(data)
if (BUILD_TESTING)
  add_subdirectory(test)
endif()

include(cmake/createk4ActsTrackingConfig.cmake)
