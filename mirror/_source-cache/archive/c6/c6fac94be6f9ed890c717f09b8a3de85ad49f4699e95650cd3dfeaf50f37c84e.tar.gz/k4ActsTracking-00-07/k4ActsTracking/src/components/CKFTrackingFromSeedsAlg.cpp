/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// k4ActsTracking
#include "k4ActsTracking/CKFRunner.hxx"
#include "k4ActsTracking/IActsGeoSvc.h"
#include "k4ActsTracking/Measurement.hxx"
#include "k4ActsTracking/SourceLink.hxx"

// k4FWCore
#include <k4FWCore/GaudiChecks.h>
#include <k4FWCore/Transformer.h>

// edm4hep
#include <edm4hep/TrackCollection.h>
#include <edm4hep/TrackerHit.h>
#include <edm4hep/TrackerHitPlaneCollection.h>

// podio
#include <podio/ObjectID.h>

// Gaudi
#include <Gaudi/Property.h>
#include <GaudiKernel/SmartIF.h>

// ACTS
#include <Acts/Definitions/Algebra.hpp>
#include <Acts/Definitions/Units.hpp>
#include <Acts/EventData/BoundTrackParameters.hpp>
#include <Acts/Geometry/GeometryContext.hpp>
#include <Acts/MagneticField/MagneticFieldContext.hpp>
#include <Acts/MagneticField/MagneticFieldProvider.hpp>
#include <Acts/Surfaces/Surface.hpp>
#include <Acts/Utilities/CalibrationContext.hpp>

// TBB
#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>
#include <tbb/task_arena.h>

#include <fmt/ostream.h>

// Standard
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <optional>
#include <ranges>
#include <string>
#include <unordered_map>
#include <vector>

/**
 * @brief CKF tracking seeded from an existing user-defined track container.
 *
 * Closely follows CKFTrackingAlg, but instead of running the internal ACTS
 * seed finder it builds the seed track parameters from an input
 * edm4hep::TrackCollection (e.g. track candidates produced by an upstream
 * pattern-recognition stage). Each input track defines a group of tracker hits;
 * the innermost / middle / outermost of those hits (ordered by radius) form a
 * three-point seed from which initial Acts::BoundTrackParameters are estimated.
 * Those parameters then feed the same Combinatorial Kalman Filter used by
 * CKFTrackingAlg (shared via ACTSTracking::CKFRunner).
 */
struct CKFTrackingFromSeedsAlg final
    : k4FWCore::MultiTransformer<std::tuple<edm4hep::TrackCollection, edm4hep::TrackCollection>(
          const edm4hep::TrackerHitPlaneCollection&, const edm4hep::TrackCollection&)> {
  CKFTrackingFromSeedsAlg(const std::string& name, ISvcLocator* svcLoc);

  StatusCode initialize() override;

  StatusCode finalize() override;

  std::tuple<edm4hep::TrackCollection, edm4hep::TrackCollection>
  operator()(const edm4hep::TrackerHitPlaneCollection& trackerHitCollection,
             const edm4hep::TrackCollection& seedTrackCollection) const override;

private:
  /// @name Run control
  ///@{
  Gaudi::Property<bool> m_doTwoWayCKF{this, "DoTwoWayCKF", false,
                                      "Run two-way CKF: first pass + smooth + second pass in opposite direction."};
  Gaudi::Property<bool> m_inflateCovarianceTwoWay{this, "InflateCovarianceTwoWay", true,
                                                  "Inflate covariance before the second CKF pass."};
  Gaudi::Property<double> m_twoWayInflateCovarianceFactor{this, "TwoWayInflateCovarianceFactor", 100.0,
                                                          "Covariance inflation factor for the second CKF pass."};
  Gaudi::Property<bool> m_propagateBackward{
      this, "PropagateBackward", false,
      "Find tracks outside-in: start the CKF at the outermost hit of each input candidate and propagate backward "
      "toward the beamline."};
  Gaudi::Property<bool> m_extrapolateToCalo{
      this, "ExtrapolateToCalo", true,
      "Extrapolate fitted tracks to the calorimeter face and add an AtCalorimeter track state."};
  Gaudi::Property<bool> m_addEndcapCaloState{
      this, "AddEndcapCaloState", false,
      "Give a track that crosses both calorimeter sections one AtCalorimeter track state per section instead of a "
      "single one. A track entering the barrel face close to the barrel/endcap corner goes on to enter the endcap "
      "too; with this enabled it gets a second AtCalorimeter state there, appended after the barrel one (the states "
      "are ordered as the track crosses them). Off by default, since a consumer looking up 'the' AtCalorimeter state "
      "by location would silently see only the barrel one. Ignored unless ExtrapolateToCalo is set."};
  Gaudi::Property<unsigned int> m_minSeedHits{this, "MinSeedHits", 3,
                                              "Minimum number of hits an input track must have to seed the CKF."};
  ///@}

  /// @name Track-fit initial error estimates
  ///@{
  Gaudi::Property<double> m_initialTrackError_pos{this, "InitialTrackError_Pos", 10 * Acts::UnitConstants::um,
                                                  "Initial track error for local position."};
  Gaudi::Property<double> m_initialTrackError_phi{this, "InitialTrackError_Phi", 1 * Acts::UnitConstants::degree,
                                                  "Initial track error for phi."};
  Gaudi::Property<double> m_initialTrackError_relP{this, "InitialTrackError_RelP", 0.25,
                                                   "Initial track error for momentum (relative)."};
  Gaudi::Property<double> m_initialTrackError_lambda{this, "InitialTrackError_Lambda", 1 * Acts::UnitConstants::degree,
                                                     "Initial track error for lambda."};
  Gaudi::Property<double> m_initialTrackError_time{this, "InitialTrackError_Time", 100 * Acts::UnitConstants::ns,
                                                   "Initial track error for time."};
  Gaudi::Property<double> m_CKF_chi2CutOff{this, "CKF_Chi2CutOff", 15, "Maximum local chi2 contribution."};
  Gaudi::Property<int32_t> m_CKF_numMeasurementsCutOff{this, "CKF_NumMeasurementsCutOff", 10,
                                                       "Maximum measurements on a single surface."};
  Gaudi::Property<unsigned int> m_maxPropagationSteps{
      this, "MaxPropagationSteps", ACTSTracking::kDefaultMaxPropagationSteps,
      "Maximum number of propagation steps for CKF track finding, IP/reference-surface extrapolation and "
      "calorimeter-face extrapolation."};
  ///@}

  /// @name Multi-threading
  ///@{
  Gaudi::Property<int> m_numThreads{this, "NumThreads", 1, "Number of threads for internal TBB parallelism."};
  ///@}

  SmartIF<IActsGeoSvc> m_actsGeoSvc;

  // Shared Combinatorial Kalman Filter, built once in initialize() and reused
  // read-only across events and threads.
  std::optional<ACTSTracking::CKFRunner> m_ckfRunner{};

  // Calorimeter-face extrapolation monitoring, updated by the shared CKFRunner
  // and summarised in finalize().
  ACTSTracking::CaloExtrapMonitor m_caloMonitor{};

  mutable std::mutex m_seedMutex{};
  mutable std::mutex m_trackMutex{};
};

DECLARE_COMPONENT(CKFTrackingFromSeedsAlg)

// ---------------------------------------------------------------------------
// Constructor / initialize
// ---------------------------------------------------------------------------

CKFTrackingFromSeedsAlg::CKFTrackingFromSeedsAlg(const std::string& name, ISvcLocator* svcLoc)
    : MultiTransformer(name, svcLoc,
                       {KeyValue("InputTrackerHitCollection", "TrackerHits"),
                        KeyValue("InputSeedTrackCollection", "SeedTrackCandidates")},
                       {KeyValue("OutputSeedCollection", "SeedTracks"), KeyValue("OutputTrackCollection", "Tracks")}) {}

StatusCode CKFTrackingFromSeedsAlg::initialize() {
  m_actsGeoSvc = svcLoc()->service<IActsGeoSvc>("ActsGeoSvc");
  K4_GAUDI_CHECK(m_actsGeoSvc);

  if (m_extrapolateToCalo && m_actsGeoSvc->caloSurfaceGeoIds().empty()) {
    warning() << "ExtrapolateToCalo requested but ActsGeoSvc provides no calorimeter-face surfaces; "
                 "no AtCalorimeter track states will be produced."
              << endmsg;
  }
  if (m_addEndcapCaloState && !m_extrapolateToCalo) {
    error() << "AddEndcapCaloState requested but ExtrapolateToCalo is off; no AtCalorimeter track states "
               "are produced at all, so the setting has no effect."
            << endmsg;
    return StatusCode::FAILURE;
  } else if (m_addEndcapCaloState && m_actsGeoSvc->caloEndcapSurfaceGeoIds().empty()) {
    warning() << "AddEndcapCaloState requested but ActsGeoSvc provides no calorimeter endcap surfaces; "
                 "every track will keep a single AtCalorimeter state."
              << endmsg;
  }

  m_ckfRunner.emplace(
      *m_actsGeoSvc, ACTSTracking::CKFRunner::Config{.chi2CutOff = m_CKF_chi2CutOff,
                                                     .numMeasurementsCutOff = m_CKF_numMeasurementsCutOff,
                                                     .propagateBackward = m_propagateBackward,
                                                     .extrapolateToCalo = m_extrapolateToCalo,
                                                     .maxSteps = m_maxPropagationSteps,
                                                     .addEndcapCaloState = m_addEndcapCaloState,
                                                     .doTwoWayCKF = m_doTwoWayCKF,
                                                     .inflateCovarianceTwoWay = m_inflateCovarianceTwoWay,
                                                     .twoWayInflateCovarianceFactor = m_twoWayInflateCovarianceFactor});

  return StatusCode::SUCCESS;
}

StatusCode CKFTrackingFromSeedsAlg::finalize() {
  if (m_extrapolateToCalo) {
    info() << m_caloMonitor.summary() << endmsg;
  }
  if (m_doTwoWayCKF && m_ckfRunner) {
    info() << m_ckfRunner->twoWaySummary() << endmsg;
  }
  return StatusCode::SUCCESS;
}

// ---------------------------------------------------------------------------
// Event processing
// ---------------------------------------------------------------------------

std::tuple<edm4hep::TrackCollection, edm4hep::TrackCollection>
CKFTrackingFromSeedsAlg::operator()(const edm4hep::TrackerHitPlaneCollection& trackerHitCollection,
                                    const edm4hep::TrackCollection& seedTrackCollection) const {
  edm4hep::TrackCollection seedCollection;
  edm4hep::TrackCollection trackCollection;

  // Default-construct ACTS contexts
  const Acts::GeometryContext geoCtx = Acts::GeometryContext::dangerouslyDefaultConstruct();
  const Acts::MagneticFieldContext magCtx{};

  ACTSTracking::SourceLinkContainer sourceLinks;
  ACTSTracking::MeasurementContainer measurements;
  ACTSTracking::HitContainer hitContainer;

  // Build measurements + source links for all hits, and keep the source link of
  // each hit so the input track candidates can be turned into seeds.
  std::unordered_map<std::uint64_t, ACTSTracking::SourceLink> slByHit;
  slByHit.reserve(trackerHitCollection.size());

  ACTSTracking::prepareTrackerHits(
      *this, *m_actsGeoSvc, geoCtx, trackerHitCollection, measurements, sourceLinks, hitContainer, m_numThreads.value(),
      [&](const edm4hep::TrackerHitPlane& hit, const ACTSTracking::SourceLink& sl, const Acts::Vector3& /*globalPos*/,
          const Acts::Surface& /*surface*/,
          const Acts::SquareMatrix2& /*localCov*/) { slByHit.emplace(ACTSTracking::trackerHitKey(hit), sl); });

  debug() << fmt::format("Created {} sourceLinks from {} hits", sourceLinks.size(), trackerHitCollection.size())
          << endmsg;

  // Parallelise over the input seed tracks: each task turns a contiguous chunk
  // of candidates into three-point seeds + initial parameters, then runs the CKF
  // once over that chunk (so the ACTS track containers are reused across the
  // chunk's seeds). Shared inputs (slByHit, measurements, sourceLinks) are
  // read-only here; the podio output collections are guarded by the mutexes.
  auto seedAndTrack = [&](const tbb::blocked_range<std::size_t>& range) {
    // Per-task magnetic-field cache: the cache is mutable state and must not be
    // shared between threads.
    auto magCacheLocal = m_actsGeoSvc->magneticField()->makeCache(magCtx);

    std::vector<Acts::BoundTrackParameters> paramseeds;
    paramseeds.reserve(range.size());

    for (std::size_t i = range.begin(); i != range.end(); ++i) {
      const auto seedTrack = seedTrackCollection[i];

      // Build the radius-ordered seed hits; the triplet is innermost / middle /
      // outermost.
      const std::vector<ACTSTracking::SeedHit> hits =
          ACTSTracking::collectSeedHits(seedTrack.getTrackerHits(), slByHit, hitContainer);

      if (hits.size() < m_minSeedHits) {
        debug() << "Skipping input track with " << hits.size() << " usable hits (< " << m_minSeedHits.value() << ")."
                << endmsg;
        continue;
      }

      std::optional<Acts::BoundTrackParameters> paramseed = ACTSTracking::estimateSeedParameters(
          *this, *m_actsGeoSvc, geoCtx, hits, hitContainer, magCacheLocal, m_initialTrackError_pos,
          m_initialTrackError_phi, m_initialTrackError_lambda, m_initialTrackError_relP, m_initialTrackError_time,
          /*errQOverP=*/0, m_propagateBackward);
      if (!paramseed) {
        continue;
      }
      paramseeds.push_back(*paramseed);

      auto seedTrackState = ACTSTracking::makeSeedTrackState(*this, *m_actsGeoSvc, geoCtx, *paramseed, magCacheLocal,
                                                             m_propagateBackward ? edm4hep::TrackState::AtLastHit
                                                                                 : edm4hep::TrackState::AtFirstHit);

      ACTSTracking::appendSeedTrack(
          seedCollection, m_seedMutex, seedTrackState,
          hits | std::views::transform([&](const ACTSTracking::SeedHit& h) { return hitContainer[h.sl.index()]; }));
    }

    // One CKF pass for the whole chunk.
    m_ckfRunner->findTracks(*this, measurements, sourceLinks, hitContainer, paramseeds, magCacheLocal, trackCollection,
                            m_trackMutex, &m_caloMonitor);
  };

  const tbb::blocked_range<std::size_t> fullRange(0, seedTrackCollection.size());
  if (m_numThreads.value() > 1) {
    tbb::task_arena arena(m_numThreads.value());
    arena.execute([&] { tbb::parallel_for(fullRange, seedAndTrack); });
  } else {
    seedAndTrack(fullRange);
  }

  debug() << "Track Collection Size: " << trackCollection.size() << endmsg;
  return std::make_tuple(std::move(seedCollection), std::move(trackCollection));
}
