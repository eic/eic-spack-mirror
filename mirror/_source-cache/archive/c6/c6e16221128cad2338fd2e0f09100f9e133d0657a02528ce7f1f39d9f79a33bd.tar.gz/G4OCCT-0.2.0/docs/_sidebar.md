<!-- SPDX-License-Identifier: LGPL-2.1-or-later -->
<!-- Copyright (C) 2026 G4OCCT Contributors -->

- [📊 Slide Deck](slides.html)
- [Project Goals](goals.md)
- [Geometry Mapping](geometry_mapping.md)
- [Reference Position Handling](reference_position.md)
- [Material Bridging](material_bridging.md)
- [Multi-Shape STEP Assembly Import](step_assembly_import.md)
- [DD4hep Plugin Design](dd4hep_plugin.md)
- [Solid Navigation Design](solid_navigation.md)
- [Performance Considerations](performance.md)
- [Low-Level Optimization Design Notes](low_level_optimization.md)
- [Geometry Test Status](geometry_test_status.md)
- [NIST CTC Fixtures](nist_ctc.md)
- **Examples**
  - [B1 — Water Phantom](example_b1.md)
  - [B4c — Sampling Calorimeter](example_b4c.md)
- **CI Reports**
  - [Test Results](reports/test-results.md)
  - [Solid Benchmark Results](reports/bench-results.md)
  - [Assembly Benchmark Results](reports/bench-assembly-results.md)
  - [Point Cloud Viewer](reports/point_cloud_viewer.html)
  - [Coverage Report](reports/coverage.md)
  - [Example Logs](reports/example-logs.md)
  - [Geometry Fixture Images](reports/geometry-images.html)
- [API Reference](https://eic.github.io/G4OCCT/api/index.html)
