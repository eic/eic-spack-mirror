// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright (C) 2023 - 2026, Joe Osborn, Dmitry Romanov, Wouter Deconinck

#pragma once

#include <Acts/Utilities/Logger.hpp>
#include <algorithms/algorithm.h>
#include <boost/container/detail/std_fwd.hpp>
#include <edm4eic/TrackParametersCollection.h>
#include <edm4eic/TrackSeedCollection.h>
#include <edm4eic/TrackerHitCollection.h>
#include <array>
#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>
#include <variant>
#include <vector>

#include "ActsGeometryProvider.h"
#include "TrackSeedingConfig.h"
#include "algorithms/interfaces/ActsSvc.h"
#include "algorithms/interfaces/WithPodConfig.h"

// Define version availability macros for each seeding method
// Seeding requires Acts >= 47, when Seeding2 was renamed to Seeding.
// Seeding2 requires Acts >= 45.3: earlier 45.x releases had ambiguous
// SeedContainer2::assignSpacePointContainer overloads for lvalues; this was
// resolved in v45.3.0 by changing the by-value overload to rvalue-ref.
#define TRACKSEEDING_HAS_SEEDING (Acts_VERSION_MAJOR >= 47)
#define TRACKSEEDING_HAS_SEEDING2                                                                  \
  (Acts_VERSION_MAJOR > 45 || (Acts_VERSION_MAJOR == 45 && Acts_VERSION_MINOR >= 3)) &&            \
      (Acts_VERSION_MAJOR < 47)
#define TRACKSEEDING_HAS_ORTHOGONAL (Acts_VERSION_MAJOR <= 46)

// Acts version-specific includes
#if TRACKSEEDING_HAS_SEEDING
#include <Acts/Seeding/BroadTripletSeedFilter.hpp>
#include <Acts/Seeding/DoubletSeedFinder.hpp>
#include <Acts/Seeding/TripletSeedFinder.hpp>
#include <Acts/Seeding/TripletSeeder.hpp>
#endif

#if TRACKSEEDING_HAS_SEEDING2
#include <Acts/Seeding2/BroadTripletSeedFilter.hpp>
#include <Acts/Seeding2/DoubletSeedFinder.hpp>
#include <Acts/Seeding2/TripletSeedFinder.hpp>
#include <Acts/Seeding2/TripletSeeder.hpp>
#endif

#if TRACKSEEDING_HAS_ORTHOGONAL
#include <Acts/EventData/Seed.hpp>
#include <Acts/EventData/SpacePointContainer.hpp>
#include <Acts/Seeding/SeedFilterConfig.hpp>
#include <Acts/Seeding/SeedFinderConfig.hpp>
#include <Acts/Seeding/SeedFinderOrthogonalConfig.hpp>
#include <Acts/Utilities/HashedString.hpp>
#include <Acts/Utilities/Holders.hpp>
#if __has_include(<ActsExamples/EventData/SpacePointContainer.hpp>)
#include <ActsExamples/EventData/SpacePointContainer.hpp>
#else
#include <any>
#include <stdexcept>
#endif
#include "SpacePoint.h"
#endif

namespace eicrecon {

#if TRACKSEEDING_HAS_ORTHOGONAL
// SpacePointContainerAdapter only needed for Orthogonal API
#if !__has_include(<ActsExamples/EventData/SpacePointContainer.hpp>)
/// Adapter to wrap a collection of space points for use with Acts::SpacePointContainer.
/// This replaces ActsExamples::SpacePointContainer<T>, which was removed in Acts >= 46
/// (see https://github.com/acts-project/acts/pull/5088).
template <typename collection_t> class SpacePointContainerAdapter {
public:
  using CollectionType = collection_t;
  using ValueType      = typename CollectionType::value_type;

  friend class Acts::SpacePointContainer<SpacePointContainerAdapter<collection_t>,
                                         Acts::detail::RefHolder>;

  SpacePointContainerAdapter() = delete;
  explicit SpacePointContainerAdapter(CollectionType& container) : m_storage(container) {}

private:
  std::size_t size_impl() const { return storage().size(); }
  float x_impl(std::size_t idx) const { return storage()[idx]->x(); }
  float y_impl(std::size_t idx) const { return storage()[idx]->y(); }
  float z_impl(std::size_t idx) const { return storage()[idx]->z(); }
  float varianceR_impl(std::size_t idx) const { return storage()[idx]->varianceR(); }
  float varianceZ_impl(std::size_t idx) const { return storage()[idx]->varianceZ(); }
  const ValueType& get_impl(std::size_t idx) const { return storage()[idx]; }
  std::any component_impl(Acts::HashedString /*key*/, std::size_t /*n*/) const {
    throw std::runtime_error(
        "SpacePointContainerAdapter does not support detailed double measurement "
        "information (useDetailedDoubleMeasurementInfo). Use Acts::SpacePointContainer2 "
        "if this feature is required.");
  }

  const CollectionType& storage() const { return *m_storage; }

  Acts::detail::RefHolder<CollectionType> m_storage;
};
#endif
#endif // TRACKSEEDING_HAS_ORTHOGONAL

namespace trackseeding_detail {

#if TRACKSEEDING_HAS_SEEDING2 || TRACKSEEDING_HAS_SEEDING
  struct SeedingData {
    std::shared_ptr<const Acts::Logger> actsLogger{nullptr};
    Acts::BroadTripletSeedFilter::Config filterConfig;
    std::optional<Acts::TripletSeeder> seedFinder;
    std::unique_ptr<Acts::DoubletSeedFinder> bottomDoubletFinder{nullptr};
    std::unique_ptr<Acts::DoubletSeedFinder> topDoubletFinder{nullptr};
    std::unique_ptr<Acts::TripletSeedFinder> tripletFinder{nullptr};
  };
#endif

#if TRACKSEEDING_HAS_ORTHOGONAL
  template <typename proxy_t> struct OrthogonalDataT {
    std::shared_ptr<const Acts::Logger> actsLogger{nullptr};
    Acts::SeedFilterConfig seedFilterConfig;
    Acts::SeedFinderOptions seedFinderOptions;
    Acts::SeedFinderOrthogonalConfig<proxy_t> seedFinderConfig;
  };
#endif

} // namespace trackseeding_detail

using TrackSeedingAlgorithm = algorithms::Algorithm<
    algorithms::Input<edm4eic::TrackerHitCollection>,
    algorithms::Output<edm4eic::TrackSeedCollection, edm4eic::TrackParametersCollection>>;

/// Track seeding algorithm with automatic implementation selection based on Acts version.
/// - seedingMethod=Auto: uses Seeding2 when available, otherwise Orthogonal
/// - seedingMethod can also force a specific implementation when it is compiled in
class TrackSeeding : public TrackSeedingAlgorithm, public WithPodConfig<TrackSeedingConfig> {
public:
#if TRACKSEEDING_HAS_ORTHOGONAL
  // Orthogonal API types
#if __has_include(<ActsExamples/EventData/SpacePointContainer.hpp>)
  using SpacePointContainerType = ActsExamples::SpacePointContainer<std::vector<const SpacePoint*>>;
#else
  using SpacePointContainerType = SpacePointContainerAdapter<std::vector<const SpacePoint*>>;
#endif
  using proxy_type =
      typename Acts::SpacePointContainer<SpacePointContainerType,
                                         Acts::detail::RefHolder>::SpacePointProxyType;
#endif

  TrackSeeding(std::string_view name)
      : TrackSeedingAlgorithm{name,
                              {"inputTrackerHits"},
                              {"outputTrackSeeds", "outputTrackParameters"},
                              "create track seeds from tracker hits"}
#if TRACKSEEDING_HAS_SEEDING2 && TRACKSEEDING_HAS_ORTHOGONAL
      , m_seedingData(std::in_place_type<SeedingData>) // Default to Seeding2 when both available
#endif
  {
  }

  void init() final;
  void process(const Input&, const Output&) const final;

private:
  const algorithms::ActsSvc& m_actsSvc{algorithms::ActsSvc::instance()};
  const std::shared_ptr<const ActsGeometryProvider> m_geoSvc{m_actsSvc.acts_geometry_provider()};

#if TRACKSEEDING_HAS_SEEDING2 || TRACKSEEDING_HAS_SEEDING
  using SeedingData = trackseeding_detail::SeedingData;
#endif

#if TRACKSEEDING_HAS_ORTHOGONAL
  using OrthogonalData = trackseeding_detail::OrthogonalDataT<proxy_type>;
#endif

#if TRACKSEEDING_HAS_SEEDING2 && TRACKSEEDING_HAS_ORTHOGONAL
  // Both methods available: Use runtime dispatch with variant
  std::variant<SeedingData, OrthogonalData> m_seedingData;

  // Helper to access Seeding2 logger
  const Acts::Logger& actsLogger() const {
    return *std::get<SeedingData>(m_seedingData).actsLogger;
  }
#elif TRACKSEEDING_HAS_SEEDING2 || TRACKSEEDING_HAS_SEEDING
  // Only Seeding2 available
  SeedingData m_seedingData;

  const Acts::Logger& actsLogger() const { return *m_seedingData.actsLogger; }
#elif TRACKSEEDING_HAS_ORTHOGONAL
  // Only Orthogonal available
  OrthogonalData m_seedingData;

  const Acts::Logger& actsLogger() const { return *m_seedingData.actsLogger; }
#else
#error "No seeding method available - check Acts version compatibility"
#endif

  // Resolved seeding method (after resolving Auto)
  TrackSeedingConfig::SeedingMethod m_resolvedMethod;

  // Shared helper functions (used by both implementations)
  static int determineCharge(std::vector<std::pair<float, float>>& positions,
                             const std::pair<float, float>& PCA,
                             std::tuple<float, float, float>& RX0Y0);
  static std::pair<float, float> findPCA(std::tuple<float, float, float>& circleParams);
  static std::tuple<float, float, float> circleFit(std::vector<std::pair<float, float>>& positions);
  static std::tuple<float, float> lineFit(std::vector<std::pair<float, float>>& positions);

  // Shared core physics calculation for track parameter estimation
  static std::optional<edm4eic::MutableTrackParameters> computeTrackParametersFromFit(
      const std::vector<std::pair<float, float>>& xyPositions,
      const std::vector<std::pair<float, float>>& rzPositions, float vertexZ, float bFieldInZ,
      const std::shared_ptr<const ActsGeometryProvider>& geoSvc, const TrackSeedingConfig& cfg);

#if TRACKSEEDING_HAS_SEEDING2 || TRACKSEEDING_HAS_SEEDING
  // Seeding2-specific: track parameter estimation from space point positions
  static std::optional<edm4eic::MutableTrackParameters>
  estimateTrackParamsFromSeed(const std::array<std::array<float, 3>, 3>& spPositions, float vertexZ,
                              float beamPosX, float beamPosY, float bFieldInZ,
                              const std::shared_ptr<const ActsGeometryProvider>& geoSvc,
                              const TrackSeedingConfig& cfg);
#endif

#if TRACKSEEDING_HAS_ORTHOGONAL
  // Orthogonal-specific: track parameter estimation from Acts::Seed
  std::optional<edm4eic::MutableTrackParameters>
  estimateTrackParamsFromSeed(const Acts::Seed<SpacePoint>& seed) const;
  static std::vector<const eicrecon::SpacePoint*>
  getSpacePoints(const edm4eic::TrackerHitCollection& trk_hits);
#endif
};
} // namespace eicrecon
