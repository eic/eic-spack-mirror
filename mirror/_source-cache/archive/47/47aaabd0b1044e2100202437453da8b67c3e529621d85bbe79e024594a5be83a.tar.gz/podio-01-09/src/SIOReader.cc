#include "podio/SIOReader.h"
#include "podio/podioVersion.h"
#include "podio/utilities/DatamodelRegistryIOHelpers.h"
#include "sioUtils.h"

#include <sio/api.h>
#include <sio/buffer.h>
#include <sio/definitions.h>

#include <cstdint>
#include <stdexcept>
#include <utility>

namespace podio {

SIOReader::SIOReader() {
  loadSIOBlocksLibraries();
}

void SIOReader::openFile(const std::string& filename) {
  if (m_stream.is_open()) {
    throw std::logic_error("SIOReader: a file has already been opened with this reader");
  }
  m_stream.open(filename, std::ios::binary);
  if (!m_stream.is_open()) {
    throw std::runtime_error("File " + filename + " couldn't be opened");
  }

  // NOTE: reading TOC record first because that jumps back to the start of the file!
  readFileTOCRecord();
  // Filter the available records from the TOC to remove records that are
  // stored, but use reserved record names for podio meta data
  const auto recordNames = m_tocRecord.getRecordNames();
  m_availableCategories.clear();
  m_availableCategories.reserve(recordNames.size());
  for (const auto recordName : recordNames) {
    if (recordName != sio_helpers::SIOEDMDefinitionName) {
      m_availableCategories.emplace_back(recordName);
    }
  }
  readPodioHeader();
  readEDMDefinitions(); // Potentially could do this lazily
}

std::unique_ptr<SIOFrameData> SIOReader::readNextEntry(std::string_view name,
                                                       const std::vector<std::string>& collsToRead) {
  // Skip to where the next record of this name starts in the file, based on
  // how many times we have already read this name
  //
  // NOTE: exploiting the fact that the operator[] of a map will create a
  // default initialized entry for us if not present yet
  const std::string nameStr(name);
  const auto recordPos = m_tocRecord.getPosition(name, m_nameCtr[nameStr]);
  if (recordPos == 0) {
    return nullptr;
  }
  m_stream.seekg(recordPos);

  auto [tableBuffer, tableInfo] = sio_utils::readRecord(m_stream, false);
  auto [dataBuffer, dataInfo] = sio_utils::readRecord(m_stream, false);

  m_nameCtr[nameStr]++;

  return std::make_unique<SIOFrameData>(std::move(dataBuffer), dataInfo._uncompressed_length, std::move(tableBuffer),
                                        tableInfo._uncompressed_length, collsToRead);
}

std::unique_ptr<SIOFrameData> SIOReader::readEntry(std::string_view name, const unsigned entry,
                                                   const std::vector<std::string>& collsToRead) {
  // NOTE: Will create or overwrite the entry counter
  //       All checks are done in the following function
  m_nameCtr[std::string(name)] = entry;
  return readNextEntry(name, collsToRead);
}

unsigned SIOReader::getEntries(std::string_view name) const {
  return m_tocRecord.getNRecords(name);
}

bool SIOReader::readFileTOCRecord() {
  // Check if there is a dedicated marker at the end of the file that tells us
  // where the TOC actually starts
  m_stream.seekg(-sio_helpers::SIOTocInfoSize, std::ios_base::end);
  uint64_t firstWords{0};
  m_stream.read(reinterpret_cast<char*>(&firstWords), sizeof(firstWords));

  const uint32_t marker = (firstWords >> 32) & 0xffffffff;
  if (marker == sio_helpers::SIOTocMarker) {
    const uint32_t position = firstWords & 0xffffffff;
    m_stream.seekg(position);

    const auto& [uncBuffer, _] = sio_utils::readRecord(m_stream);

    sio::block_list blocks;
    auto tocBlock = std::make_shared<SIOFileTOCRecordBlock>();
    tocBlock->record = &m_tocRecord;
    blocks.push_back(tocBlock);

    sio::api::read_blocks(uncBuffer.span(), blocks);

    m_stream.seekg(0);
    return true;
  }

  m_stream.clear();
  m_stream.seekg(0);
  return false;
}

void SIOReader::readPodioHeader() {
  const auto& [buffer, _] = sio_utils::readRecord(m_stream, false, sizeof(podio::version::Version));

  sio::block_list blocks;
  blocks.emplace_back(std::make_shared<SIOVersionBlock>());
  sio::api::read_blocks(buffer.span(), blocks);

  m_fileVersion = static_cast<SIOVersionBlock*>(blocks[0].get())->version;
}

void SIOReader::readEDMDefinitions() {
  const auto recordPos = m_tocRecord.getPosition(sio_helpers::SIOEDMDefinitionName);
  if (recordPos == 0) {
    // No EDM definitions found
    return;
  }
  m_stream.seekg(recordPos);

  const auto& [buffer, _] = sio_utils::readRecord(m_stream);

  sio::block_list blocks;
  blocks.emplace_back(std::make_shared<podio::SIOMapBlock<std::string, std::string>>());
  blocks.emplace_back(std::make_shared<podio::SIOMapBlock<std::string, podio::version::Version>>());

  sio::api::read_blocks(buffer.span(), blocks);

  auto datamodelDefs = static_cast<SIOMapBlock<std::string, std::string>*>(blocks[0].get());
  auto edmVersions = static_cast<SIOMapBlock<std::string, podio::version::Version>*>(blocks[1].get());
  m_datamodelHolder = DatamodelDefinitionHolder(std::move(datamodelDefs->mapData), std::move(edmVersions->mapData));
}

} // namespace podio
