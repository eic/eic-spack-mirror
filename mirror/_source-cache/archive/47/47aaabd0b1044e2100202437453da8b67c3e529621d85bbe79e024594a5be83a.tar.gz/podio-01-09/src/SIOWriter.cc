#include "podio/SIOWriter.h"
#include "podio/DatamodelRegistry.h"
#include "podio/Frame.h"
#include "podio/SIOBlock.h"
#include "podio/podioVersion.h"
#include "podio/utilities/DatamodelRegistryIOHelpers.h"
#include "sioUtils.h"

#include <sio/exception.h>

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <tuple>
#include <utility>

namespace podio {

SIOWriter::SIOWriter(const std::string& filename) {
  m_stream.open(filename, std::ios::binary);
  if (!m_stream.is_open()) {
    SIO_THROW(sio::error_code::not_open, "Couldn't open output stream '" + filename + "'");
  }

  loadSIOBlocksLibraries();

  sio::block_list blocks;
  blocks.emplace_back(std::make_shared<SIOVersionBlock>(podio::version::build_version));
  // write the version uncompressed
  sio_utils::writeRecord(blocks, "podio_header_info", m_stream, sizeof(podio::version::Version), false);
}

SIOWriter::~SIOWriter() {
  finish();
}

void SIOWriter::writeFrame(const podio::Frame& frame, std::string_view category) {
  writeFrame(frame, category, frame.getAvailableCollections());
}

void SIOWriter::writeFrame(const podio::Frame& frame, std::string_view category,
                           const std::vector<std::string>& collsToWrite) {
  std::vector<sio_utils::StoreCollection> collections;
  collections.reserve(collsToWrite.size());
  for (const auto& name : collsToWrite) {
    collections.emplace_back(name, frame.getCollectionForWrite(name));
    m_datamodelCollector.registerDatamodelDefinition(collections.back().second, name);
  }

  // Write necessary metadata and the actual data into two different records.
  // Otherwise we cannot easily unpack the data record, because necessary
  // information is contained within the record.
  const std::string catStr(category);
  sio::block_list tableBlocks;
  tableBlocks.emplace_back(sio_utils::createCollIDBlock(collections, frame.getCollectionIDTableForWrite()));
  m_tocRecord.addRecord(catStr, sio_utils::writeRecord(tableBlocks, catStr + "_HEADER", m_stream));

  const auto blocks = sio_utils::createBlocks(collections, frame.getParameters());
  sio_utils::writeRecord(blocks, catStr, m_stream);
}

void SIOWriter::finish() {
  if (!m_stream.is_open()) {
    return;
  }
  auto edmDefMap = std::make_shared<podio::SIOMapBlock<std::string, std::string>>(
      m_datamodelCollector.getDatamodelDefinitionsToWrite());

  sio::block_list blocks;
  blocks.push_back(edmDefMap);

  DatamodelDefinitionHolder::VersionList edmVersions;
  for (const auto& [name, _] : edmDefMap->mapData) {
    auto edmVersion = podio::DatamodelRegistry::instance().getDatamodelVersion(name);
    if (edmVersion) {
      edmVersions.emplace_back(name, edmVersion.value());
    }
  }

  auto edmVersionMap =
      std::make_shared<podio::SIOMapBlock<std::string, podio::version::Version>>(std::move(edmVersions));
  blocks.push_back(edmVersionMap);

  m_tocRecord.addRecord(sio_helpers::SIOEDMDefinitionName, sio_utils::writeRecord(blocks, "EDMDefinitions", m_stream));

  blocks.clear();
  blocks.emplace_back(std::make_shared<SIOFileTOCRecordBlock>(&m_tocRecord));

  auto tocStartPos = sio_utils::writeRecord(blocks, sio_helpers::SIOTocRecordName, m_stream);

  // Now that we know the position of the TOC Record, put this information
  // into a final marker that can be identified and interpreted when reading
  // again
  uint64_t finalWords = (((uint64_t)sio_helpers::SIOTocMarker) << 32) | ((uint64_t)tocStartPos & 0xffffffff);
  m_stream.write(reinterpret_cast<char*>(&finalWords), sizeof(finalWords));

  m_stream.close();
}

} // namespace podio
