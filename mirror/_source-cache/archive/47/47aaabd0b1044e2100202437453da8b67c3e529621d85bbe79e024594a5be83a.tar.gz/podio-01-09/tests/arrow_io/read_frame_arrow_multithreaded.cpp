#include "read_frame_multithreaded.h"

#include "podio/ArrowReader.h"

#include <cstdlib>
#include <string>

int main(int argc, char* argv[]) {
  int nThreads = 4;
  int framesPerThread = 10;
  if (argc >= 2) {
    nThreads = std::atoi(argv[1]);
  }
  if (argc >= 3) {
    framesPerThread = std::atoi(argv[2]);
  }

  const unsigned expectedEntries = nThreads * framesPerThread;
  return read_frames_multithreaded<podio::ArrowReader>("example_frame_arrow_multithreaded.podio_parquet", nThreads,
                                                       expectedEntries);
}
