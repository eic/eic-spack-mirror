#ifndef PODIO_ARROWREADER_H
#define PODIO_ARROWREADER_H

#include "podio/utilities/ArrowFrameData.h"
#include "podio/utilities/ReaderCommon.h"
#include "podio/utilities/StringKeyMap.h"

#include <cstddef>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

namespace arrow {
class Table;
class Schema;
} // namespace arrow

namespace podio {

/// Arrow backend reader for PODIO
///
/// Reads data from a directory structure containing one Parquet file per category
/// and a metadata.json file containing metadata for reading.
class ArrowReader : public ReaderCommon {
public:
  /// Create an ArrowReader
  ArrowReader();

  /// Open the passed directory for reading.
  ///
  /// @param directory The path to the directory to read from
  ///
  /// @throws std::logic_error if a directory has already been opened with this reader
  void openFile(const std::string& directory);

  ~ArrowReader() = default;

  ArrowReader(const ArrowReader&) = delete;
  ArrowReader& operator=(const ArrowReader&) = delete;
  ArrowReader(ArrowReader&&) = delete;
  ArrowReader& operator=(ArrowReader&&) = delete;

  /// Read the next entry for the given category
  std::unique_ptr<podio::ArrowFrameData> readNextEntry(std::string_view name,
                                                       const std::vector<std::string>& collsToRead = {});

  /// Read the specific entry for the given category
  std::unique_ptr<podio::ArrowFrameData> readEntry(std::string_view name, size_t index,
                                                   const std::vector<std::string>& collsToRead = {});

  /// Get the number of entries for a category
  size_t getEntries(std::string_view name) const;

private:
  struct CategoryInfo {
    std::string filePath{};
    size_t entries = 0;
    size_t currentIndex = 0;
    std::shared_ptr<arrow::Table> table{nullptr};
    bool allColumnsLoaded{false};                       ///< Whether the complete table containing all columns is loaded
    std::shared_ptr<arrow::Schema> fullSchema{nullptr}; ///< Full file schema containing all fields and metadata
  };

  /// Load the arrow::Table for the given category, selectively projecting only
  /// requested collections if collsToRead is specified
  void loadCategoryTable(CategoryInfo& catInfo, const std::vector<std::string>& collsToRead = {});

  std::string m_directory{};
  podio::StringKeyMap<CategoryInfo> m_categories{};
};

} // namespace podio

#endif // PODIO_ARROWREADER_H
