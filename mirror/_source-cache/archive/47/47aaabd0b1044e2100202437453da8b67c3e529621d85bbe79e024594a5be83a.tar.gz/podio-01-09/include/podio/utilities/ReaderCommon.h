#ifndef PODIO_UTILITIES_READERCOMMON_H
#define PODIO_UTILITIES_READERCOMMON_H

#include "podio/podioVersion.h"
#include "podio/utilities/DatamodelRegistryIOHelpers.h"

#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace podio {

/// Common base class for podio reader classes providing the shared members and
/// functionality related to the file version and the datamodel definitions.
///
/// The population of the members is left to the derived reader classes.
class ReaderCommon {
public:
  /// Get the build version of podio that has been used to write the current
  /// file
  ///
  /// @returns The podio build version
  podio::version::Version currentFileVersion() const {
    return m_fileVersion;
  }

  /// Get the (build) version of a datamodel that has been used to write the
  /// current file
  ///
  /// @param name The name of the datamodel
  ///
  /// @returns The (build) version of the datamodel if available or an empty
  ///          optional
  std::optional<podio::version::Version> currentFileVersion(std::string_view name) const {
    return m_datamodelHolder.getDatamodelVersion(name);
  }

  /// Get the datamodel definition for the given name
  ///
  /// @param name The name of the datamodel
  ///
  /// @returns The high level definition of the datamodel in JSON format
  const std::string_view getDatamodelDefinition(std::string_view name) const {
    return m_datamodelHolder.getDatamodelDefinition(name);
  }

  /// Get all names of the datamodels that are available from this reader
  ///
  /// @returns The names of the datamodels
  std::vector<std::string> getAvailableDatamodels() const {
    return m_datamodelHolder.getAvailableDatamodels();
  }

  /// Get the names of all the available Frame categories in the current file(s).
  ///
  /// @returns The names of the available categories from the file
  std::vector<std::string_view> getAvailableCategories() const {
    return std::vector<std::string_view>(m_availableCategories.cbegin(), m_availableCategories.cend());
  }

protected:
  podio::version::Version m_fileVersion{};
  DatamodelDefinitionHolder m_datamodelHolder{};
  std::vector<std::string> m_availableCategories{};
};

} // namespace podio

#endif // PODIO_UTILITIES_READERCOMMON_H
