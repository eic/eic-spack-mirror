#ifndef PODIO_RELATIONRANGE_H
#define PODIO_RELATIONRANGE_H

#include <ranges>
#include <vector>

namespace podio {
/// A simple helper class that allows one to return related objects in a way that
/// makes it possible to use the return type in a range-based for loop.
template <typename ReferenceType>
class RelationRange {
public:
  using ConstIteratorType = typename std::vector<ReferenceType>::const_iterator;

  RelationRange() = delete;

  constexpr RelationRange(ConstIteratorType begin, ConstIteratorType end) :
      m_begin(begin), m_end(end), m_size(std::distance(m_begin, m_end)) {
  }

  /// begin of the range (necessary for range-based for loop)
  constexpr ConstIteratorType begin() const {
    return m_begin;
  }
  /// end of the range (necessary for range-based for loop)
  constexpr ConstIteratorType end() const {
    return m_end;
  }
  /// constant begin of the range
  constexpr ConstIteratorType cbegin() const {
    return begin();
  }
  /// constant end of the range
  constexpr ConstIteratorType cend() const {
    return end();
  }
  /// convenience overload for size
  constexpr size_t size() const {
    return m_size;
  }
  /// convenience overload to check if the range is empty
  constexpr bool empty() const {
    return m_begin == m_end;
  }
  /// check whether the range is not empty
  constexpr explicit operator bool() const {
    return !empty();
  }
  /// Indexed access
  constexpr ReferenceType operator[](size_t i) const {
    auto it = m_begin;
    std::advance(it, i);
    return *it;
  }
  /// First element of the range
  constexpr ReferenceType front() const {
    return *m_begin;
  }
  /// Last element of the range
  constexpr ReferenceType back() const {
    return *(m_end - 1);
  }

  /// Indexed access with range check
  ReferenceType at(size_t i) const {
    if (i < m_size) {
      auto it = m_begin;
      std::advance(it, i);
      return *it;
    }
    throw std::out_of_range("index out of bounds for RelationRange");
  }

private:
  ConstIteratorType m_begin;
  ConstIteratorType m_end;
  size_t m_size{0};
};
} // namespace podio

// Opt-in to view concept
template <typename ReferenceType>
inline constexpr bool std::ranges::enable_view<podio::RelationRange<ReferenceType>> = true;
// Opt-in to borrowed_range concept
template <typename ReferenceType>
inline constexpr bool std::ranges::enable_borrowed_range<podio::RelationRange<ReferenceType>> = true;

#endif // PODIO_RELATIONRANGE_H
