// SPDX-License-Identifier: LGPL-2.1-or-later
// Copyright (C) 2026 G4OCCT Contributors

/// @file TGeoOCCTSolid.cc
/// @brief ROOT/TGeo adapter over the shared G4OCCT solid-query kernel.

#include "G4OCCT/TGeoOCCTSolid.hh"

#include "TGeoOCCTSolidBridge.hh"

#include <TBuffer3D.h>
#include <TError.h>
#include <TGeoBBox.h>
#include <TGeoTessellated.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <stdexcept>

namespace {

double ClampDistanceToStep(const double dist, const double step, const double infinityCm) {
  const double boundedStep = std::max(0.0, std::min(step, TGeoShape::Big()));
  if (std::isinf(dist) || dist >= 0.5 * infinityCm) {
    return boundedStep;
  }
  return std::min(dist, boundedStep);
}

} // namespace

TGeoOCCTSolid::TGeoOCCTSolid() = default;

TGeoOCCTSolid::TGeoOCCTSolid(const char* name, const TopoDS_Shape& shape)
    : TGeoShape(name), fBridge(std::make_unique<g4occt::detail::TGeoOCCTSolidBridge>(shape)) {}

TGeoOCCTSolid::~TGeoOCCTSolid() = default;

TGeoOCCTSolid* TGeoOCCTSolid::FromSTEP(const char* name, const std::string& path) {
  auto result = std::unique_ptr<TGeoOCCTSolid>(new TGeoOCCTSolid());
  result->SetName(name);
  result->fBridge = g4occt::detail::TGeoOCCTSolidBridge::FromSTEP(name, path);
  return result.release();
}

Double_t TGeoOCCTSolid::Capacity() const { return fBridge ? fBridge->CapacityCm3() : 0.0; }

void TGeoOCCTSolid::ComputeBBox() {}

void TGeoOCCTSolid::ComputeNormal(const Double_t* point, const Double_t* /*dir*/,
                                  Double_t* norm) const {
  if (!fBridge) {
    norm[0] = 0.0;
    norm[1] = 0.0;
    norm[2] = 1.0;
    return;
  }
  fBridge->SurfaceNormalCm(point, norm);
}

Bool_t TGeoOCCTSolid::Contains(const Double_t* point) const {
  if (!fBridge) {
    return kFALSE;
  }
  const auto classification = fBridge->ClassifyCm(point);
  return classification != g4occt::detail::TGeoOCCTSolidBridge::PointClassification::kOutside;
}

Bool_t TGeoOCCTSolid::CouldBeCrossed(const Double_t* point, const Double_t* dir) const {
  auto bbox = BuildBBoxHelper();
  return bbox.CouldBeCrossed(point, dir);
}

Int_t TGeoOCCTSolid::DistancetoPrimitive(Int_t px, Int_t py) {
  auto bbox = BuildBBoxHelper();
  return bbox.DistancetoPrimitive(px, py);
}

Double_t TGeoOCCTSolid::DistFromInside(const Double_t* point, const Double_t* dir, Int_t /*iact*/,
                                       Double_t step, Double_t* safe) const {
  if (!fBridge) {
    return std::max(0.0, std::min(step, TGeoShape::Big()));
  }
  const double dist = fBridge->DistFromInsideCm(point, dir, safe);
  return ClampDistanceToStep(dist, step, g4occt::detail::TGeoOCCTSolidBridge::InfinityCm());
}

Double_t TGeoOCCTSolid::DistFromOutside(const Double_t* point, const Double_t* dir, Int_t /*iact*/,
                                        Double_t step, Double_t* safe) const {
  if (!fBridge) {
    return std::max(0.0, std::min(step, TGeoShape::Big()));
  }
  const double dist = fBridge->DistFromOutsideCm(point, dir, safe);
  return ClampDistanceToStep(dist, step, g4occt::detail::TGeoOCCTSolidBridge::InfinityCm());
}

TGeoVolume* TGeoOCCTSolid::Divide(TGeoVolume* /*voldiv*/, const char* /*divname*/, Int_t /*iaxis*/,
                                  Int_t /*ndiv*/, Double_t /*start*/, Double_t /*step*/) {
  Error("Divide", "TGeoOCCTSolid does not support ROOT volume divisions");
  return nullptr;
}

const char* TGeoOCCTSolid::GetAxisName(Int_t iaxis) const {
  auto bbox = BuildBBoxHelper();
  return bbox.GetAxisName(iaxis);
}

Double_t TGeoOCCTSolid::GetAxisRange(Int_t iaxis, Double_t& xlo, Double_t& xhi) const {
  auto bbox = BuildBBoxHelper();
  return bbox.GetAxisRange(iaxis, xlo, xhi);
}

void TGeoOCCTSolid::GetBoundingCylinder(Double_t* param) const {
  auto bbox = BuildBBoxHelper();
  bbox.GetBoundingCylinder(param);
}

const TBuffer3D& TGeoOCCTSolid::GetBuffer3D(Int_t reqSections, Bool_t localFrame) const {
  EnsureDisplayHelper();
  return fDisplayHelper->GetBuffer3D(reqSections, localFrame);
}

Int_t TGeoOCCTSolid::GetByteCount() const { return 6 * static_cast<Int_t>(sizeof(Double_t)); }

Bool_t TGeoOCCTSolid::GetPointsOnSegments(Int_t npoints, Double_t* array) const {
  EnsureDisplayHelper();
  return fDisplayHelper->GetPointsOnSegments(npoints, array);
}

Int_t TGeoOCCTSolid::GetFittingBox(const TGeoBBox* parambox, TGeoMatrix* mat, Double_t& dx,
                                   Double_t& dy, Double_t& dz) const {
  auto bbox = BuildBBoxHelper();
  return bbox.GetFittingBox(parambox, mat, dx, dy, dz);
}

void TGeoOCCTSolid::GetMeshNumbers(Int_t& nvert, Int_t& nsegs, Int_t& npols) const {
  EnsureDisplayHelper();
  fDisplayHelper->GetMeshNumbers(nvert, nsegs, npols);
}

TGeoShape* TGeoOCCTSolid::GetMakeRuntimeShape(TGeoShape* /*mother*/, TGeoMatrix* /*mat*/) const {
  if (!fBridge) {
    return nullptr;
  }
  auto* runtime = new TGeoOCCTSolid(GetName(), GetOCCTShape());
  runtime->SetRuntime();
  return runtime;
}

Bool_t TGeoOCCTSolid::IsCylType() const { return kFALSE; }

Bool_t TGeoOCCTSolid::IsValidBox() const {
  auto bbox = BuildBBoxHelper();
  return bbox.IsValidBox();
}

void TGeoOCCTSolid::InspectShape() const {
  if (!fBridge) {
    Info("InspectShape", "Uninitialized TGeoOCCTSolid");
    return;
  }
  const auto bounds = fBridge->Bounds();
  EnsureDisplayHelper();
  Int_t nvert = 0;
  Int_t nsegs = 0;
  Int_t npols = 0;
  fDisplayHelper->GetMeshNumbers(nvert, nsegs, npols);
  Info("InspectShape",
       "TGeoOCCTSolid '%s' bbox=(dx=%g, dy=%g, dz=%g) cm origin=(%g,%g,%g) cm mesh=(nvert=%d, "
       "nsegs=%d, npols=%d)",
       GetName(), bounds.dx, bounds.dy, bounds.dz, bounds.origin[0], bounds.origin[1],
       bounds.origin[2], nvert, nsegs, npols);
}

TBuffer3D* TGeoOCCTSolid::MakeBuffer3D() const {
  EnsureDisplayHelper();
  return fDisplayHelper->MakeBuffer3D();
}

Double_t TGeoOCCTSolid::Safety(const Double_t* point, Bool_t in) const {
  return fBridge ? fBridge->SafetyCm(point, in == kTRUE) : 0.0;
}

void TGeoOCCTSolid::SetDimensions(Double_t* /*param*/) {
  Error("SetDimensions",
        "TGeoOCCTSolid does not support parameterized dimension mutation; use SetOCCTShape");
}

void TGeoOCCTSolid::SetPoints(Double_t* points) const {
  EnsureDisplayHelper();
  fDisplayHelper->SetPoints(points);
}

void TGeoOCCTSolid::SetPoints(Float_t* points) const {
  EnsureDisplayHelper();
  fDisplayHelper->SetPoints(points);
}

void TGeoOCCTSolid::SetSegsAndPols(TBuffer3D& buff) const {
  EnsureDisplayHelper();
  fDisplayHelper->SetSegsAndPols(buff);
}

void TGeoOCCTSolid::Sizeof3D() const {
  EnsureDisplayHelper();
  fDisplayHelper->Sizeof3D();
}

const TopoDS_Shape& TGeoOCCTSolid::GetOCCTShape() const {
  if (!fBridge) {
    throw std::runtime_error(
        "TGeoOCCTSolid::GetOCCTShape called on an uninitialized TGeoOCCTSolid");
  }
  return fBridge->Shape();
}

void TGeoOCCTSolid::SetOCCTShape(const TopoDS_Shape& shape) {
  if (!fBridge) {
    fBridge = std::make_unique<g4occt::detail::TGeoOCCTSolidBridge>(shape);
  } else {
    fBridge->SetShape(shape);
  }
  fDisplayHelper.reset();
  fDisplayGeneration = std::numeric_limits<std::uint64_t>::max();
}

TGeoBBox TGeoOCCTSolid::BuildBBoxHelper() const {
  if (!fBridge) {
    Double_t origin[3] = {0.0, 0.0, 0.0};
    return TGeoBBox(0.0, 0.0, 0.0, origin);
  }
  const auto bounds  = fBridge->Bounds();
  Double_t origin[3] = {bounds.origin[0], bounds.origin[1], bounds.origin[2]};
  return TGeoBBox(bounds.dx, bounds.dy, bounds.dz, origin);
}

void TGeoOCCTSolid::EnsureDisplayHelper() const {
  if (!fBridge) {
    if (!fDisplayHelper) {
      fDisplayHelper = std::make_unique<TGeoTessellated>(GetName(), 0);
      fDisplayHelper->CloseShape(true, true, false);
    }
    return;
  }

  const std::uint64_t generation = fBridge->ShapeGeneration();
  if (fDisplayHelper && fDisplayGeneration == generation) {
    return;
  }

  const auto mesh = fBridge->DisplayMesh();
  if (mesh->triangles.size() > static_cast<std::size_t>(std::numeric_limits<int>::max())) {
    throw std::runtime_error("TGeoOCCTSolid::EnsureDisplayHelper mesh exceeds TGeoTessellated "
                             "facet-count limit");
  }
  auto helper =
      std::make_unique<TGeoTessellated>(GetName(), static_cast<int>(mesh->triangles.size()));
  for (const auto& tri : mesh->triangles) {
    helper->AddFacet(TGeoTessellated::Vertex_t(tri.p1[0], tri.p1[1], tri.p1[2]),
                     TGeoTessellated::Vertex_t(tri.p2[0], tri.p2[1], tri.p2[2]),
                     TGeoTessellated::Vertex_t(tri.p3[0], tri.p3[1], tri.p3[2]));
  }
  helper->CloseShape(true, true, false);
  fDisplayHelper     = std::move(helper);
  fDisplayGeneration = generation;
}
