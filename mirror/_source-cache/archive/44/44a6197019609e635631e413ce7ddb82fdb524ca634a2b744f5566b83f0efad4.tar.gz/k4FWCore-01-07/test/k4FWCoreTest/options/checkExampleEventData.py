#!/usr/bin/env python3
#
# Copyright (c) 2014-2024 Key4hep-Project.
#
# This file is part of Key4hep.
# See https://key4hep.github.io/key4hep-doc/ for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from Gaudi.Configuration import INFO

from Configurables import EventDataSvc
from k4FWCore.parseArgs import parser
from Configurables import k4FWCoreTest_CheckExampleEventData
from k4FWCore import ApplicationMgr, IOSvc


parser.add_argument(
    "--collections",
    action="extend",
    nargs="?",
    help="The input collections to read",
    default=["VectorFloat", "MCParticles", "SimTrackerHits", "TrackerHits", "Tracks"],
)
my_args = parser.parse_known_args()[0]

iosvc = IOSvc()
iosvc.Input = "output_k4test_exampledata.root"
iosvc.CollectionNames = my_args.collections

checker = k4FWCoreTest_CheckExampleEventData()

ApplicationMgr(
    TopAlg=[checker],
    EvtSel="NONE",
    EvtMax=100,
    ExtSvc=[EventDataSvc()],
    OutputLevel=INFO,
    StopOnSignal=True,
)
