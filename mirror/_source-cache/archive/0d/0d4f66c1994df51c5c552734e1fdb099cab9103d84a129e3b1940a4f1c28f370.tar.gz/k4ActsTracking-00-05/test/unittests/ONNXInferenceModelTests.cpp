/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "catch2/catch_test_macros.hpp"
#include "catch2/matchers/catch_matchers_vector.hpp"

#include "ONNXInferenceModel.h"

#include <string>
#include <vector>

TEST_CASE("totalSize") {
  REQUIRE(mlutils::totalSize(42) == 1);
  REQUIRE(mlutils::totalSize(std::vector{1.23f, 2.34f}) == 2);
  REQUIRE(mlutils::totalSize(std::vector<int>{}) == 0);
  REQUIRE(mlutils::totalSize(std::vector<std::vector<int>>{{1, 2}, {3, 4, 5}}) == 5);
  REQUIRE(mlutils::totalSize(
              std::vector<std::vector<std::vector<float>>>{{{1.0f, 2.0f}, {3.0f}}, {{4.0f, 5.0f, 6.0f}}}) == 6);
}

TEST_CASE("flatten") {
  SECTION("scalar values") {
    auto output = mlutils::flatten(42);
    REQUIRE_THAT(output, Catch::Matchers::Equals(std::vector<int>{42}));
  }

  SECTION("1D vector") {
    std::vector<float> input{1.5f, 2.5f, 3.5f};
    auto               output = mlutils::flatten(input);
    REQUIRE_THAT(output, Catch::Matchers::Equals(std::vector<float>{1.5f, 2.5f, 3.5f}));
  }

  SECTION("empty vector") {
    std::vector<int> input{};
    auto             output = mlutils::flatten(input);
    REQUIRE(output.empty());
  }

  SECTION("2D vector") {
    std::vector<std::vector<int>> input{{1, 2}, {3, 4, 5}};
    auto                          output = mlutils::flatten(input);
    REQUIRE_THAT(output, Catch::Matchers::Equals(std::vector<int>{1, 2, 3, 4, 5}));
  }

  SECTION("3D vector") {
    std::vector<std::vector<std::vector<float>>> input{{{1.0f, 2.0f}, {3.0f}}, {{4.0f, 5.0f, 6.0f}}};
    auto                                         output = mlutils::flatten(input);
    REQUIRE_THAT(output, Catch::Matchers::Equals(std::vector<float>{1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f}));
  }
}

TEST_CASE("getDimensions") {
  SECTION("scalar values") {
    auto dims = mlutils::getDimensions(42);
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{}));
  }

  SECTION("1D vector") {
    std::vector<float> input{1.5f, 2.5f, 3.5f};
    auto               dims = mlutils::getDimensions(input);
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{3}));
  }

  SECTION("empty vector") {
    std::vector<int> input{};
    auto             dims = mlutils::getDimensions(input);
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{0}));
  }

  SECTION("2D vector - rectangular") {
    std::vector<std::vector<int>> input{{1, 2, 3}, {4, 5, 6}};
    auto                          dims = mlutils::getDimensions(input);
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{2, 3}));
  }

  SECTION("2D vector - jagged") {
    std::vector<std::vector<int>> input{{1, 2}, {3, 4, 5}};
    auto                          dims = mlutils::getDimensions(input);
    // NOTE here the "unexpected expected" result, due to the lack of validation
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{2, 2}));
  }

  SECTION("3D vector") {
    std::vector<std::vector<std::vector<float>>> input{{{1.0f, 2.0f}, {3.0f, 4.0f}}, {{5.0f, 6.0f}, {7.0f, 8.0f}}};
    auto                                         dims = mlutils::getDimensions(input);
    REQUIRE_THAT(dims, Catch::Matchers::Equals(std::vector<int64_t>{2, 2, 2}));
  }
}

TEST_CASE("parseList") {
  SECTION("strings") {
    REQUIRE_THAT(mlutils::parseList<std::string>("r,phi,z,t"),
                 Catch::Matchers::Equals(std::vector<std::string>{"r", "phi", "z", "t"}));
  }

  SECTION("surrounding whitespace is trimmed") {
    REQUIRE_THAT(mlutils::parseList<std::string>(" r , phi ,z "),
                 Catch::Matchers::Equals(std::vector<std::string>{"r", "phi", "z"}));
  }

  SECTION("empty elements are skipped") {
    REQUIRE_THAT(mlutils::parseList<std::string>("r,,phi,"),
                 Catch::Matchers::Equals(std::vector<std::string>{"r", "phi"}));
    REQUIRE(mlutils::parseList<std::string>("").empty());
    REQUIRE(mlutils::parseList<float>("  ").empty());
  }

  SECTION("numeric values") {
    REQUIRE_THAT(mlutils::parseList<float>("1, 2.5,1000"),
                 Catch::Matchers::Equals(std::vector<float>{1.0f, 2.5f, 1000.0f}));
    REQUIRE_THAT(mlutils::parseList<int>("1,-2,3"), Catch::Matchers::Equals(std::vector<int>{1, -2, 3}));
  }
}

TEST_CASE("parseMultiList") {
  SECTION("one list per entry") {
    const auto parsed = mlutils::parseMultiList<std::string>({"r,phi", "x,y,z"});
    REQUIRE(parsed.size() == 2);
    REQUIRE_THAT(parsed[0], Catch::Matchers::Equals(std::vector<std::string>{"r", "phi"}));
    REQUIRE_THAT(parsed[1], Catch::Matchers::Equals(std::vector<std::string>{"x", "y", "z"}));
  }

  SECTION("empty entries yield empty lists") {
    const auto parsed = mlutils::parseMultiList<float>({"1,2", ""});
    REQUIRE(parsed.size() == 2);
    REQUIRE_THAT(parsed[0], Catch::Matchers::Equals(std::vector<float>{1.0f, 2.0f}));
    REQUIRE(parsed[1].empty());
  }

  SECTION("empty input") { REQUIRE(mlutils::parseMultiList<std::string>({}).empty()); }
}

TEST_CASE("model metadata without a loaded model") {
  // The embedding dimension is read from the model metadata, so the accessors
  // have to stay safe before (or after a failed) loadModel.
  mlutils::ONNXInferenceModel model{"UnitTest"};

  REQUIRE(model.numInputs() == 0);
  REQUIRE(model.numOutputs() == 0);
  REQUIRE(model.inputShape(0).empty());
  REQUIRE(model.outputShape(0).empty());

  REQUIRE_FALSE(model.loadModel("this-file-does-not-exist.onnx"));
  REQUIRE(model.numInputs() == 0);
  REQUIRE(model.numOutputs() == 0);
  REQUIRE(model.inputShape(0).empty());
  REQUIRE(model.outputShape(0).empty());
}
