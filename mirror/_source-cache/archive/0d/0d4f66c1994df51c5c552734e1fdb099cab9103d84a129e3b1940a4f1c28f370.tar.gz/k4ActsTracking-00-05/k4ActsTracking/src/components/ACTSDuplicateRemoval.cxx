/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "k4ActsTracking/ACTSDuplicateRemoval.hxx"

// edm4hep
#include <edm4hep/MutableTrack.h>
#include <edm4hep/TrackerHit.h>

// Standard
#include <algorithm>

// ACTSTracking
#include "k4ActsTracking/Helpers.hxx"

namespace ACTSTracking {
  /**
 * @brief Return true if `trk1` and `trk2` share at least 50% of hits.
 * @param trk1 One of two tracks to compare
 * @param tkr2 One of two tracks to compare
 * @return True if they share too many of the same Tracker Hits
 */
  inline bool tracks_equal(const edm4hep::Track& trk1, const edm4hep::Track& trk2) {
    // Get an iterator for the Track hits of the first Track
    uint32_t hitOlap = 0;
    // Loop through each track hit and see if it overlaps with the second track
    for (size_t itrackHit = 0; itrackHit < trk1.trackerHits_size(); ++itrackHit) {
      auto it = std::find(trk2.trackerHits_begin(), trk2.trackerHits_end(), trk1.getTrackerHits(itrackHit));
      if (it != trk2.trackerHits_end()) {
        hitOlap++;  // If it does overlap, increment hitOlap
      }
    }

    // Smaller track count
    uint32_t size = std::min(trk1.trackerHits_size(), trk2.trackerHits_size());
    return 2 * hitOlap > size;  // half of smaller track belong to larger track
  }

  /**
 * @brief Determine which of two tracks is of better quality
 * @details Quality is determined first by number of hits, then by chi2
 * @param trk1 One of two tracks to compare
 * @param trk2 One of two tracks to compare
 * @return True if the first track is of better quality
 */
  bool track_quality_compare(const edm4hep::Track& trk1, const edm4hep::Track& trk2) {
    // If number of hits are different, then the one with more
    // hits should be chosen first
    if (trk1.trackerHits_size() != trk2.trackerHits_size())
      return trk1.trackerHits_size() > trk2.trackerHits_size();

    // Same number of hits means I want smaller chi2
    return trk1.getChi2() < trk2.getChi2();
  }

  /**
 * @brief Compares the tan(lambda) of two tracks. For ordering
 * @param trk1 One of two tracks to compare
 * @param trk2 One of two tracks to compare
 * @return True if the first track has lower tan(lambda) in the first track state
 */
  inline bool track_duplicate_compare(const edm4hep::Track& trk1, const edm4hep::Track& trk2) {
    // Order by the AtIP tanLambda, fetched by location. NB: getTrackStates(i) is
    // positional, so getTrackStates(AtIP) would return the wrong state (edm4hep
    // AtIP == 1, i.e. the first-hit state); getTrackState resolves it by the
    // `location` field. Tracks without an AtIP state sort as tanLambda 0,
    // keeping a valid strict-weak ordering for the stable_sort.
    const auto  ts1        = trk1.getTrackState(edm4hep::TrackState::AtIP);
    const auto  ts2        = trk2.getTrackState(edm4hep::TrackState::AtIP);
    const float tanLambda1 = ts1 ? ts1->tanLambda : 0.f;
    const float tanLambda2 = ts2 ? ts2->tanLambda : 0.f;
    return tanLambda1 < tanLambda2;
  }
}  // namespace ACTSTracking

DECLARE_COMPONENT(ACTSDuplicateRemoval)

ACTSDuplicateRemoval::ACTSDuplicateRemoval(const std::string& name, ISvcLocator* svcLoc)
    : Transformer(name, svcLoc, KeyValues("InputTrackCollectionName", {"TruthTracks"}),
                  KeyValues("OutputTrackCollectionName", {"DedupedTruthTracks"})) {}

edm4hep::TrackCollection ACTSDuplicateRemoval::operator()(const edm4hep::TrackCollection& trackCollection) const {
  // Make output collection
  edm4hep::TrackCollection outputTracks;
  outputTracks.setSubsetCollection();

  // Insertion sort input tracks
  std::vector<edm4hep::Track> sortedInput;
  sortedInput.reserve(trackCollection.size());
  for (const auto& track : trackCollection) {
    sortedInput.push_back(track);
  }

  std::stable_sort(sortedInput.begin(), sortedInput.end(), ACTSTracking::track_duplicate_compare);

  // Loop through all inputs and search for nearby equals
  // Remove if they are too similar
  std::vector<edm4hep::Track> finalTracks;
  for (const edm4hep::Track& track : sortedInput) {
    bool   foundAnEqual = false;
    size_t startIdx     = (finalTracks.size() >= 10) ? finalTracks.size() - 10 : 0;
    for (size_t i = startIdx; i < finalTracks.size(); ++i) {
      const edm4hep::Track& otherTrack = finalTracks[i];

      if (!ACTSTracking::tracks_equal(track, otherTrack))
        continue;
      foundAnEqual = true;
      if (ACTSTracking::track_quality_compare(track, otherTrack)) {
        finalTracks[i] = track;
        break;
      }
    }
    if (!foundAnEqual) {
      finalTracks.push_back(track);
    }
  }

  for (const auto& track : finalTracks) {
    outputTracks.push_back(track);
  }

  return outputTracks;
}
