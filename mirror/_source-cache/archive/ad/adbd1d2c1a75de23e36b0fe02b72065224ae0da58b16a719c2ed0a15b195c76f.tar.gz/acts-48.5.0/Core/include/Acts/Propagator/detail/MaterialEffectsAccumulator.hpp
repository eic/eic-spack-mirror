// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/TrackParametrization.hpp"
#include "Acts/EventData/ParticleHypothesis.hpp"
#include "Acts/Material/MaterialSlab.hpp"

namespace Acts::detail {

class MaterialEffectsAccumulator {
 public:
  bool isVacuum() const { return m_accumulatedMaterial.isVacuum(); }

  void reset() { *this = MaterialEffectsAccumulator(); }

  void initialize(double maxXOverX0Step,
                  const ParticleHypothesis& particleHypothesis,
                  double initialMomentum);

  /// @param material Material of the step
  /// @param pathLength Signed path length along the propagation direction.
  ///        Negative values step back and remove material from the end of
  ///        the path. Stepping back past the start clears the accumulator.
  /// @param qOverPin Charge over momentum at the start of the step
  /// @param qOverPout Charge over momentum at the end of the step
  void accumulate(const Material& material, double pathLength, double qOverPin,
                  double qOverPout);

  std::optional<FreeMatrix> computeAdditionalFreeCovariance(
      const Vector3& direction);

 private:
  double m_maxXOverX0Step = 0;

  ParticleHypothesis m_particleHypothesis = ParticleHypothesis::pion();
  double m_initialMomentum = 0;

  MaterialSlab m_accumulatedMaterial;

  double m_varAngle = 0;
  double m_varPosition = 0;
  double m_covAnglePosition = 0;
};

}  // namespace Acts::detail
