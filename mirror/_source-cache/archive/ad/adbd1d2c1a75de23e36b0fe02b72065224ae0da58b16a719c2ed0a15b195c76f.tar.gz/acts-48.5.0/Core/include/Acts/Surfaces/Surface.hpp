// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Definitions/Algebra.hpp"
#include "Acts/Definitions/Alignment.hpp"
#include "Acts/Definitions/Direction.hpp"
#include "Acts/Definitions/Tolerance.hpp"
#include "Acts/Definitions/TrackParametrization.hpp"
#include "Acts/Geometry/GeometryContext.hpp"
#include "Acts/Geometry/GeometryObject.hpp"
#include "Acts/Geometry/Polyhedron.hpp"
#include "Acts/Material/MaterialSlab.hpp"
#include "Acts/Surfaces/BoundaryTolerance.hpp"
#include "Acts/Surfaces/SurfaceBounds.hpp"
#include "Acts/Surfaces/SurfacePlacementBase.hpp"
#include "Acts/Utilities/AxisDefinitions.hpp"
#include "Acts/Utilities/CloneablePtr.hpp"
#include "Acts/Utilities/Intersection.hpp"
#include "Acts/Utilities/OstreamFormatter.hpp"
#include "Acts/Utilities/Result.hpp"
#include "Acts/Visualization/ViewConfig.hpp"

#include <array>
#include <memory>
#include <ostream>
#include <string>
#include <string_view>
#include <utility>

namespace Acts {

class SurfaceBounds;
class ISurfaceMaterial;
class Layer;
class TrackingVolume;
class IVisualization3D;

/// @class Surface
///
/// Abstract Base Class for tracking surfaces
///
/// The Surface class builds the core of the Acts Tracking Geometry.
/// All other geometrical objects are either extending the surface or
/// are built from it.
///
/// Surfaces are either owned by Detector elements or the Tracking Geometry,
/// in which case they are not copied within the data model objects.
///
class Surface : public virtual GeometryObject,
                public std::enable_shared_from_this<Surface> {
 public:
  friend struct GeometryContextOstreamWrapper<Surface>;

  /// @enum SurfaceType
  ///
  /// This enumerator simplifies the persistency & calculations,
  /// by saving a dynamic_cast, e.g. for persistency
  enum SurfaceType {
    Cone = 0,
    Cylinder = 1,
    Disc = 2,
    Perigee = 3,
    Plane = 4,
    Straw = 5,
    Curvilinear = 6,
    Point = 7,
    Other = 8
  };

  /// Helper strings for screen output
  static constexpr std::array<std::string_view, Surface::SurfaceType::Other + 1>
      s_surfaceTypeNames = {"Cone",  "Cylinder",    "Disc",  "Perigee", "Plane",
                            "Straw", "Curvilinear", "Point", "Other"};

  friend std::ostream& operator<<(std::ostream& os, SurfaceType type);

 protected:
  /// Constructor with Transform3 as a shared object
  ///
  /// @param transform Transform3 positions the surface in 3D global space
  /// @note also acts as default constructor
  explicit Surface(const Transform3& transform = Transform3::Identity());

  /// Copy constructor
  ///
  /// @note copy construction invalidates the association
  /// to detector element and layer
  ///
  /// @param other Source surface for copy.
  Surface(const Surface& other) noexcept = default;

  /// Constructor from SurfacePlacement: Element proxy
  ///
  /// @param placement Reference to the surface placement
  /// @note The Surface does not take any ownership over the
  ///       `SurfacePlacementBase` it is expected that the user
  ///        ensures the life-time of the `SurfacePlacementBase`
  ///        and that the `Surface` is actually owned by
  ///        the `SurfacePlacementBase` instance
  explicit Surface(const SurfacePlacementBase& placement) noexcept;

  /// Copy constructor with optional shift
  ///
  /// @note copy construction invalidates the association
  /// to detector element and layer
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param other Source surface for copy
  /// @param shift Additional transform applied as: shift * transform
  explicit Surface(const GeometryContext& gctx, const Surface& other,
                   const Transform3& shift) noexcept;

  /// Assignment operator
  /// @note copy construction invalidates the association
  /// to detector element and layer
  ///
  /// @param other Source surface for the assignment
  /// @return Reference to this surface after assignment
  /// @deprecated Surface copy-assignment will be removed; copy via
  ///             `Surface::makeShared<T>(other)` instead.
  [[deprecated(
      "Surface copy-assignment is deprecated and will be removed; copy via "
      "Surface::makeShared<T>(other) instead.")]]
  Surface& operator=(const Surface& other) noexcept = default;

 public:
  ~Surface() noexcept override;

  /// Factory for producing memory managed instances of Surface.
  /// Will forward all parameters and will attempt to find a suitable
  /// constructor.
  /// @param args Constructor arguments to forward to surface creation
  /// @return Shared pointer to the created surface instance
  template <class T, typename... Args>
  static std::shared_ptr<T> makeShared(Args&&... args) {
    return std::shared_ptr<T>(new T(std::forward<Args>(args)...));
  }

  /// Retrieve a @c std::shared_ptr for this surface (non-const version)
  ///
  /// @note Will error if this was not created through the @c makeShared factory
  ///       since it needs access to the original reference. In C++14 this is
  ///       undefined behavior (but most likely implemented as a @c bad_weak_ptr
  ///       exception), in C++17 it is defined as that exception.
  /// @note Only call this if you need shared ownership of this object.
  ///
  /// @return The shared pointer
  std::shared_ptr<Surface> getSharedPtr();

  /// Retrieve a @c std::shared_ptr for this surface (const version)
  ///
  /// @note Will error if this was not created through the @c makeShared factory
  ///       since it needs access to the original reference. In C++14 this is
  ///       undefined behavior, but most likely implemented as a @c bad_weak_ptr
  ///       exception, in C++17 it is defined as that exception.
  /// @note Only call this if you need shared ownership of this object.
  ///
  /// @return The shared pointer
  std::shared_ptr<const Surface> getSharedPtr() const;

  /// Comparison (equality) operator
  /// The strategy for comparison is
  /// (a) first pointer comparison
  /// (b) then type comparison
  /// (c) then bounds comparison
  /// (d) then transform comparison
  ///
  /// @param other source surface for the comparison
  /// @return True if surfaces are equal, false otherwise
  bool operator==(const Surface& other) const;

 public:
  /// Return method for the Surface type to avoid dynamic casts
  /// @return The surface type enumeration value
  virtual SurfaceType type() const = 0;

  /// Return method for the surface Transform3 by reference
  /// In case a detector element is associated the surface transform
  /// is just forwarded to the detector element in order to keep the
  /// (mis-)alignment cache cetrally handled
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  ///
  /// @return the contextual transform
  const Transform3& localToGlobalTransform(const GeometryContext& gctx) const;

  /// Return method for the surface center
  /// @note the center is always recalculated in order to not keep a cache
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  ///
  /// @return center position by value
  virtual Vector3 center(const GeometryContext& gctx) const;

  /// Return the surface normal at a given @p position and @p direction.
  /// This method is fully generic, and valid for all surface types.
  /// @note For some surface types, the @p direction is ignored, but
  ///       it is **not safe** to pass in a zero vector!
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param pos The position at which to calculate the normal
  /// @param direction The direction at which to calculate the normal
  /// @return The normal vector at the given position and direction
  virtual Vector3 normal(const GeometryContext& gctx, const Vector3& pos,
                         const Vector3& direction) const = 0;

  /// Return method for SurfaceBounds
  /// @return SurfaceBounds by reference
  virtual const SurfaceBounds& bounds() const = 0;

  /// Local axes of the surface
  /// @return An array of local axes directions
  virtual std::array<AxisDirection, 2> localAxes() const = 0;

  /// Return the associated surface placement if there is any
  /// @return Pointer to the surface placement, can be nullptr
  const SurfacePlacementBase* surfacePlacement() const;

  /// Return method for the associated Layer in which the surface is embedded
  /// @return Layer by plain pointer, can be nullptr
  const Layer* associatedLayer() const;

  /// Return the thickness of the surface in the normal direction
  /// @return The surface thickness
  double thickness() const;

  /// Set Associated Layer
  /// Many surfaces can be associated to a Layer, but it might not be known yet
  /// during construction of the layer, this can be set afterwards
  ///
  /// @param lay the assignment Layer by reference
  void associateLayer(const Layer& lay);

  /// Check if the surface has an associated material description
  /// @return True if the surface has an associated material, false otherwise
  bool hasMaterial() const;

  /// Return method for the associated Material to this surface
  /// @return SurfaceMaterial as plain pointer, can be nullptr
  const ISurfaceMaterial* surfaceMaterial() const;

  /// Return method for the shared pointer to the associated Material
  /// @return SurfaceMaterial as shared_pointer, can be nullptr
  const std::shared_ptr<const ISurfaceMaterial>& surfaceMaterialSharedPtr()
      const;

  /// Assign a placement object which may dynamically align the surface in space
  /// @param placement: Placement object defining the surface's position
  void assignSurfacePlacement(const SurfacePlacementBase& placement);

  /// Assign the surface material description
  ///
  /// The material is usually derived in a complicated way and loaded from
  /// a framework given source. As various surfaces may share the same source
  /// this is provided by a shared pointer
  ///
  /// @param material Material description associated to this surface
  virtual void assignSurfaceMaterial(
      std::shared_ptr<const ISurfaceMaterial> material);

  /// Assign whether the surface is sensitive
  /// @param isSensitive Boolean flag to set sensitivity
  /// @throw logic_error if the surface is associated to a detector element
  void assignIsSensitive(bool isSensitive);

  /// Assign the thickness of the surface in the
  ///        orthogonal dimension
  /// @param thick: Thickness parameter to assign (>=0)
  void assignThickness(double thick);

  /// Return method for full material description of the Surface
  /// - from local coordinate on the surface
  ///
  /// @param lp is the local position used for the (eventual) lookup
  ///
  /// @return const MaterialSlab
  virtual const MaterialSlab& materialSlab(const Vector2& lp) const;

  /// Return method for fully scaled material description of the Surface
  /// - from local coordinate on the surface
  ///
  /// @param lp is the local position used for the (eventual) lookup
  /// @param pDir is the positive direction through the surface
  /// @param mode is the material update directive
  ///
  /// @return MaterialSlab
  virtual MaterialSlab materialSlab(const Vector2& lp, Direction pDir,
                                    MaterialUpdateMode mode) const;

  /// The geometric onSurface method
  ///
  /// Geometrical check whether position is on Surface
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global position to be evaludated
  /// @param direction global momentum direction (required for line-type surfaces)
  /// @param boundaryTolerance BoundaryTolerance directive for this onSurface check
  /// @param tolerance optional tolerance within which a point is considered on surface
  ///
  /// @return boolean indication if operation was successful
  bool isOnSurface(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction,
      const BoundaryTolerance& boundaryTolerance = BoundaryTolerance::None(),
      double tolerance = s_onSurfaceTolerance) const;

  /// Calculates the closest point on the boundary of the surface to a given
  /// point in local coordinates.
  /// @param lposition The local position to check
  /// @param metric The metric to use for the calculation
  /// @return The closest point on the boundary of the surface
  virtual Vector2 closestPointOnBoundary(const Vector2& lposition,
                                         const SquareMatrix2& metric) const;

  /// Calculates the distance to the boundary of the surface from a given point
  /// in local coordinates.
  /// @param lposition The local position to check
  /// @return The distance to the boundary of the surface
  virtual double distanceToBoundary(const Vector2& lposition) const;

  /// The insideBounds method for local positions
  ///
  /// @param lposition The local position to check
  /// @param boundaryTolerance BoundaryTolerance directive for this onSurface check
  /// @return boolean indication if operation was successful
  virtual bool insideBounds(const Vector2& lposition,
                            const BoundaryTolerance& boundaryTolerance =
                                BoundaryTolerance::None()) const;

  /// Local to global transformation
  /// Generalized local to global transformation for the surface types. Since
  /// some surface types need the global momentum/direction to resolve sign
  /// ambiguity this is also provided
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param lposition local 2D position in specialized surface frame
  /// @param direction global 3D momentum direction
  ///
  /// @return The global position by value
  virtual Vector3 localToGlobal(const GeometryContext& gctx,
                                const Vector2& lposition,
                                const Vector3& direction) const = 0;

  /// Global to local transformation
  /// Generalized global to local transformation for the surface types. Since
  /// some surface types need the global momentum/direction to resolve sign
  /// ambiguity this is also provided
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position - considered to be on surface but not
  /// inside bounds (check is done)
  /// @param direction global 3D momentum direction
  /// @param tolerance optional tolerance within which a point is considered
  /// valid on surface
  ///
  /// @return a Result<Vector2> which can be !ok() if the operation fails
  virtual Result<Vector2> globalToLocal(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction,
      double tolerance = s_onSurfaceTolerance) const = 0;

  /// Return method for the reference frame
  /// This is the frame in which the covariance matrix is defined (specialized
  /// by all surfaces)
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position - considered to be on surface but not
  /// inside bounds (check is done)
  /// @param direction global 3D momentum direction (optionally ignored)
  ///
  /// @return RotationMatrix3 which defines the three axes of the measurement
  /// frame
  virtual RotationMatrix3 referenceFrame(const GeometryContext& gctx,
                                         const Vector3& position,
                                         const Vector3& direction) const;

  /// Calculate the jacobian from local to global which the surface knows best,
  /// hence the calculation is done here.
  ///
  /// @note In principle, the input could also be a free parameters
  /// vector as it could be transformed to a bound parameters. But the transform
  /// might fail in case the parameters is not on surface. To avoid the check
  /// inside this function, it takes directly the bound parameters as input
  /// (then the check might be done where this function is called).
  ///
  /// @todo this mixes track parameterisation and geometry
  /// should move to :
  /// "Acts/EventData/detail/coordinate_transformations.hpp"
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  ///
  /// @return Jacobian from local to global
  virtual BoundToFreeMatrix boundToFreeJacobian(const GeometryContext& gctx,
                                                const Vector3& position,
                                                const Vector3& direction) const;

  /// Calculate the jacobian from global to local which the surface knows best,
  /// hence the calculation is done here.
  ///
  /// @note It assumes the input free parameters is on surface, hence no
  /// onSurface check is done inside this function.
  ///
  /// @todo this mixes track parameterisation and geometry
  /// should move to :
  /// "Acts/EventData/detail/coordinate_transformations.hpp"
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  ///
  /// @return Jacobian from global to local
  virtual FreeToBoundMatrix freeToBoundJacobian(const GeometryContext& gctx,
                                                const Vector3& position,
                                                const Vector3& direction) const;

  /// Calculate the derivative of path length at the geometry constraint or
  /// point-of-closest-approach w.r.t. free parameters. The calculation is
  /// identical for all surfaces where the reference frame does not depend on
  /// the direction
  ///
  /// @todo this mixes track parameterisation and geometry
  /// should move to :
  /// "Acts/EventData/detail/coordinate_transformations.hpp"
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  ///
  /// @return Derivative of path length w.r.t. free parameters
  virtual FreeToPathMatrix freeToPathDerivative(const GeometryContext& gctx,
                                                const Vector3& position,
                                                const Vector3& direction) const;

  /// Calculation of the path correction for incident
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @note The @p position is either ignored, or it is coerced to be on the surface,
  ///       depending on the surface type.
  /// @param direction global 3D momentum direction
  ///
  /// @return Path correction with respect to the nominal incident.
  virtual double pathCorrection(const GeometryContext& gctx,
                                const Vector3& position,
                                const Vector3& direction) const = 0;

  /// Straight line intersection schema from position/direction
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position The position to start from
  /// @param direction The direction at start
  /// @param boundaryTolerance the BoundaryTolerance
  /// @param tolerance the tolerance used for the intersection
  ///
  /// @return @c MultiIntersection3D intersection object
  virtual MultiIntersection3D intersect(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction,
      const BoundaryTolerance& boundaryTolerance =
          BoundaryTolerance::Infinite(),
      double tolerance = s_onSurfaceTolerance) const = 0;

  /// Helper method for printing: the returned object captures the
  /// surface and the geometry context and will print the surface
  /// @param gctx The current geometry context object, e.g. alignment
  /// @return The wrapper object for printing
  GeometryContextOstreamWrapper<Surface> toStream(
      const GeometryContext& gctx) const {
    return {*this, gctx};
  }

  /// Output into a std::string
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @return String representation of the surface
  std::string toString(const GeometryContext& gctx) const;

  /// Return properly formatted class name
  /// @return The surface class name as a string
  virtual std::string name() const = 0;

  /// Returns whether the Surface is sensitive
  /// @return True if the surface is sensitive
  bool isSensitive() const;

  /// Returns whether the Surface is alignable
  /// @return True if the surface is alignable
  bool isAlignable() const;

  /// Return a Polyhedron for surface objects
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param quarterSegments The number of segemtns to approximate a 0.5*pi sector,
  /// which represents a quarter of the full circle
  ///
  /// @note In order to symmetrize the code between sectoral and closed cylinders
  /// in case of closed cylinders, both (-pi, pi) are given as separate vertices
  ///
  /// @note An internal surface transform can invalidate the extrema
  /// in the transformed space
  ///
  /// @return A list of vertices and a face/facett description of it
  virtual Polyhedron polyhedronRepresentation(
      const GeometryContext& gctx, unsigned int quarterSegments = 2u) const = 0;

  /// The derivative of bound track parameters w.r.t. alignment
  /// parameters of its reference surface (i.e. local frame origin in
  /// global 3D Cartesian coordinates and its rotation represented with
  /// extrinsic Euler angles)
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// change of alignment parameters
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  /// @param pathDerivative is the derivative of free parameters w.r.t. path
  /// length
  ///
  /// @return Derivative of bound track parameters w.r.t. local frame
  /// alignment parameters
  AlignmentToBoundMatrix alignmentToBoundDerivative(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction, const FreeVector& pathDerivative) const;

  /// Calculate the derivative of path length at the geometry constraint or
  /// point-of-closest-approach w.r.t. alignment parameters of the surface (i.e.
  /// local frame origin in global 3D Cartesian coordinates and its rotation
  /// represented with extrinsic Euler angles)
  ///
  /// @note Re-implementation is needed for surface whose intersection with
  /// track is not its local xy plane, e.g. LineSurface, CylinderSurface and
  /// ConeSurface
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  ///
  /// @return Derivative of path length w.r.t. the alignment parameters
  virtual AlignmentToPathMatrix alignmentToPathDerivative(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction) const;

  /// Calculate the derivative of bound track parameters local position w.r.t.
  /// position in local 3D Cartesian coordinates
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position The position of the parameters in global
  ///
  /// @return Derivative of bound local position w.r.t. position in local 3D
  /// cartesian coordinates
  virtual Matrix<2, 3> localCartesianToBoundLocalDerivative(
      const GeometryContext& gctx, const Vector3& position) const = 0;

  /// Visualize the surface for debugging and inspection
  /// @param helper Visualization helper for 3D rendering
  /// @param gctx Geometry context for coordinate transformations
  /// @param viewConfig Visual configuration (color, style, etc.)
  void visualize(IVisualization3D& helper, const GeometryContext& gctx,
                 const ViewConfig& viewConfig = s_viewSurface) const;

 protected:
  /// Output Method for std::ostream, to be overloaded by child classes
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param sl is the ostream to be dumped into
  /// @return Reference to the output stream for chaining
  virtual std::ostream& toStreamImpl(const GeometryContext& gctx,
                                     std::ostream& sl) const;

  /// Transform surface local coordinates to material local coordinates
  /// @param surfaceLocal The local coordinates on the surface
  /// @return The corresponding local coordinates for material lookup
  virtual Vector2 transformSurfaceLocalToMaterialLocal(
      const Vector2& surfaceLocal) const;

  /// Transform3 definition that positions
  /// (translation, rotation) the surface in global space
  CloneablePtr<const Transform3> m_transform;

  /// Possibility to attach a material description
  std::shared_ptr<const ISurfaceMaterial> m_surfaceMaterial;

  /// Whether to swap the local coordinates for material lookup
  bool m_swapMaterialAxes{false};

 private:
  /// Pointer to the a SurfacePlacement
  const SurfacePlacementBase* m_placement{nullptr};

  /// The associated layer Layer - layer in which the Surface is be embedded,
  /// nullptr if not associated
  const Layer* m_associatedLayer{nullptr};

  /// Flag to indicate whether the surface is sensitive
  bool m_isSensitive{false};

  /// Thickness of the surface in the normal direction
  double m_thickness{0.};

  /// Calculate the derivative of bound track parameters w.r.t.
  /// alignment parameters of its reference surface (i.e. origin in global 3D
  /// Cartesian coordinates and its rotation represented with extrinsic Euler
  /// angles) without any path correction
  ///
  /// @note This function should be used together with alignment to path
  /// derivative to get the full alignment to bound derivatives
  ///
  /// @param gctx The current geometry context object, e.g. alignment
  /// @param position global 3D position
  /// @param direction global 3D momentum direction
  ///
  /// @return Derivative of bound track parameters w.r.t. local frame alignment
  /// parameters without path correction
  AlignmentToBoundMatrix alignmentToBoundDerivativeWithoutCorrection(
      const GeometryContext& gctx, const Vector3& position,
      const Vector3& direction) const;
};

}  // namespace Acts

ACTS_OSTREAM_FORMATTER(Acts::Surface::SurfaceType);
