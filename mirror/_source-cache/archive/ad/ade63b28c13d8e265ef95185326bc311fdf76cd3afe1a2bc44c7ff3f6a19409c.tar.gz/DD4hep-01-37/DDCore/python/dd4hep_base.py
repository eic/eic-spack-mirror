# ==========================================================================
#  AIDA Detector description implementation
# --------------------------------------------------------------------------
# Copyright (C) Organisation europeenne pour la Recherche nucleaire (CERN)
# All rights reserved.
#
# For the licensing terms see $DD4hepINSTALL/LICENSE.
# For the list of contributors see $DD4hepINSTALL/doc/CREDITS.
#
# ==========================================================================
import cppyy
import importlib
import types
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
def dd4hep_directories(g4=True):
  """
  Return tuple of relevant dd4hep directories: (dd4hep, rootsys, geant4)
  """
  import os
  dd4hep = os.getenv("DD4hepINSTALL", "/usr")
  rootsys = os.getenv("ROOTSYS", "/usr")
  g4_dir = None
  if g4:
    g4_dir = os.getenv('G4INSTALL', "/usr")
  return (rootsys, g4_dir, dd4hep, )


# ---------------------------------------------------------------------------
def root_add_compile_option(option):
  from ROOT import gSystem
  known = gSystem.GetIncludePath()
  idx = known.find(option + ' ')
  if idx > 0 and idx + len(option) >= len(known):
    return known
  gSystem.AddIncludePath(' ' + option)


# ---------------------------------------------------------------------------
def root_add_include_path(path):
  from ROOT import gSystem
  known = gSystem.GetIncludePath()
  path = '"' + path + '"'
  idx = known.find(path)
  if idx > 0 and idx + len(path) == len(known):
    return known
  gSystem.AddIncludePath(' -I' + path)


# ---------------------------------------------------------------------------
def setup_root_include_path(g4=True, opt=None):
  """
  Setup the ROOT compile options and include directories
  """
  from ROOT import gSystem
  rootsys, geant4, dd4hep = dd4hep_directories(g4)
  known = gSystem.GetIncludePath()

  root_add_include_path(rootsys + '/include')
  root_add_include_path(dd4hep + '/include')
  if geant4:
    root_add_include_path(geant4 + '/include/Geant4')
    root_add_compile_option(' -Wno-shadow -g -O0')
  if opt and known.find(opt) < 0:
    gSystem.AddIncludePath(' ' + opt)
  return gSystem.GetIncludePath()


# ---------------------------------------------------------------------------
def root_compile_opts():
  """
  Return the ROOT compile options and include directories
  """
  from ROOT import gSystem
  return gSystem.GetIncludePath()


# ---------------------------------------------------------------------------
def setup_root_library_path(g4=True, opt=None):
  """
  Setup the ROOT link libraries and link options for A-Click processing of dd4hep in ROOT
  """
  from ROOT import gSystem
  rootsys, geant4, dd4hep = dd4hep_directories(g4)
  known = gSystem.GetLinkedLibs()

  lib = ' -L' + dd4hep + '/lib64 ' + ' -L' + dd4hep + '/lib -lDDCore -lDDG4 -lDDSegmentation '
  if known.find(lib) >= 0:
    lib = ''
  if geant4:
    g4_lib = ' -L' + geant4 + '/lib64  -L' + geant4 + '/lib -lG4event -lG4tracking -lG4particles '
    if known.find(g4_lib) < 0:
      lib = lib + g4_lib
  if opt and known.find(opt) < 0:
    lib = lib + ' ' + opt

  if len(lib):
    gSystem.AddLinkedLibs(lib)
  return gSystem.GetLinkedLibs()


# ---------------------------------------------------------------------------
def root_linked_libs():
  """
  Access the ROOT link libraries and link options for A-Click processing of dd4hep in ROOT
  """
  from ROOT import gSystem
  return gSystem.GetLinkedLibs()


# ---------------------------------------------------------------------------
def compileAClick(dictionary, g4=True):
  """
  We compile the DDG4 plugin on the fly if it does not exist using the AClick mechanism.

  """
  from ROOT import gInterpreter
  import os.path

  setup_root_include_path(g4)
  setup_root_library_path(g4)
  logger.info('Loading AClick %s', dictionary)
  package_spec = importlib.util.find_spec('DDG4')
  dic = os.path.dirname(package_spec.origin) + os.sep + dictionary
  gInterpreter.ProcessLine('.L ' + dic + '+')
  from ROOT import dd4hep as module
  return module


# ---------------------------------------------------------------------------
def loaddd4hep():
  """
  Import DD4hep module from ROOT using ROOT reflection
  """
  import os
  import sys
  # Add ROOT to the python path in case it is not yet there....
  rootsys = os.getenv("ROOTSYS", "/usr")
  sys.path.append(os.path.join(rootsys, 'lib'))
  sys.path.append(os.path.join(rootsys, 'lib64'))
  sys.path.append(os.path.join(rootsys, 'lib', 'root'))
  sys.path.append(os.path.join(rootsys, 'lib64', 'root'))
  from ROOT import gSystem

  import platform
  if platform.system() == "Darwin":
    gSystem.SetDynamicPath(os.environ['DD4HEP_LIBRARY_PATH'])
    os.environ['DYLD_LIBRARY_PATH'] = os.pathsep.join([os.environ['DD4HEP_LIBRARY_PATH'],
                                                       os.environ.get('DYLD_LIBRARY_PATH', '')]).strip(os.pathsep)
  result = gSystem.Load("libDDCore")
  if result < 0:
    raise Exception('dd4hep.py: Failed to load the dd4hep library libDDCore: ' + gSystem.GetErrorStr())
  from ROOT import dd4hep as module
  return module


# We are nearly there ....
name_space = __import__(__name__)


# ---------------------------------------------------------------------------
def import_namespace_item(ns, nam):
  scope = getattr(name_space, ns)
  attr = getattr(scope, nam)
  setattr(name_space, nam, attr)
  return attr


# ---------------------------------------------------------------------------
def import_root(nam):
  setattr(name_space, nam, getattr(ROOT, nam))


# ---------------------------------------------------------------------------
#
try:
  dd4hep = loaddd4hep()
  import ROOT
except Exception as X:
  import sys
  logger.error('+--%-100s--+', 100 * '-')
  logger.error('|  %-100s  |', 'Failed to load dd4hep base library:')
  logger.error('|  %-100s  |', str(X))
  logger.error('+--%-100s--+', 100 * '-')
  sys.exit(1)


# ---------------------------------------------------------------------------
class _Levels:
  def __init__(self):
    self.VERBOSE = 1
    self.DEBUG = 2
    self.INFO = 3
    self.WARNING = 4
    self.ERROR = 5
    self.FATAL = 6
    self.ALWAYS = 7


# ---------------------------------------------------------------------------
def unicode_2_string(value):
  """Turn any unicode literal into str, needed when passing to c++.

  Recursively transverses dicts, lists, sets, tuples

  :return: always a str
  """
  if isinstance(value, (bool, float, int)):
    value = value
  elif isinstance(value, str):
    value = str(value)
  elif isinstance(value, bytes):
    value = value.decode()
  elif isinstance(value, (list, set, tuple)):
    value = [unicode_2_string(x) for x in value]
  elif isinstance(value, dict):
    tempDict = {}
    for key, val in value.items():
      key = unicode_2_string(key)
      val = unicode_2_string(val)
      tempDict[key] = val
    value = tempDict
  return str(value)


OutputLevel = _Levels()
VERBOSE = OutputLevel.VERBOSE
DEBUG = OutputLevel.DEBUG
INFO = OutputLevel.INFO
WARNING = OutputLevel.WARNING
ERROR = OutputLevel.ERROR
FATAL = OutputLevel.FATAL


# ------------------------Generic STL stuff can be accessed using std:  -----
#
# -- e.g. Create an instance of std::vector<dd4hep::sim::Geant4Vertex*>:
#    >>> v=dd4hep.vector('dd4hep::sim::Geant4Vertex*')()
#
# ---------------------------------------------------------------------------
std = cppyy.gbl.std
std_vector = std.vector
std_list = std.list
std_map = std.map
std_pair = std.pair
# ---------------------------------------------------------------------------
core = dd4hep
cond = dd4hep.cond
tools = dd4hep.tools
align = dd4hep.align
detail = dd4hep.detail
units = types.ModuleType('units')
# ---------------------------------------------------------------------------
import_namespace_item('tools', 'Evaluator')
# ---------------------------------------------------------------------------
import_namespace_item('core', 'NamedObject')
import_namespace_item('core', 'run_interpreter')
#
import_namespace_item('detail', 'interp')
# No: This inhibits the usage of native python eval!
# import_namespace_item('detail', 'eval')

# ---------------------------------------------------------------------------
# def run_interpreter(name):   detail.interp.run(name)
# def evaluator():     return eval.instance()
# def g4Evaluator():   return eval.g4instance()


# ---------------------------------------------------------------------------
def import_detail():
  import_namespace_item('detail', 'DD4hepUI')


# ---------------------------------------------------------------------------
def import_geometry():
  import_namespace_item('core', 'setPrintLevel')
  import_namespace_item('core', 'setPrintFormat')
  import_namespace_item('core', 'printLevel')
  import_namespace_item('core', 'PrintLevel')

  import_namespace_item('core', 'debug')
  import_namespace_item('core', 'info')
  import_namespace_item('core', 'warning')
  import_namespace_item('core', 'error')
  import_namespace_item('core', 'fatal')
  import_namespace_item('core', 'exception')

  import_namespace_item('core', 'Detector')
  import_namespace_item('core', 'evaluator')
  import_namespace_item('core', 'g4Evaluator')

  import_namespace_item('core', 'VolumeManager')
  import_namespace_item('core', 'OverlayedField')
  import_namespace_item('core', 'Ref_t')

  # // Objects.h
  import_namespace_item('core', 'Author')
  import_namespace_item('core', 'Header')
  import_namespace_item('core', 'Constant')
  import_namespace_item('core', 'Atom')
  import_namespace_item('core', 'Material')
  import_namespace_item('core', 'VisAttr')
  import_namespace_item('core', 'Limit')
  import_namespace_item('core', 'LimitSet')
  import_namespace_item('core', 'LimitSetObject')
  import_namespace_item('core', 'Region')
  import_namespace_item('core', 'RegionObject')
  import_namespace_item('core', 'HitCollection')
  # // Typedefs from Objects.h
  import_namespace_item('core', 'Position')
  import_namespace_item('core', 'PositionRhoZPhi')
  import_namespace_item('core', 'PositionPolar')
  import_namespace_item('core', 'Direction')
  import_namespace_item('core', 'XYZAngles')
  import_namespace_item('core', 'RotationZYX')
  import_namespace_item('core', 'RotationX')
  import_namespace_item('core', 'RotationY')
  import_namespace_item('core', 'RotationZ')
  import_namespace_item('core', 'Rotation3D')
  import_namespace_item('core', 'EulerAngles')
  import_namespace_item('core', 'Transform3D')
  import_namespace_item('core', 'Translation3D')

  # // Readout.h
  import_namespace_item('core', 'Segmentation')
  import_namespace_item('core', 'SegmentationObject')
  import_namespace_item('core', 'Readout')
  import_namespace_item('core', 'ReadoutObject')

  # // Alignments.h
  import_namespace_item('core', 'Alignment')
  import_namespace_item('core', 'AlignmentCondition')

  # // Conditions.h
  import_namespace_item('core', 'Condition')
  import_namespace_item('core', 'ConditionKey')

  # // DetElement.h
  import_namespace_item('core', 'World')
  import_namespace_item('core', 'DetElement')
  import_namespace_item('core', 'SensitiveDetector')

  # // Volume.h
  import_namespace_item('core', 'Volume')
  import_namespace_item('core', 'PlacedVolume')

  # // Shapes.h
  import_namespace_item('core', 'Solid')
  import_namespace_item('core', 'Box')
  import_namespace_item('core', 'HalfSpace')
  import_namespace_item('core', 'Polycone')
  import_namespace_item('core', 'ConeSegment')
  import_namespace_item('core', 'Tube')
  import_namespace_item('core', 'CutTube')
  import_namespace_item('core', 'TruncatedTube')
  import_namespace_item('core', 'EllipticalTube')
  import_namespace_item('core', 'Cone')
  import_namespace_item('core', 'Trap')
  import_namespace_item('core', 'PseudoTrap')
  import_namespace_item('core', 'Trapezoid')
  import_namespace_item('core', 'Torus')
  import_namespace_item('core', 'Sphere')
  import_namespace_item('core', 'Paraboloid')
  import_namespace_item('core', 'Hyperboloid')
  import_namespace_item('core', 'PolyhedraRegular')
  import_namespace_item('core', 'Polyhedra')
  import_namespace_item('core', 'ExtrudedPolygon')
  import_namespace_item('core', 'EightPointSolid')
  import_namespace_item('core', 'BooleanSolid')
  import_namespace_item('core', 'SubtractionSolid')
  import_namespace_item('core', 'UnionSolid')
  import_namespace_item('core', 'IntersectionSolid')


# ---------------------------------------------------------------------------
def import_tgeo():
  import_root('TGeoManager')
  import_root('TGeoNode')
  import_root('TGeoNodeMatrix')

  import_root('TGeoVolume')
  import_root('TGeoVolumeMulti')
  import_root('TGeoVolumeAssembly')

  import_root('TGeoMaterial')
  import_root('TGeoMedium')
  import_root('TGeoIsotope')
  import_root('TGeoElement')

  import_root('TGeoMatrix')
  import_root('TGeoHMatrix')
  import_root('TGeoIdentity')
  import_root('TGeoTranslation')
  import_root('TGeoRotation')
  import_root('TGeoScale')
  import_root('TGeoCombiTrans')

  import_root('TGeoShape')
  import_root('TGeoBBox')
  import_root('TGeoArb8')
  import_root('TGeoTrap')
  import_root('TGeoGtra')
  import_root('TGeoCompositeShape')
  import_root('TGeoCone')
  import_root('TGeoConeSeg')
  import_root('TGeoTube')
  import_root('TGeoTubeSeg')
  import_root('TGeoCtub')
  import_root('TGeoEltu')
  import_root('TGeoHype')
  import_root('TGeoHalfSpace')
  import_root('TGeoPara')
  import_root('TGeoParaboloid')
  import_root('TGeoPcon')
  import_root('TGeoPgon')
  import_root('TGeoScaledShape')
  import_root('TGeoShapeAssembly')
  import_root('TGeoSphere')
  import_root('TGeoTorus')
  import_root('TGeoTrd1')
  import_root('TGeoTrd2')
  import_root('TGeoXtru')


import_tgeo()
import_geometry()
import_detail()


# ---------------------------------------------------------------------------
class Logger:
  """
  Helper class to use the dd4hep printout functions from python

  \author  M.Frank
  \version 1.0
  """

  def __init__(self, name):
    "Logger constructor"
    self.name = name

  def setPrintLevel(self, level):
    "Adjust printout level of dd4hep"
    if isinstance(level, str):
      if level == 'VERBOSE':
        level = OutputLevel.VERBOSE
      elif level == 'DEBUG':
        level = OutputLevel.DEBUG
      elif level == 'INFO':
        level = OutputLevel.INFO
      elif level == 'WARNING':
        level = OutputLevel.WARNING
      elif level == 'ERROR':
        level = OutputLevel.ERROR
      elif level == 'FATAL':
        level = OutputLevel.FATAL
      else:
        level = int(level)
    dd4hep.setPrintLevel(level)

  def always(self, msg):
    "Call dd4hep printout function with level ALWAYS"
    dd4hep.always(self.name, msg)

  def verbose(self, msg):
    "Call dd4hep printout function with level VERBOSE"
    dd4hep.verbose(self.name, msg)

  def debug(self, msg):
    "Call dd4hep printout function with level DEBUG"
    dd4hep.debug(self.name, msg)

  def info(self, msg):
    "Call dd4hep printout function with level INFO"
    dd4hep.info(self.name, msg)

  def warning(self, msg):
    "Call dd4hep printout function with level WARNING"
    dd4hep.warning(self.name, msg)

  def error(self, msg):
    "Call dd4hep printout function with level ERROR"
    dd4hep.error(self.name, msg)

  def fatal(self, msg):
    "Call dd4hep printout function with level FATAL"
    dd4hep.fatal(self.name, msg)

  def exception(self, msg):
    "Call dd4hep exception function"
    dd4hep.exception(self.name, msg)


dd4hep_logger = Logger


# ---------------------------------------------------------------------------
#
# Helper: Command line interpreter
#
# ---------------------------------------------------------------------------
class CommandLine:
  """
  Helper to ease parsing the command line.
  Any argument given in the command line is accessible
  from the object. If no value is supplied, the returned
  value is True. If the argument is not present None is returned.

  \author  M.Frank
  \version 1.0
  """
  def __init__(self, help=None):  # noqa: A002
    import sys
    self.data = {}
    help_call = help
    have_help = False
    for i in range(len(sys.argv)):
      if sys.argv[i][0] == '-':
        key = sys.argv[i][1:]
        val = True
        if i + 1 < len(sys.argv):
          v = sys.argv[i + 1]
          if v[0] != '-':
            val = v
        self.data[key] = val
        if key.upper() == 'HELP' or key.upper() == '?':
         have_help = True
    if have_help and help_call:
      help_call()
    if self.data.get('print_level'):
      log = Logger('CommandLine')
      log.setPrintLevel(self.data.get('print_level'))

  def __getattr__(self, attr):
    if self.data.get(attr):
      return self.data.get(attr)
    return None


# ---------------------------------------------------------------------------
#
#  Import units from TGeo.
#  Calling import_units makes all the units local to the dd4hep module.
#
try:
  import_namespace_item('core', 'dd4hep_units')

  def import_units(ns=None):
    if ns is None:
      ns = name_space

    logger.debug('Importing units into namespace ' + str(ns.__name__))
    count = 0
    for nam in dir(dd4hep.dd4hep_units):
      if nam[0] != '_':
        count = count + 1
        setattr(ns, nam, getattr(core.dd4hep_units, nam))
        # setattr(ns, nam, getattr(core, nam))
    return count

except Exception as e:
  logger.warning('No units can be imported. ' + str(e))

  def import_units(ns=None):
    return 0

import_units(ns=units)
