#pragma once

/**
OpticksGenstep.h
=================

Genstep versioning

Not using typedef enum for simplicity as
this needs to be used everywhere.

NB these were formely conflated with photon flags,
but the needs are somewhat different.

See also: npy/G4StepNPY.cpp  (TODO: consolidate these?)

**/

enum
{
    OpticksGenstep_INVALID                  = 0,
    // Values 1-5 are intentionally unused after retiring their legacy encodings.
    OpticksGenstep_TORCH                    = 6,
    OpticksGenstep_FABRICATED               = 7,
    OpticksGenstep_EMITSOURCE               = 8,
    OpticksGenstep_NATURAL                  = 9,
    OpticksGenstep_MACHINERY                = 10,
    OpticksGenstep_G4GUN                    = 11,
    OpticksGenstep_PRIMARYSOURCE            = 12,
    OpticksGenstep_GENSTEPSOURCE            = 13,
    OpticksGenstep_CARRIER                  = 14,
    OpticksGenstep_CERENKOV                 = 15,
    OpticksGenstep_SCINTILLATION            = 16,
    OpticksGenstep_FRAME                    = 17,
    OpticksGenstep_G4Cerenkov_modified      = 18,
    OpticksGenstep_INPUT_PHOTON             = 19,
    OpticksGenstep_INPUT_PHOTON_SIMTRACE    = 20,
    OpticksGenstep_NumType                  = 21
};


#if defined(__CUDACC__) || defined(__CUDABE__)
#else
#include <cstring>
#include <string>
#include "OpticksPhoton.h"

struct OpticksGenstep_
{
    static constexpr const char* INVALID_                 = "INVALID" ;
    static constexpr const char* TORCH_                   = "TORCH" ;
    static constexpr const char* FABRICATED_              = "FABRICATED" ;
    static constexpr const char* EMITSOURCE_              = "EMITSOURCE" ;
    static constexpr const char* NATURAL_                 = "NATURAL" ;
    static constexpr const char* MACHINERY_               = "MACHINERY" ;
    static constexpr const char* G4GUN_                   = "G4GUN" ;
    static constexpr const char* PRIMARYSOURCE_           = "PRIMARYSOURCE" ;
    static constexpr const char* GENSTEPSOURCE_           = "GENSTEPSOURCE" ;
    static constexpr const char* CARRIER_                 = "CARRIER" ;
    static constexpr const char* CERENKOV_                = "CERENKOV" ;
    static constexpr const char* SCINTILLATION_           = "SCINTILLATION" ;
    static constexpr const char* FRAME_                   = "FRAME" ;
    static constexpr const char* G4Cerenkov_modified_     = "G4Cerenkov_modified" ;
    static constexpr const char* INPUT_PHOTON_            = "INPUT_PHOTON" ;
    static constexpr const char* INPUT_PHOTON_SIMTRACE_   = "INPUT_PHOTON_SIMTRACE" ;

    static unsigned Type(const char* name);
    static unsigned Type(const std::string& name);
    static const char* Name(unsigned type);

    static bool IsValid(int gentype);

    static bool IsCerenkov(int gentype);
    static bool IsScintillation(int gentype);
    static bool IsTorchLike(int gentype);
    static bool IsInputPhoton(int gentype);
    static bool IsInputPhotonSimtrace(int gentype);
    static bool IsExpected(int gentype);

    static bool IsEmitSource(int gentype);
    static bool IsMachinery(int gentype);
    static bool IsFrame(int gentype);
    static unsigned GenstepToPhotonFlag(int gentype);
    static unsigned GentypeToPhotonFlag(char gentype); // 'C' 'S' 'T' -> CK, SI, TO

};

inline unsigned OpticksGenstep_::Type(const char* name)
{
    unsigned type = OpticksGenstep_INVALID  ;
    if(strcmp(name,G4Cerenkov_modified_ )==0)     type = OpticksGenstep_G4Cerenkov_modified ;
    if(strcmp(name,TORCH_)==0)                    type = OpticksGenstep_TORCH ;
    if(strcmp(name,FABRICATED_)==0)               type = OpticksGenstep_FABRICATED ;
    if(strcmp(name,EMITSOURCE_)==0)               type = OpticksGenstep_EMITSOURCE ;
    if(strcmp(name,NATURAL_)==0)                  type = OpticksGenstep_NATURAL ;
    if(strcmp(name,MACHINERY_)==0)                type = OpticksGenstep_MACHINERY ;
    if(strcmp(name,G4GUN_)==0)                    type = OpticksGenstep_G4GUN ;
    if(strcmp(name,PRIMARYSOURCE_)==0)            type = OpticksGenstep_PRIMARYSOURCE ;
    if(strcmp(name,GENSTEPSOURCE_)==0)            type = OpticksGenstep_GENSTEPSOURCE ;
    if(strcmp(name,CARRIER_)==0)                  type = OpticksGenstep_CARRIER ;
    if(strcmp(name,CERENKOV_)==0)                 type = OpticksGenstep_CERENKOV ;
    if(strcmp(name,SCINTILLATION_)==0)            type = OpticksGenstep_SCINTILLATION ;
    if(strcmp(name,FRAME_)==0)                    type = OpticksGenstep_FRAME ;
    if(strcmp(name,INPUT_PHOTON_)==0)             type = OpticksGenstep_INPUT_PHOTON ;
    if(strcmp(name,INPUT_PHOTON_SIMTRACE_)==0)    type = OpticksGenstep_INPUT_PHOTON_SIMTRACE ;
    return type ;
}

inline unsigned OpticksGenstep_::Type(const std::string& name)
{
    return Type(name.c_str());
}

inline const char* OpticksGenstep_::Name(unsigned type)
{
    const char* n = INVALID_ ;
    switch(type)
    {
        case OpticksGenstep_INVALID:                 n = INVALID_                 ; break ;
        case OpticksGenstep_G4Cerenkov_modified:     n = G4Cerenkov_modified_     ; break ;
        case OpticksGenstep_TORCH:                   n = TORCH_                   ; break ;
        case OpticksGenstep_FABRICATED:              n = FABRICATED_              ; break ;
        case OpticksGenstep_EMITSOURCE:              n = EMITSOURCE_              ; break ;
        case OpticksGenstep_NATURAL:                 n = NATURAL_                 ; break ;
        case OpticksGenstep_MACHINERY:               n = MACHINERY_               ; break ;
        case OpticksGenstep_G4GUN:                   n = G4GUN_                   ; break ;
        case OpticksGenstep_PRIMARYSOURCE:           n = PRIMARYSOURCE_           ; break ;
        case OpticksGenstep_GENSTEPSOURCE:           n = GENSTEPSOURCE_           ; break ;
        case OpticksGenstep_CARRIER:                 n = CARRIER_                 ; break ;
        case OpticksGenstep_CERENKOV:                n = CERENKOV_                ; break ;
        case OpticksGenstep_SCINTILLATION:           n = SCINTILLATION_           ; break ;
        case OpticksGenstep_FRAME:                   n = FRAME_                   ; break ;
        case OpticksGenstep_INPUT_PHOTON:            n = INPUT_PHOTON_            ; break ;
        case OpticksGenstep_INPUT_PHOTON_SIMTRACE:   n = INPUT_PHOTON_SIMTRACE_   ; break ;
        case OpticksGenstep_NumType:                 n = INVALID_                 ; break ;
        default:                                     n = INVALID_                 ; break ;
    }
    return n ;
}


inline bool OpticksGenstep_::IsValid(int gentype)   // static
{
   const char* s = Name(gentype);
   bool invalid = strcmp(s, INVALID_) == 0 ;
   return !invalid ;
}

inline bool OpticksGenstep_::IsCerenkov(int gentype)  // static
{
    return gentype == OpticksGenstep_CERENKOV || gentype == OpticksGenstep_G4Cerenkov_modified;
}
inline bool OpticksGenstep_::IsScintillation(int gentype)  // static
{
    return gentype == OpticksGenstep_SCINTILLATION;
}
inline bool OpticksGenstep_::IsTorchLike(int gentype)   // static
{
   return gentype == OpticksGenstep_TORCH ||
          gentype == OpticksGenstep_FABRICATED ||
          gentype == OpticksGenstep_EMITSOURCE ||
          gentype == OpticksGenstep_FRAME     ||
          gentype == OpticksGenstep_INPUT_PHOTON ||
          gentype == OpticksGenstep_INPUT_PHOTON_SIMTRACE
          ;
}

inline bool OpticksGenstep_::IsInputPhoton(int gentype)   // static
{
    return gentype == OpticksGenstep_INPUT_PHOTON ;
}
inline bool OpticksGenstep_::IsInputPhotonSimtrace(int gentype)   // static
{
    return gentype == OpticksGenstep_INPUT_PHOTON_SIMTRACE ;
}


inline bool OpticksGenstep_::IsExpected(int gentype) // static
{
    return IsCerenkov(gentype) || IsScintillation(gentype) || IsTorchLike(gentype) ;
}

inline bool OpticksGenstep_::IsEmitSource(int gentype)   // static
{
   return gentype == OpticksGenstep_EMITSOURCE ;
}
inline bool OpticksGenstep_::IsMachinery(int gentype)  // static
{
   return gentype == OpticksGenstep_MACHINERY ;
}
inline bool OpticksGenstep_::IsFrame(int gentype)  // static
{
   return gentype == OpticksGenstep_FRAME ;
}



inline unsigned OpticksGenstep_::GenstepToPhotonFlag(int gentype)  // static
{
    unsigned phcode = 0 ;
    if(!IsValid(gentype))
    {
        phcode = NAN_ABORT ;
    }
    else if(IsCerenkov(gentype))
    {
        phcode = CERENKOV ;
    }
    else if(IsScintillation(gentype))
    {
        phcode = SCINTILLATION ;
    }
    else if(IsTorchLike(gentype))
    {
        phcode = TORCH ;
    }
    else
    {
        phcode = NAN_ABORT ;
    }
    return phcode ;
}

inline unsigned OpticksGenstep_::GentypeToPhotonFlag(char gentype)  // static
{
    unsigned phcode = 0 ;
    switch(gentype)
    {
        case 'C': phcode = CERENKOV          ; break ;
        case 'S': phcode = SCINTILLATION     ; break ;
        case 'T': phcode = TORCH             ; break ;
        default:  phcode = NAN_ABORT         ; break ;
    }
    return phcode ;
}


#endif
