/*
 * Copyright (c) 2019 Opticks Team. All Rights Reserved.
 *
 * This file is part of Opticks
 * (see https://bitbucket.org/simoncblyth/opticks).
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License.  
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 */

#pragma once

/**
plog::PlainFormatter
=====================

Controls output formatting of plog logger


**/



#include <plog/Log.h>

namespace plog
{
    class PlainFormatter
    {
    public:
        static util::nstring header() // This method returns a header for a new file. In our case it is empty.
        {
            return util::nstring();
        }

        static util::nstring format(const Record& record) // This method returns a string from a record.
        {

#ifdef OLD_SLOG
            util::nstringstream ss;
            ss << record.getMessage().c_str() << "\n"; // Produce a simple string with a log message.
#else
            util::nostringstream ss;
            ss << record.getMessage() << "\n"; // Produce a simple string with a log message.
#endif

            return ss.str();
        }
    };
}

