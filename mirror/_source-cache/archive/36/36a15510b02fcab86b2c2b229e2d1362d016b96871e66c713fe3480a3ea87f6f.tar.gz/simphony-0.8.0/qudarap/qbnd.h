#pragma once
/**
qbnd.h
=========

bnd and optical are closely related so they must be kept together

**/

enum { _BOUNDARY_NUM_MATSUR = 4,  _BOUNDARY_NUM_FLOAT4 = 2 };

enum {
    OMAT,
    OSUR,
    ISUR,
    IMAT
};


#if defined(__CUDACC__) || defined(__CUDABE__)
   #define QBND_METHOD __device__
#else
   #define QBND_METHOD
#endif

struct quad4 ;
struct sstate ;


struct qbnd
{
    cudaTextureObject_t boundary_tex ;
    quad4*              boundary_meta ;
    unsigned            boundary_tex_MaterialLine_Water ;
    unsigned            boundary_tex_MaterialLine_LS ;
    quad*               optical ;

#if defined(__CUDACC__) || defined(__CUDABE__) || defined(MOCK_TEXTURE) || defined(MOCK_CUDA)
    QBND_METHOD float4 boundary_lookup(unsigned ix, unsigned iy);
    QBND_METHOD float4 boundary_lookup(float nm, unsigned line, unsigned k);
    QBND_METHOD void fill_state(sstate& s, unsigned boundary, float wavelength, float cosTheta, unsigned long long idx, unsigned long long base_pidx, unsigned carried_matline = 0xFFFFFFFFu);
#endif
};

#if defined( MOCK_TEXTURE) || defined(MOCK_CUDA)
#include "stexture.h"
#endif


#if defined(__CUDACC__) || defined(__CUDABE__) || defined( MOCK_TEXTURE) || defined(MOCK_CUDA)
/**
qbnd::boundary_lookup ix iy : Low level integer addressing lookup
--------------------------------------------------------------------

**/

inline QBND_METHOD float4 qbnd::boundary_lookup( unsigned ix, unsigned iy )
{
    const unsigned& nx = boundary_meta->q0.u.x  ;
    const unsigned& ny = boundary_meta->q0.u.y  ;
    float x = (float(ix)+0.5f)/float(nx) ;
    float y = (float(iy)+0.5f)/float(ny) ;
    float4 props = tex2D<float4>( boundary_tex, x, y );
    return props ;
}

/**
qbnd::boundary_lookup nm line k
----------------------------------

nm:    float wavelength
line:  4*boundary_index + OMAT/OSUR/ISUR/IMAT   (0/1/2/3)
k   :  property group index 0/1

return float4 props

boundary_meta is required to configure access to the texture,
it is uploaded by QTex::uploadMeta but requires calls to


QTex::init automatically sets these from tex dimensions

   q0.u.x : nx width  (eg wavelength dimension)
   q0.u.y : ny hright (eg line dimension)

QTex::setMetaDomainX::

   q1.f.x : nm0  wavelength minimum in nm
   q1.f.y : -
   q1.f.z : nms  wavelength step size in nm

QTex::setMetaDomainY::

   q2.f.x :
   q2.f.y :
   q2.f.z :


**/
inline QBND_METHOD float4 qbnd::boundary_lookup( float nm, unsigned line, unsigned k )
{
    const unsigned& nx = boundary_meta->q0.u.x  ;
    const unsigned& ny = boundary_meta->q0.u.y  ;
    const float& nm0 = boundary_meta->q1.f.x ;
    const float& nms = boundary_meta->q1.f.z ;

    // POINT filtering avoids cross-row blending on the categorical y-axis.
    // Recover wavelength-linear interpolation by reading two adjacent x-bins.
    float fx_idx = (nm - nm0) / nms;
    if (fx_idx < 0.f)
        fx_idx = 0.f;
    float    fx_lo_f = floorf(fx_idx);
    unsigned ix_lo = unsigned(fx_lo_f);
    unsigned ix_hi = ix_lo + 1u;
    if (ix_hi >= nx)
    {
        ix_hi = nx - 1u;
        ix_lo = ix_hi;
    }
    const float    w_hi = fx_idx - fx_lo_f;
    const float    w_lo = 1.0f - w_hi;
    const float    x_lo = (float(ix_lo) + 0.5f) / float(nx);
    const float    x_hi = (float(ix_hi) + 0.5f) / float(nx);
    const unsigned iy = _BOUNDARY_NUM_FLOAT4 * line + k;
    const float    y = (float(iy) + 0.5f) / float(ny);
    const float4   p_lo = tex2D<float4>(boundary_tex, x_lo, y);
    const float4   p_hi = tex2D<float4>(boundary_tex, x_hi, y);
    return make_float4(
        w_lo * p_lo.x + w_hi * p_hi.x,
        w_lo * p_lo.y + w_hi * p_hi.y,
        w_lo * p_lo.z + w_hi * p_hi.z,
        w_lo * p_lo.w + w_hi * p_hi.w);
}


/**
qbnd::fill_state
-------------------

Formerly signed the 1-based boundary, now just keeping separate cosTheta to
orient the use of the boundary so are using 0-based boundary.

cosTheta < 0.f
   photon direction is against the surface normal, ie are entering the shape

   * formerly this corresponded to -ve boundary
   * line+OSUR is relevant surface
   * line+OMAT is relevant first material

cosTheta > 0.f
   photon direction is with the surface normal, ie are exiting the shape

   * formerly this corresponded to +ve boundary
   * line+ISUR is relevant surface
   * line+IMAT is relevant first material


NB the line is above the details of the payload (ie how many float4 per matsur) it is just::

    boundaryIndex*4  + 0/1/2/3     for OMAT/OSUR/ISUR/IMAT


The optical buffer is 4 times the length of the bnd, which allows
convenient access to the material and surface indices starting
from a texture line.

Optical buffer is populated by sstandard::make_optical
former impl::

    GBndLib::createOpticalBuffer
    GBndLib::getOpticalBuf

Notice that s.optical.x and s.index.z are the same thing.
So half of s.index is extraneous and the m1 index and m2 index
is not much used.

Also only one element of m1group2 was formerly used. The y slot now carries
material2 group velocity so transmitted segments can carry the correct active
medium timing across boundary crossings.


s.optical.x
    used to distinguish between : boundary, surface (and in future multifilm)

    * currently contains 1-based surface index with 0 meaning "boundary" and anything else "surface"

    * TODO: encode boundary type enum into the high bits of s.optical.x for three way split
      (perhaps use trigger strings like MULTIFILM in the boundary spec to configure)
      THIS WILL NEED TO BE DONE AT x4 translation level (and repeated in QBndOptical for
      dynamic boundary adding)

**/

inline QBND_METHOD void qbnd::fill_state(sstate& s, unsigned boundary, float wavelength, float cosTheta, unsigned long long idx, unsigned long long base_pidx, unsigned carried_matline)
{
    const int line = boundary * _BOUNDARY_NUM_MATSUR; // now that are not signing boundary use 0-based

    int       m1_line = cosTheta > 0.f ? line + IMAT : line + OMAT;
    const int m2_line = cosTheta > 0.f ? line + OMAT : line + IMAT;
    const int su_line = cosTheta > 0.f ? line + ISUR : line + OSUR;

    // A boundary normally describes a daughter volume relative to its parent.
    // When two daughter volumes touch, however, a photon can move directly from
    // one sibling to the other. The boundary selected by OptiX may then name the
    // common parent instead of the material the photon is actually leaving.
    //
    // qsim carries the material-table row for the photon's current volume across
    // interactions. Use that row as material1 when it is valid so absorption and
    // scattering are sampled from the correct medium. Material2 and the surface
    // still come from the selected boundary.
    //
    // UINT_MAX means that no current-material row is available. Line zero is a
    // valid material row. Surface rows and rows beyond the uploaded boundary
    // table must not be used for property or optical-buffer lookups.
    const unsigned num_matline = boundary_meta->q0.u.y / _BOUNDARY_NUM_FLOAT4;
    const unsigned matline_slot = carried_matline & 0x3u;
    const bool     carried_matline_valid = carried_matline < num_matline && (matline_slot == unsigned(OMAT) || matline_slot == unsigned(IMAT));

    if (carried_matline_valid)
    {
        m1_line = int(carried_matline);
    }

    s.material1 = boundary_lookup(wavelength, m1_line, 0); // refractive_index, absorption_length, scattering_length, reemission_prob
    s.m1group2 = boundary_lookup(wavelength, m1_line, 1);  // x: material1 group_velocity, y: material2 group_velocity, z/w unused
    s.material2 = boundary_lookup(wavelength, m2_line, 0); // refractive_index, (absorption_length, scattering_length, reemission_prob) only m2:refractive index actually used
    s.surface = boundary_lookup(wavelength, su_line, 0);   // detect,         , absorb            , (reflect_specular), reflect_diffuse     [they add to 1. so one not used]
    s.set_material2_group_velocity(boundary_lookup(wavelength, m2_line, 1).x);

    s.optical = optical[su_line].u; // 1-based-surface-index-0-meaning-boundary/type/finish/value  (type,finish,value not used currently)

    s.index.x = optical[m1_line].u.x; // m1 index (1-based, see sstandard::make_optical) -- reflects override if any
    s.index.y = optical[m2_line].u.x; // m2 index (1-based, see sstandard::make_optical)
    s.index.z = optical[su_line].u.x; // su index (1-based, see sstandard::make_optical)
    s.index.w = 0u;                   // avoid undefined memory comparison issues

#if !defined(PRODUCTION) && defined(DEBUG_PIDX)
    if (idx == base_pidx)
    {
        printf("//qbnd.fill_state idx %7lld boundary %d line %d wavelength %10.4f m1_line %d m2_line %d su_line %d s.optical.x %d  \n", idx, boundary, line, wavelength, m1_line, m2_line, su_line, s.optical.x );
        printf("//qbnd.fill_state idx %7lld boundary %d [s.index.x-1](m1_index) %d [s.index.y-1](m2_index) %d [s.index.z-1](su_index) %d \n", idx, boundary, s.index.x-1u, s.index.y-1u, s.index.z-1u );
    }
#endif


}

#endif
