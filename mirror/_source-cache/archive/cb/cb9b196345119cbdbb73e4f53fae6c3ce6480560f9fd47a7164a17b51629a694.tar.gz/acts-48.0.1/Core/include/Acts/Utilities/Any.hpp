// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Utilities/HashedString.hpp"

#include <algorithm>
#include <any>
#include <array>
#include <cassert>
#include <cstddef>
#include <type_traits>
#include <typeinfo>
#include <utility>

// #define _ACTS_ANY_ENABLE_VERBOSE
// #define _ACTS_ANY_ENABLE_DEBUG
// #define _ACTS_ANY_ENABLE_TRACK_ALLOCATIONS

#if defined(_ACTS_ANY_ENABLE_TRACK_ALLOCATIONS)
#include <iostream>
#include <mutex>
#include <set>
#include <typeindex>
#endif

#if defined(_ACTS_ANY_ENABLE_VERBOSE) || defined(_ACTS_ANY_ENABLE_DEBUG)
#include <iomanip>
#include <iostream>
#endif

#if defined(_ACTS_ANY_ENABLE_DEBUG)
#define _ACTS_ANY_DEBUG(x) std::cout << x << std::endl;
#else
#define _ACTS_ANY_DEBUG(x)
#endif

#if defined(_ACTS_ANY_ENABLE_VERBOSE)
#define _ACTS_ANY_VERBOSE(x) std::cout << x << std::endl;
#define _ACTS_ANY_VERBOSE_BUFFER(s, b)              \
  do {                                              \
    std::cout << "" << s << ": 0x";                 \
    for (char c : b) {                              \
      std::cout << std::hex << static_cast<int>(c); \
    }                                               \
    std::cout << std::endl;                         \
  } while (0)
#else
#define _ACTS_ANY_VERBOSE(x)
#define _ACTS_ANY_VERBOSE_BUFFER(s, b)
#endif

namespace Acts {

namespace detail {
#if defined(_ACTS_ANY_ENABLE_TRACK_ALLOCATIONS)
static std::mutex _s_any_mutex;
static std::set<std::pair<std::type_index, void*>> _s_any_allocations;

#define _ACTS_ANY_TRACK_ALLOCATION(T, heap)                                  \
  do {                                                                       \
    std::lock_guard guard{detail::_s_any_mutex};                             \
    detail::_s_any_allocations.emplace(std::type_index(typeid(T)), heap);    \
    _ACTS_ANY_DEBUG("Allocate type: " << typeid(T).name() << " at " << heap) \
  } while (0)

#define _ACTS_ANY_TRACK_DEALLOCATION(T, heap)                           \
  do {                                                                  \
    std::lock_guard guard{detail::_s_any_mutex};                        \
    auto it = detail::_s_any_allocations.find(                          \
        std::pair{std::type_index(typeid(T)), heap});                   \
    if (it == detail::_s_any_allocations.end()) {                       \
      throw std::runtime_error{                                         \
          "Trying to deallocate heap address that we didn't allocate"}; \
    }                                                                   \
    detail::_s_any_allocations.erase(it);                               \
  } while (0)

// Do not make member functions noexcept in the debug case
static constexpr bool kAnyNoexcept = false;

struct _AnyAllocationReporter {
  static void checkAllocations() {
    std::lock_guard guard{detail::_s_any_mutex};

    if (!detail::_s_any_allocations.empty()) {
      std::cout << "Not all allocations have been released" << std::endl;
      for (const auto& [idx, addr] : detail::_s_any_allocations) {
        std::cout << "- " << idx.name() << ": " << addr << std::endl;
      }
      throw std::runtime_error{"AnyCheckAllocations failed"};
    }
  }

  ~_AnyAllocationReporter() noexcept { checkAllocations(); }
};
static _AnyAllocationReporter s_reporter;
#else
#define _ACTS_ANY_TRACK_ALLOCATION(T, heap) \
  do {                                      \
  } while (0)
#define _ACTS_ANY_TRACK_DEALLOCATION(T, heap) \
  do {                                        \
  } while (0)
static constexpr bool kAnyNoexcept = true;
#endif
}  // namespace detail

/// @addtogroup utilities
/// @{

/// Base class for all instances of @ref AnyBase regarfless of SBO size
class AnyBaseAll {};

/// Small opaque type-erased type with configurable small buffer optimization
///
/// @tparam SbSize Size of the internal buffer for small buffer optimization
/// @tparam Copyable If true, stored types must be copyable and AnyBase is
///         copyable. If false, move-only types are allowed and AnyBase is
///         move-only (copy constructor and copy assignment are deleted).
///
/// @note
/// Type requirements when Copyable is true:
/// - All stored types must be copy constructible and copy assignable.
/// - Types stored locally (`sizeof(T) <= SbSize`) must also be move
/// constructible
///   and move assignable because local moves use move operations when not
///   trivially movable (trivial moves fall back to buffer copies).
/// - Types stored on the heap (`sizeof(T) > SbSize`) are moved by stealing the
///   pointer, so no move operations are required in that case.
///
/// @note
/// Type requirements when Copyable is false:
/// - All stored types must be move constructible.
/// - Types stored locally must also be move assignable.
/// - Heap-allocated types only need move constructible (pointer steal).
///
/// @note
/// In summary:
/// - Local storage: values live inside the internal buffer; moves may invoke
///   move operations or buffer copies; copies use copy operations or buffer
///   copies when trivial.
/// - Heap storage: values are allocated on the heap; moves transfer ownership
///   of the pointer; copies allocate and copy-construct the pointee.
template <std::size_t SbSize, bool Copyable = true, typename Base = void>
class AnyBase : public AnyBaseAll {
  static_assert(sizeof(void*) <= SbSize, "Size is too small for a pointer");

  /// Type trait: T is storable when Copyable requires copy+move, else
  /// move-only. When @c Base is not @c void, the type must additionally be
  /// convertible to @c Base* (i.e. publicly and unambiguously derived).
  /// @tparam U Type to check
  /// @return True if the type is storable, false otherwise
  template <typename U>
  static constexpr bool isStorable() {
    if constexpr (std::is_base_of_v<AnyBaseAll, U>) {
      return false;
    } else if constexpr (!std::is_void_v<Base> &&
                         !std::is_convertible_v<U*, Base*>) {
      return false;
    } else if constexpr (Copyable) {
      return std::is_copy_assignable_v<U> && std::is_copy_constructible_v<U> &&
             (sizeof(U) > SbSize || (std::is_move_assignable_v<U> &&
                                     std::is_move_constructible_v<U>));
    } else {
      return std::is_move_constructible_v<U> &&
             (sizeof(U) > SbSize || std::is_move_assignable_v<U>);
    }
  }

 public:
  /// Construct with in-place type construction
  /// @tparam T Type to construct
  /// @tparam Args Constructor argument types
  /// @param args Arguments to forward to T's constructor
  template <typename T, typename... Args>
    requires(isStorable<std::decay_t<T>>())
  explicit AnyBase(std::in_place_type_t<T> /*unused*/, Args&&... args) {
    using U = std::decay_t<T>;
    m_handler = makeHandler<U>();
    constructValue<U>(std::forward<Args>(args)...);
  }

#if defined(_ACTS_ANY_ENABLE_VERBOSE)
  AnyBase() { _ACTS_ANY_VERBOSE("Default construct this=" << this); };
#else
  // User-provided (not defaulted) so that a const-qualified AnyBase can still
  // be default-initialized even though m_data is deliberately left
  // uninitialized (see its declaration).
  AnyBase() {}
#endif

  /// Construct from any value type
  /// @tparam T Type of the value to store
  /// @param value Value to store in the Any
  /// @note Not noexcept: storing a type larger than the small buffer allocates
  ///       on the heap (may throw std::bad_alloc) and the stored type's own
  ///       constructor may throw.
  template <typename T>
  explicit AnyBase(T&& value)
    requires(!std::is_base_of_v<AnyBaseAll, std::decay_t<T>> &&
             isStorable<std::decay_t<T>>())
      : AnyBase{std::in_place_type<T>, std::forward<T>(value)} {}

  /// Construct a new value in place, destroying any existing value
  /// @tparam T Type to construct
  /// @tparam Args Constructor argument types
  /// @param args Arguments to forward to T's constructor
  /// @return Reference to the newly constructed value
  template <typename T, typename... Args>
    requires(isStorable<std::decay_t<T>>())
  T& emplace(Args&&... args) {
    using U = std::decay_t<T>;
    destroy();
    // Construct the new value before installing the handler. constructValue
    // does not depend on m_handler, so if the constructor throws this object is
    // left empty (m_handler == nullptr) rather than claiming to hold a value
    // whose storage was never set up, which would make the next destroy()
    // operate on stale/freed memory.
    U* ptr = constructValue<U>(std::forward<Args>(args)...);
    m_handler = makeHandler<U>();
    return *ptr;
  }

  /// Get reference to stored value of specified type
  /// @tparam T Type to retrieve (must be exact type, no const/ref)
  /// @return Reference to the stored value
  /// @throws std::bad_any_cast if stored type doesn't match T
  template <typename T>
  T& as() {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    if (m_handler == nullptr || m_handler->typeHash != typeHash<T>()) {
      throw std::bad_any_cast{};
    }

    _ACTS_ANY_VERBOSE("Get as "
                      << (m_handler->heapAllocated ? "heap" : "local"));

    return *std::bit_cast<T*>(dataPtr());
  }

  /// Get const reference to stored value of specified type
  /// @tparam T Type to retrieve (must be exact type, no const/ref)
  /// @return Const reference to the stored value
  /// @throws std::bad_any_cast if stored type doesn't match T
  template <typename T>
  const T& as() const {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    if (m_handler == nullptr || m_handler->typeHash != typeHash<T>()) {
      throw std::bad_any_cast{};
    }

    _ACTS_ANY_VERBOSE("Get as "
                      << (m_handler->heapAllocated ? "heap" : "local"));

    return *std::bit_cast<const T*>(dataPtr());
  }

  /// Get pointer to stored value of specified type
  /// @tparam T Type to retrieve (must be exact type, no const/ref)
  /// @return Pointer to the stored value, or nullptr if the type doesn't match
  ///         or the Any is empty
  template <typename T>
  T* asPtr() {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    if (m_handler == nullptr || m_handler->typeHash != typeHash<T>()) {
      return nullptr;
    }
    return std::bit_cast<T*>(dataPtr());
  }

  /// Get const pointer to stored value of specified type
  /// @tparam T Type to retrieve (must be exact type, no const/ref)
  /// @return Const pointer to the stored value, or nullptr if the type doesn't
  ///         match or the Any is empty
  template <typename T>
  const T* asPtr() const {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    if (m_handler == nullptr || m_handler->typeHash != typeHash<T>()) {
      return nullptr;
    }
    return std::bit_cast<const T*>(dataPtr());
  }

  /// Move the stored value out. Leaves this Any empty.
  /// @tparam T Type to retrieve (must be exact type, no const/ref)
  /// @return The moved-out value
  /// @throws std::bad_any_cast if stored type doesn't match T or Any is empty
  template <typename T>
  T take() {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    if (m_handler == nullptr || m_handler->typeHash != typeHash<T>()) {
      throw std::bad_any_cast{};
    }
    T* ptr = std::bit_cast<T*>(dataPtr());
    T value = std::move(*ptr);
    destroy();
    return value;
  }

  ~AnyBase() { destroy(); }

  /// Copy constructor (only when Copyable is true)
  /// @param other The AnyBase to copy from
  /// @note Not noexcept: copying a heap-allocated value allocates (may throw
  ///       std::bad_alloc) and the stored type's copy constructor may throw.
  AnyBase(const AnyBase& other)
    requires Copyable
  {
    if (m_handler == nullptr && other.m_handler == nullptr) {
      // both are empty, noop
      return;
    }

    _ACTS_ANY_VERBOSE("Copy construct (this="
                      << this << ") at: " << static_cast<void*>(m_data.data()));

    m_handler = other.m_handler;
    copyConstruct(other);
  }

  /// Copy constructor deleted when Copyable is false (move-only variant)
  AnyBase(const AnyBase&)
    requires(!Copyable)
  = delete;

  /// Copy assignment operator (only when Copyable is true)
  /// @param other The AnyBase to copy from
  /// @return Reference to this object
  /// @note Not noexcept: copying a heap-allocated value allocates (may throw
  ///       std::bad_alloc) and the stored type's copy operations may throw.
  AnyBase& operator=(const AnyBase& other)
    requires Copyable
  {
    _ACTS_ANY_VERBOSE("Copy assign (this="
                      << this << ") at: " << static_cast<void*>(m_data.data()));

    if (this == &other) {
      // self-assignment, noop
      return *this;
    }

    if (m_handler == nullptr && other.m_handler == nullptr) {
      // both are empty, noop
      return *this;
    }

    if (m_handler == other.m_handler) {
      // same type, but checked before they're not both nullptr
      copy(other);
    } else {
      if (m_handler != nullptr) {
        // this object is not empty, but have different types => destroy
        destroy();
      }
      assert(m_handler == nullptr);
      m_handler = other.m_handler;
      try {
        copyConstruct(other);
      } catch (...) {
        // copyConstruct allocates and/or runs the stored type's copy
        // constructor, either of which may throw. If it does, no value was
        // established, so leave *this empty rather than with a handler that
        // claims a value that does not exist (which would make destruction
        // operate on uninitialized storage).
        m_handler = nullptr;
        throw;
      }
    }
    return *this;
  }

  /// Copy assignment deleted when Copyable is false (move-only variant)
  AnyBase& operator=(const AnyBase&)
    requires(!Copyable)
  = delete;

  /// Move constructor
  /// @param other The AnyBase to move from
  AnyBase(AnyBase&& other) noexcept(detail::kAnyNoexcept) {
    _ACTS_ANY_VERBOSE("Move construct (this="
                      << this << ") at: " << static_cast<void*>(m_data.data()));
    if (m_handler == nullptr && other.m_handler == nullptr) {
      // both are empty, noop
      return;
    }

    m_handler = other.m_handler;
    moveConstruct(std::move(other));
  }

  /// Move assignment operator
  /// @param other The AnyBase to move from
  /// @return Reference to this object
  AnyBase& operator=(AnyBase&& other) noexcept(detail::kAnyNoexcept) {
    _ACTS_ANY_VERBOSE("Move assign (this="
                      << this << ") at: " << static_cast<void*>(m_data.data()));
    if (this == &other) {
      // self-assignment, noop (avoids destroying our own value)
      return *this;
    }

    if (m_handler == nullptr && other.m_handler == nullptr) {
      // both are empty, noop
      return *this;
    }

    // At this point they can't be equal and nullptr, so it's safe to
    // dereference
    if (m_handler == other.m_handler &&
        m_handler->typeHash == other.m_handler->typeHash) {
      // same type, but checked before they're not both nullptr
      move(std::move(other));
    } else {
      if (m_handler != nullptr) {
        // this object is not empty, but have different types => destroy
        destroy();
      }
      assert(m_handler == nullptr);
      m_handler = other.m_handler;
      moveConstruct(std::move(other));
    }

    return *this;
  }

  /// Check if the AnyBase contains a value
  /// @return True if a value is stored, false if empty
  explicit operator bool() const { return m_handler != nullptr; }

  /// Type info of the stored value. Returns nullptr if empty.
  /// @return Pointer to the type info of the stored value, or nullptr if empty
  const std::type_info* typeInfo() const {
    return m_handler != nullptr ? m_handler->typeInfo : nullptr;
  }

  /// Check whether the stored value is exactly of type @p T.
  /// @tparam T The type to test for (raw type, no const/ref)
  /// @return True if a value of type T is stored, false otherwise (incl. empty)
  template <typename T>
  bool is() const {
    static_assert(std::is_same_v<T, std::decay_t<T>>,
                  "Please pass the raw type, no const or ref");
    return m_handler != nullptr && m_handler->typeHash == typeHash<T>();
  }

  // The base accessors below are member templates on a dummy @c B defaulting to
  // @c Base. This keeps their return types (@c B& / @c B*) from being formed
  // when @c Base is @c void: the member template is only instantiated on use,
  // and the @c requires clause removes it entirely for the untyped variant. A
  // plain non-template member would try to form @c void& at class instantiation
  // and fail to compile.

  /// Get a pointer to the stored value as @c Base*, regardless of its concrete
  /// type. Only available when @c Base is not @c void.
  /// @return Pointer to the stored value upcast to @c Base*, or nullptr if empty
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  B* asBase() {
    if (m_handler == nullptr) {
      return nullptr;
    }
    return m_handler->upcast(dataPtr());
  }

  /// Get a const pointer to the stored value as @c Base*. Only available when
  /// @c Base is not @c void.
  /// @return Const pointer to the stored value upcast to @c Base*, or nullptr if empty
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  const B* asBase() const {
    if (m_handler == nullptr) {
      return nullptr;
    }
    return m_handler->upcastConst(dataPtr());
  }

  /// Dereference to the stored value as @c Base&. Only available when @c Base
  /// is not @c void.
  /// @return Reference to the stored value upcast to @c Base&
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  B& operator*() {
    assert(m_handler != nullptr && "operator* on empty AnyBase");
    return *m_handler->upcast(dataPtr());
  }

  /// Dereference to the stored value as @c const @c Base&. Only available when
  /// @c Base is not @c void.
  /// @return Const reference to the stored value upcast to @c Base&
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  const B& operator*() const {
    assert(m_handler != nullptr && "operator* on empty AnyBase");
    return *m_handler->upcastConst(dataPtr());
  }

  /// Member access on the stored value as @c Base*. Only available when
  /// @c Base is not @c void.
  /// @return Pointer to the stored value upcast to @c Base*
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  B* operator->() {
    assert(m_handler != nullptr && "operator-> on empty AnyBase");
    return m_handler->upcast(dataPtr());
  }

  /// Member access on the stored value as @c const @c Base*. Only available
  /// when @c Base is not @c void.
  /// @return Const pointer to the stored value upcast to @c Base*
  template <typename B = Base>
    requires(!std::is_void_v<B>)
  const B* operator->() const {
    assert(m_handler != nullptr && "operator-> on empty AnyBase");
    return m_handler->upcastConst(dataPtr());
  }

 private:
  void* dataPtr() {
    if (m_handler->heapAllocated) {
      return *std::bit_cast<void**>(m_data.data());
    } else {
      return std::bit_cast<void*>(m_data.data());
    }
  }

  void setDataPtr(void* ptr) { *std::bit_cast<void**>(m_data.data()) = ptr; }

  const void* dataPtr() const {
    if (m_handler->heapAllocated) {
      return *std::bit_cast<void* const*>(m_data.data());
    } else {
      return std::bit_cast<const void*>(m_data.data());
    }
  }

  struct Handler {
    // Maps the stored payload to Base*. Collapses to void*(*)(void*) and stays
    // nullptr (never read) when Base == void.
    Base* (*upcast)(void*) = nullptr;
    // Const-qualified counterpart used by the const accessors so they don't
    // have to cast away const on the data pointer. Same as above when
    // Base == void.
    const Base* (*upcastConst)(const void*) = nullptr;
    void (*destroy)(void* ptr) = nullptr;
    void (*moveConstruct)(void* from, void* to) = nullptr;
    void (*move)(void* from, void* to) = nullptr;
    void* (*copyConstruct)(const void* from, void* to) = nullptr;
    void (*copy)(const void* from, void* to) = nullptr;
    bool heapAllocated{false};
    std::uint64_t typeHash{0};
    const std::type_info* typeInfo{nullptr};
  };

  template <typename T>
  static const Handler* makeHandler() {
    static_assert(!std::is_base_of_v<AnyBaseAll, std::decay_t<T>>,
                  "Cannot wrap Any in Any");
    static const Handler static_handler = []() {
      Handler h;
      h.heapAllocated = heapAllocated<T>();
      if constexpr (!std::is_trivially_destructible_v<T> ||
                    heapAllocated<T>()) {
        h.destroy = &destroyImpl<T>;
      }
      if constexpr (!heapAllocated<T>() &&
                    !std::is_trivially_move_constructible_v<T>) {
        h.moveConstruct = &moveConstructImpl<T>;
      }
      if constexpr (!heapAllocated<T>() &&
                    !std::is_trivially_move_assignable_v<T>) {
        h.move = &moveImpl<T>;
      }
      if constexpr (std::is_copy_constructible_v<T> &&
                    (!std::is_trivially_copy_constructible_v<T> ||
                     heapAllocated<T>())) {
        h.copyConstruct = &copyConstructImpl<T>;
      }

      if constexpr (std::is_copy_assignable_v<T> &&
                    (!std::is_trivially_copy_assignable_v<T> ||
                     heapAllocated<T>())) {
        h.copy = &copyImpl<T>;
      }

      if constexpr (!std::is_void_v<Base>) {
        h.upcast = [](void* p) -> Base* {
          return static_cast<Base*>(static_cast<T*>(p));
        };
        h.upcastConst = [](const void* p) -> const Base* {
          return static_cast<const Base*>(static_cast<const T*>(p));
        };
      }

      h.typeHash = typeHash<T>();
      h.typeInfo = &typeid(T);

      _ACTS_ANY_DEBUG("Type: " << typeid(T).name());
      _ACTS_ANY_DEBUG(" -> destroy: " << h.destroy);
      _ACTS_ANY_DEBUG(" -> moveConstruct: " << h.moveConstruct);
      _ACTS_ANY_DEBUG(" -> move: " << h.move);
      _ACTS_ANY_DEBUG(" -> copyConstruct: " << h.copyConstruct);
      _ACTS_ANY_DEBUG(" -> copy: " << h.copy);
      _ACTS_ANY_DEBUG(
          " -> heapAllocated: " << (h.heapAllocated ? "yes" : "no"));

      return h;
    }();
    return &static_handler;
  }

  template <typename T>
  static constexpr bool heapAllocated() {
    return sizeof(T) > SbSize;
  }

  template <typename T, typename... Args>
  T* constructValue(Args&&... args) {
    if constexpr (!heapAllocated<T>()) {
      // construct into local buffer
      auto* ptr = new (m_data.data()) T(std::forward<Args>(args)...);
      _ACTS_ANY_VERBOSE("Construct local (this="
                        << this
                        << ") at: " << static_cast<void*>(m_data.data()));
      return ptr;
    } else {
      // too large, heap allocate
      auto* heap = new T(std::forward<Args>(args)...);
      _ACTS_ANY_DEBUG("Allocate type: " << typeid(T).name() << " at " << heap);
      _ACTS_ANY_TRACK_ALLOCATION(T, heap);
      setDataPtr(heap);
      return heap;
    }
  }

  void destroy() {
    _ACTS_ANY_VERBOSE("Destructor this=" << this << " handler: " << m_handler);
    if (m_handler != nullptr && m_handler->destroy != nullptr) {
      _ACTS_ANY_VERBOSE("Non-trivial destruction");
      m_handler->destroy(dataPtr());
    }
    m_handler = nullptr;
  }

  void moveConstruct(AnyBase&& fromAny) {
    if (m_handler == nullptr) {
      return;
    }

    void* to = dataPtr();
    void* from = fromAny.dataPtr();
    if (m_handler->heapAllocated) {
      // stored on heap: just copy the pointer
      setDataPtr(fromAny.dataPtr());
      // do not delete in moved-from any
      fromAny.m_handler = nullptr;
      return;
    }

    if (m_handler->moveConstruct == nullptr) {
      _ACTS_ANY_VERBOSE("Trivially move construct");
      // trivially move constructible
      m_data = std::move(fromAny.m_data);
    } else {
      m_handler->moveConstruct(from, to);
    }
  }

  void move(AnyBase&& fromAny) {
    if (m_handler == nullptr) {
      return;
    }

    void* to = dataPtr();
    void* from = fromAny.dataPtr();
    if (m_handler->heapAllocated) {
      // stored on heap: just copy the pointer
      // need to delete existing pointer
      m_handler->destroy(dataPtr());
      setDataPtr(fromAny.dataPtr());
      // do not delete in moved-from any
      fromAny.m_handler = nullptr;
      return;
    }

    if (m_handler->move == nullptr) {
      _ACTS_ANY_VERBOSE("Trivially move");
      // trivially movable
      m_data = std::move(fromAny.m_data);
    } else {
      m_handler->move(from, to);
    }
  }

  void copyConstruct(const AnyBase& fromAny) {
    if (m_handler == nullptr) {
      return;
    }

    const void* from = fromAny.dataPtr();

    if (m_handler->copyConstruct == nullptr) {
      _ACTS_ANY_VERBOSE("Trivially copy construct");
      // trivially copy constructible
      m_data = fromAny.m_data;
    } else if (m_handler->heapAllocated) {
      // heap-allocated: always allocate fresh storage. We must not read the
      // current contents of m_data here: when copyConstruct runs as part of a
      // copy assignment with a type change, the previous value has already been
      // destroyed but m_data still holds its stale bytes (a freed pointer, or
      // the previous local value's bytes). Passing those as the destination
      // would placement-new into garbage. Allocate and store the new pointer.
      void* copyAt = m_handler->copyConstruct(from, nullptr);
      assert(copyAt != nullptr);
      setDataPtr(copyAt);
    } else {
      // local storage: construct into the internal buffer
      m_handler->copyConstruct(from, dataPtr());
    }
  }

  void copy(const AnyBase& fromAny) {
    if (m_handler == nullptr) {
      return;
    }

    void* to = dataPtr();
    const void* from = fromAny.dataPtr();

    if (m_handler->copy == nullptr) {
      _ACTS_ANY_VERBOSE("Trivially copy");
      // trivially copyable
      m_data = fromAny.m_data;
    } else {
      m_handler->copy(from, to);
    }
  }

  template <typename T>
  static void destroyImpl(void* ptr) {
    assert(ptr != nullptr && "Address to destroy is nullptr");
    auto* obj = static_cast<T*>(ptr);
    if constexpr (!heapAllocated<T>()) {
      // stored in place: just call the destructor
      _ACTS_ANY_VERBOSE("Destroy local at: " << ptr);
      obj->~T();
    } else {
      // stored on heap: delete
      _ACTS_ANY_DEBUG("Delete type: " << typeid(T).name()
                                      << " heap at: " << obj);
      _ACTS_ANY_TRACK_DEALLOCATION(T, obj);
      delete obj;
    }
  }

  template <typename T>
  static void moveConstructImpl(void* from, void* to) {
    _ACTS_ANY_VERBOSE("move const: " << from << " -> " << to);
    assert(from != nullptr && "Source is null");
    assert(to != nullptr && "Target is null");
    auto* _from = static_cast<T*>(from);
    /*T* ptr =*/new (to) T(std::move(*_from));
  }

  template <typename T>
  static void moveImpl(void* from, void* to) {
    _ACTS_ANY_VERBOSE("move: " << from << " -> " << to);
    assert(from != nullptr && "Source is null");
    assert(to != nullptr && "Target is null");

    auto* _from = static_cast<T*>(from);
    auto* _to = static_cast<T*>(to);

    (*_to) = std::move(*_from);
  }

  template <typename T>
  static void* copyConstructImpl(const void* from, void* to) {
    _ACTS_ANY_VERBOSE("copy const: " << from << " -> " << to);
    assert(from != nullptr && "Source is null");
    const auto* _from = static_cast<const T*>(from);
    if (to == nullptr) {
      assert(heapAllocated<T>() && "Received nullptr in local buffer case");
      to = new T(*_from);
      _ACTS_ANY_TRACK_ALLOCATION(T, to);

    } else {
      assert(!heapAllocated<T>() && "Received non-nullptr in heap case");
      /*T* ptr =*/new (to) T(*_from);
    }
    return to;
  }

  template <typename T>
  static void copyImpl(const void* from, void* to) {
    _ACTS_ANY_VERBOSE("copy: " << from << " -> " << to);
    assert(from != nullptr && "Source is null");
    assert(to != nullptr && "Target is null");

    const auto* _from = static_cast<const T*>(from);
    auto* _to = static_cast<T*>(to);

    (*_to) = *_from;
  }

  static constexpr std::size_t kMaxAlignment =
      std::max(alignof(std::max_align_t),
#if defined(__AVX512F__)
               std::size_t{64}
#elif defined(__AVX__)
               std::size_t{32}
#elif defined(__SSE__)
               std::size_t{16}
#else
               std::size_t{0}
  // Neutral element
  // for maximum
#endif
      );

  // Deliberately not value-initialized: the buffer is only ever read through
  // m_handler, which is set exactly when a value has been constructed in (or
  // pointed to from) the buffer. Zero-filling it on every default construction
  // would put a memset on hot paths that create AnyBase objects frequently.
  alignas(kMaxAlignment) std::array<std::byte, SbSize> m_data;
  const Handler* m_handler{nullptr};
};

/// @brief A type-safe container for single values of any type
/// @details This is a custom implementation similar to `std::any` but optimized for small types
///          that can fit into a pointer-sized buffer. Values larger than a
///          pointer are stored on the heap.
using Any = AnyBase<sizeof(void*), true>;

/// @brief Move-only variant that can store move-only types (e.g. std::unique_ptr)
/// @details Same as Any but copy constructor and copy assignment are deleted.
///          Use when storing types that are not copyable.
using AnyMoveOnly = AnyBase<sizeof(void*), false>;

/// @brief Typed type-erased value over a common polymorphic base
/// @details Stores any value of a type @c T convertible to @c Base* (i.e.
///          publicly and unambiguously derived from @c Base) and hands it back
///          as @c Base& / @c Base* through @ref AnyBase::asBase,
///          @ref AnyBase::operator* and @ref AnyBase::operator-> without naming
///          @c T. The concrete type can still be recovered with
///          @ref AnyBase::as / @ref AnyBase::asPtr. Copyable; values up to
///          @c SbSize bytes are stored inline, larger ones on the heap.
/// @tparam Base Common base class exposed by the accessors
/// @tparam SbSize Size of the small-buffer-optimization storage
template <typename Base, std::size_t SbSize = sizeof(void*)>
using AnyOf = AnyBase<SbSize, true, Base>;

/// @}

#undef _ACTS_ANY_VERBOSE
#undef _ACTS_ANY_VERBOSE_BUFFER
#undef _ACTS_ANY_ENABLE_VERBOSE

}  // namespace Acts
