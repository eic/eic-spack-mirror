/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "ONNXInferenceModel.h"

#include <stdexcept>

namespace mlutils {

ONNXInferenceModel::ONNXInferenceModel(const std::string& name, OrtLoggingLevel logLevel, bool useCuda,
                                       std::size_t cudaDeviceIndex)
    : m_env(std::make_unique<Ort::Env>(logLevel, name.c_str())),
      m_sessionOptions(std::make_unique<Ort::SessionOptions>()), m_envName(name) {
  // Run model on a single CPU core
  m_sessionOptions->SetIntraOpNumThreads(1);
  // Let ONNX perform optimizations on the model graph to improve performance
  m_sessionOptions->SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_EXTENDED);

  if (useCuda) {
    // Prefer CUDA but fall back to CPU for any op the CUDA EP does not support.
    OrtCUDAProviderOptions cudaOptions{};
    cudaOptions.device_id = static_cast<int>(cudaDeviceIndex);
    m_sessionOptions->AppendExecutionProvider_CUDA(cudaOptions);
  }
}

void ONNXInferenceModel::loadModel(const std::string& modelPath) {
  cleanup();
  try {
    m_session = std::make_unique<Ort::Session>(*m_env, modelPath.c_str(), *m_sessionOptions);
    extractModelInfo();
    m_modelLoaded = true;
  } catch (const std::exception& e) {
    // Leave the model in the "nothing loaded" state, whatever stage failed, and
    // hand the onnxruntime message on: it says why, but not which model.
    cleanup();
    throw std::runtime_error("Could not load the " + m_envName + " ONNX model '" + modelPath + "': " + e.what());
  }
}

std::vector<Ort::Value> ONNXInferenceModel::runInference(const std::vector<float>& inputData,
                                                         const std::vector<int64_t>& inputShape, int cudaDeviceIndex) {
  if (!m_modelLoaded) {
    throw std::runtime_error("Model not loaded");
  }

  try {
    // Create input tensor
    auto memoryInfo = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    // We re-use the buffer provided by the inputData
    auto inputTensor = Ort::Value::CreateTensor(memoryInfo, const_cast<float*>(inputData.data()), inputData.size(),
                                                inputShape.data(), inputShape.size());

    // Prepare input/output names
    std::vector<const char*> inputNames;
    std::vector<const char*> outputNames;

    for (const auto& name : m_inputNames) {
      inputNames.push_back(name.c_str());
    }
    for (const auto& name : m_outputNames) {
      outputNames.push_back(name.c_str());
    }

    if (cudaDeviceIndex < 0) {
      // Run inference (CPU/default)
      return m_session->Run(Ort::RunOptions{nullptr}, inputNames.data(), &inputTensor, 1, outputNames.data(),
                            outputNames.size());
    }

    // CUDA: bind outputs explicitly to CUDA so result tensors stay on GPU.
    Ort::IoBinding ioBinding(*m_session);
    ioBinding.BindInput(inputNames.front(), inputTensor);

    Ort::MemoryInfo cudaOutputMemoryInfo{"Cuda", OrtAllocatorType::OrtDeviceAllocator, cudaDeviceIndex,
                                         OrtMemTypeDefault};
    for (const auto* outputName : outputNames) {
      ioBinding.BindOutput(outputName, cudaOutputMemoryInfo);
    }

    m_session->Run(Ort::RunOptions{nullptr}, ioBinding);
    return ioBinding.GetOutputValues();
  } catch (const std::exception& e) {
    throw std::runtime_error("Inference failed: " + std::string(e.what()));
  }
}

void ONNXInferenceModel::extractModelInfo() {
  if (!m_session) {
    return;
  }

  // Clear existing info
  m_inputNames.clear();
  m_outputNames.clear();
  m_inputShapes.clear();
  m_outputShapes.clear();

  Ort::AllocatorWithDefaultOptions allocator;

  // Extract input information
  size_t inputCount = m_session->GetInputCount();
  for (size_t i = 0; i < inputCount; ++i) {
    auto inputName = m_session->GetInputNameAllocated(i, allocator);
    m_inputNames.push_back(std::string(inputName.get()));

    auto inputTypeInfo = m_session->GetInputTypeInfo(i);
    auto tensorInfo = inputTypeInfo.GetTensorTypeAndShapeInfo();
    auto shape = tensorInfo.GetShape();
    m_inputShapes.push_back(shape);
  }

  // Extract output information
  size_t outputCount = m_session->GetOutputCount();
  for (size_t i = 0; i < outputCount; ++i) {
    auto outputName = m_session->GetOutputNameAllocated(i, allocator);
    m_outputNames.push_back(std::string(outputName.get()));

    auto outputTypeInfo = m_session->GetOutputTypeInfo(i);
    auto tensorInfo = outputTypeInfo.GetTensorTypeAndShapeInfo();
    auto shape = tensorInfo.GetShape();
    m_outputShapes.push_back(shape);
  }
}

void ONNXInferenceModel::cleanup() {
  m_session.reset();
  m_inputNames.clear();
  m_outputNames.clear();
  m_inputShapes.clear();
  m_outputShapes.clear();
  m_modelLoaded = false;
}

} // namespace mlutils
