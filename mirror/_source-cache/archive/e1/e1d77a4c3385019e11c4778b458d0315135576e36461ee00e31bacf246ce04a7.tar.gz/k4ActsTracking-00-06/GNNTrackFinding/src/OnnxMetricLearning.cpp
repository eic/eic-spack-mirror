/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "OnnxMetricLearning.h"
#include "EdgeDirection.h"
#include "ONNXInferenceModel.h"

#include <ActsPlugins/Gnn/detail/TensorVectorConversion.hpp>
#include <ActsPlugins/Gnn/detail/buildEdges.hpp>

#include <onnxruntime_cxx_api.h>

#include <torch/torch.h>

#ifdef ACTS_GNN_WITH_CUDA
#include <cuda_runtime.h>
#endif

#include <fmt/format.h>
#include <fmt/ostream.h>
#include <fmt/ranges.h>

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <memory>
#include <numbers>
#include <optional>
#include <span>
#include <stdexcept>
#include <vector>

namespace {
/// Conver the Acts log level into an ONNX one
constexpr OrtLoggingLevel getOnnxLogLevel(Acts::Logging::Level lvl) {
  switch (lvl) {
  case Acts::Logging::VERBOSE:
    return ORT_LOGGING_LEVEL_VERBOSE;
  case Acts::Logging::DEBUG:
    return ORT_LOGGING_LEVEL_INFO;
  case Acts::Logging::INFO:
  case Acts::Logging::WARNING:
    return ORT_LOGGING_LEVEL_WARNING;
  case Acts::Logging::ERROR:
    return ORT_LOGGING_LEVEL_ERROR;
  case Acts::Logging::FATAL:
    return ORT_LOGGING_LEVEL_FATAL;
  case Acts::Logging::MAX:
    return ORT_LOGGING_LEVEL_WARNING;
  }
  return ORT_LOGGING_LEVEL_WARNING;
}

/// Convert ONNX element type to torch scalar type
constexpr torch::ScalarType toTorchType(ONNXTensorElementDataType elementType) {
  switch (elementType) {
  case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
    return torch::kFloat32;
  case ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:
    return torch::kFloat64;
  case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:
    return torch::kInt32;
  case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:
    return torch::kInt64;
  default:
    throw std::runtime_error("Unsupported ONNX tensor element type");
  }
}

/// Convert the Onnx tensor into a torch Tensor.
/// @note: This doesn't take ownership, it essentially just "re-skins" the data
/// owned by the Onnx tensor
torch::Tensor toTorchTensor(const Ort::Value& onnxTensor, bool targetCuda, std::size_t cudaDeviceIndex = 0) {
  auto tensorInfo = onnxTensor.GetTensorTypeAndShapeInfo();
  auto memoryInfo = onnxTensor.GetTensorMemoryInfo();
  auto shape = tensorInfo.GetShape();
  auto elementType = tensorInfo.GetElementType();

  const void* data = onnxTensor.GetTensorData<void>();
  const auto torchType = toTorchType(elementType);

  // ONNX Runtime may place the output either in CPU or CUDA memory depending
  // on the execution provider and which nodes were assigned to it. Create the
  // wrapper tensor on the matching device so that clone() performs a valid
  // copy before the Ort::Value goes out of scope.
  const bool onCudaMemory = memoryInfo.GetDeviceType() == OrtMemoryInfoDeviceType_GPU;
  auto options = torch::TensorOptions().dtype(torchType);
  if (onCudaMemory) {
    options = options.device(torch::Device(torch::kCUDA, static_cast<int64_t>(memoryInfo.GetDeviceId())));
  }

  auto torchTensor = torch::from_blob(const_cast<void*>(data), shape, options);

  // Host memory reports device id 0 as well, so the id alone does not tell
  // whether the output is already on cuda:0.
  if (targetCuda && (!onCudaMemory || memoryInfo.GetDeviceId() != static_cast<int>(cudaDeviceIndex))) {
    // not on target CUDA device (in host memory, or on another GPU)
    const auto targetDevice = torch::Device(torch::kCUDA, static_cast<int64_t>(cudaDeviceIndex));
    return torchTensor.to(targetDevice);
  }

  if (onCudaMemory && !targetCuda) {
    // not on target CPU
    return torchTensor.to(torch::kCPU);
  }

  // on target device (Host or CUDA), clone for ownership
  return torchTensor.clone();
}

} // namespace

OnnxMetricLearning::OnnxMetricLearning(const Config& cfg, std::unique_ptr<const Acts::Logger> lggr)
    : m_model("MetricLearning", getOnnxLogLevel(lggr->level()), cfg.device.isCuda(), cfg.device.index), m_config(cfg),
      m_logger(std::move(lggr)) {
  ACTS_INFO(fmt::format("Loading model from {}", config().modelPath));
  m_model.loadModel(config().modelPath);

  // Take the embedding dimension from the model itself instead of having it
  // configured. The last axis of the (nNodes x embeddingDim) output carries it,
  // unless the model was exported with that axis dynamic, in which case ONNX
  // reports -1 and we can only report what the model actually returns.
  const auto& outputShape = m_model.outputShape(0);
  if (outputShape.size() >= 2) {
    m_embeddingDim = outputShape.back();
  }
  if (m_embeddingDim > 0) {
    ACTS_INFO(fmt::format("Model declares an embedding dimension of {}", m_embeddingDim));
  } else {
    ACTS_INFO(fmt::format("Model '{}' does not declare a fixed embedding dimension (output shape [{}]), taking it from "
                          "the inference output",
                          config().modelPath, fmt::join(outputShape, ", ")));
  }

  // A model exported with a fixed-size input pins its node axis instead of
  // leaving it dynamic. Read it so that a mismatch can be reported against the
  // configured padding rather than as a bare onnxruntime shape error.
  const auto& modelInputShape = m_model.inputShape(0);
  if (modelInputShape.size() >= 2) {
    m_inputLength = modelInputShape.front();
  }
  if (m_inputLength > 0) {
    ACTS_INFO(fmt::format("Model expects a fixed input length of {} nodes", m_inputLength));
  } else {
    ACTS_DEBUG(fmt::format("Model '{}' takes a variable number of input nodes (input shape [{}])", config().modelPath,
                           fmt::join(modelInputShape, ", ")));
  }

  if (config().fixedInputLength > 0) {
    ACTS_INFO(fmt::format("Zero-padding the model input up to {} nodes, the padding rows are {} the edge classifiers",
                          config().fixedInputLength, config().keepPadding ? "kept for" : "dropped before"));
  }

  // The edge feature computation is optional, but if it is configured it has to
  // be given exactly the four node features it is defined in terms of.
  if (!config().edgeFeatureIndices.empty()) {
    if (config().edgeFeatureIndices.size() != kNumEdgeFeatureInputs) {
      throw std::invalid_argument(
          fmt::format("The edge feature computation needs exactly {} node features (r, phi, z, eta), but {} are "
                      "configured",
                      kNumEdgeFeatureInputs, config().edgeFeatureIndices.size()));
    }
    if (!config().edgeFeatureScales.empty() && config().edgeFeatureScales.size() != kNumEdgeFeatureInputs) {
      throw std::invalid_argument(fmt::format(
          "edgeFeatureScales has {} entries, but has to have one per edge feature input ({}) or none at all",
          config().edgeFeatureScales.size(), kNumEdgeFeatureInputs));
    }
    ACTS_INFO(fmt::format("Computing {} edge features (dr, dphi, dz, deta, phislope, rphislope) for every built edge",
                          kNumEdgeFeatures));
  } else {
    ACTS_DEBUG("No edge features are computed, the edge classifiers have to be two-input models");
  }

  // The edge ordering needs exactly the two node features its metric is defined
  // in terms of, or none at all if it is switched off.
  if (!config().distanceFeatureIndices.empty()) {
    if (config().distanceFeatureIndices.size() != gnntracking::kNumDistanceFeatures) {
      throw std::invalid_argument(
          fmt::format("The edge ordering needs exactly {} node features (r, z), but {} are configured",
                      gnntracking::kNumDistanceFeatures, config().distanceFeatureIndices.size()));
    }
    ACTS_INFO("Orienting every built edge from the hit closer to the interaction point to the one further out");
  } else {
    ACTS_DEBUG("Edges keep the orientation the edge building gave them");
  }
}

ActsPlugins::PipelineTensors OnnxMetricLearning::operator()(std::vector<float>& inputValues, std::size_t numNodes,
                                                            const std::vector<uint64_t>&,
                                                            const ActsPlugins::ExecutionContext& execContext) {
  assert(inputValues.size() % numNodes == 0);

  const std::size_t fullNumFeatures = inputValues.size() / numNodes;
  const std::vector<int>& selectedFeatures = config().selectedFeatures;
  const std::vector<float>& featureScales = config().featureScales;

  // The model only sees the selected features (all of them if no selection is
  // configured)
  const std::size_t numFeatures = selectedFeatures.empty() ? fullNumFeatures : selectedFeatures.size();

  // Optionally the input is extended with all-zero rows up to a fixed length,
  // for models that were exported with a fixed-size input. The padding rows sit
  // after the real nodes, so a node keeps the row index the rest of the pipeline
  // refers to it by, and the embedding of the padding rows is dropped again
  // below.
  const std::size_t fixedInputLength =
      config().fixedInputLength > 0 ? static_cast<std::size_t>(config().fixedInputLength) : 0;
  if (fixedInputLength != 0 && fixedInputLength < numNodes) {
    throw std::runtime_error(fmt::format(
        "Cannot zero-pad the node embedding model input to a fixed length of {} nodes, this segment already has {}. "
        "Increase EmbeddingFixedInputLength, or raise ThetaBins / PhiBins so that fewer hits land in one segment.",
        fixedInputLength, numNodes));
  }
  const std::size_t paddedNumNodes = std::max(fixedInputLength, numNodes);
  const std::vector inputShape = {static_cast<int64_t>(paddedNumNodes), static_cast<int64_t>(numFeatures)};

  // Fail with a message that names the padding knob rather than letting
  // onnxruntime reject the tensor with a bare shape mismatch.
  if (m_inputLength > 0 && static_cast<int64_t>(paddedNumNodes) != m_inputLength) {
    throw std::runtime_error(fmt::format(
        "Node embedding model expects a fixed input length of {} nodes, but {} would be passed to it "
        "({} real nodes, zero-padding {}). Set EmbeddingFixedInputLength to {}.",
        m_inputLength, paddedNumNodes, numNodes, fixedInputLength == 0 ? "disabled" : "enabled", m_inputLength));
  }

  for (const int idx : selectedFeatures) {
    if (idx < 0 || static_cast<std::size_t>(idx) >= fullNumFeatures) {
      throw std::runtime_error("Selected feature index out of range");
    }
  }
  for (const int idx : config().edgeFeatureIndices) {
    if (idx < 0 || static_cast<std::size_t>(idx) >= fullNumFeatures) {
      throw std::runtime_error("Edge feature input index out of range");
    }
  }
  if (!config().distanceFeatureIndices.empty()) {
    gnntracking::checkDistanceFeatureIndices(config().distanceFeatureIndices, fullNumFeatures);
  }
  if (!featureScales.empty() && featureScales.size() != numFeatures) {
    throw std::runtime_error("featureScales size must match the number of input features");
  }

  // Select and scale the model inputs in one pass. This is done into a separate
  // buffer (and not in place) because the pipeline expects to get the full,
  // unscaled node features back from this stage. Only if none of a selection, a
  // scaling and a padding is configured can the inputs be used as they are.
  std::vector<float> preparedValues{};
  if (!selectedFeatures.empty() || !featureScales.empty() || paddedNumNodes != numNodes) {
    // The padding rows are the [numNodes, paddedNumNodes) tail of the buffer and
    // are never written to below, so zero-initialise the whole thing.
    preparedValues.assign(paddedNumNodes * numFeatures, 0.f);
    for (std::size_t n = 0; n < numNodes; ++n) {
      for (std::size_t f = 0; f < numFeatures; ++f) {
        const std::size_t idx = selectedFeatures.empty() ? f : static_cast<std::size_t>(selectedFeatures[f]);
        const float value = inputValues[n * fullNumFeatures + idx];
        preparedValues[n * numFeatures + f] = featureScales.empty() ? value : value / featureScales[f];
      }
    }
  }
  const std::vector<float>& inferenceValues = preparedValues.empty() ? inputValues : preparedValues;

  ACTS_DEBUG(fmt::format("Embedding input tensor shape: {}", inputShape));
  ACTS_DEBUG(fmt::format("First input space point: {}", std::span(inferenceValues.data(), numFeatures)));
  if (execContext.device.isCuda()) {
#ifdef ACTS_GNN_WITH_CUDA
    cudaSetDevice(execContext.device.index);
#else
    throw std::runtime_error("can not run on CUDA, k4ActsTracking/ACTS was built without CUDA support");
#endif
  }
  const auto outputs = m_model.runInference(inferenceValues, inputShape, execContext.device);

  auto embeddedPoints = toTorchTensor(outputs[0], execContext.device.isCuda(), execContext.device.index);
  assert(embeddedPoints.size(0) == inputShape[0]); // Do not change the number of points
  // A model that declares its embedding dimension has to stick to it. This is
  // checked (rather than asserted) because a mismatch here means the loaded
  // model is not the one its own metadata describes.
  if (m_embeddingDim > 0 && embeddedPoints.size(1) != m_embeddingDim) {
    throw std::runtime_error(
        fmt::format("Node embedding model returned {} embedding dimensions, but its ONNX metadata declares {}",
                    embeddedPoints.size(1), m_embeddingDim));
  }
  ACTS_DEBUG(fmt::format("Embedding output tensor shape: [{}, {}]", embeddedPoints.size(0), embeddedPoints.size(1)));

  // Drop the embedding of the padding rows again. This is unconditional, and
  // independent of Config::keepPadding below: the padding rows are not hits, and
  // the network maps every all-zero row onto the same arbitrary (bias dependent)
  // point in embedding space, so leaving them in would have the edge building
  // connect all of them to each other and to whatever real node is nearby.
  // Slicing along the node axis of a contiguous tensor is a view, so this costs
  // nothing.
  if (paddedNumNodes != numNodes) {
    embeddedPoints = embeddedPoints.slice(0, 0, static_cast<int64_t>(numNodes));
    ACTS_DEBUG(fmt::format("Dropped {} padding nodes, {} real nodes go into the edge building",
                           paddedNumNodes - numNodes, numNodes));
  }
  ACTS_VERBOSE(fmt::format("Embedding space of first SP: [{}]", fmt::streamed(embeddedPoints.slice(0, 0, 1))));

  ACTS_DEBUG("Starting to build edges");
  auto edgeList =
      ActsPlugins::detail::buildEdges(embeddedPoints, m_config.rVal, m_config.knnVal, m_config.shuffleDirections);
  ACTS_DEBUG("Finished building edges");

  ACTS_VERBOSE(fmt::format("Shape of built edges: ({}, {})", edgeList.size(0), edgeList.size(1)));
  ACTS_VERBOSE(fmt::format("Slice of edgeList: {}", fmt::streamed(edgeList.slice(1, 0, 5))));

  // Point every edge away from the interaction point. This runs before the
  // guard below because it can only ever remove edges, and before the edge
  // features because those are signed differences along the edge.
  edgeList = orderEdgesByDistance(inputValues, numNodes, fullNumFeatures, std::move(edgeList));

  // A graph this small has no tracks in it, and handing it to the edge
  // classifier would not end well either: Acts builds the score tensor for a
  // rank-1 model output by dropping every axis of size <= 1, so both an empty
  // graph and a single edge collapse to a scalar, and onnxruntime rejects that
  // with "not enough space: expected 4, got 0" and "Invalid rank for output"
  // respectively. Report it the way the pipeline already handles a graph that
  // its cuts emptied out, which turns the segment into zero track candidates.
  //
  // Note that this does discard the two-hit candidate a single edge could have
  // made. That only matters if MinHitsPerTrack is set below 3.
  constexpr int64_t minUsableEdges = 2;
  if (edgeList.size(1) < minUsableEdges) {
    ACTS_DEBUG(fmt::format("Built {} edges from {} nodes, too few for a track candidate", edgeList.size(1), numNodes));
    throw ActsPlugins::NoEdgesError{};
  }

  auto edgeFeatures = buildEdgeFeatures(inputValues, numNodes, fullNumFeatures, edgeList);

  // Optionally pad the graph up to a fixed number of edges, for classifier
  // models exported with a fixed-size edge input. The padding edges are self
  // loops on the last (padding) node row: a self loop carries no connectivity,
  // it touches no real node so it cannot disturb their message passing, and it
  // is what PaddedEdgeRemoval recognises them by once the classifiers are done -
  // the edge building never produces one.
  const std::size_t numEdges = static_cast<std::size_t>(edgeList.size(1));
  const std::size_t fixedEdgeLength =
      config().fixedEdgeLength > 0 ? static_cast<std::size_t>(config().fixedEdgeLength) : 0;
  if (fixedEdgeLength != 0 && fixedEdgeLength < numEdges) {
    throw std::runtime_error(fmt::format(
        "Cannot zero-pad the edge classifier input to a fixed length of {} edges, this segment already has {}. "
        "Increase EdgeClassifierFixedInputLength, or lower EdgeBuildingRadius (or, on CUDA only, EdgeBuildingKnn) so "
        "that fewer edges are built.",
        fixedEdgeLength, numEdges));
  }
  if (fixedEdgeLength > numEdges) {
    const int64_t numPadEdges = static_cast<int64_t>(fixedEdgeLength - numEdges);
    const int64_t padNode = static_cast<int64_t>(paddedNumNodes) - 1;
    edgeList = torch::cat({edgeList, torch::full({2, numPadEdges}, padNode, edgeList.options())}, 1);
    if (edgeFeatures.has_value()) {
      // All six features of a self loop on an all-zero node are zero anyway, so
      // this is the same thing buildEdgeFeatures() would have produced for them.
      edgeFeatures = torch::cat(
          {*edgeFeatures, torch::zeros({numPadEdges, static_cast<int64_t>(kNumEdgeFeatures)}, edgeFeatures->options())},
          0);
    }
    ACTS_DEBUG(fmt::format("Padded {} real edges with {} self loops on node {}, {} edges go to the edge classifiers",
                           numEdges, numPadEdges, padNode, fixedEdgeLength));
  }

  std::optional<ActsPlugins::Tensor<float>> actsEdgeFeatures{};
  if (edgeFeatures.has_value()) {
    actsEdgeFeatures.emplace(ActsPlugins::detail::torchToActsTensor<float>(edgeFeatures->contiguous(), execContext));
    ACTS_DEBUG(
        fmt::format("Edge feature tensor shape: [{}, {}]", actsEdgeFeatures->shape()[0], actsEdgeFeatures->shape()[1]));
  }

  // The node features handed on to the rest of the pipeline normally cover the
  // real hits only. An edge classifier that was itself exported at a fixed
  // number of nodes needs the padding rows back, so optionally re-pad the
  // full-feature buffer to the length the embedding model was fed. Every real
  // node keeps its row index, so the extra rows are just nodes without edges,
  // and the edge index built above stays valid. Only the edge classifiers look
  // at this node count - the track building sizes its graph from the space
  // point IDs, which stay at the real hits.
  std::vector<float> paddedInputValues{};
  if (config().keepPadding && paddedNumNodes != numNodes) {
    // The rows past the real hits are never written to, so zero-initialise.
    paddedInputValues.assign(paddedNumNodes * fullNumFeatures, 0.f);
    std::copy(inputValues.begin(), inputValues.end(), paddedInputValues.begin());
    ACTS_DEBUG(fmt::format("Kept {} padding nodes, {} rows go on to the edge classifiers", paddedNumNodes - numNodes,
                           paddedNumNodes));
  }
  std::vector<float>& downstreamValues = paddedInputValues.empty() ? inputValues : paddedInputValues;

  // Create the node-feature input tensor for EdgeClassifiers directly in ACTS memory on the
  // target device, this should avoid further ORT-internal copies downstream + ensure that pipeline runs on CUDA if
  // requested. This avoids the old procedure:
  // vector -> Torch CPU tensor (-> move to CUDA) -> torchToActsTensor(execContext),
  // which does not guarantee inputs on CUDA => OnnxEdgeClasifier running on CPU if inputs in host mem
  const std::size_t downstreamNumNodes = downstreamValues.size() / fullNumFeatures;
  auto downstreamNodeTensor = ActsPlugins::Tensor<float>::Create({downstreamNumNodes, fullNumFeatures}, execContext);
  if (!execContext.device.isCuda()) {
    std::copy(downstreamValues.begin(), downstreamValues.end(), downstreamNodeTensor.data());
  } else {
#ifdef ACTS_GNN_WITH_CUDA
    const auto nbytes = downstreamValues.size() * sizeof(float);
    const auto status =
        execContext.stream.has_value()
            ? cudaMemcpyAsync(downstreamNodeTensor.data(), downstreamValues.data(), nbytes, cudaMemcpyHostToDevice,
                              *execContext.stream)
            : cudaMemcpy(downstreamNodeTensor.data(), downstreamValues.data(), nbytes, cudaMemcpyHostToDevice);
    if (status != cudaSuccess) {
      throw std::runtime_error(fmt::format("Failed to copy node features to CUDA: {}", cudaGetErrorString(status)));
    }
#else
    throw std::runtime_error("cannot run on CUDA, k4ActsTracking/ACTS was built without CUDA support");
#endif
  }

  auto actsEdgeList = ActsPlugins::detail::torchToActsTensor<int64_t>(edgeList, execContext);

  return {std::move(downstreamNodeTensor), std::move(actsEdgeList), std::move(actsEdgeFeatures), std::nullopt};
}

torch::Tensor OnnxMetricLearning::orderEdgesByDistance(const std::vector<float>& inputValues, std::size_t numNodes,
                                                       std::size_t fullNumFeatures, torch::Tensor edgeList) const {
  if (config().distanceFeatureIndices.empty()) {
    return edgeList;
  }

  // The metric is the squared distance from the interaction point of
  // EdgeDirection.h, computed from the unscaled node values. Note that this
  // makes Config::shuffleDirections moot: whatever direction the edge building
  // left, the edges end up pointing outwards.
  const auto& indices = config().distanceFeatureIndices;
  // Not const: vectorToTensor2D() wraps the buffer without copying it
  std::vector<float> distances = gnntracking::nodeDistancesSq(inputValues, numNodes, fullNumFeatures, indices);

  // Gathering with torch ops keeps this on whichever device the edge building
  // ran on.
  const auto nodeDistances = ActsPlugins::detail::vectorToTensor2D(distances, 1).squeeze(1).to(edgeList.device());
  const auto src = edgeList.select(0, 0).contiguous();
  const auto dst = edgeList.select(0, 1).contiguous();
  const auto srcDistance = nodeDistances.index_select(0, src);
  const auto dstDistance = nodeDistances.index_select(0, dst);

  // An edge is flipped unless it already points outwards, which is
  // gnntracking::pointsOutward() written in tensor ops: the node index breaks
  // ties, so that the two hits of an edge are ordered even if they sit at the
  // same distance. A self loop compares equal on both and is left alone.
  const auto flipMask = (srcDistance > dstDistance).logical_or((srcDistance == dstDistance).logical_and(src > dst));

  // Zero flipped edges is a perfectly normal outcome - it just means the edge
  // building already numbered the hits outwards - but it is also what a
  // degenerate metric looks like, so report what the metric actually saw: the
  // range it spans over the nodes, and how many edges connect two hits it
  // cannot tell apart.
  if (logger().doPrint(Acts::Logging::DEBUG) && !distances.empty()) {
    const auto [minDistance, maxDistance] = std::minmax_element(distances.begin(), distances.end());
    ACTS_DEBUG(fmt::format(
        "Distance from the interaction point over {} nodes (features {} and {} of {}): {} to {} mm, {} of {} edges "
        "connect two hits at the same distance",
        numNodes, indices[gnntracking::eR], indices[gnntracking::eZ], fullNumFeatures, std::sqrt(*minDistance),
        std::sqrt(*maxDistance), (srcDistance == dstDistance).sum().item<int64_t>(), edgeList.size(1)));
  }

  using torch::indexing::Slice;
  edgeList.index_put_({Slice(), flipMask}, edgeList.index({Slice(), flipMask}).flip(0));

  // No deduplication is needed afterwards: Acts' postprocessEdgeTensor() has
  // already reduced the graph to one column per pair of hits (in a canonical,
  // sorted order, so the graph is reproducible from run to run), and flipping
  // a column keeps it the only one of its pair.

  // The flips are only counted when this is printed: .item() waits for the
  // device. flipMask is a tensor of its own, so the flip above left it intact.
  ACTS_DEBUG(fmt::format("Oriented {} of {} edges outwards", flipMask.sum().item<int64_t>(), edgeList.size(1)));

  return edgeList;
}

std::optional<torch::Tensor> OnnxMetricLearning::buildEdgeFeatures(const std::vector<float>& inputValues,
                                                                   std::size_t numNodes, std::size_t fullNumFeatures,
                                                                   const torch::Tensor& edgeList) const {
  if (config().edgeFeatureIndices.empty()) {
    return std::nullopt;
  }

  // The six features are the ones Acts' makeEdgeFeatures() (ModuleMapUtils.cuh)
  // produces, which is the only place Acts fills them - but that one is CUDA
  // only, so the CPU pipeline has to compute them itself. Note that the edge
  // classifier scales its node input but passes the edge input through as it
  // is, so these are computed from the already scaled node values.
  enum EdgeFeatureInput { eR = 0, ePhi, eZ, eEta };
  constexpr float pi = std::numbers::pi_v<float>;

  const auto& indices = config().edgeFeatureIndices;
  const auto& scales = config().edgeFeatureScales;

  // (numNodes x 4) buffer of the scaled r, phi, z and eta of every node
  std::vector<float> nodeValues(numNodes * kNumEdgeFeatureInputs);
  for (std::size_t n = 0; n < numNodes; ++n) {
    for (std::size_t f = 0; f < kNumEdgeFeatureInputs; ++f) {
      const float value = inputValues[n * fullNumFeatures + static_cast<std::size_t>(indices[f])];
      nodeValues[n * kNumEdgeFeatureInputs + f] = scales.empty() ? value : value / scales[f];
    }
  }

  // Gathering the node values per edge with torch ops keeps the computation on
  // whichever device the edge building ran on.
  const auto nodeTensor =
      ActsPlugins::detail::vectorToTensor2D(nodeValues, kNumEdgeFeatureInputs).to(edgeList.device());
  const auto srcValues = nodeTensor.index_select(0, edgeList.select(0, 0).contiguous());
  const auto tgtValues = nodeTensor.index_select(0, edgeList.select(0, 1).contiguous());

  const auto dr = tgtValues.select(1, eR) - srcValues.select(1, eR);
  const auto dz = tgtValues.select(1, eZ) - srcValues.select(1, eZ);
  const auto deta = tgtValues.select(1, eEta) - srcValues.select(1, eEta);

  // phi is scaled by kEdgeFeaturePhiScale (checked by the caller), so the
  // difference is unscaled to wrap it back into [-pi, pi] and then scaled
  // again. A single wrap is enough since the unscaled difference cannot leave
  // [-2pi, 2pi].
  auto dphi = kEdgeFeaturePhiScale * (tgtValues.select(1, ePhi) - srcValues.select(1, ePhi));
  dphi = torch::where(dphi > pi, dphi - 2.f * pi, dphi);
  dphi = torch::where(dphi < -pi, dphi + 2.f * pi, dphi);
  dphi = dphi / kEdgeFeaturePhiScale;

  // Doublets on the same radius have no defined slope and get a flat zero. The
  // substitute denominator only keeps the discarded branch from producing infs.
  const auto hasDr = dr != 0.f;
  const auto phislope = torch::where(
      hasDr, torch::clamp(dphi / torch::where(hasDr, dr, torch::ones_like(dr)), -100.f, 100.f), torch::zeros_like(dr));
  const auto rphislope = 0.5f * (tgtValues.select(1, eR) + srcValues.select(1, eR)) * phislope;

  // Left as a torch tensor so that the caller can still pad it before it is
  // handed over to the pipeline.
  auto edgeFeatures = torch::stack({dr, dphi, dz, deta, phislope, rphislope}, 1).contiguous();

  // The features go to the classifier unscaled, so this is what the model
  // actually sees. The EdgePrintingHook logs them at DEBUG, which is the way to
  // spot a mismatch with the scales the model was trained with.
  return edgeFeatures;
}
