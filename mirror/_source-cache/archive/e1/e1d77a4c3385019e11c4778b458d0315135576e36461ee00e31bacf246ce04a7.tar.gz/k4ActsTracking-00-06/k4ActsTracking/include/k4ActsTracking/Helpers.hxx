/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#pragma once

// edm4hep
#include <edm4hep/MCParticle.h>
#include <edm4hep/MutableTrack.h>
#include <edm4hep/Track.h>
#include <edm4hep/TrackCollection.h>
#include <edm4hep/TrackState.h>

// Gaudi
#include <GaudiKernel/IDataManagerSvc.h>
#include <GaudiKernel/IDataProviderSvc.h>
#include <GaudiKernel/IEvtSelector.h>
#include <GaudiKernel/MsgStream.h>
#include <GaudiKernel/ServiceHandle.h>
#include <GaudiKernel/SmartDataPtr.h>
#include <GaudiKernel/StatusCode.h>

// ACTS
#include <Acts/Definitions/Units.hpp>
#include <Acts/EventData/BoundTrackParameters.hpp>
#include <Acts/EventData/FreeTrackParameters.hpp>
#include <Acts/EventData/ParticleHypothesis.hpp>
#include <Acts/EventData/VectorMultiTrajectory.hpp>
#include <Acts/EventData/VectorTrackContainer.hpp>
#include <Acts/Geometry/GeometryContext.hpp>
#include <Acts/Geometry/GeometryIdentifier.hpp>
#include <Acts/MagneticField/MagneticFieldContext.hpp>
#include <Acts/MagneticField/MagneticFieldProvider.hpp>
#include <Acts/Propagator/EigenStepper.hpp>
#include <Acts/Propagator/Navigator.hpp>
#include <Acts/Propagator/Propagator.hpp>
#include <Acts/TrackFinding/CombinatorialKalmanFilter.hpp>
#include <Acts/TrackFitting/KalmanFitter.hpp>

// ACTSTracking
#include "k4ActsTracking/IActsGeoSvc.h"
#include "k4ActsTracking/SourceLink.hxx"

// Standard
#include <cstddef>
#include <optional>
#include <vector>

namespace ACTSTracking {

/// Geometry-aware propagator used to extrapolate fitted tracks out to the
/// calorimeter face. It navigates the tracking geometry (which now includes
/// the passive calo volumes), so material along the way is accounted for and
/// the actual curved trajectory selects which calo surface is hit.
using CaloFacePropagator = Acts::Propagator<Acts::EigenStepper<>, Acts::Navigator>;

using TrackResult =
    Acts::TrackContainer<Acts::VectorTrackContainer, Acts::VectorMultiTrajectory, std::shared_ptr>::TrackProxy;

/// Hit time in Acts native units; use this for every hit time passed to ACTS.
template <class Hit>
double hitTime(const Hit& hit) {
  return static_cast<double>(hit.getTime()) * Acts::UnitConstants::ns;
}

//! Get path to a resource file
/**
 * Get absolute file of a file `inpath` by looking in the following places:
 *  - `inpath` to the current working directory
 *  - `ACTSTRACKING_SOURCEDIR/inpath`
 *  - `ACTSTRACKING_DATADIR/inpath`
 *
 * If the files is not found at any location, then `inpath` is returned.
 * If `path` starts with a /, then it is returned directly.
 *
 * \parm inpath File to find.
 *
 * \return Absolute path to file.
 */
std::string findFile(const std::string& inpath);

//! Convert ACTS KF result to edm4hep track class
/**
 * Thin wrapper around the centralised ActsPlugins EDM4hep converter
 * (`ActsPlugins::EDM4hepUtil::writeTrack`). This function only supplies the
 * pieces the plugin cannot know about, namely how to resolve a track state's
 * source link into the edm4hep hit it came from.
 *
 * Converted properties are:
 *  - goodness of fit (chi2, ndf, number of holes)
 *  - associated hits
 *  - track states at IP and at each measurement
 *
 * Track states are emitted IP-first, followed by the measurement states ordered
 * inside-out (AtFirstHit ... AtLastHit); any AtCalorimeter states appended by
 * the caller therefore still come last.
 *
 * \param gctx geometry context used to resolve surface positions
 * \param mctx magnetic field context used for the field lookups
 * \param fitter_res KF/CKF fit result
 * \param hits edm4hep hits parallel to the measurement container; the hit of
 *        each track state is recovered via its source-link index()
 * \param magneticField magnetic field at different locations in the detector;
 *        evaluated at each track state, so a non-uniform field is handled
 *
 * \return Track with equivalent parameters of the ACTS track
 */
edm4hep::MutableTrack ACTS2edm4hep_track(const Acts::GeometryContext& gctx, const Acts::MagneticFieldContext& mctx,
                                         const TrackResult& fitter_res, const HitContainer& hits,
                                         std::shared_ptr<const Acts::MagneticFieldProvider> magneticField);

//! Get particle hypothesis in ACTS format
/**
 * \param MCParticle
 *
 * \return Particle Hypothesis based on MCParticle PDG
 */
Acts::ParticleHypothesis convertParticle(const edm4hep::MCParticle mcParticle);

//! Outcome of a calorimeter-face extrapolation.
enum class CaloExtrapolationStatus {
  Ok,               ///< reached a calo-face surface
  NoSurfaces,       ///< no calo-face surfaces are configured
  NotReached,       ///< propagation finished without reaching a calo-face surface
  PropagationError, ///< the propagation itself failed
};

//! Result of a calorimeter-face extrapolation.
struct CaloExtrapolationResult {
  std::optional<Acts::BoundTrackParameters> params{};
  CaloExtrapolationStatus status{CaloExtrapolationStatus::NotReached};
};

//! Extrapolate track parameters to the calorimeter face.
/**
 * Propagates the given parameters through the tracking geometry (which contains
 * the passive calo volumes) and terminates as soon as the actual trajectory
 * reaches one of the calorimeter-face surfaces, identified by their geometry
 * ids. Because the propagation follows the real curved trajectory through the
 * geometry, no straight-line pre-selection of the target surface is needed and
 * material handling integrates naturally once the calo volumes carry material.
 *
 * \param propagator        Geometry-aware propagator
 * \param start             Track parameters to extrapolate from (e.g. at the last hit)
 * \param caloSurfaceGeoIds Geometry ids of the calo-face surfaces (from IActsGeoSvc)
 * \param gctx              Geometry context
 * \param mctx              Magnetic-field context
 * \param maxSteps          Maximum number of propagation steps
 *
 * \return Bound track parameters at the calorimeter face together with a status
 *         describing why the extrapolation succeeded or failed.
 */
CaloExtrapolationResult extrapolateToCaloFace(const CaloFacePropagator& propagator,
                                              const Acts::BoundTrackParameters& start,
                                              const std::vector<Acts::GeometryIdentifier>& caloSurfaceGeoIds,
                                              const Acts::GeometryContext& gctx, const Acts::MagneticFieldContext& mctx,
                                              std::size_t maxSteps);

} // namespace ACTSTracking
