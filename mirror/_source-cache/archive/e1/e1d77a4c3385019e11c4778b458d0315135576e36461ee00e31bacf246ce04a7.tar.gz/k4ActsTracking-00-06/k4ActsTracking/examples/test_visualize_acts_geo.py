#!/usr/bin/env python3
#
# Copyright (c) 2014-2024 Key4hep-Project.
#
# This file is part of Key4hep.
# See https://key4hep.github.io/key4hep-doc/ for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import pathlib

from Gaudi.Configuration import DEBUG, VERBOSE

from Configurables import ActsGeoSvc, GeoSvc, ActsTestPropagator, EventDataSvc
from k4FWCore import ApplicationMgr, IOSvc
from k4FWCore.parseArgs import parser

parser.add_argument("--compactFile", help="Compact file", required=True)
parser.add_argument(
    "--test-propagation",
    help="Test propagation through the geometry using an ACTS particle gun",
    action="store_true",
    default=False,
)
parser.add_argument(
    "--materialMapFile",
    help="ACTS material map (.json/.cbor/.root) to decorate the geometry with. "
    "Useful to check that a freshly mapped file lines up with the designated "
    "material surfaces: the service reports how many surfaces still carry a "
    "proto-material placeholder afterwards.",
    type=str,
    default="",
)

args = parser.parse_known_args()[0]

iosvc = IOSvc()
if args.test_propagation:
    iosvc.Output = f"{pathlib.Path(args.compactFile).stem}-steps.root"

geoSvc = GeoSvc()
geoSvc.detectors = [args.compactFile]

actsGeoSvc = ActsGeoSvc("ActsGeoSvc")
actsGeoSvc.MaterialMapFile = args.materialMapFile
actsGeoSvc.DumpVisualization = True
actsGeoSvc.ObjVisFileName = f"{pathlib.Path(args.compactFile).stem}-acts-geo.obj"
actsGeoSvc.OutputLevel = VERBOSE

alg_list = []

if args.test_propagation:
    propTest = ActsTestPropagator("TestPropagator")
    propTest.OutputLevel = DEBUG
    propTest.NumTracks = 100
    alg_list.append(propTest)

ApplicationMgr(
    TopAlg=alg_list,
    ExtSvc=[geoSvc, actsGeoSvc, EventDataSvc()],
    EvtMax=1,
    EvtSel="NONE",
)
