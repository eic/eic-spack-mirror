# BEGIN PLOT /OPAL_1994_I372772/d01-x01-y01
Title=$\pi^\pm$ momentum
XLabel=$p$ [GeV]
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}p$ [$\mathrm{GeV}^-1$]
# END PLOT
# BEGIN PLOT /OPAL_1994_I372772/d02-x01-y01
Title=$K^\pm$ momentum
XLabel=$p$ [GeV]
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}p$ [$\mathrm{GeV}^-1$]
# END PLOT
# BEGIN PLOT /OPAL_1994_I372772/d03-x01-y01
Title=$p,\bar{p}$ momentum
XLabel=$p$ [GeV]
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}p$ [$\mathrm{GeV}^-1$]
# END PLOT
