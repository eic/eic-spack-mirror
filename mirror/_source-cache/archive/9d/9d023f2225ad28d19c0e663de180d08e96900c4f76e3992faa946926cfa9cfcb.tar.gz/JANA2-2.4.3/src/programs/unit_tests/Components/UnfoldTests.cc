
#include <catch.hpp>
#include <JANA/JEventProcessor.h>
#include <JANA/Topology/JUnfoldArrow.h>
#include <JANA/Topology/JFoldArrow.h>

#if JANA2_HAVE_PODIO
#include <PodioDatamodel/ExampleHitCollection.h>
#endif

namespace jana {
namespace unfoldtests {


struct TestUnfolder : public JEventUnfolder {
    mutable std::vector<int> preprocessed_event_nrs;
    mutable std::vector<JEventLevel> preprocessed_event_levels;
    std::vector<int> unfolded_parent_nrs;
    std::vector<JEventLevel> unfolded_parent_levels;
    std::vector<int> unfolded_child_nrs;
    std::vector<JEventLevel> unfolded_child_levels;

    TestUnfolder() {
        SetParentLevel(JEventLevel::Timeslice);
        SetChildLevel(JEventLevel::PhysicsEvent);
    }

    void Preprocess(const JEvent& parent) const override {
        LOG << "Preprocessing " << parent.GetLevel() << " event " << parent.GetEventNumber() << LOG_END;
        preprocessed_event_nrs.push_back(parent.GetEventNumber());
        preprocessed_event_levels.push_back(parent.GetLevel());
    }

    Result Unfold(const JEvent& parent, JEvent& child, int iter) override {
        auto child_nr = iter + 100 + parent.GetEventNumber();
        unfolded_parent_nrs.push_back(parent.GetEventNumber());
        unfolded_parent_levels.push_back(parent.GetLevel());
        unfolded_child_nrs.push_back(child_nr);
        unfolded_child_levels.push_back(child.GetLevel());
        child.SetEventNumber(child_nr);
        LOG << "Unfolding " << parent.GetLevel() << " event " << parent.GetEventNumber() << " into " << child.GetLevel() << " " << child_nr << "; iter=" << iter << LOG_END;
        return (iter == 2 ? Result::NextChildNextParent : Result::NextChildKeepParent);
    }
};

TEST_CASE("UnfoldTests_Basic") {

    JApplication app;
    app.Initialize();
    auto jcm = app.GetService<JComponentManager>();

    JEventPool parent_pool {jcm, 5, 1, JEventLevel::Timeslice};
    JEventPool child_pool {jcm, 5, 1, JEventLevel::PhysicsEvent};
    JEventQueue parent_queue {3, 1};
    JEventQueue child_queue {3, 1};

    auto ts1 = parent_pool.Pop(0);
    ts1->SetEventNumber(17);

    auto ts2 = parent_pool.Pop(0);
    ts2->SetEventNumber(28);

    parent_queue.Push(ts1, 0);
    parent_queue.Push(ts2, 0);

    TestUnfolder unfolder;
    JUnfoldArrow arrow("sut", &unfolder);
    arrow.attach(&parent_queue, JUnfoldArrow::PARENT_IN);
    arrow.attach(&child_pool, JUnfoldArrow::CHILD_IN);
    arrow.attach(&child_queue, JUnfoldArrow::CHILD_OUT);

    arrow.initialize();
    arrow.execute( 0); // First call to execute() picks up the parent and exits early
    auto result = arrow.execute( 0); // Second call to execute() picks up the child, calls Unfold(), and emits the newly parented child
    REQUIRE(result == JArrow::FireResult::KeepGoing);
    REQUIRE(child_queue.GetSize(0) == 1);
    REQUIRE(unfolder.preprocessed_event_nrs.size() == 0);
    REQUIRE(unfolder.unfolded_parent_nrs.size() == 1);
    REQUIRE(unfolder.unfolded_parent_nrs[0] == 17);
    REQUIRE(unfolder.unfolded_parent_levels[0] == JEventLevel::Timeslice);
    REQUIRE(unfolder.unfolded_child_nrs.size() == 1);
    REQUIRE(unfolder.unfolded_child_nrs[0] == 117);
    REQUIRE(unfolder.unfolded_child_levels[0] == JEventLevel::PhysicsEvent);

}

TEST_CASE("FoldArrowTests") {

    JApplication app;
    app.Initialize();
    auto jcm = app.GetService<JComponentManager>();

    // We only use these to obtain preconfigured JEvents
    JEventPool parent_pool {jcm, 5, 1, JEventLevel::Timeslice};
    JEventPool child_pool {jcm, 5, 1, JEventLevel::PhysicsEvent};

    // We set up our test cases by putting events on these queues
    JEventQueue child_in(5, 1);
    JEventQueue child_out(5, 1);
    JEventQueue parent_out(5, 1);

    JFoldArrow arrow("sut", JEventLevel::Timeslice, JEventLevel::PhysicsEvent);
    arrow.attach(&child_in, JFoldArrow::CHILD_IN);
    arrow.attach(&child_out, JFoldArrow::CHILD_OUT);
    arrow.attach(&parent_out, JFoldArrow::PARENT_OUT);
    arrow.initialize();

    SECTION("One-to-one relationship between timeslices and events") {

        auto ts1 = parent_pool.Pop(0);
        ts1->SetEventNumber(17);
        REQUIRE(ts1->GetLevel() == JEventLevel::Timeslice);

        auto ts2 = parent_pool.Pop(0);
        ts2->SetEventNumber(28);

        auto evt1 = child_pool.Pop(0);
        evt1->SetEventNumber(111);

        auto evt2 = child_pool.Pop(0);
        evt2->SetEventNumber(112);


        evt1->SetParent(ts1);
        ts1->Release(); // One-to-one
        child_in.Push(evt1, 0);

        evt2->SetParent(ts2);
        ts2->Release(); // One-to-one
        child_in.Push(evt2, 0);
    
        arrow.execute(0);

        REQUIRE(child_in.GetSize(0) == 1);
        REQUIRE(child_out.GetSize(0) == 1);
        REQUIRE(parent_out.GetSize(0) == 1);

    }


    SECTION("One-to-two relationship between timeslices and events") {

        auto ts1 = parent_pool.Pop(0);
        ts1->SetEventNumber(17);
        REQUIRE(ts1->GetLevel() == JEventLevel::Timeslice);

        auto ts2 = parent_pool.Pop(0);
        ts2->SetEventNumber(28);

        auto evt1 = child_pool.Pop(0);
        evt1->SetEventNumber(111);

        auto evt2 = child_pool.Pop(0);
        evt2->SetEventNumber(112);

        auto evt3 = child_pool.Pop(0);
        evt3->SetEventNumber(113);

        auto evt4 = child_pool.Pop(0);
        evt4->SetEventNumber(114);


        evt1->SetParent(ts1);
        evt2->SetParent(ts1);
        ts1->Release(); // One-to-two
        
        evt3->SetParent(ts2);
        evt4->SetParent(ts2);
        ts2->Release(); // One-to-two
   
        child_in.Push(evt1, 0);
        child_in.Push(evt2, 0);
        child_in.Push(evt3, 0);
        child_in.Push(evt4, 0);

        arrow.execute(0);

        REQUIRE(child_in.GetSize(0) == 3);
        REQUIRE(child_out.GetSize(0) == 1);
        REQUIRE(parent_out.GetSize(0) == 0);

        arrow.execute(0);

        REQUIRE(child_in.GetSize(0) == 2);
        REQUIRE(child_out.GetSize(0) == 2);
        REQUIRE(parent_out.GetSize(0) == 1);

        arrow.execute(0);

        REQUIRE(child_in.GetSize(0) == 1);
        REQUIRE(child_out.GetSize(0) == 3);
        REQUIRE(parent_out.GetSize(0) == 1);

        arrow.execute(0);

        REQUIRE(child_in.GetSize(0) == 0);
        REQUIRE(child_out.GetSize(0) == 4);
        REQUIRE(parent_out.GetSize(0) == 2);
    }


}


class NoOpUnfolder : public JEventUnfolder {
#if JANA2_HAVE_PODIO
    PodioOutput<ExampleHit> m_hits_out {this}; 
    // We never insert these hits, and that should be fine 
    // because they should never get pushed to the frame
#endif

public:
    NoOpUnfolder() {
        SetParentLevel(JEventLevel::Timeslice);
        SetChildLevel(JEventLevel::PhysicsEvent);
    }
    Result Unfold(const JEvent&, JEvent&, int) {
        return Result::KeepChildNextParent;
    }
};

class PhysEvtProc : public JEventProcessor {
    int m_events_seen = 0;
public:
    PhysEvtProc() {
        SetCallbackStyle(CallbackStyle::ExpertMode);
    }
    void ProcessSequential(const JEvent&) {
        m_events_seen += 1;
    }
    void Finish() {
        REQUIRE(m_events_seen == 0);
    }
};

class TimesliceProc : public JEventProcessor {
    int m_events_seen = 0;
public:
    TimesliceProc() {
        SetLevel(JEventLevel::Timeslice);
        SetCallbackStyle(CallbackStyle::ExpertMode);
    }
    void ProcessSequential(const JEvent&) {
        m_events_seen += 1;
    }
    void Finish() {
        REQUIRE(m_events_seen == 10);
    }
};

TEST_CASE("NoOpUnfolder_Tests") {
    JApplication app;
    auto source = new JEventSource();
    source->SetLevel(JEventLevel::Timeslice);
    app.Add(source);
    app.Add(new NoOpUnfolder);
    app.Add(new PhysEvtProc);
    app.Add(new TimesliceProc);
    app.SetParameterValue("jana:nevents", 10);
    app.SetParameterValue("jana:loglevel", "debug");
    app.Run();
}


} // namespace arrowtests
} // namespace jana




