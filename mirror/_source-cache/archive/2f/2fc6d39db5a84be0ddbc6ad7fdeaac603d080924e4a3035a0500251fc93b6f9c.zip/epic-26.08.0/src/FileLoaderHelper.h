// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright (C) 2022 Wouter Deconinck

#pragma once

#include <DD4hep/DetFactoryHelper.h>
#include <DD4hep/Factories.h>
#include <DD4hep/Primitives.h>
#include <DD4hep/Printout.h>

#include <fmt/core.h>
#include <fmt/format.h>

#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <regex>
#include <string>

namespace fs = std::filesystem;

using dd4hep::ERROR, dd4hep::WARNING, dd4hep::VERBOSE, dd4hep::INFO;
using dd4hep::printout;

namespace FileLoaderHelper {
static constexpr const char* const kCurlCommand =
    "curl --retry 5 --location --fail {0} --output {1}";
static constexpr const char* const kXrootdCommand = "xrdcp --retry 5 {0} {1}";
} // namespace FileLoaderHelper

// Function to download files
inline void EnsureFileFromURLExists(std::string url, std::string file, std::string cache_str = "") {
  // parse cache for environment variables
  auto pos = std::string::npos;
  while ((pos = cache_str.find('$')) != std::string::npos) {
    auto after = cache_str.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                             "abcdefghijklmnopqrstuvwxyz"
                                             "0123456789"
                                             "_",
                                             pos + 1);
    if (after == std::string::npos)
      after = cache_str.size(); // cache ends on env var
    const std::string env_name(cache_str.substr(pos + 1, after - pos - 1));
    auto env_ptr = std::getenv(env_name.c_str());
    const std::string env_value(env_ptr != nullptr ? env_ptr : "");
    cache_str.erase(pos, after - pos);
    cache_str.insert(pos, env_value);
    printout(INFO, "FileLoader", "$" + env_name + " -> " + env_value);
  }

  // tokenize cache on regex
  std::regex cache_sep(":");
  std::sregex_token_iterator cache_iter(cache_str.begin(), cache_str.end(), cache_sep, -1);
  std::sregex_token_iterator cache_end;
  std::vector<std::string> cache_vec(cache_iter, cache_end);

  // create file path
  fs::path file_path(file);

  // create hash from url, hex of unsigned long long
  std::string hash =
      fmt::format("{:016x}", dd4hep::detail::hash64(url)); // TODO: Use c++20 std::fmt

  // create file parent path if not exists
  fs::path parent_path = file_path.parent_path();
  try {
    fs::create_directories(parent_path); // no-op (returns false) if already exists
  } catch (const fs::filesystem_error&) {
    printout(ERROR, "FileLoader", "parent path " + parent_path.string() + " cannot be created");
    printout(ERROR, "FileLoader", "hint: try running 'mkdir -p " + parent_path.string() + "'");
    std::exit(EXIT_FAILURE);
  }

  // if file exists and is symlink to correct hash
  fs::path hash_path(parent_path / hash);
  if (fs::exists(file_path) && fs::exists(hash_path) && fs::equivalent(file_path, hash_path)) {
    printout(INFO, "FileLoader", "link " + file + " -> hash " + hash + " already exists");
    return;
  }

  if (fs::exists(fs::symlink_status(hash_path))) {
    printout(INFO, "FileLoader", "removing symlink \"" + hash_path.string() + "\"");
    remove(hash_path);
  }

  // if hash does not exist, we try to retrieve file from cache
  if (!fs::exists(hash_path)) {
    // recursive loop into cache directories
    bool success = false;
    for (auto cache : cache_vec) {
      fs::path cache_path(cache);
      printout(INFO, "FileLoader", "cache " + cache_path.string());
      if (fs::exists(cache_path)) {
        auto check_path = [&](const fs::path& cache_dir_path) {
          printout(VERBOSE, "FileLoader", "checking " + cache_dir_path.string());
          fs::path cache_hash_path = cache_dir_path / hash;
          if (fs::exists(cache_hash_path)) {
            // symlink hash to cache/.../hash
            printout(VERBOSE, "FileLoader",
                     "file " + file + " with hash " + hash + " found in " +
                         cache_hash_path.string());
            fs::path link_target;
            if (cache_hash_path.is_absolute()) {
              link_target = cache_hash_path;
            } else {
              link_target = fs::proximate(cache_hash_path, parent_path);
            }
            try {
              fs::create_symlink(link_target, hash_path);
              success = true;
            } catch (const fs::filesystem_error&) {
              const bool hash_path_exists = fs::exists(hash_path);
              if (hash_path_exists && fs::equivalent(hash_path, link_target)) {
                // Another process created the correct symlink concurrently; that is fine
                success = true;
              } else if (hash_path_exists) {
                printout(ERROR, "FileLoader",
                         "symlink " + hash_path.string() +
                             " already exists but points to wrong target");
                std::exit(EXIT_FAILURE);
              } else {
                printout(ERROR, "FileLoader",
                         "unable to link from " + hash_path.string() + " to " +
                             link_target.string());
                printout(ERROR, "FileLoader", "check permissions and retry");
                std::exit(EXIT_FAILURE);
              }
            }
            return true;
          }
          return false;
        };
        if (!check_path(cache_path)) {
          for (auto const& dir_entry : fs::recursive_directory_iterator(cache_path)) {
            if (!dir_entry.is_directory())
              continue;
            if (check_path(dir_entry.path())) {
              break;
            };
          }
        }
      }
      if (success)
        break;
    }
  }

  // if hash does not exist, we try to retrieve file from url
  if (!fs::exists(hash_path)) {
    std::string cmd;

    if (url.find("root://") == 0) {
      cmd = fmt::format(FileLoaderHelper::kXrootdCommand, url, hash_path.c_str());
    } else {
      cmd = fmt::format(FileLoaderHelper::kCurlCommand, url, hash_path.c_str());
    }
    printout(INFO, "FileLoader", "downloading " + file + " as hash " + hash + " with " + cmd);

    // run cmd
    auto ret = std::system(cmd.c_str());
    if (!fs::exists(hash_path)) {
      printout(ERROR, "FileLoader", "unable to run the download command " + cmd);
      printout(ERROR, "FileLoader", "the return value was ", ret);
      printout(ERROR, "FileLoader", "hint: check the command and try running manually");
      printout(ERROR, "FileLoader",
               "hint: allow insecure connections on some systems with the flag -k");
      std::exit(EXIT_FAILURE);
    }
  }

  // check if file is symlink
  if (fs::is_symlink(file_path)) {
    // file is symlink, i.e. valid symlink
    if (fs::exists(file_path)) {
      // file already exists
      fs::path symlink_target = fs::read_symlink(file_path);
      if (fs::exists(symlink_target) && fs::equivalent(hash_path, symlink_target)) {
        // link points to correct path
        return;
      } else {
        // link points to incorrect path -> remove symlink
        if (fs::remove(file_path) == false) {
          // failure mode: cannot remove incorrect symlink
          printout(ERROR, "FileLoader", "unable to remove symlink " + file_path.string());
          printout(ERROR, "FileLoader",
                   "we tried to create a symlink " + file_path.string() +
                       " to the actual resource, " +
                       "but a symlink already exists there and points to an incorrect location");
          printout(ERROR, "FileLoader",
                   "hint: this may be resolved by removing directory " + parent_path.string());
          printout(ERROR, "FileLoader",
                   "hint: or in that directory removing the file or link " + file_path.string());
          std::exit(EXIT_FAILURE);
        }
      }
    } else {
      // file does not exists, i.e. dead symllink -> remove symlink
      if (fs::remove(file_path) == false) {
        // failure mode; cannot remove dead symlink
        printout(ERROR, "FileLoader", "unable to remove symlink " + file_path.string());
        std::exit(EXIT_FAILURE);
      }
    }
  } else {
    if (fs::exists(file_path)) {
      // failure mode: file exists but not symlink, and we won't remove files
      printout(ERROR, "FileLoader",
               "file " + file_path.string() + " already exists but is not a symlink");
      printout(ERROR, "FileLoader",
               "we tried to create a symlink " + file_path.string() + " to the actual resource, " +
                   "but a file already exists there and we will not remove it automatically");
      printout(ERROR, "FileLoader", "hint: backup the file, remove it manually, and retry");
      std::exit(EXIT_FAILURE);
    }
  }
  // file_path now does not exist

  // symlink file_path to hash_path
  try {
    // use new path from hash so file link is local
    fs::create_symlink(fs::path(hash), file_path);
  } catch (const fs::filesystem_error&) {
    const bool file_path_exists = fs::exists(file_path);
    if (file_path_exists && fs::equivalent(file_path, hash_path)) {
      // Another process created the correct symlink concurrently; that is fine
    } else if (file_path_exists) {
      printout(ERROR, "FileLoader",
               "symlink " + file_path.string() + " already exists but points to wrong target");
      std::exit(EXIT_FAILURE);
    } else {
      printout(ERROR, "FileLoader",
               "unable to link from " + file_path.string() + " to " + hash_path.string());
      printout(ERROR, "FileLoader", "check permissions and retry");
      std::exit(EXIT_FAILURE);
    }
  }

  // final check of the file size
  if (fs::file_size(file_path) == 0) {
    printout(ERROR, "FileLoader",
             "zero file size of symlink from " + file_path.string() + " to (ultimately) " +
                 fs::canonical(file_path).string());
    printout(ERROR, "FileLoader",
             "hint: check whether the file " + fs::canonical(file_path).string() +
                 " has any content");
    printout(ERROR, "FileLoader", "hint: check whether the URL " + url + " has any content");
    std::exit(EXIT_FAILURE);
  }
}
