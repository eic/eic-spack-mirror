#!/bin/bash

set -e

# helper function to selectively print and run commands without a subshell
function run() {
    set -x
    "$@"
    # save exit code
    { rec=$?; } 2> /dev/null
    { set +x;   } 2> /dev/null
    # restore exit code
    (exit $rec)
}

export run

shopt -s extglob


mode=${1:-all}
if ! [[ $mode = @(all|kf|gsf|gx2f|refit_kf|refit_gsf|fullchains|simulation|gx2f_vs_kf) ]]; then
    echo "Usage: $0 <all|kf|gsf|gx2f|refit_kf|refit_gsf|fullchains|simulation|gx2f_vs_kf> (outdir) (num_jobs)"
    exit 1
fi

outdir=${2:-physmon}
# number of histcmp comparisons run concurrently
num_jobs=${3:-1}
mkdir -p $outdir
mkdir -p $outdir/data
mkdir -p $outdir/html
mkdir -p $outdir/logs

refdir=CI/physmon/reference
refmanifest=CI/physmon/reference.sha256
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}"  )" &> /dev/null && pwd  )

# The reference histograms are not committed; they are fetched by content hash
# from the registry. Set ACTS_PHYSMON_NO_FETCH=1 to run against a reference
# directory you populated yourself.
if [ -z "${ACTS_PHYSMON_NO_FETCH:-}" ]; then
    if ! command -v uv > /dev/null; then
        echo "::error::'uv' is needed to fetch the physmon reference files, but is not on PATH."
        echo "Install it from https://docs.astral.sh/uv/, or populate $refdir"
        echo "yourself and set ACTS_PHYSMON_NO_FETCH=1."
        exit 1
    fi

    echo "::group::Fetch physmon references"
    # Handle the failure rather than letting set -e abort inside the group: on
    # GitHub the error would end up folded into a collapsed section that nobody
    # expands, and the run would stop without saying what was being fetched.
    fetch_ec=0
    run uv run --no-project "${SCRIPT_DIR}/reference.py" pull \
        --manifest "$refmanifest" \
        --reference-dir "$refdir" || fetch_ec=$?
    echo "::endgroup::"

    if [ $fetch_ec -ne 0 ]; then
        echo "::error::Could not fetch the physmon reference files (exit $fetch_ec, details above)"
        echo "The reference histograms are not committed, so there is nothing to compare"
        echo "against without them. See docs/pages/contributing/physmon.md, or set"
        echo "ACTS_PHYSMON_NO_FETCH=1 to run against $refdir as it is on disk."
        exit $fetch_ec
    fi
else
    echo "ACTS_PHYSMON_NO_FETCH is set: using $refdir as it is on disk"
    if [ ! -d "$refdir" ]; then
        echo "::error::$refdir does not exist, and fetching is disabled."
        echo "Unset ACTS_PHYSMON_NO_FETCH to fetch the references from the registry,"
        echo "or populate that directory yourself."
        exit 1
    fi
fi

# Ship the manifest with the artifact so an update can be reconstructed from the
# run alone, without guessing which commit it came from
cp "$refmanifest" "$outdir/reference.sha256"

# File to accumulate the histcmp results
histcmp_results=$outdir/histcmp_results.csv
echo -n "" > $histcmp_results

memory_dir=${outdir}/memory
mkdir -p "$memory_dir"

if [ "$(uname)" == "Darwin" ]; then
    function measure {
        label=$1
        slug=$2
        shift
        shift
        echo "Measure Darwin $label ($slug)" >&2
        tmp=$(mktemp)
        echo "+ $@" >&2
        /usr/bin/time -l -o "$tmp" "$@"
        # save exit code
        rec=$?

        of="${memory_dir}/mem_${slug}.csv"
        {
            echo "# spyral-label: $label"
            echo "# spyral-cmd: $*"
            echo "time,rss,vms"
            # in bytes
            grep -E "real" "$tmp" | awk '{printf $1}'
            printf ","
            grep -E "maximum resident set size" "$tmp" | awk '{printf $1}'
            printf ",0\n"
        } > "$of"
        # restore exit code
        (exit $rec)
    }
    export measure
elif [ "$(uname)" == "Linux" ]; then
    function measure {
        label=$1
        slug=$2
        shift
        shift
        echo "Measure Linux $label ($slug)" >&2
        tmp=$(mktemp)
        echo "+ $@" >&2
        /usr/bin/time -v -o  "$tmp" "$@"
        # save exit code
        rec=$?
        # in kbytes
        max_rss=$(grep "Maximum resident set size (kbytes):" "$tmp" | awk '{printf $(NF)}')
        max_rss=$(( 1024 * max_rss ))
        echo "Maximum resident set size: $(printf "%'d" $max_rss) bytes"

        wall_time=$(grep "Elapsed (wall clock)" "$tmp" | awk '{printf $(NF)}')
        wall_time=$(python3 -c "i='${wall_time}';p=i.split(':');p = p if len(p) == 3 else ['0', *p];t=float(p[0])*60*60 + float(p[1])*60 + float(p[2]);print(t)")
        echo "Elapsed (wall clock) time: ${wall_time} seconds"

        of="${memory_dir}/mem_${slug}.csv"
        {
            echo "# spyral-label: $label"
            echo "# spyral-cmd: $*"
            echo "time,rss,vms"
            echo "${wall_time},${max_rss},0"
        } > "$of"
        # restore exit code
        (exit $rec)
    }
    export measure
else
    function measure {
        echo "Not measuring because unknown environment"
        shift
        shift
        "$@"
    }
    export measure
fi

if [ -n "$CI" ]; then
    echo "CI mode, do not abort immediately on failure"
    set +e
fi
ec=0

source $SCRIPT_DIR/setup.sh

function run_physmon_gen() {
    title=$1
    slug=$2

    script=CI/physmon/workflows/physmon_${slug}.py

    mkdir -p $outdir/data/$slug
    mkdir -p $outdir/logs
    measure "$title" "$slug" python3 ${script} $outdir/data/$slug 2>&1 > $outdir/logs/${slug}.log

    this_ec=$?
    ec=$(($ec | $this_ec))

    if [ $this_ec -ne 0 ]; then
        echo "::error::🟥 Dataset generation failed: ${script} -> ec=$this_ec"
    else
        echo "::notice::✅ Dataset generation succeeded: ${script}"
    fi
}

echo "::group::Generate validation dataset"
if [[ "$mode" == "all" || "$mode" == "simulation" ]]; then
    run_physmon_gen "Simulation" "simulation"
fi
if [[ "$mode" == "all" || "$mode" == "gsf" || "$mode" == "refit_gsf" ]]; then
    run_physmon_gen "Geant4 Sim for GSF" "simulation_gsf"
fi
if [[ "$mode" == "all" || "$mode" == "kf" ]]; then
    run_physmon_gen "Truth Tracking KF" "trackfitting_kf"
fi
if [[ "$mode" == "all" || "$mode" == "gsf" ]]; then
    run_physmon_gen "Truth Tracking GSF" "trackfitting_gsf"
fi
if [[ "$mode" == "all" || "$mode" == "gx2f" ]]; then
    run_physmon_gen "Truth Tracking GX2F" "trackfitting_gx2f"
fi
if [[ "$mode" == "all" || "$mode" == "refit_kf" ]]; then
    run_physmon_gen "Truth Tracking KF refit" "trackrefitting_kf"
fi
if [[ "$mode" == "all" || "$mode" == "refit_gsf" ]]; then
    run_physmon_gen "Truth Tracking GSF refit" "trackrefitting_gsf"
fi
if [[ "$mode" == "all" || "$mode" == "fullchains" ]]; then
    run_physmon_gen "CKF single muon" "trackfinding_1muon"
    run_physmon_gen "CKF muon 50" "trackfinding_4muon_50vertices"
    run_physmon_gen "CKF ttbar 200" "trackfinding_ttbar_pu200"
fi
if [[ "$mode" == "all" || "$mode" == "gx2f_vs_kf" ]]; then
    run_physmon_gen "Comparison - Truth Tracking GX2F vs KF" "trackfitting_gx2f_vs_kf"
fi
echo "::endgroup::"


# The histcmp comparisons are independent of each other. run_histcmp only
# queues them; finish_comparisons runs them $num_jobs at a time and then replays
# their output in submission order, so the log, the results CSV and the exit
# code look as if they had run one after the other.
#
# Each comparison runs single-process (--jobs 1). histcmp's own worker pool
# starts every worker as a fresh interpreter that imports ROOT and matplotlib
# again, which costs more than it saves once whole files run side by side.
comparison_jobs_dir=$outdir/comparison_jobs
rm -rf $comparison_jobs_dir
mkdir -p $comparison_jobs_dir
comparison_count=0
comparison_cmds=()

function run_histcmp() {
    comparison_cmds[$comparison_count]=$(printf '%q ' "$@")
    comparison_count=$(($comparison_count + 1))
}

# Runs one queued comparison; its output goes to $jobdir/log by the caller
function run_comparison() {
    local jobdir=$1
    local a=$2
    local b=$3
    local title=$4
    local html_path=$5
    shift 5

    local this_ec=0

    if [ ! -f "$a" ]; then
        echo "::error::histcmp failed: File $a does not exist"
        this_ec=1
    fi

    if [ ! -f "$b" ]; then
        echo "::error::histcmp failed: File $b does not exist"
        this_ec=1
    fi

    # histcmp only creates this directory when a plot directory is configured
    mkdir -p $(dirname $outdir/html/$html_path)

    local start=$(date +%s)
    # scatter renders 3D histograms much faster than the default voxel
    # renderer at every histogram size
    local histcmp_ec=0
    run histcmp $a $b \
        --label-reference=reference \
        --label-monitored=monitored \
        --title="$title" \
        --jobs 1 \
        --renderer-3d scatter \
        -o $outdir/html/$html_path \
        "$@" || histcmp_ec=$?
    this_ec=$(($this_ec | $histcmp_ec))
    echo "histcmp took $(($(date +%s) - $start)) seconds"

    echo $this_ec > $jobdir/ec
}

function finish_comparisons() {
    local i
    local order

    # Largest monitored file first: the cost of a comparison grows with the
    # number of histograms in it, and starting the slow ones last would leave
    # them running alone at the end.
    order=$(
        for ((i = 0; i < $comparison_count; i++)); do
            eval "set -- ${comparison_cmds[$i]}"
            size=0
            if [ -f "$1" ]; then
                size=$(wc -c < "$1")
            fi
            echo "$size $i"
        done | sort -rn | awk '{print $2}'
    )

    for i in $order; do
        while [ "$(jobs -rp | wc -l)" -ge "$num_jobs" ]; do
            sleep 0.2
        done
        local jobdir=$comparison_jobs_dir/$i
        mkdir -p $jobdir
        eval "run_comparison $jobdir ${comparison_cmds[$i]}" > $jobdir/log 2>&1 &
    done
    wait

    for ((i = 0; i < $comparison_count; i++)); do
        local jobdir=$comparison_jobs_dir/$i
        eval "set -- ${comparison_cmds[$i]}"
        local a=$1
        local b=$2
        local title=$3
        local html_path=$4

        echo "::group::Comparing $a vs. $b"
        cat $jobdir/log

        local this_ec
        this_ec=$(cat $jobdir/ec 2> /dev/null || echo 1)
        ec=$(($ec | $this_ec))

        if [ $this_ec -ne 0 ]; then
            echo "::error::histcmp failed: ec=$this_ec"
        fi

        # Record which reference file this comparison covers, and which output
        # would replace it, so `reference.py candidate` can turn a failure into
        # a manifest entry. Comparisons between two monitored outputs have no
        # reference and leave both fields empty.
        local ref_path=""
        local monitored_path=""
        if [[ "$b" == "$refdir/"* ]]; then
            ref_path="${b#$refdir/}"
            monitored_path="${a#$outdir/data/}"
        fi

        echo "\"${title}\",html/${html_path},${this_ec},${ref_path},${monitored_path}" >> $histcmp_results

        echo "::endgroup::"
    done

    rm -rf $comparison_jobs_dir
}

function trackfinding() {
    name=$1
    path=$2

    default_config="CI/physmon/config/default.yml"

    if [ -f $outdir/data/$path/performance_seeding.root ] || [ -f $refdir/$path/performance_seeding.root ]; then
        run_histcmp \
            $outdir/data/$path/performance_seeding.root \
            $refdir/$path/performance_seeding.root \
            "Seeding ${name}" \
            $path/performance_seeding.html \
            --config $default_config
    fi

    run_histcmp \
        $outdir/data/$path/performance_finding_ckf.root \
        $refdir/$path/performance_finding_ckf.root \
        "CKF finding performance | ${name}" \
        $path/performance_finding_ckf.html \
        --config $default_config

    run_histcmp \
        $outdir/data/$path/performance_fitting_ckf.root \
        $refdir/$path/performance_fitting_ckf.root \
        "CKF fitting performance | ${name}" \
        $path/performance_fitting_ckf.html \
        --config $default_config

    # TODO remove
    echo "which python3: $(which python3)"
    echo "python3 version: $(python3 --version)"
    echo "python3 -m pip list: $(python3 -m pip list)"
    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/$path/tracksummary_ckf.root \
        tracksummary \
        $outdir/data/$path/tracksummary_ckf_hist.root \
        --silent \
        --config CI/physmon/config/tracksummary_ckf.yml
    ec=$(($ec | $?))

    # remove ntuple file because it's large
    rm $outdir/data/$path/tracksummary_ckf.root

    run_histcmp \
        $outdir/data/$path/tracksummary_ckf_hist.root \
        $refdir/$path/tracksummary_ckf_hist.root \
        "CKF track summary | ${name}" \
        $path/tracksummary_ckf.html

    if [ -f $refdir/$path/performance_finding_ckf_ambi.root ]; then
        run_histcmp \
            $outdir/data/$path/performance_finding_ckf_ambi.root \
            $refdir/$path/performance_finding_ckf_ambi.root \
            "Ambisolver finding performance | ${name}" \
            $path/performance_finding_ckf_ambi.html
    fi

    if [ -f $refdir/$path/performance_finding_ckf_ml_solver.root ]; then
        run_histcmp \
            $outdir/data/$path/performance_finding_ckf_ml_solver.root \
            $refdir/$path/performance_finding_ckf_ml_solver.root \
            "ML Ambisolver | ${name}" \
            $path/performance_finding_ckf_ml_solver.html
    fi
}

function vertexing() {
    name=$1
    path=$2
    config=$3

    if [ -f $refdir/$path/performance_vertexing_ivf_notime_hist.root ]; then
        run python3 Examples/Scripts/generic_plotter.py \
            $outdir/data/$path/performance_vertexing_ivf_notime.root \
            vertexing \
            $outdir/data/$path/performance_vertexing_ivf_notime_hist.root \
            --silent \
            --config $config
        ec=$(($ec | $?))

        # remove ntuple file because it's large
        rm $outdir/data/$path/performance_vertexing_ivf_notime.root

        run_histcmp \
            $outdir/data/$path/performance_vertexing_ivf_notime_hist.root \
            $refdir/$path/performance_vertexing_ivf_notime_hist.root \
            "IVF notime | ${name}" \
            $path/performance_vertexing_ivf_notime.html
    fi

    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/$path/performance_vertexing_amvf_gauss_notime.root \
        vertexing \
        $outdir/data/$path/performance_vertexing_amvf_gauss_notime_hist.root \
        --silent \
        --config $config
    ec=$(($ec | $?))

    # remove ntuple file because it's large
    rm $outdir/data/$path/performance_vertexing_amvf_gauss_notime.root

    run_histcmp \
        $outdir/data/$path/performance_vertexing_amvf_gauss_notime_hist.root \
        $refdir/$path/performance_vertexing_amvf_gauss_notime_hist.root \
        "AMVF gauss notime | ${name}" \
        $path/performance_vertexing_amvf_gauss_notime.html

    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/$path/performance_vertexing_amvf_grid_time.root \
        vertexing \
        $outdir/data/$path/performance_vertexing_amvf_grid_time_hist.root \
        --silent \
        --config $config
    ec=$(($ec | $?))

    # remove ntuple file because it's large
    rm $outdir/data/$path/performance_vertexing_amvf_grid_time.root

    run_histcmp \
        $outdir/data/$path/performance_vertexing_amvf_grid_time_hist.root \
        $refdir/$path/performance_vertexing_amvf_grid_time_hist.root \
        "AMVF grid time | ${name}" \
        $path/performance_vertexing_amvf_grid_time.html
}

function simulation() {
    suffix=$1

    config="CI/physmon/config/simulation.yml"

    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/simulation/particles_${suffix}.root \
        particles \
        $outdir/data/simulation/particles_${suffix}_hist.root \
        --silent \
        --config $config
    ec=$(($ec | $?))

    # remove ntuple file because it's large
    rm $outdir/data/simulation/particles_${suffix}.root

    run_histcmp \
        $outdir/data/simulation/particles_${suffix}_hist.root \
        $refdir/simulation/particles_${suffix}_hist.root \
        "Particles ${suffix}" \
        simulation/particles_${suffix}.html
}

function generation() {
    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/simulation/particles_ttbar.root \
        particles \
        $outdir/data/simulation/particles_ttbar_hist.root \
        --silent \
        --config CI/physmon/config/pythia8_ttbar.yml

    # remove ntuple file because it's large
    rm $outdir/data/simulation/particles_ttbar.root

    run_histcmp \
        $outdir/data/simulation/particles_ttbar_hist.root \
        $refdir/simulation/particles_ttbar_hist.root \
        "Particles ttbar" \
        simulation/particles_ttbar.html

    run python3 Examples/Scripts/generic_plotter.py \
        $outdir/data/simulation/vertices_ttbar.root \
        vertices \
        $outdir/data/simulation/vertices_ttbar_hist.root \
        --silent \
        --config CI/physmon/config/pythia8_ttbar.yml

    # remove ntuple file because it's large
    rm $outdir/data/simulation/vertices_ttbar.root

    run_histcmp \
        $outdir/data/simulation/vertices_ttbar_hist.root \
        $refdir/simulation/vertices_ttbar_hist.root \
        "Vertices ttbar" \
        simulation/vertices_ttbar.html
}

if [[ "$mode" == "all" || "$mode" == "simulation" ]]; then
    simulation fatras
    simulation geant4

    generation
fi

if [[ "$mode" == "all" || "$mode" == "kf" ]]; then
    run_histcmp \
        $outdir/data/trackfitting_kf/performance_trackfitting.root \
        $refdir/trackfitting_kf/performance_trackfitting.root \
        "Truth tracking (KF)" \
        trackfitting_kf/performance_trackfitting.html \
        --config CI/physmon/config/trackfitting_kf.yml
fi

if [[ "$mode" == "all" || "$mode" == "gsf" ]]; then
    run_histcmp \
        $outdir/data/trackfitting_gsf/performance_trackfitting.root \
        $refdir/trackfitting_gsf/performance_trackfitting.root \
        "Truth tracking (GSF)" \
        trackfitting_gsf/performance_trackfitting.html \
        --config CI/physmon/config/trackfitting_gsf.yml
fi

if [[ "$mode" == "all" || "$mode" == "gx2f" ]]; then
    run_histcmp \
        $outdir/data/trackfitting_gx2f/performance_trackfitting.root \
        $refdir/trackfitting_gx2f/performance_trackfitting.root \
        "Truth tracking (GX2F)" \
        trackfitting_gx2f/performance_trackfitting.html \
        --config CI/physmon/config/trackfitting_gx2f.yml
fi

if [[ "$mode" == "all" || "$mode" == "refit_kf" ]]; then
    run_histcmp \
        $outdir/data/trackrefitting_kf/performance_trackrefitting.root \
        $refdir/trackrefitting_kf/performance_trackrefitting.root \
        "Truth tracking (KF refit)" \
        trackrefitting_kf/performance_trackrefitting.html \
        --config CI/physmon/config/trackfitting_kf.yml
fi

if [[ "$mode" == "all" || "$mode" == "refit_gsf" ]]; then
    run_histcmp \
        $outdir/data/trackrefitting_gsf/performance_trackrefitting.root \
        $refdir/trackrefitting_gsf/performance_trackrefitting.root \
        "Truth tracking (GSF refit)" \
        trackrefitting_gsf/performance_trackrefitting.html \
        --config CI/physmon/config/trackfitting_gsf.yml
fi

if [[ "$mode" == "all" || "$mode" == "fullchains" ]]; then
    trackfinding "trackfinding | single muon | truth smeared seeding" trackfinding_1muon/truth_smeared
    trackfinding "trackfinding | single muon | truth estimated seeding" trackfinding_1muon/truth_estimated
    trackfinding "trackfinding | single muon | default seeding" trackfinding_1muon/seeded
    trackfinding "trackfinding | single muon | orthogonal seeding" trackfinding_1muon/orthogonal
    trackfinding "trackfinding | single muon | GBTS seeding" trackfinding_1muon/gbts

    trackfinding "trackfinding | 4 muon x 50 vertices | default seeding" trackfinding_4muon_50vertices
    vertexing "trackfinding | 4 muon x 50 vertices | default seeding" trackfinding_4muon_50vertices CI/physmon/config/vertexing_4muon_50vertices.yml

    trackfinding "trackfinding | ttbar with 200 pileup | default seeding" trackfinding_ttbar_pu200
    vertexing "trackfinding | ttbar with 200 pileup | default seeding" trackfinding_ttbar_pu200 CI/physmon/config/vertexing_ttbar_pu200.yml
fi

if [[ "$mode" == "all" || "$mode" == "gx2f_vs_kf" ]]; then
    run_histcmp \
        $outdir/data/trackfitting_gx2f_vs_kf/performance_trackfitting_gx2f.root \
        $outdir/data/trackfitting_gx2f_vs_kf/performance_trackfitting_kf.root \
        "Comparison - Truth tracking (GX2F vs KF)" \
        trackfitting_gx2f_vs_kf/performance_trackfitting.html \
        --config CI/physmon/config/info_only.yml \
        --label-reference=KF \
        --label-monitored=GX2F
fi

finish_comparisons

run python3 CI/physmon/summary.py $histcmp_results \
  --md $outdir/summary.md \
  --html $outdir/summary.html
ec=$(($ec | $?))

# The manifest that would apply if every failing comparison here were accepted.
# Attached to the artifact so a maintainer can publish it without re-running
# anything, and so the pull request has something to commit verbatim.
run uv run --no-project "${SCRIPT_DIR}/reference.py" candidate \
  --manifest "$refmanifest" \
  --results $histcmp_results \
  --data-dir $outdir/data \
  --output $outdir/reference-candidate.sha256

exit $ec
