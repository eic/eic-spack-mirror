/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "OverlayTiming.h"

#include <Gaudi/PluginService.h>
#include <GaudiKernel/GaudiException.h>
#include <GaudiKernel/MsgStream.h>
#include <GaudiKernel/StatusCode.h>

#include <podio/FrameCategories.h>

#include <edm4hep/CaloHitContributionCollection.h>
#include <edm4hep/Constants.h>
#include <edm4hep/EventHeaderCollection.h>
#include <edm4hep/MCParticleCollection.h>
#include <edm4hep/MutableSimCalorimeterHit.h>
#include <edm4hep/SimCalorimeterHitCollection.h>
#include <edm4hep/SimTrackerHitCollection.h>

#include "k4FWCore/MetadataUtils.h"
#include "k4Interface/IUniqueIDGenSvc.h"

#include <TMath.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

template <typename T>
inline float time_of_flight(const T& pos) {
  // Returns the time of flight to the radius in ns
  // Assumming positions in mm, then mm/m/s = 10^-3 s = 10^6 ns
  return std::sqrt((pos[0] * pos[0]) + (pos[1] * pos[1]) + (pos[2] * pos[2])) / TMath::C() * 1e6;
}

// Index of the copied background particle a relation should point at.
// An index outside the background collection leaves the relation unset, which
// covers both podio::ObjectID::untracked (-1) and podio::ObjectID::invalid (-2).
inline int overlaid_particle_index(int oldIndex, int offset, int nBgParticles) {
  return (oldIndex >= 0 && oldIndex < nBgParticles) ? offset + oldIndex : -1;
}

std::pair<float, float> OverlayTiming::define_time_windows(const std::string& collection_name) const {
  try {
    return {m_timeWindows.value().at(collection_name)[0], m_timeWindows.value().at(collection_name)[1]};
  } catch (const std::out_of_range& e) {
    error() << "No time window defined for collection " << collection_name << endmsg;
    throw e;
  }
}

StatusCode OverlayTiming::initialize() {
  m_uidSvc = service<IUniqueIDGenSvc>("UniqueIDGenSvc", true);
  if (!m_uidSvc) {
    error() << "Unable to get UniqueIDGenSvc" << endmsg;
    return StatusCode::FAILURE;
  }

  // An empty group, e.g. from a glob that matched nothing, would otherwise
  // only fail once the first background event is requested
  const auto& inputFiles = m_inputFileNames.value();
  for (size_t i = 0; i < inputFiles.size(); ++i) {
    if (inputFiles[i].empty()) {
      error() << "Background group " << i << " contains no files" << endmsg;
      return StatusCode::FAILURE;
    }
  }

  m_bkgEvents =
      make_unique<EventHolder>(inputFiles, m_randomMix.value(), m_allowReusingBackgroundFiles.value(), name());

  // In sequential mode the event counts are known upfront and can be validated
  // here. In random-mix mode they are only determined when a file is first
  // read, so an empty file is reported at that point instead.
  if (!m_randomMix) {
    for (size_t group = 0; group < m_bkgEvents->size(); ++group) {
      // A group is read as a single stream here, so this is the number of
      // events in all of its files together
      const auto nEvents = m_bkgEvents->m_totalNumberOfEvents[group].front();
      if (nEvents == 0) {
        std::string err =
            "No events found in background group " + std::to_string(group) + ", none of its files has any:";
        for (const auto& file : m_bkgEvents->m_fileNames[group]) {
          err += " " + file;
        }
        error() << err << endmsg;
        return StatusCode::FAILURE;
      }
      if (m_startWithBackgroundEvent >= static_cast<int>(nEvents)) {
        error() << "StartBackgroundEventIndex (" << m_startWithBackgroundEvent.value()
                << ") is not smaller than the number of events (" << nEvents << ") in background group " << group
                << endmsg;
        return StatusCode::FAILURE;
      }
    }
  }
  // Every group starts reading at this index, and from there on advances with each background event read
  if (m_startWithBackgroundEvent >= 0) {
    info() << "Starting every background group at event " << m_startWithBackgroundEvent << endmsg;
    for (auto& group : m_bkgEvents->m_nextEntry) {
      std::ranges::fill(group, static_cast<size_t>(m_startWithBackgroundEvent.value()));
    }
  }

  if (m_Noverlay.empty()) {
    info() << "Using the default number of overlay events (1) for each group, since none was specified with "
              "NumberBackground "
           << endmsg;
    m_Noverlay = std::vector<double>(m_bkgEvents->size(), 1);
  }

  if (m_Poisson.empty()) {
    info() << "Using the default overlay mode (no Poission distribution) for each group, since none was specified with "
              "Poisson_random_NOverlay"
           << endmsg;
    m_Poisson = std::vector<bool>(m_bkgEvents->size(), false);
  }

  // Check that the per-group settings have the right size
  if (m_Noverlay.size() != m_bkgEvents->size()) {
    error() << "NumberBackground has " << m_Noverlay.size() << " entries, but " << m_bkgEvents->size()
            << " background groups were configured" << endmsg;
    return StatusCode::FAILURE;
  }
  if (m_Poisson.size() != m_bkgEvents->size()) {
    error() << "Poisson_random_NOverlay has " << m_Poisson.size() << " entries, but " << m_bkgEvents->size()
            << " background groups were configured" << endmsg;
    return StatusCode::FAILURE;
  }

  // Copy the cellID encoding of the input collections over to the overlaid output collections.
  if (m_copyCellIDMetadata) {
    for (const auto& [input, output] :
         {std::make_pair(inputLocations("SimTrackerHits"), outputLocations("OutputSimTrackerHits")),
          std::make_pair(inputLocations("SimCalorimeterHits"), outputLocations("OutputSimCalorimeterHits"))}) {
      for (size_t i = 0; i < input.size(); ++i) {
        const auto value = k4FWCore::getCellIDEncoding(input[i], this);
        if (value.has_value()) {
          k4FWCore::putCellIDEncoding(output[i], value.value(), this);
        } else {
          warning() << "No metadata found for " << input[i] << " when copying CellID metadata was requested" << endmsg;
        }
      }
    }
  }

  return StatusCode::SUCCESS;
}

retType OverlayTiming::operator()(const edm4hep::EventHeaderCollection& headers,
                                  const edm4hep::MCParticleCollection& particles,
                                  const std::vector<const edm4hep::SimTrackerHitCollection*>& simTrackerHits,
                                  const std::vector<const edm4hep::SimCalorimeterHitCollection*>& simCaloHits) const {
  const auto seed = m_uidSvc->getUniqueID(headers[0].getEventNumber(), headers[0].getRunNumber(), this->name());
  auto rng_engine = std::mt19937(seed);

  // Output collections
  auto oparticles = edm4hep::MCParticleCollection();
  auto osimTrackerHits = std::vector<edm4hep::SimTrackerHitCollection>();
  auto osimCaloHits = std::vector<edm4hep::SimCalorimeterHitCollection>();
  auto ocaloHitContribs = std::vector<edm4hep::CaloHitContributionCollection>();
  for (size_t i = 0; i < simCaloHits.size(); ++i) {
    ocaloHitContribs.emplace_back();
  }

  // Copy MCParticles for physics event into a new collection
  for (const auto&& part : particles) {
    oparticles.push_back(part.clone(false));
  }
  // Fix relations to point to the new particles
  for (size_t i = 0; i < particles.size(); ++i) {
    for (const auto& parent : particles.at(i).getParents()) {
      if (const auto index = parent.getObjectID().index; index >= 0) {
        oparticles.at(i).addToParents(oparticles.at(index));
      }
    }
    for (const auto& daughter : particles.at(i).getDaughters()) {
      if (const auto index = daughter.getObjectID().index; index >= 0) {
        oparticles.at(i).addToDaughters(oparticles.at(index));
      }
    }
  }

  // Copy the SimTrackerHits and crop them
  for (size_t i = 0; i < simTrackerHits.size(); ++i) {
    const auto& coll = simTrackerHits[i];
    const auto name = inputLocations(SIMTRACKERHIT_INDEX_POSITION)[i];
    const auto [this_start, this_stop] = define_time_windows(name);
    auto ocoll = edm4hep::SimTrackerHitCollection();
    for (const auto&& simTrackerHit : *coll) {
      const float tof = time_of_flight(simTrackerHit.getPosition());
      if ((simTrackerHit.getTime() > this_start + tof) && (simTrackerHit.getTime() < this_stop + tof)) {
        auto nhit = simTrackerHit.clone(false);
        if (const auto index = simTrackerHit.getParticle().getObjectID().index; index >= 0) {
          nhit.setParticle(oparticles.at(index));
        }
        ocoll.push_back(nhit);
      }
    }
    osimTrackerHits.emplace_back(std::move(ocoll));
  }

  // Copy the SimCalorimeterHits and crop them together with the contributions
  std::map<int, std::map<uint64_t, edm4hep::MutableSimCalorimeterHit>> cellIDsMap;
  for (size_t i = 0; i < simCaloHits.size(); ++i) {
    const auto& coll = simCaloHits[i];
    const auto name = inputLocations(SIMCALOHIT_INDEX_POSITION)[i];
    const auto [this_start, this_stop] = define_time_windows(name);
    // operator[] on purpose: this is where the entry for this collection is created
    auto& calHitMap = cellIDsMap[i];
    auto& caloHitContribs = ocaloHitContribs[i];
    for (const auto&& simCaloHit : *coll) {
      const float tof = time_of_flight(simCaloHit.getPosition());
      bool within_time_window = false;
      std::vector<int> thisContribs;
      for (const auto& contrib : simCaloHit.getContributions()) {
        if (!((contrib.getTime() > this_start + tof) && (contrib.getTime() < this_stop + tof))) {
          continue;
        }
        within_time_window = true;
        // TODO: Make sure a contribution is not added twice
        auto newContrib = contrib.clone(false);
        if (const auto index = contrib.getParticle().getObjectID().index; index >= 0) {
          newContrib.setParticle(oparticles.at(index));
        }
        thisContribs.push_back(caloHitContribs.size());
        caloHitContribs.push_back(std::move(newContrib));
      }
      if (within_time_window) {
        auto newhit = simCaloHit.clone(false);
        for (const auto& contrib : thisContribs) {
          newhit.addToContributions(caloHitContribs.at(contrib));
        }
        calHitMap.emplace(simCaloHit.getCellID(), std::move(newhit));
      }
    }
  }

  auto physBX = m_physBX.value();
  // Iterate over each group of files and parameters
  for (size_t groupIndex = 0; groupIndex < m_bkgEvents->size(); groupIndex++) {
    if (m_randomBX) {
      physBX = std::uniform_int_distribution<int>(0, m_NBunchTrain - 1)(rng_engine);
      debug() << "Physics Event was placed in the " << physBX << " bunch crossing!" << endmsg;
    }

    // define a permutation for the events to overlay -- the physics event is per definition at position 0
    std::vector<int> permutation;

    // Permutation has negative values and the last one is 0
    // if (!m_randomBX) then physBX (default = 1)
    for (int i = -(physBX - 1); i < m_NBunchTrain - (physBX - 1); ++i) {
      permutation.push_back(i);
    }
    std::shuffle(permutation.begin(), permutation.end(), rng_engine);

    // In random-mix mode the files of the group are drawn in a random order.
    // In sequential mode the file index is ignored, so this stays trivial.
    std::vector<int> fileIndices(m_bkgEvents->m_fileNames[groupIndex].size());
    std::iota(fileIndices.begin(), fileIndices.end(), 0);
    if (m_randomMix) {
      std::shuffle(fileIndices.begin(), fileIndices.end(), rng_engine);
    }

    // TODO: Check that there is anything to overlay

    // In random-mix mode every file has its own cursor and the file is only
    // drawn below, where it is reported for each overlaid event
    if (!m_randomMix && msgLevel(MSG::DEBUG)) {
      debug() << "Starting overlay at event: " << m_bkgEvents->nextEntry(groupIndex) << " for the background group "
              << groupIndex << endmsg;
    }

    // Overlay the background events to each bunchcrossing in the bunch train.
    // The file cursor is deliberately declared outside the BX loop: it has to
    // keep advancing across bunch crossings, otherwise every BX would restart
    // at the front of the permutation and reuse the same file for the whole
    // train (which is what happens for NumberBackground = 1).
    size_t fileCursor = 0;
    for (int bxInTrain = 0; bxInTrain < m_NBunchTrain; ++bxInTrain) {
      const int BX_number_in_train = permutation.at(bxInTrain);

      int NOverlay_to_this_BX = 0;

      if (m_Poisson[groupIndex]) {
        NOverlay_to_this_BX = std::poisson_distribution<>(m_Noverlay[groupIndex])(rng_engine);
      } else {
        NOverlay_to_this_BX = m_Noverlay[groupIndex];
      }

      debug() << "Will overlay " << NOverlay_to_this_BX << " events to BX number " << BX_number_in_train + physBX
              << endmsg;

      for (int k = 0; k < NOverlay_to_this_BX; ++k) {
        // In random-mix mode walk the shuffled permutation so that consecutive
        // overlaid events draw distinct files. Once the permutation is
        // exhausted it is reshuffled, so every pass is an independent random
        // set instead of a replay of the same order. In sequential mode the
        // file index is ignored.
        int fileIndex = 0;
        if (m_randomMix) {
          if (fileCursor == fileIndices.size()) {
            std::shuffle(fileIndices.begin(), fileIndices.end(), rng_engine);
            fileCursor = 0;
          }
          fileIndex = fileIndices[fileCursor++];
        }
        if (m_randomMix) {
          debug() << "Overlaying a background event from " << m_bkgEvents->m_fileNames[groupIndex][fileIndex]
                  << " to BX " << bxInTrain << endmsg;
        } else {
          debug() << "Overlaying a background event from group " << groupIndex << " to BX " << bxInTrain << endmsg;
        }
        const auto backgroundEvent = m_bkgEvents->getFrame(groupIndex, fileIndex);
        const auto availableCollections = backgroundEvent.getAvailableCollections();

        // Either 0 or negative
        const auto timeOffset = BX_number_in_train * m_deltaT;

        // The background particles are copied in order, so the copy of background
        // particle i ends up at offset + i. Both stay 0 when the background
        // particles are not merged, which leaves every relation into them unset.
        int offset = 0;
        int nBgParticles = 0;

        // The background particles are only looked up when they are merged. If
        // their collection is missing nothing is copied, and the background
        // hits are left without a particle.
        const bool hasBgParticles =
            std::ranges::find(availableCollections, m_MCParticleCollectionName.value()) != availableCollections.end();
        if (m_mergeMCParticles && !hasBgParticles) {
          ++m_missingBackgroundMCParticles;
        }

        if (m_mergeMCParticles && hasBgParticles) {
          const auto& bgParticles = backgroundEvent.get<edm4hep::MCParticleCollection>(m_MCParticleCollectionName);
          offset = static_cast<int>(oparticles.size());
          nBgParticles = static_cast<int>(bgParticles.size());

          for (int i = 0; i < nBgParticles; ++i) {
            auto npart = bgParticles[i].clone(false);
            npart.setTime(bgParticles[i].getTime() + timeOffset);
            npart.setOverlay(true);
            oparticles.push_back(npart);
          }

          // The relations can only be wired up once every particle has been copied.
          // Relations pointing outside the background collection are left unset.
          for (int i = 0; i < nBgParticles; ++i) {
            for (const auto& parent : bgParticles[i].getParents()) {
              if (const auto index = overlaid_particle_index(parent.getObjectID().index, offset, nBgParticles);
                  index >= 0) {
                oparticles.at(offset + i).addToParents(oparticles.at(index));
              }
            }
            for (const auto& daughter : bgParticles[i].getDaughters()) {
              if (const auto index = overlaid_particle_index(daughter.getObjectID().index, offset, nBgParticles);
                  index >= 0) {
                oparticles.at(offset + i).addToDaughters(oparticles.at(index));
              }
            }
          }
        }

        for (size_t i = 0; i < simTrackerHits.size(); ++i) {
          const auto name = inputLocations(SIMTRACKERHIT_INDEX_POSITION)[i];
          debug() << "Processing collection " << name << endmsg;
          if (std::find(availableCollections.begin(), availableCollections.end(), name) == availableCollections.end()) {
            warning() << "Collection " << name << " not found in background event" << endmsg;
            continue;
          }
          const auto [this_start, this_stop] = define_time_windows(name);
          // There are only contributions to the readout if the hits are in the integration window
          if (this_stop <= (BX_number_in_train - physBX) * m_deltaT) {
            info() << "Skipping collection " << name << " as it is not in the integration window" << endmsg;
            continue;
          }
          auto& ocoll = osimTrackerHits[i];
          for (const auto&& simTrackerHit : backgroundEvent.get<edm4hep::SimTrackerHitCollection>(name)) {
            const float tof = time_of_flight(simTrackerHit.getPosition());

            if (!((simTrackerHit.getTime() + timeOffset > this_start + tof) &&
                  (simTrackerHit.getTime() + timeOffset < this_stop + tof))) {
              continue;
            }
            auto nhit = simTrackerHit.clone(false);
            nhit.setOverlay(true);
            nhit.setTime(simTrackerHit.getTime() + timeOffset);
            if (m_mergeMCParticles) {
              if (const auto index =
                      overlaid_particle_index(simTrackerHit.getParticle().getObjectID().index, offset, nBgParticles);
                  index >= 0) {
                nhit.setParticle(oparticles.at(index));
              }
            } else if (const auto mcp = simTrackerHit.getParticle(); mcp.isAvailable()) {
              // Without the background particles there is nothing to point at, so
              // preserve the momentum of the originating particle instead of the
              // one it had at this hit
              const auto mom = mcp.getMomentum();
              nhit.setMomentum({static_cast<float>(mom.x), static_cast<float>(mom.y), static_cast<float>(mom.z)});
            }
            ocoll.push_back(nhit);
          }
        }

        // Copies a background contribution, shifted in time and pointing to the
        // copy of its particle. The clone carries no relations.
        const auto cloneContribution = [&](const edm4hep::CaloHitContribution& contrib) {
          auto newContrib = contrib.clone(false);
          if (m_mergeMCParticles) {
            if (const auto index =
                    overlaid_particle_index(contrib.getParticle().getObjectID().index, offset, nBgParticles);
                index >= 0) {
              newContrib.setParticle(oparticles.at(index));
            }
          }
          newContrib.setTime(contrib.getTime() + timeOffset);
          return newContrib;
        };

        for (size_t i = 0; i < simCaloHits.size(); ++i) {
          const auto name = inputLocations(SIMCALOHIT_INDEX_POSITION)[i];
          debug() << "Processing collection " << name << endmsg;
          if (std::find(availableCollections.begin(), availableCollections.end(), name) == availableCollections.end()) {
            warning() << "Collection " << name << " not found in background event" << endmsg;
            continue;
          }
          const auto [this_start, this_stop] = define_time_windows(name);
          // There are only contributions to the readout if the hits are in the integration window
          if (this_stop <= (BX_number_in_train - physBX) * m_deltaT) {
            info() << "Skipping collection " << name << " as it is not in the integration window" << endmsg;
            continue;
          }

          auto& calHitMap = cellIDsMap[i];
          auto& calHitContribs = ocaloHitContribs[i];
          for (const auto&& simCaloHit : backgroundEvent.get<edm4hep::SimCalorimeterHitCollection>(name)) {
            if (calHitMap.find(simCaloHit.getCellID()) == calHitMap.end()) {
              // There is no hit at this position. The new hit can be added, if it is not outside the window
              auto calhit = edm4hep::MutableSimCalorimeterHit();
              bool add = false;
              for (const auto& contrib : simCaloHit.getContributions()) {
                if ((contrib.getTime() + timeOffset > this_start) && (contrib.getTime() + timeOffset < this_stop)) {
                  add = true;
                  // TODO: Make sure a contribution is not added twice
                  auto newContrib = cloneContribution(contrib);
                  calhit.addToContributions(newContrib);
                  calHitContribs.push_back(newContrib);
                }
              }
              if (add) {
                calhit.setCellID(simCaloHit.getCellID());
                calhit.setEnergy(simCaloHit.getEnergy());
                calhit.setPosition(simCaloHit.getPosition());
                calHitMap[calhit.getCellID()] = calhit;
              }
            } else {
              // there is already a hit at this position
              auto& calhit = calHitMap[simCaloHit.getCellID()];
              for (const auto& contrib : simCaloHit.getContributions()) {
                if ((contrib.getTime() + timeOffset > this_start) && (contrib.getTime() + timeOffset < this_stop)) {
                  // TODO: Make sure a contribution is not added twice
                  auto newContrib = cloneContribution(contrib);
                  calhit.addToContributions(newContrib);
                  calHitContribs.push_back(newContrib);
                }
              }
            }
          }
        }
      }
    }
  }
  // Move the SimCalorimeterHitCollections to the output vector
  // So far they are stored in a map with the cellID as key
  // but they don't belong to any collection yet
  for (const auto& [index, calHitMap] : cellIDsMap) {
    auto ocoll = edm4hep::SimCalorimeterHitCollection();
    for (const auto& [cellID, hit] : calHitMap) {
      ocoll.push_back(std::move(hit));
    }
    osimCaloHits.emplace_back(std::move(ocoll));
  }

  return std::make_tuple(std::move(oparticles), std::move(osimTrackerHits), std::move(osimCaloHits),
                         std::move(ocaloHitContribs));
}

DECLARE_COMPONENT(OverlayTiming)
