#
# Copyright (c) 2014-2024 Key4hep-Project.
#
# This file is part of Key4hep.
# See https://key4hep.github.io/key4hep-doc/ for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# This is an example reading from a file and using a consumer with several inputs
# to check that the contents of the file are the expected ones

from Gaudi.Configuration import INFO, DEBUG
from Configurables import CollectionMerger
from Configurables import EventDataSvc
from k4FWCore import ApplicationMgr, IOSvc

from Configurables import ExampleFunctionalProducer

svc = IOSvc("IOSvc")
svc.Input = "functional_producer_multiple.root"
svc.Output = "functional_merged_collections.root"
svc.outputCommands = [
    "drop *",
    "keep MCParticles1",
    "keep MCParticles2",
    "keep MCParticles3",
    "keep NewMCParticles",
    "keep SimTrackerHits",
    "keep Links",
    "keep NewLinks",
    "keep RecoParticles",
    "keep CopiedMCParticles",
    "keep CopiedLinks",
]


particle_producer = ExampleFunctionalProducer(
    OutputCollection="MCParticles3",
)


merger = CollectionMerger(
    "CollectionMerger",
    # List of collections to concatenate
    InputCollections=["MCParticles2", "MCParticles1", "MCParticles3"],
    # Name of the single output collection
    OutputCollection="NewMCParticles",
    OutputLevel=DEBUG,
)

link_merger = CollectionMerger(
    "LinkCollectionMerger",
    # List of collections to concatenate
    InputCollections=["Links", "Links"],
    # Name of the single output collection
    OutputCollection="NewLinks",
)

particle_copier = CollectionMerger(
    "ParticleCollectionCopier",
    InputCollections=["MCParticles2", "MCParticles1", "MCParticles3"],
    OutputCollection="CopiedMCParticles",
    Copy=True,
)

link_copier = CollectionMerger(
    "LinkCollectionCopier",
    InputCollections=["Links", "Links"],
    OutputCollection="CopiedLinks",
    Copy=True,
)

mgr = ApplicationMgr(
    TopAlg=[particle_producer, merger, link_merger, particle_copier, link_copier],
    EvtSel="NONE",
    EvtMax=-1,
    ExtSvc=[EventDataSvc("EventDataSvc")],
    OutputLevel=INFO,
)
