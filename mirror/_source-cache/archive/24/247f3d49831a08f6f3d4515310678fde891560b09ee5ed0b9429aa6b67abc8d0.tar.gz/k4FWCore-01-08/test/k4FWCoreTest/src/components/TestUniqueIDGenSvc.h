/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef TEST_UNIQUEIDGENSVC_H
#define TEST_UNIQUEIDGENSVC_H

#include <Gaudi/Accumulators.h>
#include <Gaudi/Algorithm.h>
#include <GaudiKernel/EventContext.h>
#include <GaudiKernel/ISvcLocator.h>
#include <GaudiKernel/SmartIF.h>
#include <GaudiKernel/StatusCode.h>

#include "k4Interface/IUniqueIDGenSvc.h"

#include <string>

class TestUniqueIDGenSvc : public Gaudi::Algorithm {
public:
  explicit TestUniqueIDGenSvc(const std::string&, ISvcLocator*);
  /**  Initialize.
   *   @return status code
   */
  StatusCode initialize() final;
  /**  Execute.
   *   @return status code
   */
  StatusCode execute(const EventContext&) const final;

private:
  SmartIF<IUniqueIDGenSvc> m_service;
  mutable Gaudi::Accumulators::Counter<> m_counter{this, "EventCounter"};
};

#endif // TEST_UNIQUEIDGENSVC_H
