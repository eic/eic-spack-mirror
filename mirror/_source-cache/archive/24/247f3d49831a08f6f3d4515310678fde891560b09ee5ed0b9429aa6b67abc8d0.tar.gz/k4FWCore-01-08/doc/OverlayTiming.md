<!--
Copyright (c) 2014-2024 Key4hep-Project.

This file is part of Key4hep.
See https://key4hep.github.io/key4hep-doc/ for further info.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# OverlayTiming

`OverlayTiming` is a Gaudi algorithm that overlays background events on top of signal events, typically used to simulate pile-up or beam-induced backgrounds. Background events are read from one or more sets of input files independently of the main event loop.

It uses [`UniqueIDGenSvc`](uniqueIDGen.md) to seed the internal random number generator.

## Collections

- `MCParticleCollection` from signal and background are merged into a single output collection. Background particles are flagged with `isOverlay = true`.
- `SimTrackerHit` collections are cropped to a configurable time window and overlaid. Background hits are flagged with `isOverlay = true`.
- `SimCalorimeterHit` collections are overlaid by merging hits that share the same cell ID. Their `CaloHitContribution` entries are filtered by the time window.

## Properties

| Property | Default | Description |
|----------|---------|-------------|
| `BackgroundFileNames` | `[]` | List of groups of background input files, one group per overlay stream. |
| `NumberBackground` | `[]` | Number of background events to overlay per stream (fixed or Poisson mean) |
| `Poisson_random_NOverlay` | `[]` | If true, draw the number of events from a Poisson distribution with mean `NumberBackground` |
| `NBunchtrain` | `1` | Number of bunch crossings in the bunch train |
| `PhysicsBX` | `1` | Position of the physics event within the bunch train |
| `RandomBx` | `false` | If true, place the physics event at a random bunch crossing (overrides `PhysicsBX`) |
| `Delta_t` | `0.5` | Time between consecutive bunch crossings (ns) |
| `TimeWindows` | `{}` | Map from collection name to `[t_min, t_max]` (ns) defining the acceptance window. Required for every `SimTrackerHit` and `SimCalorimeterHit` collection. |
| `BackgroundMCParticleCollectionName` | `"MCParticle"` | Name of the MCParticle collection in the background files |
| `AllowReusingBackgroundFiles` | `false` | If true, start over from the first event of a group once all of its events have been overlaid. If false, running out of background events is an error. With `RandomMixBackgroundFiles` the files of a group are drawn again once all of them have been used, regardless of this option |
| `RandomMixBackgroundFiles` | `false` | Treat every file of a background group as an independent (pseudo-)event source and draw one at random for each overlaid event |
| `MergeMCParticles` | `true` | Copy the background MCParticles into the output. If `false` they are left out entirely and background hits have no particle relation. The momentum stored in a background tracker hit, i.e. the momentum of the particle at the hit, is then replaced by the momentum of its originating particle at production, which would otherwise be lost. Calorimeter contributions are otherwise unchanged |
| `CopyCellIDMetadata` | `false` | Copy cell ID encoding metadata from input to output collections |
| `StartBackgroundEventIndex` | `-1` | Index of the background event every group starts reading from, once at the beginning of the job (`-1` means start from the beginning) |

## Random background mixing

Beam-induced background is often produced as a large number of files, each
holding a single pseudo-event. Reading such a group as one sequential stream
would walk the files in a fixed order, so a run that overlays fewer events than
there are files would only ever see the first few.

With `RandomMixBackgroundFiles = True` every file of a group is instead treated
as an independent event source, and one file is drawn for each overlaid event.
The draws come from a shuffled permutation of the group that is reshuffled once
exhausted, so files are used evenly rather than independently at random, and
each pass over the group is in a different order. Files are reused in this way
whatever `AllowReusingBackgroundFiles` is set to. The files of a group are
typically collected in the options file, for example:

```python
import glob

overlay.RandomMixBackgroundFiles = True
# Sorted, so that the order of the files, and with it the files that are drawn,
# does not depend on the file system
overlay.BackgroundFileNames = [sorted(glob.glob("/path/to/bib_files/*.root"))]
```

The files are drawn with the random number generator that is seeded for every
event through `UniqueIDGenSvc`, so the same `Seed` draws the same files for an
event with the same event and run numbers. The entries from each file are read
sequentially. Hence, the background overlay is only fully reproducible event by
event if there is exactly one pseudo-event in each file.

Background particles usually dominate the output size. If the background
`MCParticle` collection is not needed downstream, `MergeMCParticles = False`
leaves it out entirely. The property table above describes what this means for
the background hits.

## Usage example

The following example reads signal events from `signal.root` and overlays background events from two separate background files onto the `MCParticles`, `VertexBarrelCollection`, and `HCalRingCollection` collections. Two independent overlay streams are configured: one with a fixed number of overlaid events and one drawing from a Poisson distribution.

```python
from Gaudi.Configuration import INFO
from Configurables import EventDataSvc, OverlayTiming, UniqueIDGenSvc
from k4FWCore import ApplicationMgr, IOSvc

uid_svc = UniqueIDGenSvc("UniqueIDGenSvc")

iosvc = IOSvc("IOSvc")
iosvc.Input = "signal.root"
iosvc.Output = "signal_with_background.root"

overlay = OverlayTiming("OverlayTiming")
overlay.MCParticles = "MCParticles"
overlay.SimTrackerHits = ["VertexBarrelCollection"]
overlay.SimCalorimeterHits = ["HCalRingCollection"]
overlay.OutputMCParticles = "OverlayMCParticles"
overlay.OutputSimTrackerHits = ["OverlayVertexBarrelCollection"]
overlay.OutputSimCalorimeterHits = ["OverlayHCalRingCollection"]
overlay.OutputCaloHitContributions = ["OverlayCaloHitContributions"]
overlay.BackgroundMCParticleCollectionName = "MCParticles"
# Two independent streams of background events
overlay.BackgroundFileNames = [
    ["background_beam1.root", "background_beam2.root"],
    ["background_gamma.root"],
]
overlay.NumberBackground = [10, 1]
overlay.Poisson_random_NOverlay = [True, False]
overlay.NBunchtrain = 5
overlay.PhysicsBX = 1
overlay.Delta_t = 0.5  # ns
overlay.TimeWindows = {
    "VertexBarrelCollection": [-0.5, 5.0],
    "HCalRingCollection": [-5.0, 20.0],
}

ApplicationMgr(
    TopAlg=[overlay],
    EvtSel="NONE",
    EvtMax=100,
    ExtSvc=[EventDataSvc("EventDataSvc"), uid_svc],
    OutputLevel=INFO,
)
```
