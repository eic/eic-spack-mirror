// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Geometry/GeometryIdentifier.hpp"
#include "Acts/Geometry/Layer.hpp"
#include "Acts/Geometry/TrackingGeometry.hpp"
#include "Acts/Geometry/TrackingVolume.hpp"
#include "Acts/Navigation/INavigationPolicy.hpp"
#include "Acts/Navigation/NavigationStream.hpp"
#include "Acts/Propagator/NavigationTarget.hpp"
#include "Acts/Propagator/NavigatorInitializeArguments.hpp"
#include "Acts/Propagator/NavigatorOptions.hpp"
#include "Acts/Propagator/NavigatorStatistics.hpp"
#include "Acts/Surfaces/BoundaryTolerance.hpp"
#include "Acts/Surfaces/Surface.hpp"
#include "Acts/Utilities/Logger.hpp"
#include "Acts/Utilities/Result.hpp"

#include <limits>
#include <optional>
#include <string>

#include <boost/container/small_vector.hpp>

namespace Acts {

/// @brief The navigation options for the tracking geometry
///
/// @tparam object_t Type of the object for navigation to check against
template <typename object_t>
struct NavigationOptions final {
  /// The boundary check directive
  BoundaryTolerance boundaryTolerance = BoundaryTolerance::None();

  // How to resolve the geometry
  /// Always look for sensitive
  bool resolveSensitive = true;
  /// Always look for material
  bool resolveMaterial = true;
  /// always look for passive
  bool resolvePassive = false;

  /// Hint for start object
  const object_t* startObject = nullptr;
  /// Hint for end object
  const object_t* endObject = nullptr;

  /// Boundary tolerance to use instead of @c boundaryTolerance, for the
  /// surfaces named by their identifier
  std::vector<std::pair<GeometryIdentifier, BoundaryTolerance>>
      extendedSurfaces = {};

  /// The minimum distance for a surface to be considered
  double nearLimit = 0;
  /// The maximum distance for a surface to be considered
  double farLimit = std::numeric_limits<double>::max();
};

/// @brief Steers the propagation through the geometry by providing the next
/// surface to be targeted.
///
/// The Navigator is part of the propagation and responsible for steering
/// the surface sequence to encounter all the relevant surfaces which are
/// intersected by the trajectory.
///
/// The current navigation stage is cached in the state struct and updated
/// when necessary. If any surface in the extrapolation flow is hit, it is
/// set to the navigation state, such that other actors can deal with it.
///
/// The current target surface is referenced by an index which points into
/// the navigation candidates. The navigation candidates are ordered by the
/// path length to the surface. If a surface is hit, the
/// `state.currentSurface` pointer is set. This actors to observe
/// that we are on a surface.
///
class Navigator final {
 public:
  /// Type alias for navigation surface candidates container
  using NavigationSurfaces =
      boost::container::small_vector<NavigationTarget, 10>;

  /// Type alias for navigation layer candidates container
  using NavigationLayers = boost::container::small_vector<NavigationTarget, 10>;

  /// Type alias for navigation boundary candidates container
  using NavigationBoundaries =
      boost::container::small_vector<NavigationTarget, 4>;

  /// Type alias for geometry version enumeration
  using GeometryVersion = TrackingGeometry::GeometryVersion;

  /// The navigation stage
  enum struct Stage : int {
    initial = 0,
    surfaceTarget = 1,
    layerTarget = 2,
    boundaryTarget = 3,
  };

  /// The navigator configuration
  struct Config {
    /// Tracking Geometry for this Navigator
    std::shared_ptr<const TrackingGeometry> trackingGeometry{nullptr};

    /// stop at every sensitive surface (whether it has material or not)
    bool resolveSensitive = true;
    /// stop at every material surface (whether it is passive or not)
    bool resolveMaterial = true;
    /// stop at every surface regardless what it is
    bool resolvePassive = false;
    /// Number of candidates to reserve memory for in the navigation stream
    std::size_t candidatePreReserve = 50;
  };

  /// The navigator options
  struct Options : public NavigatorPlainOptions {
    /// Constructor with geometry context
    /// @param gctx The geometry context for the navigation
    explicit Options(const GeometryContext& gctx)
        : NavigatorPlainOptions(gctx) {}

    /// Set the plain navigation options
    /// @param options The plain navigator options to set
    void setPlainOptions(const NavigatorPlainOptions& options) {
      static_cast<NavigatorPlainOptions&>(*this) = options;
    }
  };

  /// @brief Nested State struct
  ///
  /// It acts as an internal state which is created for every propagation and
  /// meant to keep thread-local navigation information.
  struct State {
    /// Constructor with navigation options
    /// @param options_ The navigation options for this state
    explicit State(const Options& options_) : options(options_) {}

    /// Navigation options configuration
    Options options;

    /// Latest global geometric curvature supplied at a public navigation entry
    /// point. Forwarded to policy creation, validity, and candidate queries.
    Vector3 curvature = Vector3::Zero();

    /// Management of policy state allocation and deallocation
    NavigationPolicyStateManager policyStateManager;

    /// Whether the current volume's policy state carries no validity
    /// constraint. Sourced from INavigationPolicy::isStateless() (probed once
    /// at construction, fixed thereafter) and cached at each volume transition,
    /// so the per-step checks read this local bool instead of chasing the
    /// policy pointer or re-deriving defaultness from the type-erased state.
    bool policyStateIsDefault = true;

    // Navigation on surface level
    /// the vector of navigation surfaces to work through
    NavigationSurfaces navSurfaces = {};
    /// the current surface index of the navigation state
    std::optional<std::size_t> navSurfaceIndex;

    // Navigation on layer level
    /// the vector of navigation layers to work through
    NavigationLayers navLayers = {};
    /// the current layer index of the navigation state
    std::optional<std::size_t> navLayerIndex;

    // Navigation on volume level
    /// the vector of boundary surfaces to work through
    NavigationBoundaries navBoundaries = {};
    /// the current boundary index of the navigation state
    std::optional<std::size_t> navBoundaryIndex;

    /// far limit applied to the stream candidates, set during candidate
    /// resolution
    double navCandidatesFarLimit = std::numeric_limits<double>::max();

    /// An extended surface with its volume resolved
    struct ResolvedExtendedSurface {
      /// The surface
      const Surface* surface{};
      /// Tolerance used to intersect the surface
      BoundaryTolerance boundaryTolerance = BoundaryTolerance::Infinite();
      /// Volume that holds the surface. Null for Gen1, which scopes through
      /// the layer.
      const TrackingVolume* volume{};
    };

    /// Extended surfaces resolved once at initialization
    std::vector<ResolvedExtendedSurface> extendedSurfaces{};

    /// An additional surface of the options with its bookkeeping
    struct AdditionalSurfaceState {
      /// The entry of the options
      const AdditionalSurface* entry{};
      /// Whether the propagation reached the surface
      bool reached{false};
    };

    /// Additional surfaces of the options, tracked over the propagation
    std::vector<AdditionalSurfaceState> additionalSurfaces{};

    /// The staged candidate an additional surface took precedence over. It is
    /// handed out once the additional surface is no longer the closer one.
    std::optional<NavigationTarget> pendingTarget;

    /// Get reference to current navigation surface
    /// @return Reference to current navigation target
    NavigationTarget& navSurface() {
      return navSurfaces.at(navSurfaceIndex.value());
    }

    /// Get reference to current navigation layer
    /// @return Reference to current layer intersection
    NavigationTarget& navLayer() { return navLayers.at(navLayerIndex.value()); }

    /// Get reference to current navigation boundary
    /// @return Reference to current boundary intersection
    NavigationTarget& navBoundary() {
      return navBoundaries.at(navBoundaryIndex.value());
    }

    /// Get reference to current navigation candidate
    /// @return Reference to current boundary intersection
    NavigationTarget& navCandidate() { return stream.currentCandidate(); }

    /// Volume where the navigation started
    const TrackingVolume* startVolume = nullptr;
    /// Layer where the navigation started
    const Layer* startLayer = nullptr;
    /// Surface where the navigation started
    const Surface* startSurface = nullptr;
    /// Current volume during navigation
    const TrackingVolume* currentVolume = nullptr;
    /// Current layer during navigation
    const Layer* currentLayer = nullptr;
    /// Current surface during navigation
    const Surface* currentSurface = nullptr;
    /// Target surface for navigation
    const Surface* targetSurface = nullptr;

    /// Flag to break navigation loop
    bool navigationBreak = false;
    /// Current navigation stage in the state machine
    Stage navigationStage = Stage::initial;

    /// Statistics collection for navigation performance
    NavigatorStatistics statistics;

    /// Stream for navigation debugging and monitoring
    NavigationStream stream;

    /// Reset navigation state after switching layers
    void resetAfterLayerSwitch() {
      navSurfaces.clear();
      navSurfaceIndex.reset();
    }

    /// Reset navigation state after switching volumes
    void resetAfterVolumeSwitch() {
      resetAfterLayerSwitch();

      navLayers.clear();
      navLayerIndex.reset();
      navBoundaries.clear();
      navBoundaryIndex.reset();

      currentLayer = nullptr;

      policyStateManager.reset();
      policyStateIsDefault = true;

      stream.reset();
    }

    /// Reset navigation state for renavigating within the same navigation run
    ///
    /// @note Keeps the start and target information, which actors rely on for
    ///       the whole run.
    void resetForRenavigation() {
      resetAfterVolumeSwitch();

      currentVolume = nullptr;
      currentSurface = nullptr;

      navigationBreak = false;
      navigationStage = Stage::initial;
      pendingTarget.reset();
    }

    /// Completely reset navigation state for a new navigation run
    ///
    /// In contrast to @c resetForRenavigation this also drops the start and
    /// target information.
    void resetForInitialization() {
      resetForRenavigation();

      startVolume = nullptr;
      startLayer = nullptr;
      startSurface = nullptr;
      targetSurface = nullptr;
    }
  };

  /// Constructor with configuration object
  ///
  /// @param cfg The navigator configuration
  /// @param _logger a logger instance
  explicit Navigator(Config cfg,
                     std::shared_ptr<const Logger> _logger =
                         getDefaultLogger("Navigator", Logging::Level::INFO));

  /// Create a navigation state from options
  /// @param options The navigation options
  /// @return A new navigation state
  State makeState(const Options& options) const;

  /// Get the current surface from navigation state
  /// @param state The navigation state
  /// @return Pointer to current surface, or nullptr if none
  const Surface* currentSurface(const State& state) const;

  /// Get the current volume from navigation state
  /// @param state The navigation state
  /// @return Pointer to current volume, or nullptr if none
  const TrackingVolume* currentVolume(const State& state) const;

  /// Get material properties of the current volume
  /// @param state The navigation state
  /// @return Pointer to volume material, or nullptr if no volume or material
  const IVolumeMaterial* currentVolumeMaterial(const State& state) const;

  /// Get the starting surface from navigation state
  /// @param state The navigation state
  /// @return Pointer to start surface, or nullptr if none
  const Surface* startSurface(const State& state) const;

  /// Get the target surface from navigation state
  /// @param state The navigation state
  /// @return Pointer to target surface, or nullptr if none
  const Surface* targetSurface(const State& state) const;

  /// Check if navigation has reached the end of the world (no current volume)
  /// @param state The navigation state
  /// @return True if end of world is reached
  bool endOfWorldReached(const State& state) const;

  /// Check if navigation should be interrupted
  /// @param state The navigation state
  /// @return True if navigation break flag is set
  bool navigationBreak(const State& state) const;

  /// @brief Initialize the navigator state
  ///
  /// This function initializes the navigator state for a new propagation. All
  /// inputs specific to this run are passed here, so a state can be reused
  /// without carrying anything over.
  ///
  /// @param state The navigation state
  /// @param args The initialization arguments of this navigation run
  ///
  /// @return Indication if the initialization was successful
  [[nodiscard]] Result<void> initialize(
      State& state, const NavigatorInitializeArguments& args) const;

  /// @brief Get the next target surface
  ///
  /// This function gets the next target surface for the propagation.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  /// @param curvature Current global geometric curvature (inverse length)
  ///
  /// @return The next target surface
  NavigationTarget nextTarget(State& state, const Vector3& position,
                              const Vector3& direction,
                              const Vector3& curvature = Vector3::Zero()) const;

  /// @brief Check if the current target is still valid
  ///
  /// This function checks if the target is valid.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  /// @param curvature Current global geometric curvature (inverse length)
  ///
  /// @return True if the target is valid
  bool checkTargetValid(State& state, const Vector3& position,
                        const Vector3& direction,
                        const Vector3& curvature = Vector3::Zero()) const;

  /// @brief Handle the surface reached
  ///
  /// This function handles the surface reached.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  /// @param curvature Current global geometric curvature (inverse length)
  /// @param surface The surface reached
  void handleSurfaceReached(State& state, const Vector3& position,
                            const Vector3& direction, const Surface& surface,
                            const Vector3& curvature = Vector3::Zero()) const;

 private:
  /// @brief Resolve the extended surfaces of the options
  ///
  /// Throws if the tracking geometry does not hold a surface.
  ///
  /// @param state The navigation state
  void resolveExtendedSurfaces(State& state) const;

  /// @brief Get the next target of the staged navigation, without the
  ///        additional surfaces
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  /// @return The next staged target
  NavigationTarget nextStagedTarget(State& state, const Vector3& position,
                                    const Vector3& direction) const;

  /// @brief Get the closest additional surface from the current position
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  /// @return The closest additional surface, or none
  NavigationTarget nextAdditionalTarget(const State& state,
                                        const Vector3& position,
                                        const Vector3& direction) const;

  /// @brief Whether the staged navigation targets the given surface
  ///
  /// Tells a surface reached through the tracking geometry apart from one
  /// reached as an additional surface.
  ///
  /// @param state The navigation state
  /// @param surface The surface the propagation reached
  /// @return True if the current staged target is that surface
  bool stagedTargetIs(const State& state, const Surface& surface) const;

  /// @brief NextTarget helper function for Gen1 geometry configuration
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  NavigationTarget getNextTargetGen1(State& state, const Vector3& position,
                                     const Vector3& direction) const;

  /// @brief NextTarget helper function for Gen3 geometry configuration
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  NavigationTarget getNextTargetGen3(State& state, const Vector3& position,
                                     const Vector3& direction) const;

  /// @brief NextTarget helper function
  /// This function is called for returning the next target
  /// and checks gen1/gen3 case in order to sub-call the proper functions
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  NavigationTarget tryGetNextTarget(State& state, const Vector3& position,
                                    const Vector3& direction) const;

  /// @brief Resolve compatible candidates (surfaces or portals) for gen3
  /// navigation
  ///
  /// This function is called when gen3 configuration is found and it resolves
  /// at the same time for portals and surfaces
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  void resolveCandidates(State& state, const Vector3& position,
                         const Vector3& direction) const;

  /// @brief Create the navigation policy state for the given volume
  ///
  /// Volumes whose navigation policy is known to push only default states
  /// (probed at geometry construction) skip the state creation entirely; the
  /// matching popState on volume exit is skipped under the same condition.
  /// The caller must ensure the volume has a navigation policy.
  ///
  /// @param state The navigation state
  /// @param volume The volume to create the policy state for
  /// @param position The current position
  /// @param direction The current direction
  void createPolicyState(State& state, const TrackingVolume& volume,
                         const Vector3& position,
                         const Vector3& direction) const;

  /// @brief Resolve compatible surfaces
  ///
  /// This function resolves the compatible surfaces for the navigation.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  void resolveSurfaces(State& state, const Vector3& position,
                       const Vector3& direction) const;

  /// @brief Resolve compatible layers
  ///
  /// This function resolves the compatible layers for the navigation.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  void resolveLayers(State& state, const Vector3& position,
                     const Vector3& direction) const;

  /// @brief Resolve compatible boundaries
  ///
  /// This function resolves the compatible boundaries for the navigation.
  ///
  /// @param state The navigation state
  /// @param position The current position
  /// @param direction The current direction
  void resolveBoundaries(State& state, const Vector3& position,
                         const Vector3& direction) const;

  /// @brief Check if the navigator is inactive
  ///
  /// This function checks if the navigator is inactive.
  ///
  /// @param state The navigation state
  ///
  /// @return True if the navigator is inactive
  bool inactive(const State& state) const;

  /// @brief Get volume info string for logging
  ///
  /// @tparam propagator_state_t The propagator state type
  /// @param state The state containing current volume info
  /// @return String with volume name for logging
  std::string volInfo(const State& state) const;

  /// @brief Get volume info string for logging
  ///
  /// Used where the volume is not reflected in the navigation state yet.
  ///
  /// @param volume The volume to report on, may be nullptr
  /// @return String with volume name for logging
  std::string volInfo(const TrackingVolume* volume) const;

  const Logger& logger() const { return *m_logger; }

  Config m_cfg;

  // Cached so we don't have to query the TrackingGeometry constantly.
  TrackingGeometry::GeometryVersion m_geometryVersion{};

  std::shared_ptr<const Logger> m_logger;
};

}  // namespace Acts
