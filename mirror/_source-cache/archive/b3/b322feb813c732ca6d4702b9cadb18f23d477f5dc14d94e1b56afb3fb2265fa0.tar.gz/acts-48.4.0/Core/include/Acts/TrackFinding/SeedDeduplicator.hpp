// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include <cassert>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <vector>

namespace Acts {

/// @brief Flags seeds whose measurements one accepted track already holds
///
/// Measurements are dense keys in `[0, nMeasKeys)`. The caller chooses which
/// keys a seed contributes. The keys are plain indices and not `SourceLink`s,
/// because a `SourceLink` has no hash and no equality comparison.
///
/// Each key has a weight, 1 by default. The weight can for example be the
/// number of measured local coordinates, so that a pixel measurement counts 2
/// and a strip measurement counts 1. A seed with the summed weight `seedScore`
/// is a duplicate if one track holds keys of the summed weight
///
///   `min(seedScore, max(1, minScore, seedScore - maxMissingScore))`.
///
/// The scores of different tracks do not add up. Seeds can be queried in any
/// order.
class SeedDeduplicator {
 public:
  /// Type of the dense measurement key
  using MeasurementKey = std::uint32_t;
  /// Type of the weight of a key
  using Weight = std::uint8_t;
  /// Type of a summed weight
  using Score = std::uint32_t;

  /// Configuration of the duplicate threshold
  ///
  /// The default requires every key. A cut on `minScore` alone needs
  /// `maxMissingScore` at its maximum.
  struct Config {
    /// Minimum shared score that makes a seed a duplicate
    Score minScore = 0;
    /// Maximum score of the seed that the track may miss
    Score maxMissingScore = 0;
  };

  /// Constructor
  /// @param config The threshold configuration
  explicit SeedDeduplicator(const Config& config);

  /// Remove all tracks and set the key range. Every weight becomes 1.
  /// @param nMeasKeys The number of measurement keys, every key must be below
  ///                  this number
  void reset(std::size_t nMeasKeys);

  /// @return The number of accepted tracks
  std::size_t nTracks() const { return m_nTracks; }

  /// Set the weight of a key
  /// @param measKey The measurement key
  /// @param weight The weight of the key
  void setWeight(MeasurementKey measKey, Weight weight) {
    assert(measKey < m_weights.size() && "Key out of range");
    m_weights[measKey] = weight;
  }

  /// @param measKey The measurement key
  /// @return The weight of the key
  Weight weight(MeasurementKey measKey) const {
    assert(measKey < m_weights.size() && "Key out of range");
    return m_weights[measKey];
  }

  /// Accept a track
  /// @param measKeys The keys of the measurements on the track
  void addTrack(std::span<const MeasurementKey> measKeys);

  /// Check if one accepted track holds enough of the seed keys
  /// @param measKeys The keys of the seed, each key at most once
  /// @return True if the seed is a duplicate
  bool isDuplicate(std::span<const MeasurementKey> measKeys) const;

 private:
  static constexpr std::uint32_t kNone =
      std::numeric_limits<std::uint32_t>::max();
  /// Number of tracks per seed query that need no heap allocation. This value
  /// is not tuned. A query with more tracks moves the list to the heap and
  /// gives the same result.
  static constexpr std::size_t kInlineTracks = 8;

  /// @param seedScore The summed weight of the seed keys
  /// @return The score that one track must share with the seed to make the
  ///         seed a duplicate
  Score duplicateThreshold(Score seedScore) const;

  /// One accepted track on one key
  struct Node {
    /// The index of the track
    std::uint32_t track;
    /// The next node of the same key, or `kNone`
    std::uint32_t next;
  };

  Config m_cfg;

  /// The latest node for each key, or `kNone`
  std::vector<std::uint32_t> m_trackHeads;
  std::vector<Weight> m_weights;
  std::vector<Node> m_nodes;
  std::size_t m_nTracks = 0;
};

}  // namespace Acts
