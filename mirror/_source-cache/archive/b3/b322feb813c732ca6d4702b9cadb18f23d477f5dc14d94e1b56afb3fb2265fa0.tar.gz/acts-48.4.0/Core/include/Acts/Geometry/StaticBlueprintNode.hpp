// This file is part of the ACTS project.
//
// Copyright (C) 2016 CERN for the benefit of the ACTS project
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

#pragma once

#include "Acts/Geometry/BlueprintNode.hpp"
#include "Acts/Geometry/GeometryContext.hpp"
#include "Acts/Geometry/IVolumeLookup.hpp"
#include "Acts/Geometry/PortalShell.hpp"
#include "Acts/Geometry/TrackingVolume.hpp"

namespace Acts {

/// The static blueprint node wraps a single already-constructred @c TrackingVolume.
/// The node will present this volume to its hierarchy. The volume is given as
/// mutable, and will be potentially enlarged in order to connect to neighboring
/// volumes.
/// - In case the volume already has child volumes, they will be retained.
/// - In case the volume already has a registered navigation policy, it will be
///   overwritten with the one configured on this node, regardless of content.
class StaticBlueprintNode : public BlueprintNode {
 public:
  /// Construct the static node from an existing volume
  /// @param volume The volume to wrap
  explicit StaticBlueprintNode(std::unique_ptr<TrackingVolume> volume);

  /// Get the name of this node. It is automatically taken from the wrapped
  /// volume
  /// @return The name of the volume
  const std::string& name() const override;

  /// @copydoc BlueprintNode::build
  /// Build-phase of the blueprint construction. Returns the wrapped volume for
  /// sizing.
  Volume& build(const BlueprintOptions& options, const GeometryContext& gctx,
                const Logger& logger = Acts::getDummyLogger()) override;

  /// @copydoc BlueprintNode::connect
  PortalShellBase& connect(
      const BlueprintOptions& options, const GeometryContext& gctx,
      const Logger& logger = Acts::getDummyLogger()) override;

  /// @copydoc BlueprintNode::finalize
  void finalize(const BlueprintOptions& options, const GeometryContext& gctx,
                TrackingVolume& parent,
                const Logger& logger = Acts::getDummyLogger()) override;

  /// Set the navigation policy factory for this node
  /// @param navigationPolicyFactory Shared pointer to navigation policy factory
  /// @return Reference to this node for chaining
  virtual StaticBlueprintNode& setNavigationPolicyFactory(
      std::shared_ptr<NavigationPolicyFactory> navigationPolicyFactory);

  /// Get the navigation policy factory for this node
  /// @return Pointer to the navigation policy factory (may be nullptr)
  const NavigationPolicyFactory* navigationPolicyFactory() const;

  /// Set the lookup factory for the wrapped volume only.
  /// An empty factory leaves the volume's lookup unchanged. Descendant policies
  /// are installed first, so subtree indices can stop at explicit overrides.
  /// @param factory Factory returning a non-null lookup
  /// @return This node for chaining
  StaticBlueprintNode& setVolumeLookupFactory(VolumeLookupFactory factory);

  /// Return the optional lookup factory.
  /// @return Configured factory, which may be empty
  const VolumeLookupFactory& volumeLookupFactory() const;

 protected:
  void addToGraphviz(std::ostream& os) const override;

  /// Optional factory for the lookup installed after descendant finalization.
  VolumeLookupFactory m_volumeLookupFactory;

  /// The wrapped tracking volume managed by this blueprint node
  std::unique_ptr<TrackingVolume> m_volume;

  /// Portal shell representation for geometry connection
  std::unique_ptr<PortalShellBase> m_shell;

  /// Factory for creating navigation policies for this volume
  std::shared_ptr<NavigationPolicyFactory> m_navigationPolicyFactory;
};

namespace Experimental {
/// @deprecated The blueprint geometry moved out of the `Acts::Experimental`
///             namespace. Use @ref Acts::StaticBlueprintNode instead. This
///             alias is kept for backward compatibility and will be removed.
using StaticBlueprintNode
    [[deprecated("Acts::Experimental::StaticBlueprintNode moved to "
                 "Acts::StaticBlueprintNode")]] = Acts::StaticBlueprintNode;
}  // namespace Experimental

}  // namespace Acts
