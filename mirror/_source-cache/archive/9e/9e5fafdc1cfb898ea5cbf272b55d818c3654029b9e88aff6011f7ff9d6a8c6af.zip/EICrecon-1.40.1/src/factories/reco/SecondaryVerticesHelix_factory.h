// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright (C) 2025 Xin Dong

#pragma once

#include <JANA/JEvent.h>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "algorithms/reco/SecondaryVerticesHelix.h"
#include "algorithms/reco/SecondaryVerticesHelixConfig.h"
#include "services/algorithms_init/AlgorithmsInit_service.h"
#include "extensions/jana/JOmniFactory.h"

namespace eicrecon {

class SecondaryVerticesHelix_factory
    : public JOmniFactory<SecondaryVerticesHelix_factory, SecondaryVerticesHelixConfig> {

public:
  using AlgoT = eicrecon::SecondaryVerticesHelix;

private:
  std::unique_ptr<AlgoT> m_algo;

  PodioInput<edm4eic::Vertex> m_rc_vertices_input{this};
  PodioInput<edm4eic::ReconstructedParticle> m_rc_parts_input{this};

  // Declare outputs
  PodioOutput<edm4eic::Vertex> m_secondary_vertices_output{this};

  // Declare parameters
  ParameterRef<bool> m_unlikesign{this, "unlikesign", config().unlikesign};
  ParameterRef<float> m_minDca{this, "minDca", config().minDca};
  ParameterRef<float> m_maxDca12{this, "maxDca12", config().maxDca12};
  ParameterRef<float> m_maxDca{this, "maxDca", config().maxDca};
  ParameterRef<float> m_minCostheta{this, "minCostheta", config().minCostheta};

  Service<AlgorithmsInit_service> m_algorithmsInit{this};

public:
  void Configure() {
    m_algo = std::make_unique<AlgoT>(GetPrefix());
    m_algo->level((algorithms::LogLevel)logger()->level());

    m_algo->applyConfig(config());
    m_algo->init();
  }

  void Process(int32_t /* run_number */, uint64_t /* event_number */) {
    m_algo->process({m_rc_vertices_input(), m_rc_parts_input()},
                    {m_secondary_vertices_output().get()});
  }
};

} // namespace eicrecon
