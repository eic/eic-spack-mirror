// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright (C) 2025 Dongwi H. Dongwi (Bishoy)

#pragma once

#include <Acts/Definitions/Units.hpp>

using namespace Acts::UnitLiterals;

namespace eicrecon {

struct SecondaryVertexFinderConfig {
  // If true, run in primary vertex mode (all tracks at once).
  // If false, run in secondary vertex mode (pairwise track combinations).
  bool isPrimary = true;

  unsigned int maxVertices   = 20;
  unsigned int maxIterations = 500;
  // Max z interval used for adding tracks to fit: when adding a new vertex to
  // the multi vertex fit, only the tracks whose z at PCA is closer to the
  // seeded vertex than tracksMaxZinterval are added to this new vertex
  float tracksMaxZinterval = 3_mm;

  // Max chi2 value for which tracks are considered compatible with
  // the fitted vertex. These tracks are removed from the seedTracks
  // after the fit has been performed.
  double maxVertexChi2 = 18.42;
  bool doFullSplitting = false;
  // 5 corresponds to a p-value of ~0.92 using `chi2(x=5,ndf=2)`
  float tracksMaxSignificance      = 6.7;
  float maxMergeVertexSignificance = 3;
  float minWeight                  = 1e-04;
  float maxDistToLinPoint          = 5.5_mm;
  // Bin extent in z-direction
  float spatialBinExtent         = 25_um;
  Acts::Vector4 initialVariances = Acts::Vector4{1e+2_mm, 1e+2_mm, 1e+2_mm, 1e+8_mm};
  // Bin extent in t-direction
  float temporalBinExtent          = 19_mm;
  bool doSmoothing                 = true;
  bool reassignTracksAfterFirstFit = true;
  bool useTime                     = false;
  // Use seed vertex as a constraint for the fit
  bool useSeedConstraint = false;
};

} // namespace eicrecon
