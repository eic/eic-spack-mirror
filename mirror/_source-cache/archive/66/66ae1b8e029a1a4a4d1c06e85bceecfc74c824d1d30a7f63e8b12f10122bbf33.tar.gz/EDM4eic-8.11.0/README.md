EDM4eic - EIC data model
========================

A data model for EIC defined with [podio](https://github.com/AIDASoft/podio) and based on [EDM4hep](https://github.com/key4hep/EDM4hep).

![](docs/EDM4eic_v8100_diagramWithNoAssociations_parPIDLinkToSameSpot.svg)

## Full Description File

The entire data model is defined with a single YAML file, `edm4eic.yml`.

\verbinclude edm4eic.yaml

## Installing

To install the data model into `~/local`, use the following commands:
```console
git clone https://github.com/eic/edm4eic
cd edm4eic
cmake -S . -B build -DCMAKE_INSTALL_PREFIX=~/local
cmake --build build
cmake --install build
```

