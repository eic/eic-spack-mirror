
#include "JANA/Components/JOmniFactory.h"
#include "JANA/Components/JWiredFactoryGeneratorT.h"
#include "JANA/JEventProcessor.h"
#include "JANA/JException.h"
#include "JANA/Utils/JEventLevel.h"
#include <JANA/Services/JWiringService.h>
#include <catch.hpp>
#include <memory>
#include <toml.hpp>
#include <iostream>


static constexpr std::string_view some_wiring = R"(
    include = ["asdf.toml"]

    [[wiring]]
    action = "add"
    plugin_name = "BCAL"
    type_name = "MyFac"
    prefix = "myfac"
    input_names = ["input_coll_1", "input_coll_2"]
    input_levels = ["Run", "Subrun"]
    output_names = ["output_coll_1", "output_coll_2"]

        [wiring.configs]
        x = "22"
        y = "verbose"

    [[wiring]]
    action = "add"
    plugin_name = "BCAL"
    type_name = "MyFac"
    prefix = "myfac_modified"
    input_names = ["input_coll_1", "input_coll_3"]
    output_names = ["output_coll_1_modified", "output_coll_2_modified"]

        [wiring.configs]
        x = "100"
        y = "verbose"

)";

TEST_CASE("WiringTests") {

    jana::services::JWiringService sut;
    toml::table table = toml::parse(some_wiring);
    sut.ApplyWiringSet(sut.ParseWiringSet(table));

    const auto& wirings = sut.GetAllWirings();
    REQUIRE(wirings.size() == 2);
    auto& w0 = wirings.at("myfac");
    auto& w1 = wirings.at("myfac_modified");

    REQUIRE(w0->prefix == "myfac");
    REQUIRE(w1->prefix == "myfac_modified");
    REQUIRE(w0->plugin_name == "BCAL");
    REQUIRE(w0->input_names[1] == "input_coll_2");
    REQUIRE(w1->input_names[1] == "input_coll_3");
    REQUIRE(w0->input_levels.size() == 2);
    REQUIRE(w0->input_levels[0] == JEventLevel::Run);
    REQUIRE(w0->input_levels[1] == JEventLevel::Subrun);
    REQUIRE(w1->input_levels.size() == 0);
    REQUIRE(w0->configs.size() == 2);
    REQUIRE(w0->configs["x"] == "22");
    REQUIRE(w0->configs["y"] == "verbose");

}

static constexpr std::string_view duplicate_prefixes = R"(
    [[wiring]]
    action = "add"
    plugin_name = "BCAL"
    type_name = "MyFac"
    prefix = "myfac"

    [[wiring]]
    action = "add"
    plugin_name = "BCAL"
    type_name = "MyFac"
    prefix = "myfac"
)";

TEST_CASE("WiringTests_DuplicatePrefixes") {

    jana::services::JWiringService sut;
    toml::table table = toml::parse(duplicate_prefixes);
    try {
        sut.ApplyWiringSet(sut.ParseWiringSet(table));
        REQUIRE(1 == 0);
    }
    catch (const JException& e) {
        std::cout << e << std::endl;
    }
}

TEST_CASE("WiringTests_Overlay") {
    using Wiring = jana::services::JWiringService::Wiring;
    auto above = std::make_unique<Wiring>();
    above->prefix = "myfac";
    above->type_name = "ClusteringFac";
    above->plugin_name = "FCAL";
    above->input_names = {"this", "should", "make", "it"};
    above->configs["x"] = "6.18";

    auto below = std::make_unique<Wiring>();
    below->prefix = "myfac";
    below->type_name = "ClusteringFac";
    below->plugin_name = "FCAL";
    below->input_names = {"this", "should", "NOT", "make", "it"};
    below->input_levels = {JEventLevel::Run, JEventLevel::PhysicsEvent};
    below->configs["x"] = "7.6";
    below->configs["y"] = "42";

    auto sut = jana::services::JWiringService();
    sut.Overlay(*above, *below);
    REQUIRE(above->input_names[2] == "make");
    REQUIRE(above->input_levels[1] == JEventLevel::PhysicsEvent);
    REQUIRE(above->configs["x"] == "6.18");
    REQUIRE(above->configs["y"] == "42");
}

static constexpr std::string_view fake_wiring_file = R"(
    [[wiring]]
    action = "add"
    plugin_name = "ECAL"
    type_name = "ClusteringFac"
    prefix = "myfac"

        [wiring.configs]
        x = "22"
        y = "verbose"

    [[wiring]]
    action = "update"
    plugin_name = "ECAL"
    type_name = "ClusteringFac"
    prefix = "variantfac"

        [wiring.configs]
        x = "49"
        y = "silent"

    [[wiring]]
    action = "add"
    plugin_name = "BCAL"
    type_name = "ClusteringFac"
    prefix = "sillyfac"

        [wiring.configs]
        x = "618"
        y = "mediocre"
)";


TEST_CASE("WiringTests_FakeFacGen") {
    jana::services::JWiringService sut;
    toml::table table = toml::parse(fake_wiring_file);
    auto wiring_set_file = sut.ParseWiringSet(table);

    using Wiring = jana::services::JWiringService::Wiring;
    using WiringSet = jana::services::JWiringService::WiringSet;
    WiringSet wiring_set_facgen;

    // One gets overlaid with an existing wiring
    auto a = std::make_unique<Wiring>();
    a->plugin_name = "ECAL";
    a->type_name = "ClusteringFac";
    a->prefix = "variantfac";
    a->configs["x"] = "42";
    wiring_set_facgen.wirings["variantfac"] = std::move(a);

    // The other is brand new
    auto b = std::make_unique<Wiring>();
    b->plugin_name = "ECAL";
    b->type_name = "ClusteringFac";
    b->prefix = "exuberantfac";
    b->configs["x"] = "27";
    wiring_set_facgen.wirings["exuberantfac"] = std::move(b);

    sut.OverlayWiringSet(wiring_set_file, wiring_set_facgen);
    sut.ApplyWiringSet(std::move(wiring_set_file));

    auto myfac = sut.GetWiring("myfac");
    auto variantfac = sut.GetWiring("variantfac");
    auto exuberantfac = sut.GetWiring("exuberantfac");

    REQUIRE(myfac != nullptr);
    REQUIRE(variantfac != nullptr);
    REQUIRE(exuberantfac != nullptr);

    REQUIRE(myfac->configs["x"] == "22"); // from file only
    REQUIRE(variantfac->configs["x"] == "49"); // file overrides facgen
    REQUIRE(exuberantfac->configs["x"] == "27"); // from facgen only
}

struct Cluster { double x,y,E; };

struct WiredOmniFac : jana::components::JOmniFactory<WiredOmniFac> {
    Input<Cluster> m_protoclusters_in {this};
    Output<Cluster> m_clusters_out {this};

    Parameter<int> m_x {this, "x", 1, "x"};
    Parameter<std::string> m_y {this, "y", "silent", "y" };

    void Configure() {
    }

    void ChangeRun(int32_t /*run_nr*/) {
    }

    void Execute(int32_t /*run_nr*/, uint64_t /*evt_nr*/) {

        for (auto protocluster : *m_protoclusters_in) {
            m_clusters_out().push_back(new Cluster {protocluster->x, protocluster->y, protocluster->E + 1});
        }
    }
};

static constexpr std::string_view realfacgen_wiring = R"(
    [[wiring]]
    action = "add"
    type_name = "WiredOmniFac"
    prefix = "myfac"
    input_names = ["usual_input"]
    output_names = ["usual_output"]

        [wiring.configs]
        x = "22"
        y = "verbose"

    [[wiring]]
    action = "add"
    type_name = "WiredOmniFac"
    prefix = "myfac_modified"
    input_names = ["different_input"]
    output_names = ["different_output"]

        [wiring.configs]
        x = "100"
        y = "silent"

)";

TEST_CASE("WiringTests_RealFacGen") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(realfacgen_wiring);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto gen = new jana::components::JWiredFactoryGeneratorT<WiredOmniFac>;
    app.Add(gen);
    app.Initialize();

    auto& summary = app.GetComponentSummary();
    jout << summary;
    auto vf = summary.FindComponents("myfac");
    REQUIRE(vf.size() == 1);
    REQUIRE(vf.at(0)->GetOutputs().at(0)->GetName() == "usual_output");

    auto ef = summary.FindComponents("myfac_modified");
    REQUIRE(ef.size() == 1);
    REQUIRE(ef.at(0)->GetOutputs().at(0)->GetName() == "different_output");

    // Check that parameter values propagated from wiring file to parameter manager
    REQUIRE(app.GetParameterValue<int>("myfac:x") == 22);
    REQUIRE(app.GetParameterValue<std::string>("myfac:y") == "verbose");
    REQUIRE(app.GetParameterValue<int>("myfac_modified:x") == 100);
    REQUIRE(app.GetParameterValue<std::string>("myfac_modified:y") == "silent");

    //app.GetJParameterManager()->PrintParameters(2, 0);
    //auto event = std::make_shared<JEvent>(&app);
    //auto facs = event->GetFactorySet()->GetAllMultifactories();

}

struct WiredOmniFacConfig {
    int shared = 0;
    int isolated = 2;
};

struct WiredOmniFacWithShared : jana::components::JOmniFactory<WiredOmniFacWithShared, WiredOmniFacConfig> {
    Input<Cluster> m_protoclusters_in {this};
    Output<Cluster> m_clusters_out {this};

    ParameterRef<int> m_shared {this, "shared", config().shared, "shared", true};
    ParameterRef<int> m_isolated {this, "isolated", config().isolated, "isolated" };

    void Configure() {
    }

    void ChangeRun(int32_t /*run_nr*/) {
    }

    void Execute(int32_t /*run_nr*/, uint64_t /*evt_nr*/) {

        for (auto protocluster : *m_protoclusters_in) {
            m_clusters_out().push_back(new Cluster {protocluster->x, protocluster->y, protocluster->E + 1});
        }
    }
};

static constexpr std::string_view sharedparam_wiring = R"(
    [configs]
    shared = "28"

    [[wiring]]
    action = "add"
    type_name = "WiredOmniFacWithShared"
    prefix = "myfac"
    input_names = ["usual_input"]
    output_names = ["usual_output"]

        [wiring.configs]
        isolated = "22"

    [[wiring]]
    action = "add"
    type_name = "WiredOmniFacWithShared"
    prefix = "myfac_modified"
    input_names = ["different_input"]
    output_names = ["different_output"]

        [wiring.configs]
        isolated = "100"
)";

TEST_CASE("WiringTests_SharedParam") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(sharedparam_wiring);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto gen = new jana::components::JWiredFactoryGeneratorT<WiredOmniFacWithShared>;
    app.Add(gen);
    app.Initialize();

    auto& summary = app.GetComponentSummary();
    //jout << summary;
    auto vf = summary.FindComponents("myfac");
    REQUIRE(vf.size() == 1);
    REQUIRE(vf.at(0)->GetOutputs().at(0)->GetName() == "usual_output");

    auto ef = summary.FindComponents("myfac_modified");
    REQUIRE(ef.size() == 1);
    REQUIRE(ef.at(0)->GetOutputs().at(0)->GetName() == "different_output");

    // Check that parameter values propagated from wiring file to parameter manager
    REQUIRE(app.GetParameterValue<int>("shared") == 28);
    REQUIRE(app.GetParameterValue<int>("myfac:isolated") == 22);
    REQUIRE(app.GetParameterValue<int>("myfac_modified:isolated") == 100);

    //app.GetJParameterManager()->PrintParameters(2, 0);
    //auto event = std::make_shared<JEvent>(&app);
    //auto facs = event->GetFactorySet()->GetAllMultifactories();

}


class WiredEvtProc : public JEventProcessor {

    Parameter<int> m_x {this, "x", 22};
    Input<Cluster> m_cluster_in {this};
    //Input<Cluster> m_different_cluster_in {this};
    //VariadicInput<Cluster> m_even_more_in {this};

public:

    WiredEvtProc() {
        SetTypeName("WiredEvtProc");
        SetPrefix("myproc");
        SetCallbackStyle(CallbackStyle::ExpertMode);
    }

    void Init() override {
        REQUIRE(*m_x == 99); // Set by wiring file
    }

    void ProcessSequential(const JEvent&) override {

        // Set by wiring file
        REQUIRE(GetPrefix() == "myproc");
        REQUIRE(m_cluster_in.GetDatabundleName() == "myclusters");

        // Data is reachable
        REQUIRE(m_cluster_in->size() == 1); 
    }
};

static constexpr std::string_view evtproc_wiring = R"(
    [[wiring]]
    action = "update"
    type_name = "WiredEvtProc"
    prefix = "myproc"
    input_names = ["myclusters"]

        [wiring.configs]
        x = "99"
)";

TEST_CASE("WiringTests_Proc") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(evtproc_wiring);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto proc = new WiredEvtProc;
    app.Add(proc);

    app.Initialize();
    auto event = std::make_shared<JEvent>(&app);
    std::vector<Cluster*> test_data;
    test_data.push_back(new Cluster{0, 0, 22.2});
    event->Insert<Cluster>(test_data, "myclusters");

    proc->DoInit();
    proc->DoMap(*event);
    proc->DoTap(*event);
}


struct WiredFac : public JFactory {
    Input<Cluster> m_protoclusters_in {this};
    Output<Cluster> m_clusters_out {this};

    Parameter<int> m_x {this, "x", 1, "x"};

    WiredFac() {
        SetPrefix("wiredfac");
        m_protoclusters_in.SetDatabundleName("default_protos");
        m_clusters_out.SetUniqueName("default_clusters");
    }
    void Process(const JEvent&) {
        for (auto protocluster : *m_protoclusters_in) {
            m_clusters_out().push_back(new Cluster {protocluster->x, protocluster->y, protocluster->E + *m_x});
        }
    }
};

static constexpr std::string_view facgen_wiring = R"(
    [[wiring]]
    action = "update"
    type_name = "WiredFac"
    prefix = "wiredfac"
    input_names = ["usual_input"]
    output_names = ["usual_output"]

        [wiring.configs]
        x = "22"
)";

TEST_CASE("WiringTests_FacGen") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(facgen_wiring);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto gen = new JFactoryGeneratorT<WiredFac>;
    app.Add(gen);
    app.Initialize();

    auto& summary = app.GetComponentSummary();
    jout << summary;
    auto vf = summary.FindComponents("wiredfac");
    REQUIRE(vf.size() == 1);
    REQUIRE(vf.at(0)->GetOutputs().at(0)->GetName() == "usual_output");

    REQUIRE(app.GetParameterValue<int>("wiredfac:x") == 22);

    auto event = std::make_shared<JEvent>(&app);
    std::vector<Cluster*> test_data;
    test_data.push_back(new Cluster{0, 0, 22.2});
    event->Insert<Cluster>(test_data, "usual_input");

    auto results = event->Get<Cluster>("usual_output");
    REQUIRE(results.size() == 1);
    REQUIRE(results.at(0)->E == 44.2);

}


static constexpr std::string_view facgen_shortnames_true = R"(
    use_short_names = true

    [[wiring]]
    action = "update"
    type_name = "WiredFac"
    prefix = "wiredfac"
    input_names = ["usual_input"]
    output_names = ["usual_output"]

        [wiring.configs]
        x = "22"
)";

TEST_CASE("WiringTests_FacGenShortnames") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(facgen_shortnames_true);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    REQUIRE(wiring_svc->AreShortNamesUsed() == true);

    auto gen = new JFactoryGeneratorT<WiredFac>;
    app.Add(gen);
    app.Initialize();

    auto event = std::make_shared<JEvent>(&app);
    std::vector<Cluster*> test_data;
    test_data.push_back(new Cluster{0, 0, 22.2});
    event->Insert<Cluster>(test_data, "usual_input");

    auto results = event->Get<Cluster>("usual_output");
    REQUIRE(results.size() == 1);
    REQUIRE(results.at(0)->E == 44.2);

}


static constexpr std::string_view facgen_partial_input_names_only = R"(
    [[wiring]]
    action = "update"
    type_name = "WiredFac"
    prefix = "wiredfac"
    input_names = ["overridden_input"]
)";

TEST_CASE("WiringTests_Partial_InputNamesOnly") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(facgen_partial_input_names_only);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto gen = new JFactoryGeneratorT<WiredFac>;
    app.Add(gen);
    app.Initialize();

    auto event = std::make_shared<JEvent>(&app);
    std::vector<Cluster*> test_data;
    test_data.push_back(new Cluster{0, 0, 22.2});
    event->Insert<Cluster>(test_data, "overridden_input");

    auto results = event->Get<Cluster>("default_clusters");
    REQUIRE(results.size() == 1);
    REQUIRE(results.at(0)->E == 23.2);

}

static constexpr std::string_view facgen_partial_output_names_only = R"(
    [[wiring]]
    action = "update"
    type_name = "WiredFac"
    prefix = "wiredfac"
    output_names = ["overridden_output"]
)";

TEST_CASE("WiringTests_Partial_OutputNamesOnly") {

    JApplication app;

    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(facgen_partial_output_names_only);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    auto gen = new JFactoryGeneratorT<WiredFac>;
    app.Add(gen);
    app.Initialize();

    auto event = std::make_shared<JEvent>(&app);
    std::vector<Cluster*> test_data;
    test_data.push_back(new Cluster{0, 0, 22.2});
    event->Insert<Cluster>(test_data, "default_protos");

    auto results = event->Get<Cluster>("overridden_output");
    REQUIRE(results.size() == 1);
    REQUIRE(results.at(0)->E == 23.2);

}

static constexpr std::string_view plugins_yaml = R"(
    plugins = ["JTest"]
)";

TEST_CASE("WiringTests_PluginLoading") {

    JApplication app;
    app.SetParameterValue("jana:nevents", 3);
    auto wiring_svc = app.GetService<jana::services::JWiringService>();
    toml::table table = toml::parse(plugins_yaml);
    wiring_svc->ApplyWiringSet(wiring_svc->ParseWiringSet(table));

    app.Run();
    REQUIRE(app.GetNEventsProcessed() == 3);
}



