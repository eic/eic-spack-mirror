
// Copyright 2023, Jefferson Science Associates, LLC.
// Subject to the terms in the LICENSE file found in the top-level directory.

#include <JANA/JFactory.h>
#include <JANA/JEvent.h>
#include <JANA/JEventSource.h>
#include <JANA/Utils/JTypeInfo.h>


class FlagGuard {
    bool* m_flag;
public:
    FlagGuard(bool* flag) : m_flag(flag) {
        *m_flag = true;
    }
    ~FlagGuard() {
        *m_flag = false;
    }
};

void JFactory::Create(const std::shared_ptr<const JEvent>& event) {
    Create(*event.get());
}

void JFactory::Create(const JEvent& event) {

    if (mInsideCreate && (mStatus != Status::Inserted)) {
        // Ideally, we disallow any calls to Create() that end up calling it right back. However, we do allow
        // calls that go down to GetObjects, who inserts the data, but then RETRIEVES the same data it just inserted,
        // so that it can subsequently calculate and insert OTHER data. Once we refactor JEventSourceEVIOpp, we can consider
        // removing this weird edge case.
        throw JException("Encountered a cycle in the factory dependency graph! Hint: Maybe this data was supposed to be inserted in the JEventSource");
    }
    FlagGuard insideCreateFlagGuard (&mInsideCreate); // No matter how we exit from Create() (particularly with exceptions) mInsideCreate will be set back to false

    if (m_app == nullptr && event.GetJApplication() != nullptr) {
        // These are usually set by JFactoryGeneratorT, but some user code has custom JFactoryGenerators which don't!
        // The design of JFactoryGenerator doesn't give us a better place to inject things
        m_app = event.GetJApplication();
        m_logger = m_app->GetJParameterManager()->GetLogger(GetLoggerName());
    }

    // How do we obtain our data? The priority is as follows:
    // 1. JFactory::Process() if REGENERATE flag is set
    // 2. JEvent::Insert()
    // 3. JEventSource::GetObjects() if source has GetObjects() enabled
    // 4. JFactory::Process()

    // ---------------------------------------------------------------------
    // 1. JFactory::Process() if REGENERATE flag is set
    // ---------------------------------------------------------------------

    if (mRegenerate) {
        if (mStatus == Status::Inserted) {
            // Status::Inserted indicates that the data came from either src->GetObjects() or evt->Insert()
            ClearData(); 
            // ClearData() resets mStatus to Unprocessed so that the data will be regenerated exactly once.
        }
        // After this point, control flow falls through to "4. JFactory::Process"
    }
    else {

        // ---------------------------------------------------------------------
        // 2. JEvent::Insert()
        // ---------------------------------------------------------------------

        if (mStatus == Status::Inserted) {
            // This may include data cached from eventsource->GetObjects().
            // Either way, short-circuit here, because the data is present.
            return;
        }

        // ---------------------------------------------------------------------
        // 3. JEventSource::GetObjects() if source has GetObjects() enabled
        // ---------------------------------------------------------------------

        auto src = event.GetJEventSource();
        if (src != nullptr && src->IsGetObjectsEnabled()) {
            bool found_data = false;

            CallWithJExceptionWrapper("JEventSource::GetObjects", [&](){ 
                found_data = src->GetObjects(event.shared_from_this(), this); });

            if (found_data) {
                mStatus = Status::Inserted;
                return;
            }
        }
        // If neither "2. JEvent::Insert()" nor "3. JEventSource::GetObjects()" succeeded, fall through to "4. JFactory::Process()"
    }

    // ---------------------------------------------------------------------
    // 4. JFactory::Process()
    // ---------------------------------------------------------------------

    // Check if init had _previously_ excepted but the cache was since cleared
    if (mInitStatus == InitStatus::InitExcepted && mStatus == Status::Empty) {
        for (auto* output : GetOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
        }
        for (auto* output : GetVariadicOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
        }
        mStatus = Status::Excepted;
        std::rethrow_exception(mException);
    }

    // Make sure Init() ran, which might except...
    try {
        DoInit(); // This checks mInitStatus internally before calling Init()
    }
    catch(...) {
        // If Init() excepts, we still need to store an empty collection
        mStatus = Status::Excepted;
        for (auto* output : GetOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
        }
        for (auto* output : GetVariadicOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
        }
        std::rethrow_exception(mException);
    }

    // At this point, Init() has run and has _not_ excepted

    if (mStatus == Status::Excepted) {
        // But Process() might have already excepted!
        std::rethrow_exception(mException);
    }
    else if (mStatus == Status::Empty) {
        // Now we know that we need to run Process() to create the data in the first place
        try {
            auto run_number = event.GetRunNumber();
            if (mPreviousRunNumber != run_number) {
                if (m_callback_style == CallbackStyle::LegacyMode) {
                    if (mPreviousRunNumber != -1) {
                        CallWithJExceptionWrapper("JFactory::EndRun", [&](){ EndRun(); });
                    }
                    CallWithJExceptionWrapper("JFactory::ChangeRun", [&](){ ChangeRun(event.shared_from_this()); });
                    CallWithJExceptionWrapper("JFactory::BeginRun", [&](){ BeginRun(event.shared_from_this()); });
                }
                else if (m_callback_style == CallbackStyle::ExpertMode) {
                    CallWithJExceptionWrapper("JFactory::ChangeRun", [&](){ ChangeRun(event); });
                }
                mPreviousRunNumber = run_number;
            }
            for (auto* input : GetInputs()) {
                input->Populate(event);
            }
            for (auto* input : GetVariadicInputs()) {
                input->Populate(event);
            }
            if (m_callback_style == CallbackStyle::LegacyMode) {
                CallWithJExceptionWrapper("JFactory::Process", [&](){ Process(event.shared_from_this()); });
            }
            else if (m_callback_style == CallbackStyle::ExpertMode) {
                CallWithJExceptionWrapper("JFactory::Process", [&](){ Process(event); });
            }
            else {
                throw JException("Invalid callback style");
            }
        }
        catch (...) {
            // Save everything already created even if we throw an exception
            // This is so that we leave everything in a valid state just in case someone tries to catch the exception recover,
            // such as EICrecon. (Remember that a missing collection in the podio frame will segfault if anyone tries to write that frame)
            // Note that the collections themselves won't know that they exited early

            LOG << "Exception in JFactory::Create, prefix=" << GetPrefix();
            mStatus = Status::Excepted;
            mException = std::current_exception();
            for (auto* output : GetOutputs()) {
                output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
            }
            for (auto* output : GetVariadicOutputs()) {
                output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Excepted);
            }
            throw;
        }

        // Save the (successfully processed) data
        mStatus = Status::Processed;
        for (auto* output : GetOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Created);
        }
        for (auto* output : GetVariadicOutputs()) {
            output->LagrangianStore(*event.GetFactorySet(), JDatabundle::Status::Created);
        }
    }
}

void JFactory::DoInit() {
    if (mInitStatus != InitStatus::InitNotRun) {
        return;
    }
    for (auto* parameter : m_parameters) {
        parameter->Init(*(m_app->GetJParameterManager()), m_prefix);
    }
    for (auto* service : m_services) {
        service->Fetch(m_app);
    }
    try {
        CallWithJExceptionWrapper("JFactory::Init", [&](){ Init(); });
        mInitStatus = InitStatus::InitRun;
    }
    catch (...) {
        mInitStatus = InitStatus::InitExcepted;
        mException = std::current_exception();
        throw;
    }
}

void JFactory::DoFinish() {
    if (mInitStatus == InitStatus::InitRun) {
        if (mPreviousRunNumber != -1) {
            CallWithJExceptionWrapper("JFactory::EndRun", [&](){ EndRun(); });
        }
        CallWithJExceptionWrapper("JFactory::Finish", [&](){ Finish(); });
    }
}

void JFactory::Summarize(JComponentSummary& summary) const {

    auto fs = new JComponentSummary::Component(
            "Factory",
            GetPrefix(),
            GetTypeName(),
            GetLevel(),
            GetPluginName());

    SummarizeInputs(*fs);
    SummarizeOutputs(*fs);
    summary.Add(fs);
}


