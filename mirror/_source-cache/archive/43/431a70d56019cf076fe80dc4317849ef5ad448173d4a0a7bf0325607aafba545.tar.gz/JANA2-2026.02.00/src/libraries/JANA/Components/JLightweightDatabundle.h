
#pragma once

#include <JANA/Components/JDatabundle.h>
#include <JANA/JObject.h> 
#include <JANA/Utils/JTypeInfo.h>
#include <typeindex>

#if JANA2_HAVE_ROOT
#include <TObject.h>
#endif

template <typename T>
class JLightweightDatabundleT : public JDatabundle {
private:
    std::vector<T*>* m_data = nullptr;
    bool m_owns_data = false;
    bool m_is_persistent = false;
    bool m_not_object_owner = false;

public:
    JLightweightDatabundleT(std::vector<T*>* external_data=nullptr);
    JLightweightDatabundleT(const JLightweightDatabundleT& other);
    ~JLightweightDatabundleT() override;

    void ClearData() override;

    size_t GetSize() const override { return m_data->size();}
    std::vector<T*>& GetData() { return *m_data; }

    void SetPersistentFlag(bool persistent) { m_is_persistent = persistent; }
    void SetNotOwnerFlag(bool not_owner) { m_not_object_owner = not_owner; }

    bool GetPersistentFlag() { return m_is_persistent; }
    bool GetNotOwnerFlag() { return m_not_object_owner; }

    /// EnableGetAs generates a vtable entry so that users may extract the
    /// contents of this JFactoryT from the type-erased JFactory. The user has to manually specify which upcasts
    /// to allow, and they have to do so for each instance. It is recommended to do so in the constructor.
    /// Note that EnableGetAs<T>() is called automatically.
    template <typename S> void EnableGetAs ();

    // The following specializations allow automatically adding standard types (e.g. JObject) using things like
    // std::is_convertible(). The std::true_type version defers to the standard EnableGetAs().
    template <typename S> void EnableGetAs(std::true_type) { EnableGetAs<S>(); }
    template <typename S> void EnableGetAs(std::false_type) {}
};

// Template definitions

template <typename T>
JLightweightDatabundleT<T>::JLightweightDatabundleT(std::vector<T*>* external_data) {
    if (external_data != nullptr) {
        m_data = external_data;
        m_owns_data = false;
    }
    else {
        m_data = new std::vector<T*>;
        m_owns_data = true;
    }

    SetTypeName(JTypeInfo::demangle<T>());
    SetTypeIndex(std::type_index(typeid(T)));
    EnableGetAs<T>();
    EnableGetAs<JObject>( std::is_convertible<T,JObject>() ); // Automatically add JObject if this can be converted to it
#if JANA2_HAVE_ROOT
    EnableGetAs<TObject>( std::is_convertible<T,TObject>() ); // Automatically add TObject if this can be converted to it
#endif
}

template <typename T>
JLightweightDatabundleT<T>::JLightweightDatabundleT(const JLightweightDatabundleT& other) : JDatabundle(other) {

    m_data = new std::vector<T*>;
    m_owns_data = true;

    m_is_persistent = other.m_is_persistent;
    m_not_object_owner = other.m_not_object_owner;

    // TODO: This doesn't copy over any additional EnableGetAs()
    EnableGetAs<T>();
    EnableGetAs<JObject>( std::is_convertible<T,JObject>() ); // Automatically add JObject if this can be converted to it
#if JANA2_HAVE_ROOT
    EnableGetAs<TObject>( std::is_convertible<T,TObject>() ); // Automatically add TObject if this can be converted to it
#endif
}

template <typename T>
JLightweightDatabundleT<T>::~JLightweightDatabundleT() {
    if (m_owns_data) {
        delete m_data;
    }
}

template <typename T>
void JLightweightDatabundleT<T>::ClearData() {

    // ClearData() does nothing if persistent flag is set.
    // User must manually recycle data, e.g. during ChangeRun()
    if (GetPersistentFlag()) {
        return;
    }

    // Assuming we _are_ the object owner, delete the underlying jobjects
    if (!GetNotOwnerFlag()) {
        for (auto p : *m_data) delete p;
    }
    m_data->clear();
    SetStatus(Status::Empty);
}

template<typename T>
template<typename S>
void JLightweightDatabundleT<T>::EnableGetAs() {

    auto upcast_lambda = [this]() {
        std::vector<S*> results;
        for (auto t : *m_data) {
            results.push_back(static_cast<S*>(t));
        }
        return results;
    };

    auto key = std::type_index(typeid(S));
    using upcast_fn_t = std::function<std::vector<S*>()>;
    (*m_upcast_fns)[key] = std::unique_ptr<JAny>(new JAnyT<upcast_fn_t>(std::move(upcast_lambda)));
}





