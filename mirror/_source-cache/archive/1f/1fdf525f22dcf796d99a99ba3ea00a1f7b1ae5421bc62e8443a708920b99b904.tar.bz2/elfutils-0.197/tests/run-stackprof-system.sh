#!/usr/bin/env bash
#
# Copyright (C) 2026 Red Hat, Inc.
# This file is part of elfutils.
#
# This file is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# elfutils is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $srcdir/stackprof-subr.sh

set -x
unset VALGRIND_CMD

# prerequisites
type timeout 2>/dev/null || (echo "no timeout installed"; exit 77)
check_perf_event_open || (echo "perf_event_open fails (check kernel.perf_event_paranoid + kernel config)"; exit 77)
expr `whoami` = "root" || (echo "not running as root"; exit 77)

tempfiles test.out

# guarantee background load on idle systems (cleaned up on exit)
testjob_launch

# run systemwide scan, no gprof output
testrun timeout -p --kill-after=5 10 ${abs_top_builddir}/src/stackprof -v 2>&1 | tee test.out
grep "^perf_event_attr configuration" test.out
grep "Starting stack profile collection systemwide" test.out || (grep "ERROR: Unsupported architecture" test.out && echo "unsupported arch" && exit 77)
grep -E "^[0-9]+ " test.out # -- pid / sample counts entries

# run systemwide scan again, with gprof output
# reduce verbosity, bump post-processing timeout compared to the first run
testrun timeout -p --kill-after=10 15 ${abs_top_builddir}/src/stackprof -g 2>&1 | tee test.out
tempfiles gmon.*
grep "^perf_event_attr configuration" test.out
grep "Starting stack profile collection systemwide" test.out
grep -E "^buildid [0-9a-f]+" test.out

exit 0
