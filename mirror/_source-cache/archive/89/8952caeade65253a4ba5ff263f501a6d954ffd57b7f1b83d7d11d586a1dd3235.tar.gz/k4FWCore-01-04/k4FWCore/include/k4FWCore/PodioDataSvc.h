/*
 * Copyright (c) 2014-2024 Key4hep-Project.
 *
 * This file is part of Key4hep.
 * See https://key4hep.github.io/key4hep-doc/ for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef FWCORE_PODIODATASVC_H
#define FWCORE_PODIODATASVC_H

#include "GaudiKernel/DataSvc.h"
#include "GaudiKernel/IConversionSvc.h"
// PODIO
#include "podio/CollectionBase.h"
#include "podio/CollectionIDTable.h"
#include "podio/Frame.h"
#include "podio/ROOTReader.h"
#include <utility>
// Forward declarations
#include "k4FWCore/DataWrapper.h"
class DataWrapperBase;
class PodioOutput;
namespace k4FWCore {
template <typename T>
class MetaDataHandle;
}

/** @class PodioEvtSvc EvtDataSvc.h
 *
 *   An EvtDataSvc for PODIO classes
 *
 *  @author B. Hegner
 */
class [[deprecated("Use the IOSvc instead")]] PodioDataSvc : public DataSvc {
  template <typename T>
  friend class k4FWCore::MetaDataHandle;
  friend class PodioOutput;
  friend class Lcio2EDM4hepTool;

public:
  typedef std::vector<std::pair<std::string, podio::CollectionBase*>> CollRegistry;

  StatusCode initialize() final;
  StatusCode reinitialize() final;
  StatusCode finalize() final;
  StatusCode clearStore() final;
  StatusCode i_setRoot(std::string root_path, IOpaqueAddress* pRootAddr) final;
  StatusCode i_setRoot(std::string root_path, DataObject* pRootObj) final;

  /// Standard Constructor
  PodioDataSvc(const std::string& name, ISvcLocator* svc);

  // Use DataSvc functionality except where we override
  using DataSvc::registerObject;
  /// Overriding standard behaviour of evt service
  /// Register object with the data store.
  StatusCode registerObject(std::string_view parentPath, std::string_view fullPath, DataObject* pObject) final;

  const std::string_view getCollectionType(const std::string& collName);

  template <typename T>
  StatusCode readCollection(const std::string& collName) {
    DataObject* objectPtr = nullptr;
    if (DataSvc::findObject("/Event", "/" + collName, objectPtr)) {
      debug() << "Collection " << collName << " already read, not reading it again" << endmsg;
      return StatusCode::SUCCESS;
    }
    const T* collection(nullptr);
    collection = static_cast<const T*>(m_eventframe.get(collName));
    if (collection == nullptr) {
      error() << "Collection " << collName << " does not exist." << endmsg;
    }
    auto wrapper = new DataWrapper<T>;
    wrapper->setData(collection);
    m_podio_datawrappers.push_back(wrapper);
    return DataSvc::registerObject("/Event", "/" + collName, wrapper);
  }

  const podio::Frame& getEventFrame() const { return m_eventframe; }

  /// Resets caches of reader and event store, increases event counter
  void endOfRead();

  /// TODO: Make this private again after conversions have been properly solved
  podio::Frame& getMetaDataFrame() { return m_metadataframe; }

  void setCollsToRead(const std::vector<std::string>& collsToRead) { m_collsToRead = collsToRead; }

private:
  /// PODIO reader for ROOT files
  podio::ROOTReader m_reader;
  /// PODIO Frame, used to initialise collections
  podio::Frame m_eventframe;
  /// PODIO Frame, used to store metadata
  podio::Frame m_metadataframe;
  /// Counter of the event number
  int m_eventNum{0};
  /// Number of events in the file / to process
  int m_numAvailableEvents{-1};
  int m_requestedEventMax{-1};
  /// Whether reading from file at all
  bool m_reading_from_file{false};

  SmartIF<IConversionSvc> m_cnvSvc;

  // Registry of data wrappers; needed for memory management
  std::vector<DataWrapperBase*> m_podio_datawrappers;
  /// The names of the collections to read (set externally)
  std::vector<std::string> m_collsToRead{};

protected:
  /// ROOT file name the input is read from. Set by option filename
  std::vector<std::string> m_filenames;
  std::string m_filename;
  /// Jump to nth events at the beginning. Set by option FirstEventEntry
  /// This option is helpful when we want to debug an event in the middle of a file
  unsigned m_1stEvtEntry{0};
  bool m_bounds_check_needed{true};
};
#endif // CORE_PODIODATASVC_H
