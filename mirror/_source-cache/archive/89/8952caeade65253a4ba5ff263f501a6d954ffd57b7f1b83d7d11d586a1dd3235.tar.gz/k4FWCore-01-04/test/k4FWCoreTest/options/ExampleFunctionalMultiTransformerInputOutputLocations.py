#
# Copyright (c) 2014-2024 Key4hep-Project.
#
# This file is part of Key4hep.
# See https://key4hep.github.io/key4hep-doc/ for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# This is an example using a transformer that takes and produces any number of collections

from Gaudi.Configuration import INFO
from Configurables import (
    ExampleFunctionalProducer,
    ExampleFunctionalMultiTransformerInputOutputLocations,
)
from k4FWCore import ApplicationMgr
from Configurables import EventDataSvc

producer0 = ExampleFunctionalProducer(
    "Producer0",
    OutputCollection="MCParticles0",
)
producer1 = ExampleFunctionalProducer(
    "Producer1",
    OutputCollection="MCParticles1",
)
producer2 = ExampleFunctionalProducer(
    "Producer2",
    OutputCollection="MCParticles2",
)
producer3 = ExampleFunctionalProducer(
    "Producer3",
    OutputCollection="MCParticles3",
)
producer4 = ExampleFunctionalProducer(
    "Producer4",
    OutputCollection="MCParticles4",
)
transformer = ExampleFunctionalMultiTransformerInputOutputLocations(
    "Transformer",
)

ApplicationMgr(
    TopAlg=[producer0, producer1, producer2, producer3, producer4, transformer],
    EvtSel="NONE",
    EvtMax=10,
    ExtSvc=[EventDataSvc("EventDataSvc")],
    OutputLevel=INFO,
)
